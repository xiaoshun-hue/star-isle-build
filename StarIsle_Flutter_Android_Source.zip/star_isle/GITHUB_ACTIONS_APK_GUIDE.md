# 用 GitHub Actions 免费打包「星屿」APK

> 适合只有手机、没有 Flutter/Android SDK 的情况。
> 构建在 GitHub 的 Linux 机器上完成，你只需要浏览器。

---

## 0. 你会得到什么

- 不需要在本地安装 Flutter、JDK、Android SDK
- 不需要把手机用 USB 连到电脑
- 构建产物是一个可安装的 `app-release.apk`
- 首次构建约 **10～25 分钟**
- 免费 GitHub 账号的私人仓库每月有 Actions 免费额度，个人测试足够

项目已经包含：

```text
star_isle/.github/workflows/build-apk.yml
```

这个 workflow 会：

1. 安装 JDK 17
2. 安装 Android SDK 35
3. 安装 Flutter 3.24.5
4. 解压源码 ZIP（如果仓库根目录有 ZIP）
5. 执行 `flutter pub get`
6. 执行 `flutter build apk --release`
7. 上传 APK 到 Actions Artifacts

---

## 1. 准备工作

需要：

- 一个 GitHub 账号：https://github.com
- 当前源码包：`StarIsle_Flutter_Android_Source.zip`
- 能访问 GitHub 的网络

不需要：

- 不需要 API Key
- 不需要 Android 手机连接电脑
- 不需要安装 Android Studio

> 建议仓库设为 **Private**。源码里没有 API Key，但私人仓库更稳妥。

---

## 2. 创建私有仓库

1. 登录 GitHub。
2. 右上角 `+` → `New repository`。
3. 填写：
   - Repository name：`star-isle-build`
   - 勾选 **Private**
   - 勾选 `Add a README file`（也可以不勾）
4. 点击 `Create repository`。

---

## 3. 上传源码 ZIP

1. 打开刚创建的仓库主页。
2. 点击 `Add file` → `Upload files`。
3. 选择 `StarIsle_Flutter_Android_Source.zip`。
4. 点击页面底部 `Commit changes`。
5. 等文件上传完成。

上传后仓库根目录应能看到：

```text
StarIsle_Flutter_Android_Source.zip
README.md
```

---

## 4. 添加打包 workflow

这是最关键的一步。

1. 仓库主页点击 `Add file` → `Create new file`。
2. 在文件名输入框中输入完整路径：

```text
.github/workflows/build-apk.yml
```

> 注意：必须包含 `.github/workflows/` 这些斜杠。
> 手机浏览器如果不好操作，可以切换到「桌面版网站」。

3. 把下面的 YAML 原样粘贴进编辑框：

```yaml
name: Build Star Isle APK

on:
  workflow_dispatch:

permissions:
  contents: read

jobs:
  build-apk:
    name: Flutter Release APK
    runs-on: ubuntu-latest
    timeout-minutes: 60

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Android SDK 35
        uses: android-actions/setup-android@v3
        with:
          packages: 'platform-tools platforms;android-35 build-tools;35.0.0'

      - name: Set up Flutter 3.24.5
        uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.24.5'
          channel: stable
          cache: true

      - name: Locate project and unzip source
        id: locate
        shell: bash
        run: |
          set -euo pipefail
          if [ -f "StarIsle_Flutter_Android_Source.zip" ]; then
            echo "Found source zip, extracting..."
            unzip -q -o "StarIsle_Flutter_Android_Source.zip" -d .
          fi

          PUBSPEC=$(find . -maxdepth 4 -name pubspec.yaml -not -path './.git/*' -print -quit)
          if [ -z "$PUBSPEC" ]; then
            echo "::error::pubspec.yaml not found. Upload StarIsle_Flutter_Android_Source.zip to the repository root."
            exit 1
          fi

          PROJECT_DIR=$(dirname "$PUBSPEC")
          echo "project_dir=$PROJECT_DIR" >> "$GITHUB_OUTPUT"
          echo "Using project directory: $PROJECT_DIR"

          if [ -f "$PROJECT_DIR/android/gradlew" ]; then
            chmod +x "$PROJECT_DIR/android/gradlew"
          fi

          # Compatibility: plugins resolved from pub may require compileSdk 35.
          sed -i 's/compileSdk = 34/compileSdk = 35/' "$PROJECT_DIR/android/app/build.gradle"
          sed -i '/postSplashScreenTheme/d' "$PROJECT_DIR/android/app/src/main/res/values-v31/styles.xml" "$PROJECT_DIR/android/app/src/main/res/values-night-v31/styles.xml"
          if ! grep -q 'suppressUnsupportedCompileSdk' "$PROJECT_DIR/android/gradle.properties"; then
            echo 'android.suppressUnsupportedCompileSdk=35' >> "$PROJECT_DIR/android/gradle.properties"
          fi

      - name: Resolve Flutter dependencies
        working-directory: ${{ steps.locate.outputs.project_dir }}
        run: |
          flutter config --no-analytics
          flutter pub get

      - name: Flutter doctor (diagnostics)
        run: flutter doctor -v || true

      - name: Build release APK
        working-directory: ${{ steps.locate.outputs.project_dir }}
        run: flutter build apk --release --no-pub

      - name: Upload APK artifact
        uses: actions/upload-artifact@v4
        with:
          name: StarIsle-release-apk
          path: ${{ steps.locate.outputs.project_dir }}/build/app/outputs/flutter-apk/app-release.apk
          if-no-files-found: error
          retention-days: 30

      - name: Build summary
        if: success()
        run: |
          {
            echo "## 星屿 APK 构建成功"
            echo ""
            echo "请在本次运行页面底部 **Artifacts** 下载 StarIsle-release-apk。"
            echo ""
            echo "> 此 APK 使用 CI 自动生成的 debug 签名，适合个人安装测试。若要长期覆盖更新，请配置固定 release keystore。"
          } >> "$GITHUB_STEP_SUMMARY"
```

4. 页面底部点击 `Commit changes`。
5. 提交到 `main` 分支。

---

## 5. 运行云端打包

1. 打开仓库顶部的 `Actions` 标签。
2. 左侧选择 `Build Star Isle APK`。
3. 右侧点击 `Run workflow`。
4. 分支选择 `main`，再点绿色 `Run workflow`。
5. 刷新页面，会看到一条黄色/绿色状态记录。

等待 10～25 分钟，首次构建会下载 Gradle 和依赖，所以稍慢。

---

## 6. 下载 APK

构建成功后：

1. 点击最新一次运行记录（绿色对勾）。
2. 向下滚动到页面底部的 `Artifacts`。
3. 点击 `StarIsle-release-apk`。
4. 浏览器会下载一个 ZIP：`StarIsle-release-apk.zip`。
5. 解压 ZIP，得到：

```text
app-release.apk
```

6. 把 APK 传到 Android 手机。
7. 点击 APK 安装，允许「安装未知来源应用」。

> GitHub 的 Artifact 下载的是 ZIP，不是 APK，需要解压一层。

---

## 7. 安装后配置

应用名称：**星屿**

首次打开：

1. 按 3 步引导设置你的称呼、AI 名称、头像和性格。
2. 想先用离线模式：直接选择「单机陪伴」。
3. 想联网：需要 DeepSeek API Key，在「我们 → AI 与网络」里填写并测试连接。

不要在 GitHub 仓库里填写 API Key。
API Key 只在安装后的 App 设置里输入，保存在手机本地。

---

## 8. 构建失败怎么办

打开失败的运行记录 → 点击 `build-apk` Job → 展开红色失败步骤，查看最后 20～30 行日志。

### 常见错误

#### `pubspec.yaml not found`
- 源码 ZIP 没有上传到仓库根目录
- 文件名必须正好是 `StarIsle_Flutter_Android_Source.zip`
- 或者 ZIP 内的顶层目录结构被修改了

#### `No workflow runs` / 没有 `Run workflow` 按钮
- workflow 文件路径必须正好是 `.github/workflows/build-apk.yml`
- 文件必须在默认分支 `main`
- 仓库 `Settings → Actions → General` 中允许 Actions

#### Gradle 下载失败 / 构建超时
- 这是 GitHub runner 网络偶发问题，重新运行一次
- 不需要改代码

#### Java / SDK 相关错误
- workflow 已固定 JDK 17 和 Android SDK 35
- 重新运行前点右上角 `Re-run all jobs`

#### 构建成功但没有 APK
- 展开 `Upload APK artifact` 步骤看错误
- 确认构建输出路径没有被改动

### 把错误发给我时

请附上：

- 失败步骤的红色日志截图
- 仓库是 Private 还是 Public
- 运行编号（例如 `#1`）

---

## 9. 重要：签名与后续更新

这个 workflow 得到的是 **debug 签名的 Release APK**，第一次安装和使用没有问题。

但如果你以后重新运行 GitHub Actions 再安装新版本：

- CI 环境每次都是新的；
- debug 签名不保证每次都相同；
- 签名不同时，Android 会拒绝覆盖安装；
- 若卸载旧版再装新版，本地数据库和聊天记录会丢失。

如果你打算长期使用并持续更新，应该配置固定的 release keystore。后续可以让 workflow 从 GitHub Secrets 读取 keystore，实现每次构建签名一致。

**现在先完成第一次安装和体验即可；需要长期更新时再配置固定签名。**

---

## 10. 隐私提醒

- 不要把 DeepSeek API Key 写进代码、README、Issues 或 workflow。
- 建议仓库设为 Private。
- GitHub Actions 构建的是源码，不包含你的聊天数据；聊天数据只在安装后的手机本地。
- 测试完成后，如果不再需要 Actions 构建，可以删除 workflow 或仓库。

---

## 11. 可选：更简单的方式

如果你能在电脑（哪怕是网吧/图书馆电脑）上打开浏览器，但不想安装 Flutter：

1. 在电脑上解压源码 ZIP；
2. 在 GitHub 新建私有仓库；
3. 把解压后的项目**内容**上传到仓库根目录；
4. `.github/workflows/build-apk.yml` 会一并上传；
5. 直接进入 Actions 运行 `Build Star Isle APK`。

这比“在网吧安装 Android SDK”简单得多，因为只需要浏览器上传文件，不需要管理员权限。
