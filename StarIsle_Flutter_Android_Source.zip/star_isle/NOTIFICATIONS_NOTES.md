# 星屿 · 系统通知（第一阶段）

## 已实现

- Android 本地通知，不依赖第三方通知插件
- 原生 MethodChannel：`com.starisle.companion/notifications`
- Android 13+ `POST_NOTIFICATIONS` 运行时权限
- 通知渠道：`star_isle_messages` / 「晚晚的消息」
- 点击通知打开 App，并自动切回「消息」页
- 点击后清除该通知，并标记聊天已读
- 设置 → 人格与主动陪伴 → 「系统通知」开关
- 默认关闭；在设置中手动开启后才请求系统通知权限

## 触发时机

只有满足以下条件才发通知：

1. `settings.notificationsEnabled == true`
2. 系统通知权限已允许
3. 当前不在「消息页且 App 前台」

覆盖：

- 她的主动私聊
- 你在其他页面/后台时她对你消息的回复
- 纪念日提醒

不会通知：

- 你正在聊天页看她回复
- 系统消息、动态、相册更新

## 原生端

| 文件 | 作用 |
|---|---|
| `android/app/src/main/kotlin/com/starisle/companion/MainActivity.kt` | MethodChannel、权限、通知、点击回传 |
| `android/app/src/main/AndroidManifest.xml` | `POST_NOTIFICATIONS` 权限 |
| `android/app/src/main/res/drawable/ic_stat_star_isle.xml` | 通知栏白色小图标 |

Dart 桥接：

- `lib/services/notification_service.dart`
- `SettingsController.notificationsEnabled`
- `CompanionController._notifyIfAway()`
- `HomeShell` 监听点击并切换聊天页

## 重要限制

这是第一阶段本地通知：

- App 进程仍在运行时有效，包括短时间后台/锁屏
- App 被系统杀掉、强制停止或设备重启后，Dart 定时器不会继续运行
- 因此**不能保证** App 完全关闭时准时收到
- 如需“杀掉后也能收到”，下一阶段需要 WorkManager / AlarmManager 或服务端推送

## 默认行为

- `notificationsEnabled` 默认 `false`
- 在设置中打开「系统通知」时会弹出 Android 13+ 通知权限请求
- 用户拒绝不会崩溃，也不会影响聊天
- 可在设置中关闭；关闭时会取消现有通知
- 关闭后主动消息仍会进入 App 内聊天，只是不弹系统通知

## 测试

1. 安装新 APK，到设置打开「系统通知」，允许通知权限
2. 确认开关为开启
3. 把 App 切到后台或锁屏
4. 等待主动消息，或在设置里点「让她现在说一句」
5. 通知栏应出现「晚晚」的消息
6. 点击通知应回到消息页
7. 关闭开关后重复，应该不再出现通知
