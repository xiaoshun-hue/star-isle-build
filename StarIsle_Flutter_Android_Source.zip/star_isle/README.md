# 星屿 · Star Isle

> 一座只住着你和她的私人小岛。单人专属 AI 陪伴 Android App。
>
> Flutter + SQLite + DeepSeek（可选）+ 本地陪伴引擎 · 无注册 / 无登录 / 数据只在本机。

---

## 1. 项目概览

| 项目 | 值 |
| --- | --- |
| 应用名 | 星屿 |
| 应用包名 | `com.starisle.companion` |
| 技术栈 | Flutter 3.24+ / Dart 3.5+ / Provider / SQLite / SharedPreferences |
| 最低系统 | Android 6.0（API 23） |
| 推荐系统 | Android 10+ |
| 联网能力 | DeepSeek Chat API（可选，自备 API Key） |
| 离线能力 | 本地人格引擎、长期记忆、主动消息、纪念日提醒、程序化配图 |
| 账号系统 | 无 |
| 云端同步 | 无 |
| 默认 AI 名 | 晚晚（首次启动可改） |
| 默认用户称呼 | 阿屿（首次启动可改） |

### 核心能力

- **私聊**
  - 文字、表情、表情包、图片消息
  - 真人打字节奏、分段气泡、已读/时间、消息长按操作
  - 长期记忆注入、情绪与好感状态、固定人设、可编辑语气
  - AI 主动发来私聊；应用回到前台时自动补上错过的时间点
- **AI 角色资料**
  - 程序化渐变头像，可随 AI 自主成长自动更换
  - 自动更新昵称与个性签名（默认昵称池内轮换；用户自定义名字不会被擅自改掉）
  - 角色主页：人设、关系阶段、心动值、记忆、最近变化
- **动态广场**
  - AI 自动生成文案 + 本地程序化配图，像朋友圈一样发布
  - 点赞、AI 点赞、评论区互动、AI 在评论区回复
  - 用户也可以发布自己的动态（照片或自动画卡）
- **相册**
  - 自动收集聊天图片、动态配图
  - 从手机相册导入、分类筛选、全屏查看、移除
- **纪念日 / 备忘**
  - 新增 / 编辑 / 删除、每年重复、提前提醒天数
  - AI 可通过聊天自动写入日期，并主动发私聊提醒
- **语音**
  - 系统中文 TTS 朗读 AI 消息
  - 自动朗读开关 + 单条消息朗读
- **皮肤**
  - 5 套完整视觉皮肤：暮光海 / 雾玫瑰 / 薄荷岛 / 琥珀黄昏 / 夜樱紫
  - 每套都有深色与浅色版本
  - 浅色 / 深色 / 跟随系统，立即切换并持久化
- **动画与交互**
  - 启动动画、环境极光、进入动画、消息气泡动画、点赞心动动画
  - 打字三点动画、页面滑动/淡入过渡、玻璃拟态卡片、触感反馈

---

## 2. 目录结构

```text
star_isle/
├── pubspec.yaml                     # 依赖与项目元信息
├── analysis_options.yaml
├── README.md
├── android/
│   ├── build.gradle
│   ├── settings.gradle
│   ├── gradle.properties
│   ├── gradlew / gradlew.bat
│   ├── gradle/wrapper/
│   │   ├── gradle-wrapper.jar
│   │   └── gradle-wrapper.properties
│   └── app/
│       ├── build.gradle
│       └── src/main/
│           ├── AndroidManifest.xml
│           ├── kotlin/com/starisle/companion/MainActivity.kt
│           └── res/                 # 启动页、自适应图标、主题资源
└── lib/
    ├── main.dart                    # 初始化 DB / Provider / TTS / 系统 UI
    ├── app.dart                     # MaterialApp、语言、皮肤、转场
    ├── core/
    │   ├── theme/                   # 颜色语义、5 套皮肤、ThemeData
    │   ├── navigation/              # 页面切换动画
    │   ├── utils/                   # 中文日期、ID、触感
    │   └── widgets/                 # 极光、玻璃卡片、头像、气泡、通用按钮
    ├── data/
    │   ├── app_database.dart        # SQLite 建表
    │   ├── app_repository.dart      # 所有 DAO
    │   └── models/
    │       ├── chat_message.dart
    │       ├── companion_profile.dart
    │       ├── memory_entry.dart
    │       ├── moment_entry.dart
    │       ├── anniversary_entry.dart
    │       └── album_entry.dart
    ├── services/
    │   ├── ai/
    │   │   ├── ai_service.dart      # 在线/离线编排、JSON 解析、提示词
    │   │   ├── deepseek_client.dart # DeepSeek HTTP 客户端
    │   │   ├── local_persona_engine.dart
    │   │   ├── memory_extractor.dart
    │   │   └── ai_types.dart
    │   ├── art_service.dart         # 本地程序化画卡（Canvas → PNG）
    │   ├── media_service.dart       # 相册、图片持久化
    │   └── tts_service.dart         # flutter_tts 封装
    ├── state/
    │   ├── settings_controller.dart
    │   ├── companion_controller.dart# 聊天、记忆、主动消息、资料成长
    │   ├── moments_controller.dart  # 动态、配图、评论、自动发帖
    │   ├── anniversary_controller.dart
    │   └── album_controller.dart
    └── ui/screens/
        ├── splash/                  # 启动动画
        ├── onboarding/              # 3 步首次设置
        ├── home/                    # 5 标签主容器 + 自定义底栏
        ├── chat/                    # 私聊页、气泡、输入栏
        ├── moments/                 # 动态广场、详情、发布
        ├── anniversary/             # 纪念日与编辑器
        ├── album/                   # 相册与全屏查看
        └── profile/ + settings/     # 我们、角色主页、记忆、主题、网络、人格、关于
```

---

## 3. API 与数据流

```text
用户输入
  ├─ 离线模式 → LocalPersonaEngine
  │    意图识别 / 情绪状态 / 记忆检索 / 人设语气 / 本地文案
  └─ 联网模式 → AiService → DeepSeekClient → DeepSeek Chat API
       失败时自动回退到 LocalPersonaEngine

AI 结果
  → 多气泡 + 打字延迟
  → 写入 SQLite
  → 更新好感度 / 心情 / 长期记忆
  → 可选：自动更新资料、写入纪念日、生成本地画卡
  → UI 消息动画 / 可选 TTS 朗读
```

- 所有对话、动态、照片路径、记忆、纪念日都保存在本机私有目录。
- 联网时只发送：人设、当前关系状态、最近的对话、记忆摘要和当前任务提示词。
- 不发送聊天图片的二进制内容；DeepSeek 文本模型也看不到图片，AI 会诚实邀请用户讲述。
- API Key 保存在应用私有 `SharedPreferences` 中。它不会上传到星屿服务器——本项目没有中转服务器。

### 关于“本地离线 AI”

单机模式不下载大模型，也不在后台偷偷连接服务器。它使用：

1. 意图分类（问候、亲密、低落、工作、饮食、纪念日、照片请求等）
2. 情绪与好感状态机
3. 本地长期记忆检索（二元词重合度）
4. 人设、语气、时间段与上文的组合生成
5. 安全兜底（自伤风险时引导联系现实中的帮助）

这是一个轻量、可控、完全离线的陪伴推理引擎，**不是通用大语言模型**。因此它不会像 DeepSeek 那样回答任意百科问题；优点是安装包小、无需网络、隐私完整。如果你需要“完整本地大模型”，需要额外集成 llama.cpp / MNN / ONNX Runtime 并打包 1–4GB 模型；本项目未内置这类模型。

### 关于 AI 配图

DeepSeek API 目前是文本模型。星屿的动态配图和“AI 自拍/画卡”由 `ArtService` 在本地用 Canvas 生成：
- 根据文案、种子和色板生成原创抽象氛围画
- 输出真实 PNG，保存进相册
- 不伪装成真实照片；聊天中明确说明是画卡

用户也可以从手机相册发送真实照片。

---

## 4. 从零安装环境并打包 APK

> 当前目录是完整 Flutter 项目源码（不含 `build/` 产物，也不含 API Key）。
> 受当前执行环境限制（Android/Termux，无 Flutter SDK 与 Android SDK），未在本机直接产出 APK；以下步骤可在装有 Flutter 的电脑上直接生成。

### 4.1 推荐工具链

- **Flutter 3.24.5 stable**（Dart 3.5.4）——项目已按这个版本编写；使用更新的 Flutter 时若遇到 Gradle/compileSdk 提示，可按 4.7 节调整。
- **JDK 17**
- **Android SDK Platform 35 + Build-Tools 35.0.0**
- Android 手机一台（Android 6.0+），开启“开发者选项 → USB 调试”
- 网络（首次构建会下载 Gradle、依赖和 Android 构建工具）

### 4.2 安装 Flutter（Windows / macOS / Linux 通用）

1. 下载 Flutter 3.24.5：
   - 官方页面：https://docs.flutter.dev/release/archive
2. 解压后把 `flutter/bin` 加入 PATH。
3. 安装 Android Studio（含 Android SDK、Platform Tools）。
4. 打开终端：

```bash
flutter --version
flutter doctor -v
flutter doctor --android-licenses
```

需要做到 `flutter doctor` 中 Flutter、Android toolchain、Connected device 基本可用。

> 如果系统默认 JDK 不是 17，在 Android Studio：
> `Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle JDK` 选择 JDK 17。
> 命令行也可以设置 `JAVA_HOME` 指向 JDK 17。

### 4.3 获取依赖

```bash
cd star_isle
# macOS/Linux 从 ZIP 解压后，如果 Gradle Wrapper 没有执行权限：
chmod +x android/gradlew

flutter pub get
flutter analyze
```

### 4.4 连手机调试

```bash
adb devices
flutter run
```

第一次运行会请求照片访问；语音朗读依赖手机系统自带的中文 TTS 引擎（如“语音服务”“Google 文字转语音”）。

### 4.5 生成可直接安装的 Release APK

项目默认已经支持**没有正式 keystore 时使用 debug 签名构建可安装 APK**：

```bash
cd star_isle
flutter clean
flutter pub get
flutter build apk --release
```

产物：

```text
build/app/outputs/flutter-apk/app-release.apk
```

安装：

```bash
adb install -r build/app/outputs/flutter-apk/app-release.apk
```

也可以把 APK 复制到手机，点击安装，需允许“安装未知来源应用”。

如果只装 ARM64 手机会更小：

```bash
flutter build apk --release --target-platform android-arm64
```

按 CPU 架构拆分生成多个 APK：

```bash
flutter build apk --split-per-abi
# 产物：
# build/app/outputs/flutter-apk/app-armeabi-v7a-release.apk
# build/app/outputs/flutter-apk/app-arm64-v8a-release.apk
# build/app/outputs/flutter-apk/app-x86_64-release.apk
```

生成上架用的 App Bundle（可选）：

```bash
flutter build appbundle --release
# build/app/outputs/bundle/release/app-release.aab
```

### 4.6 配置正式签名（长期使用 / 应用商店建议）

没有正式签名时，Release APK 使用 debug keystore，仍可安装，但不适合长期更新和上架。正式签名流程：

**Step 1：生成 keystore**

```bash
keytool -genkeypair \
  -v \
  -keystore star-isle-release.jks \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -alias starisle
```

**Step 2：在 `android/key.properties` 写入**（该文件已被 `.gitignore` 忽略）

```properties
storePassword=你的store密码
keyPassword=你的key密码
keyAlias=starisle
storeFile=/绝对路径/star-isle-release.jks
```

Windows 示例：

```properties
storeFile=C:\\Users\\you\\keys\\star-isle-release.jks
```

`android/app/build.gradle` 已经内置读取逻辑：检测到 `key.properties` 时自动使用正式签名，否则回退到 debug 签名。

**Step 3：重新构建**

```bash
flutter clean
flutter pub get
flutter build apk --release
```

请妥善备份 `.jks` 和密码。丢失后将无法对已发布应用进行覆盖更新。

### 4.7 使用更新版本 Flutter 的兼容调整

项目当前固定在：

- Gradle 8.4
- Android Gradle Plugin 8.3.2
- Kotlin 1.9.22
- compileSdk 35 / targetSdk 34

如果你使用 2025/2026 年更新的 Flutter，并且构建提示 AGP/compileSdk 不兼容，可以：

- **优先推荐**：安装并使用 Flutter 3.24.5 构建本项目。
- 或按 Flutter 报错提示升级：
  - `android/settings.gradle` 中的 AGP / Kotlin 版本
  - `android/gradle/wrapper/gradle-wrapper.properties` 的 Gradle 版本
  - `android/app/build.gradle` 的 `compileSdk` / `targetSdk`
- 升级前保留可回退的提交或另存一份项目。

### 4.8 国内网络下载慢

如果 Gradle 发行包下载慢，可以编辑：

`android/gradle/wrapper/gradle-wrapper.properties`

把：

```properties
distributionUrl=https\://services.gradle.org/distributions/gradle-8.4-bin.zip
```

换成可访问的 Gradle 8.4 镜像地址。Android 依赖由 Google Maven / Maven Central 提供，请确保网络可访问 `dl.google.com`、`repo.maven.apache.org`。

---

## 5. 首次启动与 DeepSeek 配置

1. 打开星屿，跟随 3 步引导设置称呼、角色名、头像与说话方式。
2. 选择：
   - **单机陪伴**：无需 API Key，全程离线。
   - **DeepSeek 联网**：填入在 https://platform.deepseek.com 创建的 API Key。
3. 随时可在 `我们 → AI 与网络` 中切换模式、修改 Base URL、模型名、测试连接。
4. 默认配置：
   - Base URL：`https://api.deepseek.com`
   - Model：`deepseek-chat`
   - 也支持 OpenAI 兼容代理地址。

> Key 会保存在本机应用的 SharedPreferences 中，请勿在共享设备上配置个人 Key。
> DeepSeek 会产生 API 费用，请以官方计费为准。

---

## 6. 数据与隐私

- 数据库：应用私有目录下的 `star_isle.db`
- 图片/画卡：应用私有目录 `star_isle/images`、`star_isle/art`
- 设置、API Key：SharedPreferences
- 不上传图片二进制、不上传数据库、不含分析 SDK、无广告、无账号
- 卸载 App 或清除应用数据会删除全部记录；本项目不提供云备份
- 联网模式只请求你配置的 DeepSeek/兼容接口
- 若要彻底停止联网：在 `AI 与网络` 中选择“单机陪伴”，或清空 API Key

---

## 7. 已知边界与设计取舍

1. **提醒与应用关闭**
   - 星屿不申请后台常驻 / 通知权限。
   - AI 主动消息与纪念日提醒会在应用打开或回到前台时判断并补上。
   - 如果你需要“应用完全关闭也能收到系统通知”，需要接入 `flutter_local_notifications` + WorkManager/ AlarmManager 并处理 Android 13 通知权限与国产 ROM 后台限制，本项目未包含该层。
2. **离线引擎不是通用大模型**，见第 3 节。
3. **AI 配图是程序化画卡**，不是扩散模型生成的照片。
4. **AI 不能真正看见用户发送的图片**；DeepSeek 文本接口无法读取图片内容。AI 会诚实说明并邀请用户描述。
5. **没有多用户、云端同步、导出备份、公开社交**，符合“单人专属、无需登录”的定位。
6. **没有内置任何 API Key**。请使用自己的 Key，且不要提交到公开仓库。

---

## 8. 个性化修改速查

| 想修改 | 文件 |
| --- | --- |
| 颜色、皮肤、背景 | `lib/core/theme/app_theme_spec.dart` |
| 全局文字样式、按钮、输入框 | `lib/core/theme/app_theme.dart` |
| 默认 AI 人设 / 初始签名 / 好感度 | `lib/data/models/companion_profile.dart` |
| 离线回复文案、语气、意图、主动消息 | `lib/services/ai/local_persona_engine.dart` |
| 在线提示词与 JSON 解析 | `lib/services/ai/ai_service.dart` |
| DeepSeek 地址 / 错误文案 | `lib/services/ai/deepseek_client.dart` |
| 动态自动发布间隔 / 首次种子内容 | `lib/state/moments_controller.dart` |
| 主动私聊间隔 / 纪念日提醒逻辑 | `lib/state/companion_controller.dart` |
| 画卡构图与色板 | `lib/services/art_service.dart` |
| App 名称 / 包名 | `android/app/src/main/AndroidManifest.xml`、`android/app/build.gradle` |
| 启动图 / 图标 | `android/app/src/main/res/` |
| 应用版本号 | `pubspec.yaml` 的 `version` |

修改应用包名时，至少同步修改：
- `android/app/build.gradle` 的 `namespace` 与 `applicationId`
- `MainActivity.kt` 的 package
- `AndroidManifest.xml` 中的 activity 相对类名（如果包名路径变化）

---

## 9. 常见问题

### Q：macOS/Linux 报 `Permission denied`（android/gradlew）
ZIP 解压工具有时不保留执行位，运行：

```bash
chmod +x android/gradlew
```

再执行 `flutter build apk --release`。

### Q：`flutter pub get` 失败
- 检查 Flutter/Dart 版本是否满足 `pubspec.yaml`：Dart >= 3.5.0，Flutter >= 3.24.0
- 更换国内 pub 镜像（可选）：
```bash
export PUB_HOSTED_URL=https://pub.flutter-io.cn
export FLUTTER_STORAGE_BASE_URL=https://storage.flutter-io.cn
```

### Q：Gradle 构建卡在下载
- 检查网络是否能访问 Gradle / Google Maven
- 使用 4.8 节的 Gradle 镜像
- 关闭代理后重试，或让代理软件开启 TUN / 全局模式

### Q：`Unsupported class file major version` / Gradle JDK 错误
- 使用 JDK 17
- Android Studio：Gradle JDK 选 17
- 命令行：确保 `JAVA_HOME` 指向 JDK 17

### Q：APK 安装时提示签名冲突
- 手机上已经装了同包名、不同签名的旧版本。先卸载旧应用，或始终使用同一 keystore。

### Q：没有声音
- 检查系统是否安装中文 TTS 引擎
- `设置 → 语言与输入 → 文字转语音 → 首选引擎`，安装/选择支持中文普通话的引擎
- 在星屿聊天页右上角确认自动朗读已开启，或点单条消息下方的小喇叭

### Q：相册选择无反应/没有权限
- 检查系统照片权限；Android 13+ 通过系统照片选择器访问
- 如果系统拦截，可在设置中给星屿“照片和视频”权限

### Q：想清空所有数据
- Android 设置 → 应用 → 星屿 → 存储 → 清除数据
- 清除后重新打开会回到首次引导

---

## 10. 生产使用建议

- 替换默认包名和 keystore。
- 如果准备上架，补充隐私政策、通知权限说明、内容安全策略。
- 将 API Key 的存储升级到 Keystore/EncryptedSharedPreferences（当前为了单文件可编译性使用 SharedPreferences）。
- 如接入图片理解，使用支持视觉的模型，并在 UI 中明确告知用户。
- 如需离线大模型，将模型文件放入私有目录按需下载，避免把 1GB+ 模型直接塞进基础 APK。

---

## 11. GitHub Actions 云端打包（推荐给没有本地 Flutter 环境的人）

项目已内置：

```text
.github/workflows/build-apk.yml
```

可以只通过 GitHub 网页/手机浏览器构建 APK，不需要安装 Flutter、JDK、Android SDK。完整图文步骤见：

- `GITHUB_ACTIONS_APK_GUIDE.md`（项目根目录）

简要流程：

1. 新建 GitHub **Private** 仓库；
2. 上传 `StarIsle_Flutter_Android_Source.zip` 到仓库根目录；
3. 新建 `.github/workflows/build-apk.yml`，粘贴工程内 workflow 内容；
4. `Actions → Build Star Isle APK → Run workflow`；
5. 构建成功后从 `Artifacts → StarIsle-release-apk` 下载 ZIP，解压得到 APK。

> CI 首次构建通常需要 10–25 分钟。产出的 APK 使用 CI debug 签名，适合个人安装测试；长期覆盖更新建议后续配置固定 release keystore。

---

## 12. 许可

本项目为个人陪伴应用示例代码，使用 Flutter、DeepSeek API 及第三方开源包均遵循各自许可证。
请在分发或商用前自行检查依赖许可证、DeepSeek 服务条款与当地隐私法律。

---

**星屿 · 把晚风留在身边。**
