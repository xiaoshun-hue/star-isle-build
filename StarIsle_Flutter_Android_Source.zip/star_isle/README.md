# 星屿 1.3.0+15 · 大肥鱼人设 / Edge-TTS / 主动语音气泡

## 文件

Dart：
- lib/services/ai/ai_service.dart
- lib/services/free_edge_tts_service.dart（新增）
- lib/services/voice_message_service.dart（新增）
- lib/services/tts_service.dart
- lib/services/notification_service.dart
- lib/services/media_service.dart
- lib/state/companion_controller.dart
- lib/state/settings_controller.dart
- lib/data/models/companion_profile.dart
- lib/core/decoration_pack.dart
- lib/core/widgets/companion_avatar.dart
- lib/ui/pages/decoration_page.dart
- lib/ui/screens/profile/profile_screen.dart
- lib/ui/screens/chat/chat_screen.dart
- lib/ui/screens/chat/widgets/chat_bubble.dart
- lib/ui/screens/chat/widgets/chat_composer.dart
- lib/ui/screens/home/home_shell.dart
- lib/ui/screens/settings/companion_settings_screen.dart
- lib/ui/screens/settings/voice_settings_screen.dart（新增）
- lib/main.dart
- pubspec.yaml（crypto 依赖、版本 1.3.0+15）

Android：
- android/app/src/main/kotlin/com/starisle/companion/MainActivity.kt
- android/app/src/main/AndroidManifest.xml
- android/app/src/main/res/drawable/ic_stat_star_isle.xml

## 功能

- 大肥鱼 2.0 人设预设按钮（不覆盖旧人设，手动保存）
- 系统朗读 / Edge-TTS 免费音色二选一
- 晓晓、晓伊、云扬、云希、云健；语速/音调可调
- Edge 失败自动系统朗读；语音气泡还会用系统 TTS 合成文件兜底
- 主动消息：文字（默认）/ 语音气泡 / 随机
- 语音气泡带字幕，点击才播放，本地缓存
- 普通聊天只出文字气泡
- 缓存 7 天/最多 120 个文件清理
- 通知默认关闭，手动开启
- 头像池、AI 降级、主动消息防骚扰等保留

## 说明

Edge Read Aloud 是非官方免密钥接口，当前网络可能 403；失败会回退系统。
Kotlin 原生代码未在本机编译，需 GitHub Actions 实际构建验证。

## 校验

- 73 个 Dart 文件语法检查：0 错误
- 合并项目 Dart 静态分析：0 error / 0 warning
