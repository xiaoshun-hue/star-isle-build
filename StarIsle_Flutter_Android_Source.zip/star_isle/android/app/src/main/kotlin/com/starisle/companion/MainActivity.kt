package com.starisle.companion

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.util.Locale
import java.util.UUID

class MainActivity : FlutterActivity() {
    companion object {
        private const val CHANNEL = "com.starisle.companion/notifications"
        private const val AUDIO_CHANNEL = "com.starisle.companion/audio"
        private const val CHANNEL_ID = "star_isle_messages"
        private const val EXTRA_OPEN_CHAT = "open_chat"
        private const val PERMISSION_REQUEST_CODE = 4102
    }

    private var channel: MethodChannel? = null
    private var audioChannel: MethodChannel? = null
    private var mediaPlayer: MediaPlayer? = null
    private var systemTts: TextToSpeech? = null
    private var systemTtsReady = false
    private var synthResult: MethodChannel.Result? = null
    private var synthUtteranceId: String? = null
    private var pendingOpenChat = false
    private var permissionResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        pendingOpenChat = consumeOpenChat(intent)
        createNotificationChannel()

        audioChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            AUDIO_CHANNEL
        )
        audioChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "playFile" -> {
                    val path = (call.arguments as? Map<*, *>)?.get("path") as? String
                    playAudioFile(path, result)
                }

                "synthesizeToFile" -> {
                    val args = call.arguments as? Map<*, *>
                    val text = (args?.get("text") as? String)?.trim().orEmpty()
                    val path = (args?.get("path") as? String)?.trim().orEmpty()
                    synthesizeSystemTts(text, path, result)
                }

                "stop" -> {
                    stopAudio()
                    result.success(null)
                }

                else -> result.notImplemented()
            }
        }

        systemTts = TextToSpeech(this) { status ->
            systemTtsReady = status == TextToSpeech.SUCCESS
            if (systemTtsReady) {
                val language = systemTts?.setLanguage(Locale.SIMPLIFIED_CHINESE)
                if (language == TextToSpeech.LANG_MISSING_DATA ||
                    language == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    systemTtsReady = false
                }
            }
        }

        channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        channel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "initialize" -> {
                    val open = pendingOpenChat
                    pendingOpenChat = false
                    result.success(open)
                }

                "requestPermission" -> requestNotificationPermission(result)
                "areEnabled" -> result.success(areNotificationsEnabled())
                "show" -> showNotification(call.arguments, result)
                "cancelAll" -> {
                    notificationManager().cancelAll()
                    result.success(null)
                }

                else -> result.notImplemented()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (consumeOpenChat(intent)) {
            val current = channel
            if (current != null) {
                current.invokeMethod("onNotificationTap", null)
            } else {
                pendingOpenChat = true
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            val result = permissionResult
            permissionResult = null
            result?.success(areNotificationsEnabled())
        }
    }

    private fun consumeOpenChat(intent: Intent?): Boolean {
        if (intent?.getBooleanExtra(EXTRA_OPEN_CHAT, false) == true) {
            intent.removeExtra(EXTRA_OPEN_CHAT)
            return true
        }
        return false
    }

    private fun requestNotificationPermission(result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            result.success(areNotificationsEnabled())
            return
        }
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            result.success(areNotificationsEnabled())
            return
        }
        if (permissionResult != null) {
            result.success(false)
            return
        }
        permissionResult = result
        try {
            requestPermissions(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                PERMISSION_REQUEST_CODE
            )
        } catch (error: Exception) {
            permissionResult = null
            result.error("permission_error", error.message, null)
        }
    }

    private fun showNotification(arguments: Any?, result: MethodChannel.Result) {
        val args = arguments as? Map<*, *>
        val id = (args?.get("id") as? Number)?.toInt() ?: 4101
        val title = (args?.get("title") as? String)?.trim().orEmpty()
        val body = (args?.get("body") as? String)?.trim().orEmpty()
        if (body.isEmpty()) {
            result.success(false)
            return
        }
        if (!areNotificationsEnabled()) {
            result.success(false)
            return
        }
        try {
            createNotificationChannel()
            val openIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_OPEN_CHAT, true)
            }
            val pendingIntent = PendingIntent.getActivity(
                this,
                id,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val builder: Notification.Builder =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    Notification.Builder(this, CHANNEL_ID)
                } else {
                    Notification.Builder(this).setPriority(Notification.PRIORITY_HIGH)
                }
            val notification = builder
                .setSmallIcon(R.drawable.ic_stat_star_isle)
                .setContentTitle(if (title.isEmpty()) "星屿" else title)
                .setContentText(body)
                .setStyle(Notification.BigTextStyle().bigText(body))
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setColor(Color.parseColor("#FFB4C1"))
                .setWhen(System.currentTimeMillis())
                .build()
            notificationManager().notify(id, notification)
            result.success(true)
        } catch (error: Exception) {
            result.error("notification_error", error.message, null)
        }
    }

    private fun synthesizeSystemTts(
        text: String,
        path: String,
        result: MethodChannel.Result
    ) {
        if (text.isEmpty() || path.isEmpty() || !systemTtsReady) {
            result.success(false)
            return
        }
        if (synthResult != null) {
            result.success(false)
            return
        }
        val file = File(path)
        file.parentFile?.mkdirs()
        val utteranceId = UUID.randomUUID().toString()
        synthResult = result
        synthUtteranceId = utteranceId
        systemTts?.setOnUtteranceProgressListener(
            object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}

                override fun onDone(id: String?) {
                    if (id == synthUtteranceId) {
                        runOnUiThread {
                            synthResult?.success(true)
                            synthResult = null
                            synthUtteranceId = null
                        }
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) {
                    if (id == synthUtteranceId) {
                        runOnUiThread {
                            synthResult?.success(false)
                            synthResult = null
                            synthUtteranceId = null
                        }
                    }
                }
            }
        )
        val status = systemTts?.synthesizeToFile(
            text,
            Bundle(),
            file,
            utteranceId
        ) ?: TextToSpeech.ERROR
        if (status != TextToSpeech.SUCCESS) {
            synthResult = null
            synthUtteranceId = null
            result.success(false)
        }
    }

    private fun playAudioFile(path: String?, result: MethodChannel.Result) {
        if (path.isNullOrBlank() || !File(path).exists()) {
            result.success(false)
            return
        }
        stopAudio()
        val player = MediaPlayer()
        mediaPlayer = player
        var replied = false
        try {
            player.setDataSource(path)
            player.setOnPreparedListener { prepared ->
                if (!replied) {
                    replied = true
                    result.success(true)
                }
                prepared.start()
            }
            player.setOnCompletionListener {
                runOnUiThread {
                    audioChannel?.invokeMethod("onAudioComplete", null)
                }
                if (mediaPlayer === player) {
                    mediaPlayer = null
                }
                player.release()
            }
            player.setOnErrorListener { _, _, _ ->
                runOnUiThread {
                    audioChannel?.invokeMethod("onAudioError", null)
                }
                if (!replied) {
                    replied = true
                    result.success(false)
                }
                if (mediaPlayer === player) {
                    mediaPlayer = null
                }
                player.release()
                true
            }
            player.prepareAsync()
        } catch (error: Exception) {
            if (mediaPlayer === player) {
                mediaPlayer = null
            }
            player.release()
            if (!replied) {
                replied = true
                result.error("audio_error", error.message, null)
            }
        }
    }

    private fun stopAudio() {
        val player = mediaPlayer
        mediaPlayer = null
        if (player == null) return
        try {
            if (player.isPlaying) player.stop()
        } catch (_: Exception) {
            // ignore
        }
        try {
            player.release()
        } catch (_: Exception) {
            // ignore
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "晚晚的消息",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "星屿里她发来的新消息"
            enableVibration(true)
            setShowBadge(true)
        }
        notificationManager().createNotificationChannel(channel)
    }

    override fun onDestroy() {
        stopAudio()
        systemTts?.stop()
        systemTts?.shutdown()
        systemTts = null
        super.onDestroy()
    }

    private fun notificationManager(): NotificationManager =
        getSystemService(NOTIFICATION_SERVICE) as NotificationManager

    private fun areNotificationsEnabled(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return false
        }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            notificationManager().areNotificationsEnabled()
        } else {
            true
        }
    }
}
