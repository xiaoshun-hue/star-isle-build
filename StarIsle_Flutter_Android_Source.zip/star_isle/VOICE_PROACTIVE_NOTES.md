# 星屿 · 大肥鱼 2.0 / 语音 / 主动消息

## 大肥鱼 2.0 人设

在「设置 → 人格与主动陪伴 → 她的人设与生活」上方，点击
「填入大肥鱼 2.0 人设」，会填入：

- 名字：大肥鱼
- 独立伙伴，不是客服
- 口语短句，一次两三句
- 不懂直接说不知道，不装懂
- 三不：不泄露隐私、不帮人吵架、不刷屏
- 三不许：不刻意讨好、不装懂、不答应所有请求
- 口头禅：讲道理说哈、这个我拿不准、换个角度看、得看实际情况
- 有自己的判断，不一味附和

这是手动预设，不会覆盖旧用户已有的人设；保存后才生效。

## 朗读引擎

默认：**系统本地朗读**，不联网。

可选：**免费在线 AI 音色（Edge-TTS）**。

- 内置音色：晓晓、晓伊、云扬、云希、云健
- 支持语速 `0.7–1.3×`
- 支持音调 `-12–+12 Hz`
- 试听按钮
- 断网/接口失败/解码失败自动降级系统本地朗读
- Edge Read Aloud 是非官方公开接口，**存在远期失效风险**，设置页已标注

### Edge 失败时的语音气泡兜底

当前网络下 Edge 接口可能返回 403。实现里做了两级兜底：

1. 优先 Edge 在线音色；
2. 失败后用 Android 系统 TTS 的 `synthesizeToFile` 生成 WAV/音频文件；
3. 两种都失败才降级为文字消息。

因此即使 Edge 接口失效，主动语音气泡仍能点击播放，只是使用系统音色。

## 主动消息三模式

设置 → 人格与主动陪伴 → 语音与主动消息 → 主动消息形式：

1. **文字消息（默认）**
2. **语音气泡**
   - 带字幕
   - 点击才播放
   - 不自动出声
   - 音频缓存到本地
3. **随机文字/语音**

规则：

- 普通对话回复永远是普通文字气泡，不生成语音气泡。
- 语音模式失败自动降级为文字。
- 主动语音气泡不触发 `autoSpeak`，只有用户点击才播放。
- 语音气泡字幕仍保存在 `ChatMessage.content`，不修改模型。
- 音频路径通过 `VoiceBubbleRegistry` 与 `messageId` 关联，并持久化到 SharedPreferences。

## 音频缓存

- Edge/系统 TTS 文件存放在应用临时目录 `edge_tts_cache`。
- 启动时清理超过 7 天的文件。
- 最多保留 120 个音频文件。
- 设置页提供「语音缓存清理」按钮。
- 缓存被清理后，语音气泡自动退回文字，不崩溃。

## 涉及文件

- `lib/services/free_edge_tts_service.dart`（新增）
- `lib/services/voice_message_service.dart`（新增）
- `lib/services/tts_service.dart`
- `lib/ui/screens/settings/voice_settings_screen.dart`（新增）
- `lib/ui/screens/settings/companion_settings_screen.dart`
- `lib/data/models/companion_profile.dart`
- `lib/state/settings_controller.dart`
- `lib/state/companion_controller.dart`
- `lib/ui/screens/chat/widgets/chat_bubble.dart`
- `lib/ui/screens/chat/chat_screen.dart`
- `lib/main.dart`
- `android/.../MainActivity.kt`（通知 + 音频播放/系统 TTS 合成）
- `pubspec.yaml`（crypto 依赖）

## 默认与兼容

- 朗读引擎默认系统
- 主动消息默认文字
- 通知默认关闭
- 头像池默认关闭
- 旧配置缺字段自动回落
- 不修改 `ChatMessage`、`CompanionProfile`、`AiTurnResult` 结构

## 校验

- 73 个 Dart 文件语法检查：0 错误
- 项目合并静态分析：0 error / 0 warning
- Kotlin 原生代码需要实际 Gradle 构建验证
