import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../core/theme/app_palette.dart';
import '../../../../services/sticker_favorites.dart';
import '../../../../services/sticker_semantics.dart';

class StickerPickerPanel extends StatefulWidget {
  const StickerPickerPanel({
    super.key,
    required this.onEmojiSelected,
    required this.onStickerSelected,
    required this.onShowKeyboard,
    this.onPickStickerImage,
  });

  final ValueChanged<String> onEmojiSelected;
  final ValueChanged<String> onStickerSelected;
  final VoidCallback onShowKeyboard;
  final VoidCallback? onPickStickerImage;

  @override
  State<StickerPickerPanel> createState() => _StickerPickerPanelState();
}

class _StickerPickerPanelState extends State<StickerPickerPanel> {
  int _tab = 0;
  int _categoryIndex = 0;

  static const List<String> _emojiItems = <String>[
    '😊', '🥰', '😘', '🫠', '😭', '🥺', '😴', '😌',
    '🤔', '🙃', '😼', '🫶', '💗', '✨', '🌙', '🫧',
    '🌊', '🍃', '🌷', '☕', '🍵', '🎧', '🎬', '📖',
    '🌈', '🔥', '💫', '🪐', '⭐', '🎀', '🍓', '🥐',
    '😤', '😢', '😳', '🫣', '🥹', '💢', '🐧', '🫂',
  ];

  static const List<_StickerCategory> _emojiCategories = <_StickerCategory>[
    _StickerCategory('全部'),
    _StickerCategory('开心', mood: StickerMood.happy),
    _StickerCategory('心动', mood: StickerMood.love),
    _StickerCategory('难过', mood: StickerMood.sad),
    _StickerCategory('困倦', mood: StickerMood.sleepy),
    _StickerCategory('搞怪', mood: StickerMood.funny),
    _StickerCategory('收藏', favorites: true),
  ];

  static const List<_StickerCategory> _packCategories = <_StickerCategory>[
    _StickerCategory('全部'),
    _StickerCategory('抱抱', mood: StickerMood.comfort),
    _StickerCategory('想念', mood: StickerMood.miss),
    _StickerCategory('夜晚', mood: StickerMood.night),
    _StickerCategory('搞怪', mood: StickerMood.funny),
    _StickerCategory('食物', mood: StickerMood.food),
    _StickerCategory('收藏', favorites: true),
  ];

  List<_StickerCategory> get _categories =>
      _tab == 0 ? _emojiCategories : _packCategories;

  List<String> get _baseEmojis {
    if (_tab == 1) {
      return StickerSemantics.pack
          .map((StickerPackItem item) => item.emoji)
          .toSet()
          .toList(growable: false);
    }
    final Set<String> all = <String>{..._emojiItems};
    all.addAll(
      StickerSemantics.pack.map((StickerPackItem item) => item.emoji),
    );
    return all.toList(growable: false);
  }

  List<String> get _visibleEmojis {
    final _StickerCategory category = _categories[_categoryIndex];
    final List<String> base = _baseEmojis;
    if (category.favorites) {
      final StickerFavoritesStore store = StickerFavoritesStore.instance;
      return base.where((String emoji) => store.contains(emoji)).toList();
    }
    final StickerMood? mood = category.mood;
    if (mood == null) return base;
    return base
        .where((String emoji) => StickerSemantics.moodOf(emoji) == mood)
        .toList(growable: false);
  }

  void _switchTab(int tab) {
    if (_tab == tab) return;
    setState(() {
      _tab = tab;
      _categoryIndex = 0;
    });
  }

  void _selectCategory(int index) {
    if (_categoryIndex == index) return;
    setState(() => _categoryIndex = index);
  }

  void _send(String emoji) {
    if (_tab == 0) {
      widget.onEmojiSelected(emoji);
      return;
    }
    final StickerPackItem? item = _findItem(emoji);
    widget.onStickerSelected(item?.payload ?? emoji);
  }

  StickerPackItem? _findItem(String emoji) {
    for (final StickerPackItem item in StickerSemantics.pack) {
      if (item.emoji == emoji) return item;
    }
    return null;
  }

  void _toggleFavorite(String emoji) {
    HapticFeedback.selectionClick();
    unawaited(StickerFavoritesStore.instance.toggle(emoji));
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: StickerFavoritesStore.instance,
      builder: (BuildContext context, Widget? child) => _buildPanel(context),
    );
  }

  Widget _buildPanel(BuildContext context) {
    final AppPalette palette = context.palette;
    final Color surface = palette.isDark
        ? palette.backgroundMid
        : palette.glassStrong;
    final List<String> items = _visibleEmojis;

    return Container(
      height: 276,
      width: double.infinity,
      decoration: BoxDecoration(
        color: surface,
        border: Border(
          top: BorderSide(
            color: palette.border.withOpacity(palette.isDark ? 0.72 : 0.48),
            width: 0.8,
          ),
        ),
      ),
      child: Column(
        children: <Widget>[
          SizedBox(
            height: 38,
            child: Row(
              children: <Widget>[
                const SizedBox(width: 12),
                _tabButton('表情', 0, palette),
                const SizedBox(width: 4),
                _tabButton('表情包', 1, palette),
                const Spacer(),
                if (widget.onPickStickerImage != null)
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    tooltip: '添加表情',
                    onPressed: widget.onPickStickerImage,
                    icon: Icon(
                      Icons.add_circle_outline_rounded,
                      size: 20,
                      color: palette.muted,
                    ),
                  ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  tooltip: '键盘',
                  onPressed: widget.onShowKeyboard,
                  icon: Icon(
                    Icons.keyboard_rounded,
                    size: 20,
                    color: palette.muted,
                  ),
                ),
                const SizedBox(width: 4),
              ],
            ),
          ),
          SizedBox(
            height: 34,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: _categories.length,
              separatorBuilder: (_, __) => const SizedBox(width: 4),
              itemBuilder: (BuildContext context, int index) {
                return _categoryChip(_categories[index], index, palette);
              },
            ),
          ),
          const SizedBox(height: 2),
          Expanded(
            child: items.isEmpty
                ? _favoritesEmpty(palette)
                : GridView.builder(
                    padding: const EdgeInsets.fromLTRB(10, 2, 10, 8),
                    physics: const BouncingScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 8,
                          mainAxisSpacing: 2,
                          crossAxisSpacing: 2,
                        ),
                    itemCount: items.length,
                    itemBuilder: (BuildContext context, int index) {
                      return _stickerCell(items[index], palette);
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _tabButton(String label, int tab, AppPalette palette) {
    final bool selected = _tab == tab;
    return GestureDetector(
      onTap: () => _switchTab(tab),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: selected
              ? Theme.of(context).colorScheme.primary.withOpacity(0.12)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          label,
          style: Theme.of(context).textTheme.labelMedium?.copyWith(
            color: selected
                ? Theme.of(context).colorScheme.primary
                : palette.muted,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
            fontSize: 11,
          ),
        ),
      ),
    );
  }

  Widget _categoryChip(
    _StickerCategory category,
    int index,
    AppPalette palette,
  ) {
    final bool selected = _categoryIndex == index;
    return GestureDetector(
      onTap: () => _selectCategory(index),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
        decoration: BoxDecoration(
          color: selected
              ? Theme.of(context).colorScheme.primary.withOpacity(0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(7),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (category.favorites) ...<Widget>[
              Icon(
                Icons.favorite_border_rounded,
                size: 11,
                color: selected
                    ? Theme.of(context).colorScheme.primary
                    : palette.muted,
              ),
              const SizedBox(width: 3),
            ],
            Text(
              category.label,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: selected
                    ? Theme.of(context).colorScheme.primary
                    : palette.muted,
                fontSize: 10,
                fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stickerCell(String emoji, AppPalette palette) {
    final bool favorite = StickerFavoritesStore.instance.contains(emoji);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _send(emoji),
      onLongPress: () => _toggleFavorite(emoji),
      child: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          Center(
            child: Text(
              emoji,
              style: const TextStyle(fontSize: 24, height: 1.0),
            ),
          ),
          if (favorite)
            Positioned(
              top: 3,
              right: 3,
              child: Icon(
                Icons.favorite_rounded,
                size: 7,
                color: Theme.of(context).colorScheme.primary.withOpacity(0.7),
              ),
            ),
        ],
      ),
    );
  }

  Widget _favoritesEmpty(AppPalette palette) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(
            Icons.favorite_border_rounded,
            size: 22,
            color: palette.muted.withOpacity(0.55),
          ),
          const SizedBox(height: 7),
          Text(
            '还没有收藏的表情',
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: palette.muted,
              fontSize: 10,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            '长按表情即可收藏',
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: palette.muted.withOpacity(0.6),
              fontSize: 9,
            ),
          ),
        ],
      ),
    );
  }
}

class _StickerCategory {
  const _StickerCategory(
    this.label, {
    this.mood,
    this.favorites = false,
  });

  final String label;
  final StickerMood? mood;
  final bool favorites;
}
