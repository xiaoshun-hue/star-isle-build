import 'package:flutter/material.dart';

import '../../../../core/theme/app_palette.dart';
import '../../../../core/widgets/pressable_scale.dart';

class ChatComposer extends StatefulWidget {
  const ChatComposer({
    super.key,
    required this.controller,
    required this.focusNode,
    required this.isReplying,
    required this.isPickingImage,
    required this.extrasOpen,
    required this.onToggleExtras,
    required this.onPickImage,
    required this.onSend,
    required this.onInputFocus,
    this.hintText = '说点什么…',
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final bool isReplying;
  final bool isPickingImage;
  final bool extrasOpen;
  final VoidCallback onToggleExtras;
  final VoidCallback onPickImage;
  final VoidCallback onSend;
  final VoidCallback onInputFocus;
  final String hintText;

  @override
  State<ChatComposer> createState() => _ChatComposerState();
}

class _ChatComposerState extends State<ChatComposer> {
  bool _focused = false;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onTextChanged);
    widget.focusNode.addListener(_onFocusChanged);
  }

  @override
  void didUpdateWidget(covariant ChatComposer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_onTextChanged);
      widget.controller.addListener(_onTextChanged);
    }
    if (oldWidget.focusNode != widget.focusNode) {
      oldWidget.focusNode.removeListener(_onFocusChanged);
      widget.focusNode.addListener(_onFocusChanged);
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onTextChanged);
    widget.focusNode.removeListener(_onFocusChanged);
    super.dispose();
  }

  void _onTextChanged() {
    if (mounted) setState(() {});
  }

  void _onFocusChanged() {
    if (!mounted) return;
    setState(() => _focused = widget.focusNode.hasFocus);
    if (widget.focusNode.hasFocus) widget.onInputFocus();
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final bool canSend =
        widget.controller.text.trim().isNotEmpty && !widget.isReplying;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 8),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 240),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.fromLTRB(6, 5, 6, 5),
        decoration: BoxDecoration(
          color: palette.glass,
          borderRadius: BorderRadius.circular(26),
          border: Border.all(
            color: _focused
                ? Theme.of(context).colorScheme.primary.withOpacity(0.55)
                : palette.border,
            width: _focused ? 1.1 : 0.8,
          ),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: palette.shadow.withOpacity(palette.isDark ? 0.17 : 0.06),
              blurRadius: 22,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            _RoundAction(
              icon: widget.isPickingImage
                  ? null
                  : widget.extrasOpen
                  ? Icons.keyboard_alt_outlined
                  : Icons.add_photo_alternate_outlined,
              busy: widget.isPickingImage,
              onTap: widget.isPickingImage
                  ? null
                  : widget.extrasOpen
                  ? widget.onToggleExtras
                  : widget.onPickImage,
              tooltip: widget.extrasOpen ? '打开键盘' : '从相册发送图片',
            ),
            Expanded(
              child: TextField(
                controller: widget.controller,
                focusNode: widget.focusNode,
                minLines: 1,
                maxLines: 4,
                maxLength: 1200,
                keyboardType: TextInputType.multiline,
                textInputAction: TextInputAction.newline,
                style: Theme.of(context).textTheme.bodyMedium
                    ?.copyWith(fontSize: 15, height: 1.5),
                decoration: InputDecoration(
                  isDense: true,
                  filled: false,
                  counterText: '',
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 9,
                  ),
                  hintText: widget.isReplying ? '她正在打字…' : widget.hintText,
                  hintStyle: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: palette.muted.withOpacity(0.64),
                    fontSize: 14.5,
                  ),
                ),
              ),
            ),
            _RoundAction(
              icon: widget.extrasOpen
                  ? Icons.keyboard_rounded
                  : Icons.sentiment_satisfied_alt_rounded,
              onTap: widget.onToggleExtras,
              tooltip: widget.extrasOpen ? '收起表情' : '表情与贴纸',
            ),
            const SizedBox(width: 4),
            PressableScale(
              onTap: canSend ? widget.onSend : null,
              enabled: canSend,
              scale: 0.92,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: canSend
                      ? LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: <Color>[
                            palette.bubbleUserStart,
                            palette.bubbleUserEnd,
                          ],
                        )
                      : null,
                  color: canSend ? null : palette.muted.withOpacity(0.12),
                  boxShadow: canSend
                      ? <BoxShadow>[
                          BoxShadow(
                            color: palette.bubbleUserStart.withOpacity(0.26),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ]
                      : null,
                ),
                child: Icon(
                  Icons.arrow_upward_rounded,
                  size: 20,
                  color: canSend
                      ? Colors.white
                      : palette.muted.withOpacity(0.4),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RoundAction extends StatelessWidget {
  const _RoundAction({
    required this.icon,
    required this.onTap,
    this.busy = false,
    this.tooltip,
  });

  final IconData? icon;
  final VoidCallback? onTap;
  final bool busy;
  final String? tooltip;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    Widget button = PressableScale(
      onTap: onTap,
      scale: 0.9,
      child: SizedBox(
        width: 38,
        height: 42,
        child: Center(
          child: busy
              ? SizedBox(
                  width: 17,
                  height: 17,
                  child: CircularProgressIndicator(
                    strokeWidth: 1.8,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                )
              : Icon(icon, size: 22, color: palette.muted.withOpacity(0.82)),
        ),
      ),
    );
    if (tooltip != null) {
      button = Tooltip(message: tooltip!, child: button);
    }
    return button;
  }
}

class ChatExtrasPanel extends StatefulWidget {
  const ChatExtrasPanel({
    super.key,
    required this.onEmojiSelected,
    required this.onStickerSelected,
    required this.onShowKeyboard,
  });

  final ValueChanged<String> onEmojiSelected;
  final ValueChanged<String> onStickerSelected;
  final VoidCallback onShowKeyboard;

  @override
  State<ChatExtrasPanel> createState() => _ChatExtrasPanelState();
}

class _ChatExtrasPanelState extends State<ChatExtrasPanel> {
  int _tab = 0;

  static const List<String> _emojis = <String>[
    '😊',
    '🥰',
    '😘',
    '🫠',
    '😭',
    '🥺',
    '😴',
    '😌',
    '🤔',
    '🙃',
    '😼',
    '🫶',
    '💗',
    '✨',
    '🌙',
    '🫧',
    '🌊',
    '🍃',
    '🌷',
    '☕',
    '🍵',
    '🎧',
    '🎬',
    '📖',
    '🌈',
    '🔥',
    '💫',
    '🪐',
    '⭐',
    '🎀',
    '🍓',
    '🥐',
  ];

  static const List<_StickerData> _stickers = <_StickerData>[
    _StickerData('🌙', '晚安啦'),
    _StickerData('🫧', '想你了'),
    _StickerData('🥺', '有点委屈'),
    _StickerData('🫶', '抱抱你'),
    _StickerData('✨', '你好棒'),
    _StickerData('🍵', '喝点热的'),
    _StickerData('🌧️', 'emo 一下'),
    _StickerData('🪐', '陪你发呆'),
  ];

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    return Container(
      height: 238,
      margin: const EdgeInsets.fromLTRB(12, 2, 12, 6),
      padding: const EdgeInsets.fromLTRB(12, 9, 12, 10),
      decoration: BoxDecoration(
        color: palette.glass,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: palette.border, width: 0.8),
      ),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              _tabButton('表情', 0, palette),
              const SizedBox(width: 5),
              _tabButton('表情包', 1, palette),
              const Spacer(),
              GestureDetector(
                onTap: widget.onShowKeyboard,
                behavior: HitTestBehavior.opaque,
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Icon(
                    Icons.keyboard_rounded,
                    size: 19,
                    color: palette.muted,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Expanded(
            child: _tab == 0
                ? GridView.builder(
                    padding: EdgeInsets.zero,
                    physics: const BouncingScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 8,
                          mainAxisSpacing: 4,
                          crossAxisSpacing: 4,
                        ),
                    itemCount: _emojis.length,
                    itemBuilder: (BuildContext context, int index) {
                      return InkWell(
                        borderRadius: BorderRadius.circular(12),
                        onTap: () => widget.onEmojiSelected(_emojis[index]),
                        child: Center(
                          child: Text(
                            _emojis[index],
                            style: const TextStyle(fontSize: 23),
                          ),
                        ),
                      );
                    },
                  )
                : GridView.builder(
                    padding: EdgeInsets.zero,
                    physics: const BouncingScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 4,
                          mainAxisSpacing: 7,
                          crossAxisSpacing: 7,
                          childAspectRatio: 1.35,
                        ),
                    itemCount: _stickers.length,
                    itemBuilder: (BuildContext context, int index) {
                      final _StickerData sticker = _stickers[index];
                      return InkWell(
                        borderRadius: BorderRadius.circular(15),
                        onTap: () => widget.onStickerSelected(
                          '${sticker.emoji}|${sticker.label}',
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            color: palette.bubbleAi,
                            borderRadius: BorderRadius.circular(15),
                            border: Border.all(color: palette.border),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                sticker.emoji,
                                style: const TextStyle(fontSize: 24),
                              ),
                              const SizedBox(width: 6),
                              Flexible(
                                child: Text(
                                  sticker.label,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.labelSmall
                                      ?.copyWith(
                                        color: palette.muted,
                                        fontSize: 10,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _tabButton(String label, int index, AppPalette palette) {
    final bool selected = _tab == index;
    return GestureDetector(
      onTap: () => setState(() => _tab = index),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 6),
        decoration: BoxDecoration(
          color: selected
              ? Theme.of(context).colorScheme.primary.withOpacity(0.13)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(99),
        ),
        child: Text(
          label,
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
            color: selected
                ? Theme.of(context).colorScheme.primary
                : palette.muted,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

class _StickerData {
  const _StickerData(this.emoji, this.label);

  final String emoji;
  final String label;
}
