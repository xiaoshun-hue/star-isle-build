import 'package:flutter/material.dart';

import '../../../../core/theme/app_palette.dart';
import '../../../../core/widgets/pressable_scale.dart';

class ChatComposer extends StatefulWidget {
  const ChatComposer({
    super.key,
    required this.controller,
    required this.focusNode,
    required this.isReplying,
    required this.isPickingImage,
    required this.extrasOpen,
    required this.onToggleExtras,
    required this.onPickImage,
    this.onPickImages,
    required this.onVoice,
    required this.onSend,
    required this.onInputFocus,
    this.hintText = '说点什么…',
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final bool isReplying;
  final bool isPickingImage;
  final bool extrasOpen;
  final VoidCallback onToggleExtras;
  final VoidCallback onPickImage;
  final VoidCallback? onPickImages;
  final VoidCallback onVoice;
  final VoidCallback onSend;
  final VoidCallback onInputFocus;
  final String hintText;

  @override
  State<ChatComposer> createState() => _ChatComposerState();
}

class _ChatComposerState extends State<ChatComposer> {
  bool _focused = false;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onTextChanged);
    widget.focusNode.addListener(_onFocusChanged);
  }

  @override
  void didUpdateWidget(covariant ChatComposer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_onTextChanged);
      widget.controller.addListener(_onTextChanged);
    }
    if (oldWidget.focusNode != widget.focusNode) {
      oldWidget.focusNode.removeListener(_onFocusChanged);
      widget.focusNode.addListener(_onFocusChanged);
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onTextChanged);
    widget.focusNode.removeListener(_onFocusChanged);
    super.dispose();
  }

  void _onTextChanged() {
    if (mounted) setState(() {});
  }

  void _onFocusChanged() {
    if (!mounted) return;
    setState(() => _focused = widget.focusNode.hasFocus);
    if (widget.focusNode.hasFocus) widget.onInputFocus();
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final bool canSend =
        widget.controller.text.trim().isNotEmpty && !widget.isReplying;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 8),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 240),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.fromLTRB(6, 5, 6, 5),
        decoration: BoxDecoration(
          color: palette.glass,
          borderRadius: BorderRadius.circular(26),
          border: Border.all(
            color: _focused
                ? Theme.of(context).colorScheme.primary.withOpacity(0.55)
                : palette.border,
            width: _focused ? 1.1 : 0.8,
          ),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: palette.shadow.withOpacity(palette.isDark ? 0.17 : 0.06),
              blurRadius: 22,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            _RoundAction(
              icon: widget.isPickingImage
                  ? null
                  : widget.extrasOpen
                  ? Icons.keyboard_alt_outlined
                  : Icons.add_photo_alternate_outlined,
              busy: widget.isPickingImage,
              onTap: widget.isPickingImage
                  ? null
                  : widget.extrasOpen
                  ? widget.onToggleExtras
                  : widget.onPickImage,
              onLongPress: widget.isPickingImage || widget.extrasOpen
                  ? null
                  : widget.onPickImages,
              tooltip: widget.extrasOpen
                  ? '打开键盘'
                  : '点按发单图，长按选多图',
            ),
            Expanded(
              child: TextField(
                controller: widget.controller,
                focusNode: widget.focusNode,
                minLines: 1,
                maxLines: 4,
                maxLength: 1200,
                keyboardType: TextInputType.multiline,
                textInputAction: TextInputAction.newline,
                style: Theme.of(context).textTheme.bodyMedium
                    ?.copyWith(fontSize: 15, height: 1.5),
                decoration: InputDecoration(
                  isDense: true,
                  filled: false,
                  counterText: '',
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 9,
                  ),
                  hintText: widget.isReplying ? '她正在打字…' : widget.hintText,
                  hintStyle: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: palette.muted.withOpacity(0.64),
                    fontSize: 14.5,
                  ),
                ),
              ),
            ),
            _RoundAction(
              icon: Icons.mic_none_rounded,
              onTap: widget.isReplying ? null : widget.onVoice,
              tooltip: '语音输入',
            ),
            _RoundAction(
              icon: widget.extrasOpen
                  ? Icons.keyboard_rounded
                  : Icons.sentiment_satisfied_alt_rounded,
              onTap: widget.onToggleExtras,
              tooltip: widget.extrasOpen ? '收起表情' : '表情与贴纸',
            ),
            const SizedBox(width: 4),
            PressableScale(
              onTap: canSend ? widget.onSend : null,
              enabled: canSend,
              scale: 0.92,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: canSend
                      ? LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: <Color>[
                            palette.bubbleUserStart,
                            palette.bubbleUserEnd,
                          ],
                        )
                      : null,
                  color: canSend ? null : palette.muted.withOpacity(0.12),
                  boxShadow: canSend
                      ? <BoxShadow>[
                          BoxShadow(
                            color: palette.bubbleUserStart.withOpacity(0.26),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ]
                      : null,
                ),
                child: Icon(
                  Icons.arrow_upward_rounded,
                  size: 20,
                  color: canSend
                      ? Colors.white
                      : palette.muted.withOpacity(0.4),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RoundAction extends StatelessWidget {
  const _RoundAction({
    required this.icon,
    required this.onTap,
    this.onLongPress,
    this.busy = false,
    this.tooltip,
  });

  final IconData? icon;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final bool busy;
  final String? tooltip;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    Widget button = PressableScale(
      onTap: onTap,
      onLongPress: onLongPress,
      scale: 0.9,
      child: SizedBox(
        width: 38,
        height: 42,
        child: Center(
          child: busy
              ? SizedBox(
                  width: 17,
                  height: 17,
                  child: CircularProgressIndicator(
                    strokeWidth: 1.8,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                )
              : Icon(icon, size: 22, color: palette.muted.withOpacity(0.82)),
        ),
      ),
    );
    if (tooltip != null) {
      button = Tooltip(message: tooltip!, child: button);
    }
    return button;
  }
}
