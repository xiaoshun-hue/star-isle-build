import 'dart:async';

import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';

import '../../../../core/widgets/glass_panel.dart';
import '../../../../core/theme/app_palette.dart';

class VoiceInputSheet extends StatefulWidget {
  const VoiceInputSheet({super.key, this.localeId = 'zh_CN'});

  final String localeId;

  @override
  State<VoiceInputSheet> createState() => _VoiceInputSheetState();
}

class _VoiceInputSheetState extends State<VoiceInputSheet> {
  final SpeechToText _speech = SpeechToText();
  bool _listening = false;
  bool _finished = false;
  String _transcript = '';
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) unawaited(_start());
    });
  }

  Future<void> _start() async {
    if (!mounted) return;
    setState(() {
      _error = null;
      _transcript = '';
      _finished = false;
    });

    bool available = false;
    try {
      available = await _speech.initialize(
        onStatus: (String status) {
          if (!mounted || _finished) return;
          if (status == 'listening') {
            setState(() => _listening = true);
          } else if (status == 'notListening' || status == 'done') {
            setState(() => _listening = false);
          }
        },
        onError: (dynamic error) {
          if (!mounted || _finished) return;
          setState(() {
            _listening = false;
            _error = '语音识别失败：${_errorText(error)}';
          });
        },
      );
    } catch (error) {
      if (mounted) {
        setState(() {
          _listening = false;
          _error = '语音识别启动失败：$error';
        });
      }
      return;
    }

    if (!mounted) return;
    if (!available) {
      setState(() {
        _error = '当前手机没有可用的语音识别引擎，或没有允许麦克风权限。';
      });
      return;
    }

    try {
      await _speech.listen(
        onResult: (dynamic result) {
          if (!mounted || _finished) return;
          final String words = (result.recognizedWords as String?) ?? '';
          if (words.isEmpty) return;
          setState(() => _transcript = words);
          if (result.finalResult == true) {
            _finishWith(words);
          }
        },
        localeId: widget.localeId,
        listenFor: const Duration(seconds: 30),
        pauseFor: const Duration(seconds: 3),
        partialResults: true,
        cancelOnError: true,
        listenMode: ListenMode.dictation,
      );
      if (mounted) setState(() => _listening = true);
    } catch (error) {
      if (mounted) {
        setState(() {
          _listening = false;
          _error = '语音识别启动失败：$error';
        });
      }
    }
  }

  String _errorText(dynamic error) {
    final String? message = error?.errorMsg?.toString();
    return (message == null || message.isEmpty) ? '$error' : message;
  }

  void _finishWith(String text) {
    if (_finished || !mounted) return;
    final String clean = text.trim();
    if (clean.isEmpty) return;
    _finished = true;
    unawaited(_speech.stop());
    Navigator.of(context).pop(clean);
  }

  void _cancel() {
    _finished = true;
    unawaited(_speech.cancel());
    Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _finished = true;
    unawaited(_speech.cancel());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final bool hasText = _transcript.trim().isNotEmpty;
    return Material(
      color: Colors.transparent,
      child: Container(
        padding: EdgeInsets.fromLTRB(
          22,
          14,
          22,
          20 + MediaQuery.of(context).viewInsets.bottom,
        ),
        decoration: BoxDecoration(
          color: palette.backgroundBottom,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
          border: Border.all(color: palette.border),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                width: 38,
                height: 4,
                decoration: BoxDecoration(
                  color: palette.muted.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
              const SizedBox(height: 22),
              AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: 92,
                height: 92,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: palette.glass,
                  border: Border.all(
                    color: _listening
                        ? Theme.of(context).colorScheme.primary
                        : palette.border,
                    width: 1.4,
                  ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: Theme.of(
                        context,
                      ).colorScheme.primary.withOpacity(_listening ? 0.28 : 0.08),
                      blurRadius: _listening ? 34 : 12,
                    ),
                  ],
                ),
                child: Icon(
                  _listening ? Icons.graphic_eq_rounded : Icons.mic_none_rounded,
                  size: 38,
                  color: _error != null
                      ? palette.muted
                      : Theme.of(context).colorScheme.primary,
                ),
              ),
              const SizedBox(height: 18),
              Text(
                _error != null
                    ? '语音没有打开'
                    : hasText
                    ? '听到了'
                    : _listening
                    ? '我在听，请说…'
                    : '准备听你说',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 8),
              if (_error != null)
                Text(
                  _error!,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: palette.muted,
                    height: 1.5,
                  ),
                )
              else if (hasText)
                GlassPanel(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 14,
                  ),
                  child: Text(
                    _transcript,
                    textAlign: TextAlign.center,
                    style: Theme.of(
                      context,
                    ).textTheme.bodyMedium?.copyWith(height: 1.55),
                  ),
                )
              else
                Text(
                  '说完后会自动发送；她的回复会自动朗读。',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: palette.muted,
                    height: 1.5,
                  ),
                ),
              const SizedBox(height: 20),
              if (_error != null)
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _cancel,
                        child: const Text('关闭'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: () => unawaited(_start()),
                        child: const Text('再试一次'),
                      ),
                    ),
                  ],
                )
              else
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _cancel,
                        child: const Text('取消'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: hasText
                            ? () => _finishWith(_transcript)
                            : null,
                        child: const Text('发送'),
                      ),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}
