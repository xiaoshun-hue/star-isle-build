import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';

import '../../../../core/theme/app_palette.dart';
import '../../../../services/voice_asr_service.dart';

class VoiceInputSheet extends StatefulWidget {
  const VoiceInputSheet({super.key, required this.apiKey});

  final String apiKey;

  @override
  State<VoiceInputSheet> createState() => _VoiceInputSheetState();
}

class _VoiceInputSheetState extends State<VoiceInputSheet> {
  final AudioRecorder _recorder = AudioRecorder();
  final VoiceAsrService _asr = VoiceAsrService();
  Timer? _timer;
  String? _path;
  String? _error;
  bool _recording = false;
  bool _busy = false;
  bool _finished = false;
  int _seconds = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) unawaited(_begin());
    });
  }

  Future<void> _begin() async {
    if (_busy || _recording) return;
    setState(() {
      _error = null;
      _seconds = 0;
      _finished = false;
    });

    try {
      final bool hasPermission = await _recorder.hasPermission(request: true);
      if (!mounted) return;
      if (!hasPermission) {
        setState(() => _error = '没有麦克风权限。请到系统设置里允许星屿使用麦克风。');
        return;
      }

      final Directory dir = await getTemporaryDirectory();
      final String path =
          '${dir.path}/star_isle_voice_${DateTime.now().millisecondsSinceEpoch}.wav';
      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.wav,
          sampleRate: 16000,
          numChannels: 1,
        ),
        path: path,
      );
      if (!mounted) return;
      _path = path;
      setState(() {
        _recording = true;
        _error = null;
        _seconds = 0;
      });
      _timer?.cancel();
      _timer = Timer.periodic(const Duration(seconds: 1), (Timer timer) {
        if (!mounted || !_recording) return;
        setState(() => _seconds++);
        if (_seconds >= 30) {
          unawaited(_stopAndTranscribe());
        }
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _recording = false;
        _error = '录音启动失败：$error';
      });
    }
  }

  Future<void> _stopAndTranscribe() async {
    if (!_recording || _busy) return;
    _timer?.cancel();
    setState(() {
      _recording = false;
      _busy = true;
      _error = null;
    });

    try {
      final String? path = await _recorder.stop();
      _path = path ?? _path;
      if (_path == null || _path!.isEmpty) {
        throw const VoiceAsrException('没有录到音频。');
      }
      final String text = await _asr.transcribe(
        apiKey: widget.apiKey,
        filePath: _path!,
      );
      if (!mounted) return;
      _finished = true;
      Navigator.of(context).pop(text);
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = error.toString();
      });
    } finally {
      await _deleteRecording();
    }
  }

  Future<void> _cancel() async {
    _finished = true;
    _timer?.cancel();
    try {
      await _recorder.cancel();
    } catch (_) {
      // ignore
    }
    await _deleteRecording();
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _deleteRecording() async {
    final String? path = _path;
    _path = null;
    if (path == null) return;
    try {
      final File file = File(path);
      if (await file.exists()) await file.delete();
    } catch (_) {
      // ignore
    }
  }

  @override
  void dispose() {
    _finished = true;
    _timer?.cancel();
    unawaited(_recorder.cancel());
    unawaited(_recorder.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final Color accent = Theme.of(context).colorScheme.primary;
    final String title = _error != null
        ? '没有听清'
        : _busy
        ? '正在识别…'
        : _recording
        ? '我在听，请说…'
        : '准备录音';
    final String subtitle = _error != null
        ? _error!
        : _busy
        ? '正在把语音发送到 SiliconFlow，请稍等'
        : _recording
        ? '最长 30 秒 · 说完点「说完了」'
        : '点下面按钮重新开始';
    final String seconds = '${(_seconds ~/ 60).toString().padLeft(2, '0')}:${(_seconds % 60).toString().padLeft(2, '0')}';

    return Material(
      color: Colors.transparent,
      child: Container(
        padding: EdgeInsets.fromLTRB(
          22,
          14,
          22,
          20 + MediaQuery.of(context).viewInsets.bottom,
        ),
        decoration: BoxDecoration(
          color: palette.backgroundBottom,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
          border: Border.all(color: palette.border),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                width: 38,
                height: 4,
                decoration: BoxDecoration(
                  color: palette.muted.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
              const SizedBox(height: 22),
              AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                width: 96,
                height: 96,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: palette.glass,
                  border: Border.all(
                    color: _recording ? accent : palette.border,
                    width: 1.5,
                  ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: accent.withOpacity(_recording ? 0.3 : 0.08),
                      blurRadius: _recording ? 36 : 12,
                    ),
                  ],
                ),
                child: Icon(
                  _error != null
                      ? Icons.mic_off_rounded
                      : _recording
                      ? Icons.graphic_eq_rounded
                      : Icons.mic_none_rounded,
                  size: 40,
                  color: _error != null ? palette.muted : accent,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                title,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
              if (_recording) ...<Widget>[
                const SizedBox(height: 4),
                Text(
                  seconds,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: accent,
                  ),
                ),
              ],
              const SizedBox(height: 8),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: palette.muted,
                  height: 1.55,
                ),
              ),
              const SizedBox(height: 18),
              if (_error != null)
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => unawaited(_cancel()),
                        child: const Text('关闭'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: _busy ? null : () => unawaited(_begin()),
                        child: const Text('重新录'),
                      ),
                    ),
                  ],
                )
              else if (_busy)
                FilledButton(
                  onPressed: null,
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                      SizedBox(width: 9),
                      Text('识别中'),
                    ],
                  ),
                )
              else
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => unawaited(_cancel()),
                        child: const Text('取消'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: _recording
                            ? () => unawaited(_stopAndTranscribe())
                            : () => unawaited(_begin()),
                        child: Text(_recording ? '说完了' : '开始录音'),
                      ),
                    ),
                  ],
                ),
              const SizedBox(height: 10),
              Text(
                '语音识别由 SiliconFlow 提供，音频仅用于本次转文字。',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: palette.muted.withOpacity(0.6),
                  fontSize: 8.5,
                  height: 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
