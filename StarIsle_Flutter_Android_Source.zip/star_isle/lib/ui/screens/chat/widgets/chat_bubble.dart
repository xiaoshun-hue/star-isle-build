import 'dart:io';

import 'package:flutter/material.dart';

import '../../../../core/decoration_pack.dart';
import '../../../../core/theme/app_palette.dart';
import '../../../../core/utils/app_dates.dart';
import '../../../../core/widgets/companion_avatar.dart';
import '../../../../core/widgets/fade_slide_in.dart';
import '../../../../services/voice_message_service.dart';
import '../../../../data/models/chat_message.dart';
import '../../../../data/models/companion_profile.dart';

class ChatBubble extends StatelessWidget {
  const ChatBubble({
    super.key,
    required this.message,
    required this.profile,
    required this.showAvatar,
    required this.showMeta,
    required this.isSpeaking,
    required this.onSpeak,
    required this.onLongPress,
    required this.onImageTap,
  });

  final ChatMessage message;
  final CompanionProfile profile;
  final bool showAvatar;
  final bool showMeta;
  final bool isSpeaking;
  final VoidCallback onSpeak;
  final VoidCallback onLongPress;
  final VoidCallback onImageTap;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge(<Listenable>[
        DecorationStore.instance,
        VoiceBubbleRegistry.instance,
      ]),
      builder: (BuildContext context, Widget? child) => _buildBubble(context),
    );
  }

  Widget _buildBubble(BuildContext context) {
    if (message.isSystem) return const SizedBox.shrink();
    final DecorationStore decorations = DecorationStore.instance;
    final AvatarFrameDecoration? frame = decorations.avatarFrame;
    final ChatBubbleDecoration? bubbleStyle = decorations.bubbleStyle;
    final ThemeColorDecoration? colorTheme = decorations.colorTheme;
    final VoiceBubbleEntry? voiceEntry = VoiceBubbleRegistry.instance.entry(
      message.id,
    );
    final AppPalette palette = context.palette;
    final bool isUser = message.isUser;
    final double maxWidth = MediaQuery.sizeOf(context).width * 0.73;
    final BorderRadius radius = BorderRadius.only(
      topLeft: Radius.circular(isUser ? 22 : 8),
      topRight: Radius.circular(isUser ? 8 : 22),
      bottomLeft: const Radius.circular(22),
      bottomRight: Radius.circular(isUser ? 22 : 8),
    );

    final Widget content = _content(
      context,
      palette,
      maxWidth,
      radius,
      bubbleStyle,
      colorTheme,
      voiceEntry,
    );
    final Widget meta = showMeta
        ? Padding(
            padding: EdgeInsets.only(
              top: 5,
              left: isUser ? 0 : 7,
              right: isUser ? 7 : 0,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: isUser
                  ? MainAxisAlignment.end
                  : MainAxisAlignment.start,
              children: <Widget>[
                Text(
                  AppDates.clock(message.createdAt),
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted.withOpacity(0.52),
                    fontSize: 9.5,
                    letterSpacing: 0.2,
                  ),
                ),
                if (isUser) ...<Widget>[
                  const SizedBox(width: 4),
                  Icon(
                    Icons.done_all_rounded,
                    size: 12,
                    color: Theme.of(context).colorScheme.primary
                        .withOpacity(0.7),
                  ),
                ],
                if (!isUser && message.kind != MessageKind.image) ...<Widget>[
                  const SizedBox(width: 7),
                  GestureDetector(
                    onTap: onSpeak,
                    behavior: HitTestBehavior.opaque,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 2,
                        vertical: 1,
                      ),
                      child: Icon(
                        isSpeaking
                            ? Icons.graphic_eq_rounded
                            : Icons.volume_up_outlined,
                        size: 13,
                        color: isSpeaking
                            ? Theme.of(context).colorScheme.primary
                            : palette.muted.withOpacity(0.5),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          )
        : const SizedBox.shrink();

    final Widget bubble = GestureDetector(
      onLongPress: onLongPress,
      behavior: HitTestBehavior.deferToChild,
      child: Column(
        crossAxisAlignment: isUser
            ? CrossAxisAlignment.end
            : CrossAxisAlignment.start,
        children: <Widget>[content, meta],
      ),
    );

    final Widget row = Padding(
      padding: EdgeInsets.only(
        left: 12,
        right: 12,
        top: showAvatar ? 7 : 2,
        bottom: showMeta ? 3 : 1,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: isUser
            ? MainAxisAlignment.end
            : MainAxisAlignment.start,
        children: <Widget>[
          if (!isUser)
            SizedBox(
              width: frame == null ? 32 : 41,
              child: showAvatar
                  ? Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: _framedAvatar(
                        CompanionAvatar(
                          seed: profile.avatarSeed,
                          size: 27,
                          nickname: profile.nickname,
                        ),
                        frame,
                      ),
                    )
                  : null,
            ),
          Flexible(child: bubble),
        ],
      ),
    );

    return FadeSlideIn(
      offset: Offset(isUser ? 0.025 : -0.025, 0.035),
      duration: const Duration(milliseconds: 360),
      child: row,
    );
  }

  Widget _framedAvatar(Widget avatar, AvatarFrameDecoration? frame) {
    if (frame == null) return avatar;
    return Container(
      padding: EdgeInsets.all(frame.padding),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[frame.primary, frame.secondary],
        ),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: frame.glow.withOpacity(0.3),
            blurRadius: 9,
            spreadRadius: 0.5,
          ),
        ],
      ),
      child: avatar,
    );
  }

  Widget _content(
    BuildContext context,
    AppPalette palette,
    double maxWidth,
    BorderRadius radius,
    ChatBubbleDecoration? bubbleStyle,
    ThemeColorDecoration? colorTheme,
    VoiceBubbleEntry? voiceEntry,
  ) {
    if (voiceEntry != null &&
        (voiceEntry.isGenerating || voiceEntry.isReady)) {
      return _voiceBubble(
        context,
        palette,
        maxWidth,
        radius,
        bubbleStyle,
        colorTheme,
        voiceEntry,
      );
    }
    final Color userStart =
        bubbleStyle?.userStart ?? colorTheme?.userStart ?? palette.bubbleUserStart;
    final Color userEnd =
        bubbleStyle?.userEnd ?? colorTheme?.userEnd ?? palette.bubbleUserEnd;
    final Color aiColor =
        bubbleStyle?.aiColor ?? colorTheme?.aiColor ?? palette.bubbleAi;
    final Color aiBorder =
        bubbleStyle?.aiBorder ?? colorTheme?.aiBorder ?? palette.border;
    final double? styleRadius = bubbleStyle?.radius;
    final BorderRadius effectiveRadius = styleRadius == null
        ? radius
        : BorderRadius.circular(styleRadius);
    final bool custom = bubbleStyle != null || colorTheme != null;
    final Color aiTextColor = custom
        ? (aiColor.computeLuminance() > 0.56
              ? Colors.black.withOpacity(0.84)
              : Colors.white.withOpacity(0.92))
        : Theme.of(context).colorScheme.onSurface.withOpacity(0.93);
    if (message.kind == MessageKind.image) {
      final String? path = message.imagePath;
      final bool exists = path != null && File(path).existsSync();
      return GestureDetector(
        onTap: onImageTap,
        child: Hero(
          tag: 'chat-image-${message.id}',
          child: Container(
            width: 222,
            height: 274,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: palette.glass,
              border: Border.all(color: palette.border),
            ),
            clipBehavior: Clip.antiAlias,
            child: exists
                ? Image.file(
                    File(path),
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => _imageFallback(context),
                  )
                : _imageFallback(context),
          ),
        ),
      );
    }

    if (message.kind == MessageKind.sticker) {
      final List<String> parts = message.content.split('|');
      final String emoji = parts.first.trim();
      final String? label = parts.length > 1 ? parts[1].trim() : null;
      final bool isUser = message.isUser;
      return Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          gradient: isUser
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[
                    userStart.withOpacity(0.16),
                    userEnd.withOpacity(0.16),
                  ],
                )
              : null,
          color: isUser ? null : aiColor,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: isUser ? userStart.withOpacity(0.22) : aiBorder,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(
              emoji.isEmpty ? '🫧' : emoji,
              style: const TextStyle(fontSize: 43, height: 1.1),
            ),
            if (label != null && label.isNotEmpty) ...<Widget>[
              const SizedBox(width: 10),
              Text(
                label,
                style: Theme.of(context).textTheme.labelMedium?.copyWith(
                  color: isUser
                      ? Theme.of(context).colorScheme.onSurface
                      : Theme.of(context).colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ],
        ),
      );
    }

    final bool isUser = message.isUser;
    return Container(
      constraints: BoxConstraints(maxWidth: maxWidth),
      padding: const EdgeInsets.fromLTRB(15, 11, 15, 12),
      decoration: BoxDecoration(
        gradient: isUser
            ? LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[userStart, userEnd],
              )
            : null,
        color: isUser ? null : aiColor,
        borderRadius: effectiveRadius,
        border: isUser ? null : Border.all(color: aiBorder, width: 0.8),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: palette.shadow.withOpacity(palette.isDark ? 0.16 : 0.06),
            blurRadius: 16,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Text(
        message.content,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
          color: isUser ? Colors.white.withOpacity(0.98) : aiTextColor,
          fontSize: 15.2,
          height: 1.58,
          letterSpacing: 0.1,
        ),
      ),
    );
  }

  Widget _voiceBubble(
    BuildContext context,
    AppPalette palette,
    double maxWidth,
    BorderRadius radius,
    ChatBubbleDecoration? bubbleStyle,
    ThemeColorDecoration? colorTheme,
    VoiceBubbleEntry entry,
  ) {
    final Color aiColor =
        bubbleStyle?.aiColor ?? colorTheme?.aiColor ?? palette.bubbleAi;
    final Color aiBorder =
        bubbleStyle?.aiBorder ?? colorTheme?.aiBorder ?? palette.border;
    final BorderRadius effectiveRadius = bubbleStyle == null
        ? radius
        : BorderRadius.circular(bubbleStyle.radius);
    final bool custom = bubbleStyle != null || colorTheme != null;
    final Color textColor = custom
        ? (aiColor.computeLuminance() > 0.56
              ? Colors.black.withOpacity(0.84)
              : Colors.white.withOpacity(0.92))
        : Theme.of(context).colorScheme.onSurface.withOpacity(0.93);
    final bool generating = entry.isGenerating;
    final bool playing = isSpeaking;

    return GestureDetector(
      onTap: generating ? null : onSpeak,
      child: Container(
        constraints: BoxConstraints(maxWidth: maxWidth),
        padding: const EdgeInsets.fromLTRB(13, 10, 14, 11),
        decoration: BoxDecoration(
          color: aiColor,
          borderRadius: effectiveRadius,
          border: Border.all(color: aiBorder, width: 0.8),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: palette.shadow.withOpacity(
                palette.isDark ? 0.16 : 0.06,
              ),
              blurRadius: 16,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Theme.of(context).colorScheme.primary.withOpacity(0.16),
                border: Border.all(
                  color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                ),
              ),
              child: Center(
                child: generating
                    ? SizedBox(
                        width: 13,
                        height: 13,
                        child: CircularProgressIndicator(
                          strokeWidth: 1.6,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      )
                    : Icon(
                        playing
                            ? Icons.stop_rounded
                            : Icons.play_arrow_rounded,
                        size: 18,
                        color: Theme.of(context).colorScheme.primary,
                      ),
              ),
            ),
            const SizedBox(width: 9),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    entry.text,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: textColor,
                      fontSize: 14.4,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    generating ? '语音生成中…' : (playing ? '正在播放' : '点击播放语音'),
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: textColor.withOpacity(0.55),
                      fontSize: 8.4,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 7),
            Icon(
              Icons.graphic_eq_rounded,
              size: 16,
              color: textColor.withOpacity(0.5),
            ),
          ],
        ),
      ),
    );
  }

  Widget _imageFallback(BuildContext context) {
    final AppPalette palette = context.palette;
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(
            Icons.broken_image_outlined,
            size: 32,
            color: palette.muted.withOpacity(0.5),
          ),
          const SizedBox(height: 8),
          Text(
            '照片迷路了',
            style: Theme.of(context).textTheme.labelSmall
                ?.copyWith(color: palette.muted),
          ),
        ],
      ),
    );
  }
}
