import 'dart:io';

import 'package:flutter/material.dart';

import '../../../../core/theme/app_palette.dart';
import '../../../../core/utils/app_dates.dart';
import '../../../../core/widgets/companion_avatar.dart';
import '../../../../core/widgets/fade_slide_in.dart';
import '../../../../data/models/chat_message.dart';
import '../../../../data/models/companion_profile.dart';

class ChatBubble extends StatelessWidget {
  const ChatBubble({
    super.key,
    required this.message,
    required this.profile,
    required this.showAvatar,
    required this.showMeta,
    required this.isSpeaking,
    required this.onSpeak,
    required this.onLongPress,
    required this.onImageTap,
  });

  final ChatMessage message;
  final CompanionProfile profile;
  final bool showAvatar;
  final bool showMeta;
  final bool isSpeaking;
  final VoidCallback onSpeak;
  final VoidCallback onLongPress;
  final VoidCallback onImageTap;

  @override
  Widget build(BuildContext context) {
    if (message.isSystem) return const SizedBox.shrink();
    final AppPalette palette = context.palette;
    final bool isUser = message.isUser;
    final double maxWidth = MediaQuery.sizeOf(context).width * 0.73;
    final BorderRadius radius = BorderRadius.only(
      topLeft: Radius.circular(isUser ? 22 : 8),
      topRight: Radius.circular(isUser ? 8 : 22),
      bottomLeft: const Radius.circular(22),
      bottomRight: Radius.circular(isUser ? 22 : 8),
    );

    final Widget content = _content(context, palette, maxWidth, radius);
    final Widget meta = showMeta
        ? Padding(
            padding: EdgeInsets.only(
              top: 5,
              left: isUser ? 0 : 7,
              right: isUser ? 7 : 0,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: isUser
                  ? MainAxisAlignment.end
                  : MainAxisAlignment.start,
              children: <Widget>[
                Text(
                  AppDates.clock(message.createdAt),
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted.withOpacity(0.52),
                    fontSize: 9.5,
                    letterSpacing: 0.2,
                  ),
                ),
                if (isUser) ...<Widget>[
                  const SizedBox(width: 4),
                  Icon(
                    Icons.done_all_rounded,
                    size: 12,
                    color: Theme.of(context).colorScheme.primary
                        .withOpacity(0.7),
                  ),
                ],
                if (!isUser && message.kind != MessageKind.image) ...<Widget>[
                  const SizedBox(width: 7),
                  GestureDetector(
                    onTap: onSpeak,
                    behavior: HitTestBehavior.opaque,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 2,
                        vertical: 1,
                      ),
                      child: Icon(
                        isSpeaking
                            ? Icons.graphic_eq_rounded
                            : Icons.volume_up_outlined,
                        size: 13,
                        color: isSpeaking
                            ? Theme.of(context).colorScheme.primary
                            : palette.muted.withOpacity(0.5),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          )
        : const SizedBox.shrink();

    final Widget bubble = GestureDetector(
      onLongPress: onLongPress,
      behavior: HitTestBehavior.deferToChild,
      child: Column(
        crossAxisAlignment: isUser
            ? CrossAxisAlignment.end
            : CrossAxisAlignment.start,
        children: <Widget>[content, meta],
      ),
    );

    final Widget row = Padding(
      padding: EdgeInsets.only(
        left: 12,
        right: 12,
        top: showAvatar ? 7 : 2,
        bottom: showMeta ? 3 : 1,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: isUser
            ? MainAxisAlignment.end
            : MainAxisAlignment.start,
        children: <Widget>[
          if (!isUser)
            SizedBox(
              width: 32,
              child: showAvatar
                  ? Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: CompanionAvatar(
                        seed: profile.avatarSeed,
                        size: 27,
                        nickname: profile.nickname,
                      ),
                    )
                  : null,
            ),
          Flexible(child: bubble),
        ],
      ),
    );

    return FadeSlideIn(
      offset: Offset(isUser ? 0.025 : -0.025, 0.035),
      duration: const Duration(milliseconds: 360),
      child: row,
    );
  }

  Widget _content(
    BuildContext context,
    AppPalette palette,
    double maxWidth,
    BorderRadius radius,
  ) {
    if (message.kind == MessageKind.image) {
      final String? path = message.imagePath;
      final bool exists = path != null && File(path).existsSync();
      return GestureDetector(
        onTap: onImageTap,
        child: Hero(
          tag: 'chat-image-${message.id}',
          child: Container(
            width: 222,
            height: 274,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: palette.glass,
              border: Border.all(color: palette.border),
            ),
            clipBehavior: Clip.antiAlias,
            child: exists
                ? Image.file(
                    File(path),
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => _imageFallback(context),
                  )
                : _imageFallback(context),
          ),
        ),
      );
    }

    if (message.kind == MessageKind.sticker) {
      final List<String> parts = message.content.split('|');
      final String emoji = parts.first.trim();
      final String? label = parts.length > 1 ? parts[1].trim() : null;
      final bool isUser = message.isUser;
      return Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          gradient: isUser
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[
                    palette.bubbleUserStart.withOpacity(0.16),
                    palette.bubbleUserEnd.withOpacity(0.16),
                  ],
                )
              : null,
          color: isUser ? null : palette.bubbleAi,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: isUser
                ? palette.bubbleUserStart.withOpacity(0.22)
                : palette.border,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(
              emoji.isEmpty ? '🫧' : emoji,
              style: const TextStyle(fontSize: 43, height: 1.1),
            ),
            if (label != null && label.isNotEmpty) ...<Widget>[
              const SizedBox(width: 10),
              Text(
                label,
                style: Theme.of(context).textTheme.labelMedium?.copyWith(
                  color: isUser
                      ? Theme.of(context).colorScheme.onSurface
                      : Theme.of(context).colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ],
        ),
      );
    }

    final bool isUser = message.isUser;
    return Container(
      constraints: BoxConstraints(maxWidth: maxWidth),
      padding: const EdgeInsets.fromLTRB(15, 11, 15, 12),
      decoration: BoxDecoration(
        gradient: isUser
            ? LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[palette.bubbleUserStart, palette.bubbleUserEnd],
              )
            : null,
        color: isUser ? null : palette.bubbleAi,
        borderRadius: radius,
        border: isUser ? null : Border.all(color: palette.border, width: 0.8),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: palette.shadow.withOpacity(palette.isDark ? 0.16 : 0.06),
            blurRadius: 16,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Text(
        message.content,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
          color: isUser
              ? Colors.white.withOpacity(0.98)
              : Theme.of(context).colorScheme.onSurface.withOpacity(0.93),
          fontSize: 15.2,
          height: 1.58,
          letterSpacing: 0.1,
        ),
      ),
    );
  }

  Widget _imageFallback(BuildContext context) {
    final AppPalette palette = context.palette;
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(
            Icons.broken_image_outlined,
            size: 32,
            color: palette.muted.withOpacity(0.5),
          ),
          const SizedBox(height: 8),
          Text(
            '照片迷路了',
            style: Theme.of(context).textTheme.labelSmall
                ?.copyWith(color: palette.muted),
          ),
        ],
      ),
    );
  }
}
