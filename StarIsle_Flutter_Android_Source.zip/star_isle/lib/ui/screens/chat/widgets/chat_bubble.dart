import 'dart:io';

import 'package:flutter/material.dart';

import '../../../../core/decoration_pack.dart';
import '../../../../core/theme/app_palette.dart';
import '../../../../core/utils/app_dates.dart';
import '../../../../core/widgets/companion_avatar.dart';
import '../../../../core/widgets/fade_slide_in.dart';
import '../../../../services/sticker_semantics.dart';
import '../../../../services/voice_message_service.dart';
import '../../../../data/models/chat_message.dart';
import '../../../../data/models/companion_profile.dart';

class ChatBubble extends StatelessWidget {
  const ChatBubble({
    super.key,
    required this.message,
    required this.profile,
    required this.showAvatar,
    required this.showMeta,
    required this.isSpeaking,
    required this.onSpeak,
    required this.onLongPress,
    required this.onImageTap,
  });

  final ChatMessage message;
  final CompanionProfile profile;
  final bool showAvatar;
  final bool showMeta;
  final bool isSpeaking;
  final VoidCallback onSpeak;
  final VoidCallback onLongPress;
  final VoidCallback onImageTap;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge(<Listenable>[
        DecorationStore.instance,
        VoiceBubbleRegistry.instance,
      ]),
      builder: (BuildContext context, Widget? child) => _buildBubble(context),
    );
  }

  Widget _buildBubble(BuildContext context) {
    if (message.isSystem) return const SizedBox.shrink();
    final DecorationStore decorations = DecorationStore.instance;
    final AvatarFrameDecoration? frame = decorations.avatarFrame;
    final ChatBubbleDecoration? bubbleStyle = decorations.bubbleStyle;
    final ThemeColorDecoration? colorTheme = decorations.colorTheme;
    final VoiceBubbleEntry? voiceEntry = VoiceBubbleRegistry.instance.entry(
      message.id,
    );
    final AppPalette palette = context.palette;
    final bool isUser = message.isUser;
    final double maxWidth = MediaQuery.sizeOf(context).width * 0.73;
    final BorderRadius radius = BorderRadius.only(
      topLeft: Radius.circular(isUser ? 22 : 8),
      topRight: Radius.circular(isUser ? 8 : 22),
      bottomLeft: const Radius.circular(22),
      bottomRight: Radius.circular(isUser ? 22 : 8),
    );

    final Widget content = _content(
      context,
      palette,
      maxWidth,
      radius,
      bubbleStyle,
      colorTheme,
      voiceEntry,
    );
    final Widget meta = showMeta
        ? Padding(
            padding: EdgeInsets.only(
              top: 5,
              left: isUser ? 0 : 7,
              right: isUser ? 7 : 0,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: isUser
                  ? MainAxisAlignment.end
                  : MainAxisAlignment.start,
              children: <Widget>[
                Text(
                  AppDates.clock(message.createdAt),
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted.withOpacity(0.52),
                    fontSize: 9.5,
                    letterSpacing: 0.2,
                  ),
                ),
                if (isUser) ...<Widget>[
                  const SizedBox(width: 4),
                  Icon(
                    Icons.done_all_rounded,
                    size: 12,
                    color: Theme.of(context).colorScheme.primary
                        .withOpacity(0.7),
                  ),
                ],
                if (!isUser &&
                    message.kind != MessageKind.image &&
                    message.kind != MessageKind.sticker &&
                    message.imagePath == null &&
                    !(message.kind == MessageKind.text &&
                        StickerSemantics.isEmojiOnly(message.content))) ...<Widget>[
                  const SizedBox(width: 7),
                  GestureDetector(
                    onTap: onSpeak,
                    behavior: HitTestBehavior.opaque,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 2,
                        vertical: 1,
                      ),
                      child: Icon(
                        isSpeaking
                            ? Icons.graphic_eq_rounded
                            : Icons.volume_up_outlined,
                        size: 13,
                        color: isSpeaking
                            ? Theme.of(context).colorScheme.primary
                            : palette.muted.withOpacity(0.5),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          )
        : const SizedBox.shrink();

    final Widget bubble = GestureDetector(
      onLongPress: onLongPress,
      behavior: HitTestBehavior.deferToChild,
      child: Column(
        crossAxisAlignment: isUser
            ? CrossAxisAlignment.end
            : CrossAxisAlignment.start,
        children: <Widget>[content, meta],
      ),
    );

    final Widget row = Padding(
      padding: EdgeInsets.only(
        left: 12,
        right: 12,
        top: showAvatar ? 7 : 2,
        bottom: showMeta ? 3 : 1,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: isUser
            ? MainAxisAlignment.end
            : MainAxisAlignment.start,
        children: <Widget>[
          if (!isUser)
            SizedBox(
              width: frame == null ? 32 : 41,
              child: showAvatar
                  ? Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: _framedAvatar(
                        CompanionAvatar(
                          seed: profile.avatarSeed,
                          size: 27,
                          nickname: profile.nickname,
                        ),
                        frame,
                      ),
                    )
                  : null,
            ),
          Flexible(child: bubble),
        ],
      ),
    );

    return FadeSlideIn(
      offset: Offset(isUser ? 0.025 : -0.025, 0.035),
      duration: const Duration(milliseconds: 360),
      child: row,
    );
  }

  Widget _framedAvatar(Widget avatar, AvatarFrameDecoration? frame) {
    if (frame == null) return avatar;
    return Container(
      padding: EdgeInsets.all(frame.padding),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[frame.primary, frame.secondary],
        ),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: frame.glow.withOpacity(0.3),
            blurRadius: 9,
            spreadRadius: 0.5,
          ),
        ],
      ),
      child: avatar,
    );
  }

  Widget _content(
    BuildContext context,
    AppPalette palette,
    double maxWidth,
    BorderRadius radius,
    ChatBubbleDecoration? bubbleStyle,
    ThemeColorDecoration? colorTheme,
    VoiceBubbleEntry? voiceEntry,
  ) {
    if (voiceEntry != null &&
        (voiceEntry.isGenerating || voiceEntry.isReady)) {
      return _voiceBubble(
        context,
        palette,
        maxWidth,
        radius,
        bubbleStyle,
        colorTheme,
        voiceEntry,
      );
    }
    final Color userStart =
        bubbleStyle?.userStart ?? colorTheme?.userStart ?? palette.bubbleUserStart;
    final Color userEnd =
        bubbleStyle?.userEnd ?? colorTheme?.userEnd ?? palette.bubbleUserEnd;
    final Color aiColor =
        bubbleStyle?.aiColor ?? colorTheme?.aiColor ?? palette.bubbleAi;
    final Color aiBorder =
        bubbleStyle?.aiBorder ?? colorTheme?.aiBorder ?? palette.border;
    final double? styleRadius = bubbleStyle?.radius;
    final BorderRadius effectiveRadius = styleRadius == null
        ? radius
        : BorderRadius.circular(styleRadius);
    final bool custom = bubbleStyle != null || colorTheme != null;
    final Color aiTextColor = custom
        ? (aiColor.computeLuminance() > 0.56
              ? Colors.black.withOpacity(0.84)
              : Colors.white.withOpacity(0.92))
        : Theme.of(context).colorScheme.onSurface.withOpacity(0.93);
    if (message.kind == MessageKind.image) {
      final String? path = message.imagePath;
      final bool exists = path != null && File(path).existsSync();
      return GestureDetector(
        onTap: onImageTap,
        child: Hero(
          tag: 'chat-image-${message.id}',
          child: Container(
            width: 222,
            height: 274,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: palette.glass,
              border: Border.all(color: palette.border),
            ),
            clipBehavior: Clip.antiAlias,
            child: exists
                ? Image.file(
                    File(path),
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => _imageFallback(context),
                  )
                : _imageFallback(context),
          ),
        ),
      );
    }

    if (message.kind == MessageKind.sticker &&
        message.imagePath != null &&
        File(message.imagePath!).existsSync()) {
      // 微信式：单发表情包不套气泡；图片按原始比例放大展示。
      return GestureDetector(
        onTap: onImageTap,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 188, maxHeight: 188),
          margin: const EdgeInsets.symmetric(vertical: 3),
          child: Image.file(
            File(message.imagePath!),
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => _stickerFallback(context, palette),
          ),
        ),
      );
    }

    if (message.kind == MessageKind.sticker) {
      // 单发表情：不套气泡，只显示表情本体；语义标签不进入界面。
      final String emoji = StickerSemantics.find(message.content)?.emoji ??
          message.content.split('|').first.trim();
      return _standaloneEmoji(emoji.isEmpty ? '🫧' : emoji);
    }

    if (message.kind == MessageKind.text &&
        StickerSemantics.isEmojiOnly(message.content)) {
      // 输入框里只发了一个/一组表情，也按微信单发表情处理。
      return _standaloneEmoji(message.content.trim());
    }

    final bool isUser = message.isUser;
    return Container(
      constraints: BoxConstraints(maxWidth: maxWidth),
      padding: const EdgeInsets.fromLTRB(15, 11, 15, 12),
      decoration: BoxDecoration(
        gradient: isUser
            ? LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[userStart, userEnd],
              )
            : null,
        color: isUser ? null : aiColor,
        borderRadius: effectiveRadius,
        border: isUser ? null : Border.all(color: aiBorder, width: 0.8),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: palette.shadow.withOpacity(palette.isDark ? 0.16 : 0.06),
            blurRadius: 16,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Text(
        message.content,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
          color: isUser ? Colors.white.withOpacity(0.98) : aiTextColor,
          fontSize: 15.2,
          height: 1.58,
          letterSpacing: 0.1,
        ),
      ),
    );
  }

  Widget _standaloneEmoji(String emoji) {
    final int length = emoji.runes.length;
    final double size = length <= 2 ? 64 : (length <= 5 ? 50 : 38);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 2),
      child: Text(
        emoji,
        textAlign: TextAlign.left,
        style: TextStyle(fontSize: size, height: 1.08),
      ),
    );
  }

  Widget _voiceBubble(
    BuildContext context,
    AppPalette palette,
    double maxWidth,
    BorderRadius radius,
    ChatBubbleDecoration? bubbleStyle,
    ThemeColorDecoration? colorTheme,
    VoiceBubbleEntry entry,
  ) {
    final bool isUser = message.isUser;
    final Color userStart =
        bubbleStyle?.userStart ?? colorTheme?.userStart ?? palette.bubbleUserStart;
    final Color userEnd =
        bubbleStyle?.userEnd ?? colorTheme?.userEnd ?? palette.bubbleUserEnd;
    final Color aiColor =
        bubbleStyle?.aiColor ?? colorTheme?.aiColor ?? palette.bubbleAi;
    final Color aiBorder =
        bubbleStyle?.aiBorder ?? colorTheme?.aiBorder ?? palette.border;
    final BorderRadius effectiveRadius = bubbleStyle == null
        ? radius
        : BorderRadius.circular(bubbleStyle.radius);
    final bool custom = bubbleStyle != null || colorTheme != null;
    final Color textColor = isUser
        ? Colors.white.withOpacity(0.97)
        : (custom
              ? (aiColor.computeLuminance() > 0.56
                    ? Colors.black.withOpacity(0.84)
                    : Colors.white.withOpacity(0.92))
              : Theme.of(context).colorScheme.onSurface.withOpacity(0.93));
    final Color accent = isUser
        ? Colors.white.withOpacity(0.92)
        : Theme.of(context).colorScheme.primary;
    final bool generating = entry.isGenerating;
    final bool playing = isSpeaking;
    final String duration = entry.durationMs == null
        ? '语音'
        : '${(entry.durationMs! / 1000).ceil()}″';

    return GestureDetector(
      onTap: generating ? null : onSpeak,
      child: Container(
        constraints: BoxConstraints(maxWidth: maxWidth),
        padding: const EdgeInsets.fromLTRB(12, 10, 14, 11),
        decoration: BoxDecoration(
          gradient: isUser
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[userStart, userEnd],
                )
              : null,
          color: isUser ? null : aiColor,
          borderRadius: effectiveRadius,
          border: Border.all(
            color: isUser ? userStart.withOpacity(0.28) : aiBorder,
            width: 0.8,
          ),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: palette.shadow.withOpacity(
                palette.isDark ? 0.16 : 0.06,
              ),
              blurRadius: 16,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              width: 31,
              height: 31,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isUser
                    ? Colors.white.withOpacity(0.18)
                    : Theme.of(context).colorScheme.primary.withOpacity(0.16),
                border: Border.all(
                  color: isUser
                      ? Colors.white.withOpacity(0.35)
                      : Theme.of(context).colorScheme.primary.withOpacity(0.3),
                ),
              ),
              child: Center(
                child: generating
                    ? SizedBox(
                        width: 13,
                        height: 13,
                        child: CircularProgressIndicator(
                          strokeWidth: 1.6,
                          color: accent,
                        ),
                      )
                    : Icon(
                        playing
                            ? Icons.stop_rounded
                            : Icons.play_arrow_rounded,
                        size: 19,
                        color: accent,
                      ),
              ),
            ),
            const SizedBox(width: 9),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      _waveform(textColor.withOpacity(0.62)),
                      const SizedBox(width: 7),
                      Text(
                        duration,
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: textColor.withOpacity(0.68),
                          fontSize: 8.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(
                    entry.text,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: textColor.withOpacity(0.9),
                      fontSize: 11.8,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    generating
                        ? '语音生成中…'
                        : (playing ? '正在播放' : '点击播放语音'),
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: textColor.withOpacity(0.5),
                      fontSize: 8,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _waveform(Color color) {
    const List<double> heights = <double>[7, 12, 9, 16, 11, 18, 8, 14, 10, 17, 7, 12];
    return SizedBox(
      width: 47,
      height: 18,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: heights.map((double height) {
          return Container(
            width: 2.1,
            height: height,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(99),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _stickerFallback(BuildContext context, AppPalette palette) {
    return Container(
      width: 120,
      height: 120,
      alignment: Alignment.center,
      child: Icon(
        Icons.broken_image_outlined,
        size: 28,
        color: palette.muted.withOpacity(0.55),
      ),
    );
  }

  Widget _imageFallback(BuildContext context) {
    final AppPalette palette = context.palette;
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(
            Icons.broken_image_outlined,
            size: 32,
            color: palette.muted.withOpacity(0.5),
          ),
          const SizedBox(height: 8),
          Text(
            '照片迷路了',
            style: Theme.of(context).textTheme.labelSmall
                ?.copyWith(color: palette.muted),
          ),
        ],
      ),
    );
  }
}
