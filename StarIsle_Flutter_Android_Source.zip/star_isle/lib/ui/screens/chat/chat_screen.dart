import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/utils/app_dates.dart';
import '../../../core/utils/app_feedback.dart';
import '../../../core/widgets/app_feedback_widgets.dart';
import '../../../core/widgets/app_sheet.dart';
import '../../../core/widgets/companion_avatar.dart';
import '../../../core/widgets/glass_icon_button.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../core/widgets/typing_dots.dart';
import '../../../data/models/chat_message.dart';
import '../../../data/models/companion_profile.dart';
import '../../../services/media_service.dart';
import '../../../services/voice_message_service.dart';
import '../../../services/tts_service.dart';
import '../../../state/companion_controller.dart';
import '../../../state/settings_controller.dart';
import '../album/photo_viewer_screen.dart';
import '../profile/ai_profile_screen.dart';
import '../profile/memory_book_screen.dart';
import '../settings/ai_settings_screen.dart';
import '../settings/companion_settings_screen.dart';
import 'widgets/chat_bubble.dart';
import 'widgets/chat_composer.dart';
import 'widgets/voice_input_sheet.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen>
    with AutomaticKeepAliveClientMixin {
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _textController = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  bool _extrasOpen = false;
  bool _pickingImage = false;
  bool _showJumpButton = false;
  bool _didInitialScroll = false;
  int _lastMessageCount = -1;
  bool _lastTyping = false;

  static const String _draftKey = 'star_isle_chat_draft_v1';
  Timer? _draftTimer;
  bool _restoringDraft = false;
  ChatMessage? _quotedMessage;
  final List<File> _pendingImages = <File>[];
  int _visibleMessageCount = 80;
  bool _loadingOlder = false;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
    _textController.addListener(_onDraftChanged);
    unawaited(_restoreDraft());
  }

  @override
  void dispose() {
    _draftTimer?.cancel();
    // 先同步读取文本，再异步写入；避免 controller 被 dispose 后读取。
    unawaited(_persistDraftNow());
    _textController.removeListener(_onDraftChanged);
    _scrollController
      ..removeListener(_onScroll)
      ..dispose();
    _textController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  Future<void> _restoreDraft() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final String draft = prefs.getString(_draftKey) ?? '';
      if (!mounted || draft.isEmpty || _textController.text.isNotEmpty) return;
      _restoringDraft = true;
      _textController.value = TextEditingValue(
        text: draft,
        selection: TextSelection.collapsed(offset: draft.length),
      );
      _restoringDraft = false;
    } catch (error) {
      debugPrint('restore chat draft failed: $error');
      _restoringDraft = false;
    }
  }

  void _onDraftChanged() {
    if (_restoringDraft) return;
    _draftTimer?.cancel();
    _draftTimer = Timer(const Duration(milliseconds: 450), () {
      unawaited(_persistDraftNow());
    });
  }

  Future<void> _persistDraftNow() async {
    final String text = _textController.text;
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      if (text.trim().isEmpty) {
        await prefs.remove(_draftKey);
      } else {
        await prefs.setString(_draftKey, text);
      }
    } catch (error) {
      debugPrint('save chat draft failed: $error');
    }
  }

  Future<void> _clearDraft() async {
    _draftTimer?.cancel();
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.remove(_draftKey);
    } catch (error) {
      debugPrint('clear chat draft failed: $error');
    }
  }

  void _onScroll() {
    if (!_scrollController.hasClients) return;
    final bool nearBottom =
        _scrollController.position.maxScrollExtent -
            _scrollController.position.pixels <
        150;
    if (nearBottom && _showJumpButton) {
      setState(() => _showJumpButton = false);
    }
    if (_didInitialScroll && _scrollController.position.pixels < 80) {
      _loadOlderMessages();
    }
  }

  void _loadOlderMessages() {
    if (_loadingOlder || !mounted) return;
    final CompanionController chat = context.read<CompanionController>();
    final int total = chat.messages.length;
    if (_visibleMessageCount >= total) return;
    final double oldMax = _scrollController.position.maxScrollExtent;
    final double oldPixels = _scrollController.position.pixels;
    _loadingOlder = true;
    setState(() {
      _visibleMessageCount =
          (_visibleMessageCount + 60).clamp(0, total).toInt();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadingOlder = false;
      if (!mounted || !_scrollController.hasClients) return;
      final double newMax = _scrollController.position.maxScrollExtent;
      final double target = (oldPixels + newMax - oldMax)
          .clamp(0.0, newMax)
          .toDouble();
      _scrollController.jumpTo(target);
    });
  }

  bool _isNearBottom() {
    if (!_scrollController.hasClients) return true;
    return _scrollController.position.maxScrollExtent -
            _scrollController.position.pixels <
        170;
  }

  void _scrollToBottom({bool animate = true}) {
    if (!_scrollController.hasClients) return;
    final double target = _scrollController.position.maxScrollExtent;
    if (animate) {
      _scrollController.animateTo(
        target,
        duration: const Duration(milliseconds: 420),
        curve: Curves.easeOutCubic,
      );
    } else {
      _scrollController.jumpTo(target);
    }
    if (_showJumpButton) setState(() => _showJumpButton = false);
  }

  void _scheduleAutoScroll(CompanionController chat) {
    final bool initial = !_didInitialScroll;
    final bool countChanged = chat.messages.length != _lastMessageCount;
    final bool typingChanged = chat.isTyping != _lastTyping;
    final bool lastIsUser =
        chat.messages.isNotEmpty && chat.messages.last.isUser;

    _lastMessageCount = chat.messages.length;
    _lastTyping = chat.isTyping;
    if (!(initial || countChanged || typingChanged)) return;

    final bool shouldStick = initial || _isNearBottom() || lastIsUser;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (initial) {
        _didInitialScroll = true;
        _scrollToBottom(animate: false);
        return;
      }
      if (shouldStick) {
        _scrollToBottom();
      } else if (countChanged && !lastIsUser) {
        if (!_showJumpButton) setState(() => _showJumpButton = true);
      }
    });
  }

  Future<void> _handleSend(CompanionController chat) async {
    final String text = _textController.text.trim();
    if (text.isEmpty || chat.isReplying) return;

    final ChatMessage? quote = _quotedMessage;
    final String outgoing = quote == null
        ? text
        : '（引用回复${quote.isUser ? '你' : chat.profile.nickname}：'
              '${_clipForQuote(_displayQuote(quote), 60)}）\n$text';

    _draftTimer?.cancel();
    _textController.clear();
    setState(() {
      _extrasOpen = false;
      _quotedMessage = null;
    });
    unawaited(_clearDraft());
    AppFeedback.impact(context.read<SettingsController>().haptics);
    final bool accepted = await chat.sendText(outgoing);
    if (!accepted && mounted) {
      _textController.value = TextEditingValue(
        text: text,
        selection: TextSelection.collapsed(offset: text.length),
      );
      setState(() => _quotedMessage = quote);
      showAppToast(context, '晚晚还在打字，等一下再说。');
    }
  }

  String _displayQuote(ChatMessage message) {
    final String content = message.kind == MessageKind.sticker
        ? message.content.replaceAll('|', ' ')
        : message.content;
    return content.replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  String _clipForQuote(String value, int max) {
    if (value.runes.length <= max) return value;
    return '${String.fromCharCodes(value.runes.take(max))}…';
  }

  Future<void> _handlePickMultipleImages(CompanionController chat) async {
    if (_pickingImage || chat.isReplying) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _pickingImage = true;
      _extrasOpen = false;
    });
    try {
      final List<File> files = await MediaService.pickImagesFromGallery(
        limit: 9,
      );
      if (!mounted) return;
      if (files.isNotEmpty) {
        setState(() => _pendingImages
          ..clear()
          ..addAll(files));
        showAppToast(context, '已选择 ${files.length} 张，多图发送接口已预留。');
      }
    } finally {
      if (mounted) setState(() => _pickingImage = false);
    }
  }

  Future<void> _handlePickImage(CompanionController chat) async {
    if (_pickingImage || chat.isReplying) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _pickingImage = true;
      _extrasOpen = false;
    });
    try {
      final bool sent = await chat.pickAndSendImage();
      if (!mounted) return;
      if (sent) {
        AppFeedback.impact(context.read<SettingsController>().haptics);
      }
    } finally {
      if (mounted) setState(() => _pickingImage = false);
    }
  }

  Future<void> _handlePickStickerImage(CompanionController chat) async {
    if (_pickingImage || chat.isReplying) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _extrasOpen = false;
      _pickingImage = true;
    });
    try {
      final bool sent = await chat.pickAndSendStickerImage();
      if (sent && mounted) {
        AppFeedback.impact(context.read<SettingsController>().haptics);
      }
    } finally {
      if (mounted) setState(() => _pickingImage = false);
    }
  }

  Future<void> _handleSticker(CompanionController chat, String sticker) async {
    if (chat.isReplying) {
      showAppToast(context, '等她说完这句再发吧。');
      return;
    }
    AppFeedback.tap(context.read<SettingsController>().haptics);
    await chat.sendSticker(sticker);
  }

  void _handleEmojiAppend(String emoji) {
    final TextSelection selection = _textController.selection;
    final String text = _textController.text;
    final int start = selection.isValid ? selection.start : text.length;
    final int end = selection.isValid ? selection.end : text.length;
    _textController.value = TextEditingValue(
      text: text.replaceRange(start, end, emoji),
      selection: TextSelection.collapsed(offset: start + emoji.length),
    );
  }

  void _toggleExtras() {
    if (_extrasOpen) {
      setState(() => _extrasOpen = false);
      _focusNode.requestFocus();
    } else {
      FocusScope.of(context).unfocus();
      setState(() => _extrasOpen = true);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _scrollToBottom();
      });
    }
  }

  void _handleInputFocus() {
    if (_extrasOpen) setState(() => _extrasOpen = false);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && _isNearBottom()) _scrollToBottom();
    });
  }

  Future<void> _toggleAutoSpeak(SettingsController settings) async {
    final bool next = !settings.autoSpeak;
    if (!next) {
      await context.read<TtsService>().stop();
    }
    await settings.setAutoSpeak(next);
    if (mounted) {
      showAppToast(
        context,
        next ? '已开启自动朗读' : '已关闭自动朗读',
        icon: next ? Icons.graphic_eq_rounded : Icons.volume_off_rounded,
      );
    }
  }

  Future<bool> _ensureVoiceApiKey(SettingsController settings) async {
    if (settings.hasVoiceApiKey) return true;
    final TextEditingController controller = TextEditingController();
    final String? key = await showDialog<String>(
      context: context,
      builder: (BuildContext context) {
        final AppPalette palette = context.palette;
        return AlertDialog(
          title: const Text('语音识别 Key'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Text(
                '语音识别使用 SiliconFlow，需要单独申请一个 API Key。'
                'Key 只保存在本机，不会发给我。',
                style: TextStyle(height: 1.55),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: controller,
                obscureText: true,
                autocorrect: false,
                enableSuggestions: false,
                decoration: const InputDecoration(
                  labelText: 'SiliconFlow API Key',
                  hintText: 'sk-...',
                  prefixIcon: Icon(Icons.key_rounded, size: 19),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                '获取地址：cloud.siliconflow.cn/account/ak',
                style: TextStyle(fontSize: 10, color: palette.muted),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(controller.text.trim()),
              child: const Text('保存'),
            ),
          ],
        );
      },
    );
    controller.dispose();
    if (key == null || key.isEmpty) return false;
    await settings.saveVoiceApiKey(key);
    return true;
  }

  Future<void> _startVoiceInput(
    SettingsController settings,
    CompanionController chat,
  ) async {
    if (chat.isReplying) {
      showAppToast(context, '她还在回复，稍等一下再说。');
      return;
    }
    if (!await _ensureVoiceApiKey(settings)) return;
    if (!mounted) return;
    FocusScope.of(context).unfocus();
    final VoiceInputResult? recognized =
        await showModalBottomSheet<VoiceInputResult>(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (BuildContext context) =>
              VoiceInputSheet(apiKey: settings.voiceApiKey),
        );
    if (!mounted || recognized == null || recognized.text.trim().isEmpty) {
      return;
    }

    // 语音识别只负责把语音变成文字，不擅自打开自动朗读。
    final bool sent = await chat.sendVoiceMessage(
      rawText: recognized.text,
      audioPath: recognized.audioPath,
      durationMs: recognized.durationMs,
    );
    if (!sent && mounted) {
      showAppToast(context, '语音内容没有发出去，再试一次吧。');
    }
  }

  Future<void> _speakMessage(String messageId, String content) async {
    final TtsService tts = context.read<TtsService>();
    if (tts.speakingId == messageId) {
      await tts.stop();
      return;
    }

    final VoiceBubbleEntry? voice =
        VoiceBubbleRegistry.instance.entry(messageId);
    if (voice != null) {
      if (voice.isGenerating) {
        showAppToast(context, '语音还在生成，稍等一下。');
        return;
      }
      if (voice.isReady) {
        final bool ok = await tts.playFile(
          messageId,
          voice.audioPath!,
          fallbackText: content,
        );
        if (!ok && mounted) {
          showAppToast(context, '语音播放失败，已尝试使用系统朗读。');
        }
        return;
      }
    }

    final bool ok = await tts.speak(messageId, content);
    if (!ok && mounted) {
      showAppToast(context, '这台手机暂时没有可用的语音引擎。');
    }
  }

  void _openPage(Widget page) {
    FocusScope.of(context).unfocus();
    Navigator.of(context).push(
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 420),
        reverseTransitionDuration: const Duration(milliseconds: 320),
        pageBuilder: (_, __, ___) => page,
        transitionsBuilder: (_, Animation<double> animation, __, Widget child) {
          final CurvedAnimation curve = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
          );
          return FadeTransition(
            opacity: curve,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.055, 0),
                end: Offset.zero,
              ).animate(curve),
              child: child,
            ),
          );
        },
      ),
    );
  }

  Future<void> _openImage(ChatMessage message) async {
    final String? path = message.imagePath;
    if (path == null) return;
    await Navigator.of(context).push(
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 330),
        pageBuilder: (_, __, ___) => PhotoViewerScreen(
          paths: <String>[path],
          initialIndex: 0,
          title: '来自${context.read<CompanionController>().profile.nickname}的照片',
          heroTag: 'chat-image-${message.id}',
        ),
      ),
    );
  }

  Future<void> _showMessageMenu(ChatMessage message) async {
    AppFeedback.impact(context.read<SettingsController>().haptics);
    final CompanionController chat = context.read<CompanionController>();
    final TtsService tts = context.read<TtsService>();
    final bool isSpeaking = tts.speakingId == message.id;
    final String copyText = message.kind == MessageKind.sticker
        ? message.content.replaceAll('|', ' ')
        : message.content;
    final BuildContext outer = context;
    await showGlassSheet<void>(
      context,
      title: '这条消息',
      child: SheetBody(
        scroll: false,
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (copyText.trim().isNotEmpty &&
                message.kind != MessageKind.image &&
                message.imagePath == null)
              _SheetAction(
                icon: Icons.content_copy_rounded,
                label: '复制文字',
                onTap: () {
                  Navigator.of(context).pop();
                  Clipboard.setData(ClipboardData(text: copyText));
                  showAppToast(outer, '已复制');
                },
              ),
            if (message.kind != MessageKind.image)
              _SheetAction(
                icon: Icons.format_quote_rounded,
                label: '引用回复',
                onTap: () {
                  Navigator.of(context).pop();
                  setState(() => _quotedMessage = message);
                  FocusScope.of(context).requestFocus(_focusNode);
                },
              ),
            if (message.isAi && message.kind != MessageKind.image)
              _SheetAction(
                icon: isSpeaking
                    ? Icons.stop_circle_outlined
                    : Icons.volume_up_outlined,
                label: isSpeaking ? '停止朗读' : '朗读这条消息',
                onTap: () {
                  Navigator.of(context).pop();
                  unawaited(_speakMessage(message.id, message.content));
                },
              ),
            if (message.imagePath != null)
              _SheetAction(
                icon: Icons.fullscreen_rounded,
                label: '查看大图',
                onTap: () {
                  Navigator.of(context).pop();
                  unawaited(_openImage(message));
                },
              ),
            _SheetAction(
              icon: Icons.delete_outline_rounded,
              label: '删除这条消息',
              destructive: true,
              onTap: () async {
                Navigator.of(context).pop();
                final bool confirmed = await showAppConfirm(
                  outer,
                  title: '删除这条消息？',
                  message: '它会从你们的聊天记录里消失，但已经收藏进相册的图片不会一起删除。',
                  confirmLabel: '删除',
                  destructive: true,
                );
                if (confirmed) {
                  await chat.deleteMessage(message.id);
                  if (outer.mounted) {
                    showAppToast(outer, '已删除');
                  }
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showHeaderMenu(CompanionController chat) async {
    final BuildContext outer = context;
    await showGlassSheet<void>(
      context,
      title: chat.profile.nickname,
      child: SheetBody(
        scroll: false,
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            _SheetAction(
              icon: Icons.favorite_outline_rounded,
              label: '她的主页',
              onTap: () {
                Navigator.of(context).pop();
                _openPage(const AiProfileScreen());
              },
            ),
            _SheetAction(
              icon: Icons.auto_stories_outlined,
              label: '长期记忆簿',
              onTap: () {
                Navigator.of(context).pop();
                _openPage(const MemoryBookScreen());
              },
            ),
            _SheetAction(
              icon: Icons.tune_rounded,
              label: '人格与陪伴偏好',
              onTap: () {
                Navigator.of(context).pop();
                _openPage(const CompanionSettingsScreen());
              },
            ),
            _SheetAction(
              icon: Icons.wifi_tethering_rounded,
              label: '连接与模型',
              onTap: () {
                Navigator.of(context).pop();
                _openPage(const AiSettingsScreen());
              },
            ),
            const SizedBox(height: 4),
            Text(
              '所有对话都保存在这台设备上。',
              style: Theme.of(outer).textTheme.labelSmall
                  ?.copyWith(color: outer.palette.muted),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showStarterPrompt(String text, CompanionController chat) async {
    if (chat.isReplying) return;
    AppFeedback.tap(context.read<SettingsController>().haptics);
    await chat.sendText(text);
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final AppPalette palette = context.palette;
    final CompanionController chat = context.watch<CompanionController>();
    final SettingsController settings = context.watch<SettingsController>();
    final TtsService tts = context.watch<TtsService>();
    final List<_ChatRow> rows = _buildRows(chat);
    _scheduleAutoScroll(chat);

    final bool hasUserMessage = chat.messages.any(
      (ChatMessage message) => message.isUser,
    );
    final bool showStarter = !hasUserMessage && !chat.isTyping;

    return SafeArea(
      bottom: false,
      child: Column(
        children: <Widget>[
          _buildHeader(context, chat, settings, tts, palette),
          Expanded(
            child: Stack(
              children: <Widget>[
                if (rows.isEmpty)
                  _buildEmptyChat(context, chat, palette)
                else
                  ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.only(top: 4, bottom: 10),
                    physics: const BouncingScrollPhysics(
                      parent: AlwaysScrollableScrollPhysics(),
                    ),
                    keyboardDismissBehavior:
                        ScrollViewKeyboardDismissBehavior.onDrag,
                    itemCount: rows.length,
                    itemBuilder: (BuildContext context, int index) {
                      return _buildRow(context, rows[index], chat, tts);
                    },
                  ),
                AnimatedPositioned(
                  duration: const Duration(milliseconds: 240),
                  curve: Curves.easeOutCubic,
                  right: 15,
                  bottom: _showJumpButton ? 12 : -48,
                  child: AnimatedOpacity(
                    opacity: _showJumpButton ? 1 : 0,
                    duration: const Duration(milliseconds: 200),
                    child: PressableScale(
                      onTap: () => _scrollToBottom(),
                      child: Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: palette.glassStrong,
                          border: Border.all(color: palette.border),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: palette.shadow.withOpacity(0.16),
                              blurRadius: 14,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.keyboard_arrow_down_rounded,
                          size: 22,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (showStarter) _buildStarterPrompts(context, chat, palette),
          if (_quotedMessage != null)
            _buildQuoteBar(context, palette, chat.profile.nickname),
          if (_pendingImages.isNotEmpty)
            _buildPendingImages(context, palette),
          AnimatedSize(
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeOutCubic,
            child: _extrasOpen
                ? ChatExtrasPanel(
                    onEmojiSelected: _handleEmojiAppend,
                    onStickerSelected: (String value) {
                      unawaited(_handleSticker(chat, value));
                    },
                    onPickStickerImage: () => unawaited(
                      _handlePickStickerImage(chat),
                    ),
                    onShowKeyboard: _toggleExtras,
                  )
                : const SizedBox.shrink(),
          ),
          ChatComposer(
            controller: _textController,
            focusNode: _focusNode,
            isReplying: chat.isReplying,
            isPickingImage: _pickingImage,
            extrasOpen: _extrasOpen,
            hintText: '和${chat.profile.nickname}说点什么…',
            onToggleExtras: _toggleExtras,
            onPickImage: () => unawaited(_handlePickImage(chat)),
            onPickImages: () => unawaited(_handlePickMultipleImages(chat)),
            onVoice: () => unawaited(_startVoiceInput(settings, chat)),
            onSend: () => unawaited(_handleSend(chat)),
            onInputFocus: _handleInputFocus,
          ),
        ],
      ),
    );
  }

  Widget _buildQuoteBar(
    BuildContext context,
    AppPalette palette,
    String nickname,
  ) {
    final ChatMessage quote = _quotedMessage!;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 5, 16, 0),
      child: Container(
        padding: const EdgeInsets.fromLTRB(11, 7, 4, 7),
        decoration: BoxDecoration(
          color: palette.glass,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: palette.border),
        ),
        child: Row(
          children: <Widget>[
            Icon(
              Icons.format_quote_rounded,
              size: 16,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(width: 7),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    '回复${quote.isUser ? '你' : nickname}',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: Theme.of(context).colorScheme.primary,
                      fontSize: 8.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _displayQuote(quote),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: palette.muted,
                      fontSize: 9.5,
                    ),
                  ),
                ],
              ),
            ),
            IconButton(
              visualDensity: VisualDensity.compact,
              onPressed: () => setState(() => _quotedMessage = null),
              icon: Icon(
                Icons.close_rounded,
                size: 16,
                color: palette.muted,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPendingImages(BuildContext context, AppPalette palette) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 5, 16, 0),
      child: Container(
        padding: const EdgeInsets.fromLTRB(8, 7, 6, 7),
        decoration: BoxDecoration(
          color: palette.glass,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: palette.border),
        ),
        child: Row(
          children: <Widget>[
            Expanded(
              child: SizedBox(
                height: 56,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: _pendingImages.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 6),
                  itemBuilder: (BuildContext context, int index) {
                    final File file = _pendingImages[index];
                    return Stack(
                      children: <Widget>[
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.file(
                            file,
                            width: 56,
                            height: 56,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              width: 56,
                              height: 56,
                              color: palette.muted.withOpacity(0.12),
                              child: Icon(
                                Icons.broken_image_outlined,
                                size: 18,
                                color: palette.muted,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          right: 0,
                          top: 0,
                          child: GestureDetector(
                            onTap: () => setState(
                              () => _pendingImages.removeAt(index),
                            ),
                            child: Container(
                              width: 18,
                              height: 18,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.black.withOpacity(0.55),
                              ),
                              child: const Icon(
                                Icons.close_rounded,
                                size: 12,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ),
            const SizedBox(width: 5),
            TextButton(
              onPressed: () => setState(_pendingImages.clear),
              style: TextButton.styleFrom(
                visualDensity: VisualDensity.compact,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                minimumSize: const Size(0, 32),
              ),
              child: Text(
                '清空',
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: palette.muted,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(
    BuildContext context,
    CompanionController chat,
    SettingsController settings,
    TtsService tts,
    AppPalette palette,
  ) {
    final Color accent = Theme.of(context).colorScheme.primary;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 6, 12, 2),
      child: Row(
        children: <Widget>[
          PressableScale(
            onTap: () => _openPage(const AiProfileScreen()),
            scale: 0.94,
            child: CompanionAvatar(
              seed: chat.profile.avatarSeed,
              size: 47,
              nickname: chat.profile.nickname,
              showOnline: true,
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => _openPage(const AiProfileScreen()),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Flexible(
                        child: Text(
                          chat.profile.nickname,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.titleMedium
                              ?.copyWith(
                                fontWeight: FontWeight.w700,
                                letterSpacing: -0.1,
                              ),
                        ),
                      ),
                      const SizedBox(width: 6),
                      GestureDetector(
                        onTap: () => _openPage(const AiSettingsScreen()),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 7,
                            vertical: 2.5,
                          ),
                          decoration: BoxDecoration(
                            color: settings.onlineReady
                                ? accent.withOpacity(0.12)
                                : palette.glass,
                            borderRadius: BorderRadius.circular(99),
                            border: Border.all(
                              color: settings.onlineReady
                                  ? accent.withOpacity(0.25)
                                  : palette.border,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Icon(
                                settings.onlineReady
                                    ? Icons.bolt_rounded
                                    : Icons.cloud_off_rounded,
                                size: 10,
                                color: settings.onlineReady
                                    ? accent
                                    : palette.muted,
                              ),
                              const SizedBox(width: 3),
                              Text(
                                settings.onlineReady ? '联网' : '单机',
                                style: Theme.of(context).textTheme.labelSmall
                                    ?.copyWith(
                                      fontSize: 8.5,
                                      color: settings.onlineReady
                                          ? accent
                                          : palette.muted,
                                      fontWeight: FontWeight.w600,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 220),
                    child: Row(
                      key: ValueKey<String>(
                        '${chat.isTyping}_${chat.profile.mood}',
                      ),
                      children: <Widget>[
                        Container(
                          width: 5,
                          height: 5,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: chat.isTyping
                                ? accent
                                : const Color(0xFF6AE5AE),
                          ),
                        ),
                        const SizedBox(width: 5),
                        Flexible(
                          child: Text(
                            chat.profileStatusLine,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.labelSmall
                                ?.copyWith(
                                  color: chat.isTyping ? accent : palette.muted,
                                  fontSize: 10.5,
                                  letterSpacing: 0.1,
                                ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 6),
          GlassIconButton(
            icon: settings.autoSpeak
                ? Icons.graphic_eq_rounded
                : Icons.volume_off_outlined,
            size: 39,
            iconSize: 18,
            active: settings.autoSpeak,
            tooltip: settings.autoSpeak ? '关闭自动朗读' : '开启自动朗读',
            onTap: () => unawaited(_toggleAutoSpeak(settings)),
          ),
          const SizedBox(width: 7),
          GlassIconButton(
            icon: Icons.more_horiz_rounded,
            size: 39,
            iconSize: 20,
            tooltip: '更多',
            onTap: () => unawaited(_showHeaderMenu(chat)),
          ),
        ],
      ),
    );
  }

  List<_ChatRow> _buildRows(CompanionController chat) {
    final List<ChatMessage> all = chat.messages;
    final int start = all.length > _visibleMessageCount
        ? all.length - _visibleMessageCount
        : 0;
    final List<ChatMessage> messages = all.sublist(start);
    final List<_ChatRow> rows = <_ChatRow>[];
    DateTime? lastDate;
    for (int i = 0; i < messages.length; i++) {
      final ChatMessage message = messages[i];
      if (lastDate == null ||
          !AppDates.isSameDay(lastDate, message.createdAt)) {
        rows.add(
          _ChatRow.date(label: AppDates.daySeparator(message.createdAt)),
        );
        lastDate = message.createdAt;
      }
      final ChatMessage? previous = i > 0
          ? messages[i - 1]
          : (start > 0 ? all[start - 1] : null);
      final ChatMessage? next = i < messages.length - 1
          ? messages[i + 1]
          : null;
      bool newGroup =
          previous == null ||
          previous.role != message.role ||
          previous.isSystem ||
          message.isSystem ||
          !AppDates.isSameDay(previous.createdAt, message.createdAt) ||
          message.createdAt.difference(previous.createdAt).inMinutes > 4;
      if (message.isSystem) newGroup = true;
      bool endGroup =
          next == null ||
          next.role != message.role ||
          next.isSystem ||
          message.isSystem ||
          !AppDates.isSameDay(next.createdAt, message.createdAt) ||
          next.createdAt.difference(message.createdAt).inMinutes > 4;
      if (message.isSystem) endGroup = true;
      rows.add(
        _ChatRow.message(
          message: message,
          showAvatar: newGroup,
          showMeta: endGroup,
        ),
      );
    }
    if (chat.isTyping) rows.add(const _ChatRow.typing());
    return rows;
  }

  Widget _buildRow(
    BuildContext context,
    _ChatRow row,
    CompanionController chat,
    TtsService tts,
  ) {
    switch (row.kind) {
      case _ChatRowKind.date:
        return _DateDivider(label: row.label ?? '');
      case _ChatRowKind.typing:
        return _TypingBubble(profile: chat.profile);
      case _ChatRowKind.message:
        final ChatMessage message = row.message!;
        if (message.isSystem) {
          return _SystemNotice(message: message);
        }
        return ChatBubble(
          key: ValueKey<String>(message.id),
          message: message,
          profile: chat.profile,
          showAvatar: row.showAvatar,
          showMeta: row.showMeta,
          isSpeaking: tts.speakingId == message.id,
          onSpeak: () => unawaited(_speakMessage(message.id, message.content)),
          onLongPress: () => unawaited(_showMessageMenu(message)),
          onImageTap: () => unawaited(_openImage(message)),
        );
    }
  }

  Widget _buildEmptyChat(
    BuildContext context,
    CompanionController chat,
    AppPalette palette,
  ) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 34),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            CompanionAvatar(
              seed: chat.profile.avatarSeed,
              size: 78,
              showOnline: true,
            ),
            const SizedBox(height: 16),
            Text(
              '这里还很安静。',
              style: Theme.of(context).textTheme.titleMedium
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 7),
            Text(
              '从一句晚安，或者今天发生的一件小事开始吧。',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall
                  ?.copyWith(color: palette.muted, height: 1.6),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStarterPrompts(
    BuildContext context,
    CompanionController chat,
    AppPalette palette,
  ) {
    final List<String> prompts = <String>['今天有点累', '你在做什么呀？', '给我讲个睡前故事'];
    return SizedBox(
      height: 40,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: prompts.length,
        separatorBuilder: (_, __) => const SizedBox(width: 7),
        itemBuilder: (BuildContext context, int index) {
          return PressableScale(
            onTap: () => unawaited(_showStarterPrompt(prompts[index], chat)),
            scale: 0.96,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
              decoration: BoxDecoration(
                color: palette.glass,
                borderRadius: BorderRadius.circular(99),
                border: Border.all(color: palette.border),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Icon(
                    Icons.auto_awesome_rounded,
                    size: 12,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  const SizedBox(width: 5),
                  Text(
                    prompts[index],
                    style: Theme.of(context).textTheme.labelSmall
                        ?.copyWith(color: palette.muted, fontSize: 10.5),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _DateDivider extends StatelessWidget {
  const _DateDivider({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 13),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Container(width: 18, height: 0.6, color: palette.border),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 9),
            child: Text(
              label,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                fontSize: 9.5,
                letterSpacing: 0.5,
                color: palette.muted.withOpacity(0.58),
              ),
            ),
          ),
          Container(width: 18, height: 0.6, color: palette.border),
        ],
      ),
    );
  }
}

class _SystemNotice extends StatelessWidget {
  const _SystemNotice({required this.message});

  final ChatMessage message;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 28, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: palette.glass,
          borderRadius: BorderRadius.circular(99),
          border: Border.all(color: palette.border),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(
              Icons.auto_awesome_rounded,
              size: 11,
              color: Theme.of(context).colorScheme.primary.withOpacity(0.7),
            ),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                message.content,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: palette.muted,
                  fontSize: 9.8,
                  height: 1.45,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TypingBubble extends StatelessWidget {
  const _TypingBubble({required this.profile});

  final CompanionProfile profile;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    return Padding(
      padding: const EdgeInsets.only(left: 12, right: 80, top: 6, bottom: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          CompanionAvatar(
            seed: profile.avatarSeed,
            size: 27,
            nickname: profile.nickname,
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 13),
            decoration: BoxDecoration(
              color: palette.bubbleAi,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(8),
                topRight: Radius.circular(20),
                bottomLeft: Radius.circular(20),
                bottomRight: Radius.circular(20),
              ),
              border: Border.all(color: palette.border, width: 0.8),
            ),
            child: TypingDots(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.46),
              size: 5,
              spacing: 3.5,
            ),
          ),
        ],
      ),
    );
  }
}

class _SheetAction extends StatelessWidget {
  const _SheetAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.destructive = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool destructive;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    final Color color = destructive
        ? Theme.of(context).colorScheme.error
        : Theme.of(context).colorScheme.onSurface.withOpacity(0.86);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
        child: Row(
          children: <Widget>[
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: destructive ? color.withOpacity(0.09) : palette.glass,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, size: 18, color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: Theme.of(context).textTheme.bodyMedium
                    ?.copyWith(color: color, fontWeight: FontWeight.w500),
              ),
            ),
            Icon(
              Icons.chevron_right_rounded,
              size: 18,
              color: palette.muted.withOpacity(0.42),
            ),
          ],
        ),
      ),
    );
  }
}

enum _ChatRowKind { date, message, typing }

class _ChatRow {
  const _ChatRow._({
    required this.kind,
    this.message,
    this.label,
    this.showAvatar = false,
    this.showMeta = false,
  });

  factory _ChatRow.date({required String label}) =>
      _ChatRow._(kind: _ChatRowKind.date, label: label);

  factory _ChatRow.message({
    required ChatMessage message,
    required bool showAvatar,
    required bool showMeta,
  }) => _ChatRow._(
    kind: _ChatRowKind.message,
    message: message,
    showAvatar: showAvatar,
    showMeta: showMeta,
  );

  const _ChatRow.typing()
    : kind = _ChatRowKind.typing,
      message = null,
      label = null,
      showAvatar = false,
      showMeta = false;

  final _ChatRowKind kind;
  final ChatMessage? message;
  final String? label;
  final bool showAvatar;
  final bool showMeta;
}
