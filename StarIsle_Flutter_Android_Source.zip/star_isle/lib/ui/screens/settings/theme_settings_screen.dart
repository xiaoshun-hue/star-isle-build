import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/theme/app_theme_spec.dart';
import '../../../core/utils/app_feedback.dart';
import '../../../core/widgets/detail_scaffold.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../state/settings_controller.dart';
import 'widgets/settings_tile.dart';

class ThemeSettingsScreen extends StatelessWidget {
  const ThemeSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final SettingsController settings = context.watch<SettingsController>();
    return DetailScaffold(
      title: '主题与外观',
      subtitle: '换一个房间，也换一种心情',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 30),
        physics: const BouncingScrollPhysics(),
        children: <Widget>[
          _buildLivePreview(context, palette, settings),
          const SizedBox(height: 22),
          const SettingsSectionLabel(title: 'APPEARANCE · 明暗模式'),
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: palette.glass,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: palette.border),
            ),
            child: Row(
              children: <Widget>[
                _modeItem(
                  context,
                  settings,
                  ThemeMode.light,
                  '浅色',
                  Icons.light_mode_outlined,
                ),
                _modeItem(
                  context,
                  settings,
                  ThemeMode.dark,
                  '深色',
                  Icons.dark_mode_outlined,
                ),
                _modeItem(
                  context,
                  settings,
                  ThemeMode.system,
                  '跟随系统',
                  Icons.brightness_auto_outlined,
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const SettingsSectionLabel(title: 'SKIN · 选择皮肤'),
          ...AppThemeSpec.all.map(
            (AppThemeSpec spec) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _ThemeCard(
                spec: spec,
                selected: settings.themeId == spec.id,
                onTap: () {
                  if (settings.themeId == spec.id) return;
                  AppFeedback.tap(settings.haptics);
                  unawaited(settings.setThemeId(spec.id));
                },
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Icon(
                Icons.info_outline_rounded,
                size: 13,
                color: palette.muted.withOpacity(0.6),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  '主题会立即应用并保存在本机。每套皮肤都配有独立的深色与浅色背景、聊天气泡和渐变氛围光。',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted.withOpacity(0.56),
                    fontSize: 8.8,
                    height: 1.6,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLivePreview(
    BuildContext context,
    AppPalette palette,
    SettingsController settings,
  ) {
    return Container(
      height: 178,
      decoration: BoxDecoration(
        gradient: palette.backgroundGradient,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: palette.border),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(26),
        child: Stack(
          children: <Widget>[
            Positioned(
              top: -45,
              right: -20,
              child: Container(
                width: 160,
                height: 160,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: <Color>[
                      palette.auroraA.withOpacity(0.30),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              left: -25,
              bottom: -55,
              child: Container(
                width: 170,
                height: 170,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: <Color>[
                      palette.auroraB.withOpacity(0.22),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: palette.accentGradient,
                        ),
                        child: const Icon(
                          Icons.nights_stay_rounded,
                          color: Colors.white,
                          size: 15,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            settings.themeSpec.name,
                            style: Theme.of(context).textTheme.labelMedium
                                ?.copyWith(fontWeight: FontWeight.w700),
                          ),
                          Text(
                            '当前皮肤预览',
                            style: Theme.of(context).textTheme.labelSmall
                                ?.copyWith(color: palette.muted, fontSize: 8),
                          ),
                        ],
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: palette.glass,
                          borderRadius: BorderRadius.circular(99),
                          border: Border.all(color: palette.border),
                        ),
                        child: Text(
                          palette.isDark ? 'DARK' : 'LIGHT',
                          style: Theme.of(context).textTheme.labelSmall
                              ?.copyWith(
                                color: palette.muted,
                                fontSize: 7,
                                letterSpacing: 0.8,
                              ),
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      Container(
                        width: 35,
                        height: 35,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: palette.accentGradient,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Flexible(
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 13,
                            vertical: 9,
                          ),
                          decoration: BoxDecoration(
                            color: palette.bubbleAi,
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(6),
                              topRight: Radius.circular(16),
                              bottomLeft: Radius.circular(16),
                              bottomRight: Radius.circular(16),
                            ),
                            border: Border.all(color: palette.border),
                          ),
                          child: Text(
                            '今晚的月亮很好看。你在做什么？',
                            style: Theme.of(context).textTheme.bodySmall
                                ?.copyWith(fontSize: 11),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 13,
                        vertical: 9,
                      ),
                      decoration: BoxDecoration(
                        gradient: palette.userBubbleGradient,
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(16),
                          topRight: Radius.circular(6),
                          bottomLeft: Radius.circular(16),
                          bottomRight: Radius.circular(16),
                        ),
                      ),
                      child: const Text(
                        '在想你呀。',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _modeItem(
    BuildContext context,
    SettingsController settings,
    ThemeMode mode,
    String label,
    IconData icon,
  ) {
    final palette = context.palette;
    final bool selected = settings.themeMode == mode;
    return Expanded(
      child: PressableScale(
        onTap: () {
          if (settings.themeMode == mode) return;
          AppFeedback.tap(settings.haptics);
          unawaited(settings.setThemeMode(mode));
        },
        scale: 0.96,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 240),
          padding: const EdgeInsets.symmetric(vertical: 11),
          decoration: BoxDecoration(
            color: selected
                ? Theme.of(context).colorScheme.primary.withOpacity(0.13)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: selected
                  ? Theme.of(context).colorScheme.primary.withOpacity(0.25)
                  : Colors.transparent,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(
                icon,
                size: 15,
                color: selected
                    ? Theme.of(context).colorScheme.primary
                    : palette.muted,
              ),
              const SizedBox(width: 5),
              Text(
                label,
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: selected
                      ? Theme.of(context).colorScheme.primary
                      : palette.muted,
                  fontSize: 9.5,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ThemeCard extends StatelessWidget {
  const _ThemeCard({
    required this.spec,
    required this.selected,
    required this.onTap,
  });

  final AppThemeSpec spec;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final Color accent = spec.accent;
    return PressableScale(
      onTap: onTap,
      scale: 0.985,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        height: 112,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: <Color>[
              spec.darkColors[0],
              spec.darkColors[1],
              spec.darkColors[2],
            ],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: selected
                ? accent.withOpacity(0.9)
                : Colors.white.withOpacity(0.08),
            width: selected ? 1.4 : 0.8,
          ),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: spec.darkAurora[0].withOpacity(selected ? 0.24 : 0.10),
              blurRadius: 22,
              offset: const Offset(0, 9),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Stack(
            children: <Widget>[
              Positioned(
                right: -30,
                top: -35,
                child: Container(
                  width: 130,
                  height: 130,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: <Color>[
                        spec.darkAurora[1].withOpacity(0.35),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 15, 15, 14),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Text(
                                spec.name,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 0.2,
                                ),
                              ),
                              if (selected) ...<Widget>[
                                const SizedBox(width: 7),
                                Container(
                                  width: 16,
                                  height: 16,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: accent,
                                  ),
                                  child: const Icon(
                                    Icons.check_rounded,
                                    size: 11,
                                    color: Colors.black54,
                                  ),
                                ),
                              ],
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            spec.description,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.48),
                              fontSize: 9,
                            ),
                          ),
                          const Spacer(),
                          Row(
                            children: <Widget>[
                              _swatch(spec.darkColors[2]),
                              const SizedBox(width: 4),
                              _swatch(spec.lightColors[0]),
                              const SizedBox(width: 4),
                              _swatch(spec.userBubble[0]),
                              const SizedBox(width: 4),
                              _swatch(spec.userBubble[1]),
                              const SizedBox(width: 9),
                              Text(
                                selected ? '正在使用' : '轻触应用',
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.36),
                                  fontSize: 8,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.08),
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(11),
                              topRight: Radius.circular(3),
                              bottomLeft: Radius.circular(11),
                              bottomRight: Radius.circular(11),
                            ),
                            border: Border.all(color: Colors.white10),
                          ),
                          child: const Text(
                            '晚安。',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 9,
                            ),
                          ),
                        ),
                        const SizedBox(height: 5),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(colors: spec.userBubble),
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(11),
                              topRight: Radius.circular(11),
                              bottomLeft: Radius.circular(11),
                              bottomRight: Radius.circular(3),
                            ),
                          ),
                          child: const Text(
                            '做个好梦。',
                            style: TextStyle(color: Colors.white, fontSize: 9),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _swatch(Color color) {
    return Container(
      width: 11,
      height: 11,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        border: Border.all(color: Colors.white24, width: 0.5),
      ),
    );
  }
}
