import 'package:flutter/material.dart';

import '../../../../core/theme/app_palette.dart';
import '../../../../core/widgets/glass_panel.dart';

class SettingsGroup extends StatelessWidget {
  const SettingsGroup({
    super.key,
    required this.children,
    this.margin = const EdgeInsets.only(bottom: 14),
  });

  final List<Widget> children;
  final EdgeInsetsGeometry margin;

  @override
  Widget build(BuildContext context) {
    final List<Widget> content = <Widget>[];
    for (int i = 0; i < children.length; i++) {
      content.add(children[i]);
      if (i != children.length - 1) {
        content.add(
          Padding(
            padding: const EdgeInsets.only(left: 64, right: 16),
            child: Divider(
              height: 0.6,
              thickness: 0.6,
              color: context.palette.border,
            ),
          ),
        );
      }
    }
    return Padding(
      padding: margin,
      child: GlassPanel(
        padding: EdgeInsets.zero,
        borderRadius: 22,
        blur: 16,
        child: Material(
          color: Colors.transparent,
          child: Column(children: content),
        ),
      ),
    );
  }
}

class SettingsTile extends StatelessWidget {
  const SettingsTile({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    this.trailingText,
    this.onTap,
    this.trailing,
    this.danger = false,
    this.showChevron = true,
    this.iconColor,
  });

  final IconData icon;
  final String title;
  final String? subtitle;
  final String? trailingText;
  final VoidCallback? onTap;
  final Widget? trailing;
  final bool danger;
  final bool showChevron;
  final Color? iconColor;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    final Color color = danger
        ? const Color(0xFFFF708A)
        : (iconColor ?? Theme.of(context).colorScheme.primary);
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
        child: Row(
          children: <Widget>[
            Container(
              width: 37,
              height: 37,
              decoration: BoxDecoration(
                color: color.withOpacity(0.10),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, size: 18, color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    title,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: danger
                          ? color
                          : Theme.of(context).colorScheme.onSurface
                                .withOpacity(0.88),
                    ),
                  ),
                  if (subtitle != null) ...<Widget>[
                    const SizedBox(height: 3),
                    Text(
                      subtitle!,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: palette.muted,
                        fontSize: 9,
                        height: 1.45,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            if (trailingText != null)
              Padding(
                padding: const EdgeInsets.only(left: 8),
                child: Text(
                  trailingText!,
                  style: Theme.of(context).textTheme.labelSmall
                      ?.copyWith(color: palette.muted, fontSize: 9.5),
                ),
              ),
            if (trailing != null) ...<Widget>[
              const SizedBox(width: 6),
              trailing!,
            ],
            if (showChevron && trailing == null)
              Padding(
                padding: const EdgeInsets.only(left: 3),
                child: Icon(
                  Icons.chevron_right_rounded,
                  size: 18,
                  color: palette.muted.withOpacity(0.35),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class SettingsSwitchTile extends StatelessWidget {
  const SettingsSwitchTile({
    super.key,
    required this.icon,
    required this.title,
    required this.value,
    required this.onChanged,
    this.subtitle,
    this.iconColor,
  });

  final IconData icon;
  final String title;
  final String? subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  final Color? iconColor;

  @override
  Widget build(BuildContext context) {
    return SettingsTile(
      icon: icon,
      title: title,
      subtitle: subtitle,
      iconColor: iconColor,
      onTap: () => onChanged(!value),
      showChevron: false,
      trailing: Switch.adaptive(
        value: value,
        activeColor: Theme.of(context).colorScheme.primary,
        onChanged: onChanged,
      ),
    );
  }
}

class SettingsSectionLabel extends StatelessWidget {
  const SettingsSectionLabel({super.key, required this.title, this.trailing});

  final String title;
  final String? trailing;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 10, 4, 8),
      child: Row(
        children: <Widget>[
          Text(
            title,
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: palette.muted,
              letterSpacing: 1,
              fontSize: 9,
              fontWeight: FontWeight.w600,
            ),
          ),
          const Spacer(),
          if (trailing != null)
            Text(
              trailing!,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: palette.muted.withOpacity(0.5),
                fontSize: 8.5,
              ),
            ),
        ],
      ),
    );
  }
}
