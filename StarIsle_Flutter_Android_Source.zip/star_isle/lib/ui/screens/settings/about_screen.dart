import 'package:flutter/material.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/widgets/detail_scaffold.dart';
import '../../../core/widgets/glass_panel.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../state/settings_controller.dart';

import 'package:provider/provider.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final SettingsController settings = context.watch<SettingsController>();
    return DetailScaffold(
      title: '关于星屿',
      subtitle: '把晚风留在身边',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 30),
        physics: const BouncingScrollPhysics(),
        children: <Widget>[
          Center(
            child: Column(
              children: <Widget>[
                Container(
                  width: 88,
                  height: 88,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: <Color>[
                        palette.auroraA,
                        palette.auroraB,
                        const Color(0xFFF6D7AE),
                      ],
                    ),
                    boxShadow: <BoxShadow>[
                      BoxShadow(
                        color: palette.auroraB.withOpacity(0.28),
                        blurRadius: 30,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.nights_stay_rounded,
                    size: 38,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  '星屿',
                  style: Theme.of(context).textTheme.headlineMedium
                      ?.copyWith(fontWeight: FontWeight.w800, letterSpacing: 3),
                ),
                const SizedBox(height: 5),
                Text(
                  'STAR ISLE · 版本 1.3.3',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted,
                    fontSize: 8.5,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  '一座只住着你和她的私人小岛。',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: palette.muted,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),
          _sectionLabel(context, 'ABOUT THE ISLE · 关于这座岛'),
          _infoCard(
            context,
            icon: Icons.favorite_outline_rounded,
            title: '为一个人存在',
            content: '没有注册、没有陌生人、没有公开主页。你的称呼、对话、照片、记忆、纪念日和她的成长，都只属于这台设备。',
          ),
          const SizedBox(height: 10),
          _infoCard(
            context,
            icon: Icons.cloud_off_rounded,
            title: '单机模式',
            content: '完全离线的人格引擎会在本地完成意图识别、长期记忆检索和情绪回应。它不是通用大语言模型，但会认真接住你、记住你说过的事，并持续保持同一个“她”。',
          ),
          const SizedBox(height: 10),
          _infoCard(
            context,
            icon: Icons.bolt_rounded,
            title: '联网模式',
            content: '配置你自己的 DeepSeek API Key 后，对话、动态文案和评论会由 DeepSeek 生成。请求从手机直接发往你配置的接口，只包含人设、记忆摘要和最近对话上下文。',
          ),
          const SizedBox(height: 22),
          _sectionLabel(context, 'PRIVACY · 隐私与数据'),
          GlassPanel(
            padding: const EdgeInsets.all(17),
            borderRadius: 22,
            child: Column(
              children: <Widget>[
                _privacyRow(
                  context,
                  icon: Icons.storage_rounded,
                  title: '本地存储',
                  content: 'SQLite 数据库 · 所有聊天与动态不上传',
                ),
                _divider(palette),
                _privacyRow(
                  context,
                  icon: Icons.key_outlined,
                  title: 'API Key',
                  content: '只保存在应用私有 SharedPreferences 中',
                ),
                _divider(palette),
                _privacyRow(
                  context,
                  icon: Icons.photo_outlined,
                  title: '图片',
                  content: '用户照片与生成画卡保存在应用私有目录',
                ),
                _divider(palette),
                _privacyRow(
                  context,
                  icon: Icons.person_off_outlined,
                  title: '没有账号系统',
                  content: '没有云端同步、广告追踪或行为分析',
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _sectionLabel(context, 'CURRENT · 当前状态'),
          GlassPanel(
            padding: const EdgeInsets.all(17),
            borderRadius: 22,
            child: Column(
              children: <Widget>[
                _statusRow(context, '连接', settings.connectionLabel),
                const SizedBox(height: 10),
                _statusRow(context, '主题', settings.themeSpec.name),
                const SizedBox(height: 10),
                _statusRow(
                  context,
                  '主动陪伴',
                  settings.proactiveEnabled ? '开启' : '关闭',
                ),
                const SizedBox(height: 10),
                _statusRow(context, '自动朗读', settings.autoSpeak ? '开启' : '关闭'),
              ],
            ),
          ),
          const SizedBox(height: 22),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[
                  palette.auroraA.withOpacity(0.16),
                  palette.glass,
                ],
              ),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: palette.border),
            ),
            child: Column(
              children: <Widget>[
                Icon(
                  Icons.format_quote_rounded,
                  size: 20,
                  color: palette.auroraB.withOpacity(0.65),
                ),
                const SizedBox(height: 8),
                Text(
                  '“重要的不是 AI 有多聪明，\n而是有人愿意把你随口说的话放在心上。”',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    height: 1.85,
                    color: Theme.of(context).colorScheme.onSurface
                        .withOpacity(0.65),
                    fontStyle: FontStyle.italic,
                  ),
                ),
                const SizedBox(height: 9),
                Text(
                  '星屿以 Flutter 构建 · 本地优先 · 单人专属',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted.withOpacity(0.42),
                    fontSize: 8,
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 23),
          Center(
            child: PressableScale(
              onTap: () => Navigator.of(context).pop(),
              child: Text(
                '把晚风留在身边',
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: palette.muted.withOpacity(0.3),
                  fontSize: 8.5,
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionLabel(BuildContext context, String text) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 0, 4, 9),
      child: Text(
        text,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
          color: context.palette.muted,
          fontSize: 8.5,
          letterSpacing: 1.1,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _infoCard(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String content,
  }) {
    final palette = context.palette;
    return GlassPanel(
      padding: const EdgeInsets.all(16),
      borderRadius: 21,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            width: 35,
            height: 35,
            decoration: BoxDecoration(
              color: palette.auroraA.withOpacity(0.11),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(
              icon,
              size: 17,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleSmall
                      ?.copyWith(fontWeight: FontWeight.w700, fontSize: 12),
                ),
                const SizedBox(height: 5),
                Text(
                  content,
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted,
                    height: 1.65,
                    fontSize: 9.2,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _privacyRow(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String content,
  }) {
    final palette = context.palette;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: <Widget>[
          Icon(icon, size: 15, color: palette.muted.withOpacity(0.7)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              title,
              style: Theme.of(context).textTheme.labelMedium
                  ?.copyWith(fontWeight: FontWeight.w600, fontSize: 10.5),
            ),
          ),
          Flexible(
            child: Text(
              content,
              textAlign: TextAlign.right,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: palette.muted.withOpacity(0.58),
                fontSize: 8.2,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _statusRow(BuildContext context, String label, String value) {
    final palette = context.palette;
    return Row(
      children: <Widget>[
        Text(
          label,
          style: Theme.of(context).textTheme.labelSmall
              ?.copyWith(color: palette.muted, fontSize: 9),
        ),
        const Spacer(),
        Container(
          width: 4,
          height: 4,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: palette.auroraB,
          ),
        ),
        const SizedBox(width: 6),
        Text(
          value,
          style: Theme.of(context).textTheme.labelSmall
              ?.copyWith(fontSize: 9, fontWeight: FontWeight.w600),
        ),
      ],
    );
  }

  Widget _divider(AppPalette palette) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 9),
      child: Container(height: 0.6, color: palette.border),
    );
  }
}
