import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/widgets/app_feedback_widgets.dart';
import '../../../core/widgets/detail_scaffold.dart';
import '../../../core/widgets/glass_panel.dart';
import '../../../core/widgets/gradient_button.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../services/ai/ai_service.dart';
import '../../../services/ai/ai_types.dart';
import '../../../state/settings_controller.dart';
import 'widgets/settings_tile.dart';

class AiSettingsScreen extends StatefulWidget {
  const AiSettingsScreen({super.key});

  @override
  State<AiSettingsScreen> createState() => _AiSettingsScreenState();
}

class _AiSettingsScreenState extends State<AiSettingsScreen> {
  late final TextEditingController _apiKey;
  late final TextEditingController _baseUrl;
  late final TextEditingController _model;
  late final TextEditingController _voiceKey;
  late bool _online;
  bool _obscure = true;
  bool _voiceObscure = true;
  bool _saving = false;
  bool _testing = false;

  @override
  void initState() {
    super.initState();
    final SettingsController settings = context.read<SettingsController>();
    _apiKey = TextEditingController(text: settings.apiKey);
    _baseUrl = TextEditingController(text: settings.baseUrl);
    _model = TextEditingController(text: settings.model);
    _voiceKey = TextEditingController(text: settings.voiceApiKey);
    _online = settings.isOnlineMode;
  }

  @override
  void dispose() {
    _apiKey.dispose();
    _baseUrl.dispose();
    _model.dispose();
    _voiceKey.dispose();
    super.dispose();
  }

  Future<bool> _save({bool quiet = false}) async {
    final SettingsController settings = context.read<SettingsController>();
    final String key = _apiKey.text.trim();
    if (_online && key.isEmpty) {
      showAppToast(
        context,
        '联网模式需要 DeepSeek API Key。',
        icon: Icons.key_rounded,
      );
      return false;
    }
    setState(() => _saving = true);
    try {
      await settings.saveApiConfig(
        online: _online,
        apiKey: key,
        baseUrl: _baseUrl.text,
        model: _model.text,
      );
      await settings.saveVoiceApiKey(_voiceKey.text.trim());
      if (!quiet && mounted) {
        showAppToast(
          context,
          '连接设置已保存',
          icon: Icons.check_circle_outline_rounded,
        );
      }
      return true;
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _testConnection() async {
    if (_testing) return;
    if (_apiKey.text.trim().isEmpty) {
      showAppToast(context, '请先填写 API Key。', icon: Icons.key_rounded);
      return;
    }
    final bool saved = await _save(quiet: true);
    if (!saved || !mounted) return;
    setState(() => _testing = true);
    try {
      final String result = await context.read<AiService>().testConnection();
      if (!mounted) return;
      showAppToast(context, result, icon: Icons.bolt_rounded);
    } on AiException catch (error) {
      if (!mounted) return;
      showAppToast(context, error.message, icon: Icons.cloud_off_rounded);
    } catch (error) {
      if (!mounted) return;
      showAppToast(context, '测试失败：$error', icon: Icons.error_outline_rounded);
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final SettingsController settings = context.watch<SettingsController>();
    return DetailScaffold(
      title: 'AI 与网络',
      subtitle: '决定她如何思考，也决定对话去哪里',
      resizeToAvoidBottomInset: true,
      child: Column(
        children: <Widget>[
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 20),
              physics: const BouncingScrollPhysics(),
              children: <Widget>[
                _buildStatusCard(context, settings, palette),
                const SizedBox(height: 20),
                const SettingsSectionLabel(title: 'CONNECTION · 运行方式'),
                _buildModeCard(
                  context,
                  selected: !_online,
                  icon: Icons.cloud_off_rounded,
                  eyebrow: '完全离线',
                  title: '单机陪伴',
                  subtitle: '本地人格引擎，不需要网络',
                  description: '意图识别、情绪状态、长期记忆检索与本地文案生成都在这台手机里完成。不会发送任何数据。',
                  color: palette.auroraA,
                  onTap: () => setState(() => _online = false),
                ),
                const SizedBox(height: 9),
                _buildModeCard(
                  context,
                  selected: _online,
                  icon: Icons.auto_awesome_rounded,
                  eyebrow: '更自由的语言',
                  title: 'DeepSeek 联网',
                  subtitle: '使用你自己的 API Key',
                  description: '每次对话会把最近的消息、人设和记忆摘要发送到 DeepSeek。会消耗你的 API 额度。',
                  color: palette.auroraB,
                  onTap: () => setState(() => _online = true),
                ),
                AnimatedSize(
                  duration: const Duration(milliseconds: 360),
                  curve: Curves.easeOutCubic,
                  child: _online
                      ? Padding(
                          padding: const EdgeInsets.only(top: 14),
                          child: GlassPanel(
                            padding: const EdgeInsets.all(16),
                            borderRadius: 23,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    Icon(
                                      Icons.key_rounded,
                                      size: 16,
                                      color: Theme.of(context)
                                          .colorScheme
                                          .primary,
                                    ),
                                    const SizedBox(width: 7),
                                    Text(
                                      'DeepSeek 连接配置',
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleSmall
                                          ?.copyWith(
                                            fontWeight: FontWeight.w700,
                                          ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 14),
                                TextField(
                                  controller: _apiKey,
                                  obscureText: _obscure,
                                  autocorrect: false,
                                  enableSuggestions: false,
                                  style: const TextStyle(fontSize: 13),
                                  decoration: InputDecoration(
                                    labelText: 'API Key',
                                    hintText: 'sk-...',
                                    prefixIcon: const Icon(
                                      Icons.lock_outline_rounded,
                                      size: 19,
                                    ),
                                    suffixIcon: IconButton(
                                      onPressed: () =>
                                          setState(() => _obscure = !_obscure),
                                      icon: Icon(
                                        _obscure
                                            ? Icons.visibility_off_outlined
                                            : Icons.visibility_outlined,
                                        size: 19,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 10),
                                TextField(
                                  controller: _baseUrl,
                                  autocorrect: false,
                                  keyboardType: TextInputType.url,
                                  style: const TextStyle(fontSize: 12),
                                  decoration: const InputDecoration(
                                    labelText: 'Base URL',
                                    hintText: 'https://api.deepseek.com',
                                    prefixIcon: Icon(
                                      Icons.link_rounded,
                                      size: 19,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 10),
                                TextField(
                                  controller: _model,
                                  autocorrect: false,
                                  style: const TextStyle(fontSize: 12),
                                  decoration: const InputDecoration(
                                    labelText: '模型名称',
                                    hintText: 'deepseek-chat',
                                    prefixIcon: Icon(
                                      Icons.memory_rounded,
                                      size: 19,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Icon(
                                      Icons.shield_outlined,
                                      size: 13,
                                      color: palette.muted,
                                    ),
                                    const SizedBox(width: 6),
                                    Expanded(
                                      child: Text(
                                        'Key 只保存在本机应用数据中。星屿没有中转服务器，也不会上传你的 API Key。',
                                        style: Theme.of(context)
                                            .textTheme
                                            .labelSmall
                                            ?.copyWith(
                                              color: palette.muted,
                                              height: 1.6,
                                              fontSize: 8.8,
                                            ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        )
                      : const SizedBox.shrink(),
                ),
                const SizedBox(height: 18),
                const SettingsSectionLabel(title: 'VOICE · 语音识别'),
                GlassPanel(
                  padding: const EdgeInsets.all(16),
                  borderRadius: 23,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Icon(
                            Icons.mic_none_rounded,
                            size: 17,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                          const SizedBox(width: 7),
                          Text(
                            'SiliconFlow 语音识别',
                            style: Theme.of(context).textTheme.titleSmall
                                ?.copyWith(fontWeight: FontWeight.w700),
                          ),
                          const Spacer(),
                          Text(
                            _voiceKey.text.trim().isEmpty ? '未配置' : '已配置',
                            style: Theme.of(context).textTheme.labelSmall
                                ?.copyWith(color: palette.muted),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _voiceKey,
                        obscureText: _voiceObscure,
                        autocorrect: false,
                        enableSuggestions: false,
                        onChanged: (_) => setState(() {}),
                        style: const TextStyle(fontSize: 12),
                        decoration: InputDecoration(
                          labelText: '语音识别 API Key',
                          hintText: 'sk-...',
                          prefixIcon: const Icon(
                            Icons.key_rounded,
                            size: 19,
                          ),
                          suffixIcon: IconButton(
                            onPressed: () => setState(
                              () => _voiceObscure = !_voiceObscure,
                            ),
                            icon: Icon(
                              _voiceObscure
                                  ? Icons.visibility_off_outlined
                                  : Icons.visibility_outlined,
                              size: 19,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 9),
                      Text(
                        '用于把她面前的麦克风录音转成文字。Key 只保存在本机；'
                        '录音会直接上传到 SiliconFlow，不经过星屿服务器。'
                        'Key 获取：cloud.siliconflow.cn/account/ak',
                        style: Theme.of(context).textTheme.labelSmall
                            ?.copyWith(
                              color: palette.muted,
                              height: 1.6,
                              fontSize: 8.8,
                            ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Icon(
                      Icons.info_outline_rounded,
                      size: 14,
                      color: palette.muted.withOpacity(0.65),
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        '未配置 Key 或网络失败时，聊天会自动回退到单机模式，不会丢失当前对话。单机模式也永远不会因为切换皮肤而发起网络请求。',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: palette.muted.withOpacity(0.58),
                          fontSize: 8.8,
                          height: 1.6,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
            child: Row(
              children: <Widget>[
                Expanded(
                  flex: 5,
                  child: GradientButton(
                    label: '保存设置',
                    icon: Icons.check_rounded,
                    height: 50,
                    borderRadius: 16,
                    busy: _saving,
                    onPressed: _saving ? null : () => unawaited(_save()),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  flex: 4,
                  child: PressableScale(
                    onTap: _testing ? null : () => unawaited(_testConnection()),
                    enabled: !_testing,
                    child: Container(
                      height: 50,
                      decoration: BoxDecoration(
                        color: palette.glass,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: palette.border),
                      ),
                      child: Center(
                        child: _testing
                            ? SizedBox(
                                width: 17,
                                height: 17,
                                child: CircularProgressIndicator(
                                  strokeWidth: 1.8,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                              )
                            : Row(
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Icon(
                                    Icons.bolt_rounded,
                                    size: 16,
                                    color: Theme.of(context)
                                        .colorScheme
                                        .primary,
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    '测试连接',
                                    style: Theme.of(context)
                                        .textTheme
                                        .labelSmall
                                        ?.copyWith(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusCard(
    BuildContext context,
    SettingsController settings,
    AppPalette palette,
  ) {
    final bool active = settings.onlineReady;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            (active ? palette.auroraB : palette.auroraA).withOpacity(0.19),
            palette.glass,
          ],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: palette.border),
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: (active ? palette.auroraB : palette.auroraA).withOpacity(
                0.17,
              ),
              border: Border.all(color: palette.border),
            ),
            child: Icon(
              active ? Icons.bolt_rounded : Icons.cloud_off_rounded,
              size: 19,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  settings.connectionLabel,
                  style: Theme.of(context).textTheme.titleSmall
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 3),
                Text(
                  active
                      ? '下一次对话将使用 ${settings.model}'
                      : settings.isOnlineMode
                      ? '正在等待配置 · 当前自动使用本地引擎'
                      : '当前对话完全在本机完成，不会联网',
                  style: Theme.of(context).textTheme.labelSmall
                      ?.copyWith(color: palette.muted, fontSize: 9),
                ),
              ],
            ),
          ),
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: active
                  ? const Color(0xFF68E4B2)
                  : palette.muted.withOpacity(0.4),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModeCard(
    BuildContext context, {
    required bool selected,
    required IconData icon,
    required String eyebrow,
    required String title,
    required String subtitle,
    required String description,
    required Color color,
    required VoidCallback onTap,
  }) {
    final palette = context.palette;
    return PressableScale(
      onTap: onTap,
      scale: 0.99,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 240),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          gradient: selected
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[color.withOpacity(0.16), palette.glass],
                )
              : null,
          color: selected ? null : palette.glass,
          borderRadius: BorderRadius.circular(21),
          border: Border.all(
            color: selected ? color.withOpacity(0.48) : palette.border,
            width: selected ? 1 : 0.8,
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              width: 39,
              height: 39,
              decoration: BoxDecoration(
                color: color.withOpacity(selected ? 0.22 : 0.09),
                borderRadius: BorderRadius.circular(13),
              ),
              child: Icon(icon, size: 19, color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Text(
                        title,
                        style: Theme.of(context).textTheme.titleSmall
                            ?.copyWith(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(width: 7),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 5,
                          vertical: 1.5,
                        ),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.09),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          eyebrow,
                          style: Theme.of(context).textTheme.labelSmall
                              ?.copyWith(color: color, fontSize: 7),
                        ),
                      ),
                      const Spacer(),
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: 18,
                        height: 18,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: selected
                                ? color
                                : palette.muted.withOpacity(0.3),
                            width: 1.3,
                          ),
                        ),
                        child: selected
                            ? Center(
                                child: Container(
                                  width: 8,
                                  height: 8,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: color,
                                  ),
                                ),
                              )
                            : null,
                      ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: color,
                      fontSize: 8.8,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    description,
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: palette.muted,
                      height: 1.55,
                      fontSize: 8.8,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
