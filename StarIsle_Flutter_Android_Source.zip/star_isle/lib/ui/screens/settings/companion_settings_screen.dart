import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/utils/app_feedback.dart';
import '../../../core/widgets/app_feedback_widgets.dart';
import '../../../core/widgets/app_sheet.dart';
import '../../../core/widgets/companion_avatar.dart';
import '../../../core/widgets/detail_scaffold.dart';
import '../../../core/widgets/glass_panel.dart';
import '../../../core/widgets/gradient_button.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../data/models/companion_profile.dart';
import '../../../state/companion_controller.dart';
import '../../../state/moments_controller.dart';
import '../../../state/settings_controller.dart';
import 'widgets/settings_tile.dart';

class CompanionSettingsScreen extends StatefulWidget {
  const CompanionSettingsScreen({super.key});

  @override
  State<CompanionSettingsScreen> createState() =>
      _CompanionSettingsScreenState();
}

class _CompanionSettingsScreenState extends State<CompanionSettingsScreen> {
  late final TextEditingController _userName;
  late final TextEditingController _aiName;
  late final TextEditingController _persona;
  late String _tone;

  bool _saving = false;
  bool _evolving = false;
  bool _messaging = false;
  bool _posting = false;

  static const List<_ToneChoice> _tones = <_ToneChoice>[
    _ToneChoice('warm', '温柔细腻', '轻声接住你的情绪'),
    _ToneChoice('playful', '俏皮元气', '会逗你笑，也会认真听'),
    _ToneChoice('cool', '清冷文艺', '句子短，但有余温'),
    _ToneChoice('clingy', '黏人热烈', '想你就要让你知道'),
  ];

  static const List<int> _intervalOptions = <int>[30, 60, 120, 180, 360, 720];

  @override
  void initState() {
    super.initState();
    final SettingsController settings = context.read<SettingsController>();
    final CompanionController companion = context.read<CompanionController>();
    _userName = TextEditingController(text: settings.userName);
    _aiName = TextEditingController(text: companion.profile.nickname);
    _persona = TextEditingController(text: companion.profile.persona);
    _tone = companion.profile.tone;
  }

  @override
  void dispose() {
    _userName.dispose();
    _aiName.dispose();
    _persona.dispose();
    super.dispose();
  }

  Future<void> _saveIdentity() async {
    if (_saving) return;
    final String userName = _userName.text.trim();
    final String aiName = _aiName.text.trim();
    if (userName.isEmpty || aiName.isEmpty) {
      showAppToast(context, '名字不能为空。', icon: Icons.edit_outlined);
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() => _saving = true);
    try {
      final SettingsController settings = context.read<SettingsController>();
      final CompanionController companion = context.read<CompanionController>();
      await settings.setUserName(userName);
      await companion.updateCompanionIdentity(
        nickname: aiName,
        persona: _persona.text,
        tone: _tone,
      );
      if (mounted) {
        showAppToast(context, '她的设定已经更新', icon: Icons.auto_awesome_rounded);
      }
    } catch (error) {
      if (mounted) {
        showAppToast(context, '保存时出了点问题，再试一次吧。');
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _chooseInterval(SettingsController settings) async {
    final int? selected = await showGlassSheet<int>(
      context,
      title: '主动消息间隔',
      child: SheetBody(
        scroll: false,
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: _intervalOptions.map((int minutes) {
            final bool active = settings.proactiveIntervalMinutes == minutes;
            final String label = switch (minutes) {
              30 => '30 分钟',
              60 => '1 小时',
              120 => '2 小时',
              180 => '3 小时',
              360 => '6 小时',
              _ => '12 小时',
            };
            return InkWell(
              borderRadius: BorderRadius.circular(15),
              onTap: () => Navigator.of(context).pop(minutes),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 13,
                ),
                child: Row(
                  children: <Widget>[
                    Icon(
                      active
                          ? Icons.radio_button_checked_rounded
                          : Icons.radio_button_unchecked_rounded,
                      size: 18,
                      color: active
                          ? Theme.of(context).colorScheme.primary
                          : context.palette.muted,
                    ),
                    const SizedBox(width: 11),
                    Text(
                      label,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: active ? FontWeight.w600 : FontWeight.w400,
                      ),
                    ),
                    const Spacer(),
                    if (minutes == 180)
                      Text(
                        '推荐',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: Theme.of(context).colorScheme.primary,
                          fontSize: 8.5,
                        ),
                      ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
    if (selected != null) {
      await settings.setProactiveInterval(selected);
      if (mounted) {
        showAppToast(context, '主动消息间隔已调整');
      }
    }
  }

  Future<void> _triggerMessage() async {
    if (_messaging) return;
    setState(() => _messaging = true);
    try {
      await context.read<CompanionController>().triggerProactive();
      if (mounted) {
        showAppToast(
          context,
          '她已经发了一条私聊消息。回到消息页看看吧。',
          icon: Icons.chat_bubble_rounded,
        );
      }
    } finally {
      if (mounted) setState(() => _messaging = false);
    }
  }

  Future<void> _triggerMoment() async {
    if (_posting) return;
    setState(() => _posting = true);
    try {
      await context.read<MomentsController>().createAiMoment(force: true);
      if (mounted) {
        showAppToast(
          context,
          '她刚刚在动态里留下了一段新的生活。',
          icon: Icons.auto_awesome_rounded,
        );
      }
    } finally {
      if (mounted) setState(() => _posting = false);
    }
  }

  Future<void> _evolve() async {
    if (_evolving) return;
    setState(() => _evolving = true);
    try {
      await context.read<CompanionController>().evolveCompanion();
      if (mounted) {
        showAppToast(
          context,
          '她换了一个新的头像和签名。',
          icon: Icons.auto_awesome_rounded,
        );
      }
    } finally {
      if (mounted) setState(() => _evolving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final CompanionController companion = context.watch<CompanionController>();
    final SettingsController settings = context.watch<SettingsController>();
    final MomentsController moments = context.watch<MomentsController>();
    final CompanionProfile profile = companion.profile;
    return DetailScaffold(
      title: '人格与主动陪伴',
      subtitle: '她如何说话，也如何想起你',
      child: Column(
        children: <Widget>[
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 24),
              physics: const BouncingScrollPhysics(),
              children: <Widget>[
                _buildHero(context, profile, palette),
                const SizedBox(height: 20),
                const SettingsSectionLabel(title: 'IDENTITY · 称呼与设定'),
                GlassPanel(
                  padding: const EdgeInsets.all(15),
                  borderRadius: 22,
                  child: Column(
                    children: <Widget>[
                      TextField(
                        controller: _userName,
                        maxLength: 10,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          labelText: '她怎么称呼你',
                          hintText: '阿屿',
                          counterText: '',
                          prefixIcon: Icon(
                            Icons.person_outline_rounded,
                            size: 19,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _aiName,
                        maxLength: 10,
                        textInputAction: TextInputAction.next,
                        onChanged: (_) => setState(() {}),
                        decoration: const InputDecoration(
                          labelText: '她的名字',
                          hintText: '晚晚',
                          counterText: '',
                          prefixIcon: Icon(
                            Icons.nights_stay_outlined,
                            size: 19,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                const SettingsSectionLabel(title: 'VOICE · 说话的方式'),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _tones.map((_ToneChoice choice) {
                    final bool selected = _tone == choice.id;
                    return PressableScale(
                      onTap: () => setState(() => _tone = choice.id),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: MediaQuery.sizeOf(context).width * 0.435,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: selected
                              ? Theme.of(context).colorScheme.primary
                                    .withOpacity(0.12)
                              : palette.glass,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: selected
                                ? Theme.of(context).colorScheme.primary
                                      .withOpacity(0.35)
                                : palette.border,
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Text(
                                  choice.label,
                                  style: Theme.of(context).textTheme.labelLarge
                                      ?.copyWith(
                                        fontSize: 11.5,
                                        fontWeight: FontWeight.w700,
                                        color: selected
                                            ? Theme.of(context)
                                                  .colorScheme
                                                  .primary
                                            : null,
                                      ),
                                ),
                                const Spacer(),
                                if (selected)
                                  Icon(
                                    Icons.check_circle_rounded,
                                    size: 13,
                                    color: Theme.of(context)
                                        .colorScheme
                                        .primary,
                                  ),
                              ],
                            ),
                            const SizedBox(height: 5),
                            Text(
                              choice.caption,
                              style: Theme.of(context).textTheme.labelSmall
                                  ?.copyWith(
                                    color: palette.muted,
                                    fontSize: 8.5,
                                    height: 1.4,
                                  ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _persona,
                  maxLength: 900,
                  maxLines: 7,
                  minLines: 5,
                  style: Theme.of(context).textTheme.bodySmall
                      ?.copyWith(height: 1.7, fontSize: 11.5),
                  decoration: const InputDecoration(
                    labelText: '她的人设与生活',
                    hintText: '写下她的性格、喜好、说话习惯，以及她如何看待你。',
                    alignLabelWithHint: true,
                    counterStyle: TextStyle(fontSize: 8),
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: <Widget>[
                    Icon(
                      Icons.info_outline_rounded,
                      size: 12,
                      color: palette.muted,
                    ),
                    const SizedBox(width: 5),
                    Expanded(
                      child: Text(
                        '人设会同时影响单机引擎与 DeepSeek 的提示词。写具体一点，她会更像一个真实的人。',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: palette.muted,
                          fontSize: 8.3,
                          height: 1.55,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                const SettingsSectionLabel(title: 'HABITS · 陪伴习惯'),
                SettingsGroup(
                  margin: EdgeInsets.zero,
                  children: <Widget>[
                    SettingsSwitchTile(
                      icon: Icons.auto_awesome_rounded,
                      title: '让她自己更新资料',
                      subtitle: '自动更换头像、签名，偶尔改一个昵称',
                      value: settings.autoProfile,
                      onChanged: (bool value) {
                        AppFeedback.tap(settings.haptics);
                        unawaited(settings.setAutoProfile(value));
                      },
                      iconColor: palette.auroraB,
                    ),
                    SettingsSwitchTile(
                      icon: Icons.explore_outlined,
                      title: '让她自己发动态',
                      subtitle: '每隔一段时间记录生活，并配上本地画卡',
                      value: settings.autoMoments,
                      onChanged: (bool value) {
                        AppFeedback.tap(settings.haptics);
                        unawaited(settings.setAutoMoments(value));
                      },
                    ),
                    SettingsSwitchTile(
                      icon: Icons.notifications_active_outlined,
                      title: '允许她主动找你',
                      subtitle: '她会挑合适的时间发来一条私聊，而不是定时通知',
                      value: settings.proactiveEnabled,
                      onChanged: (bool value) {
                        AppFeedback.tap(settings.haptics);
                        unawaited(settings.setProactiveEnabled(value));
                      },
                    ),
                    if (settings.proactiveEnabled)
                      SettingsTile(
                        icon: Icons.schedule_rounded,
                        title: '主动消息间隔',
                        subtitle: '应用打开或回到前台时感知并补上',
                        trailingText: settings.proactiveIntervalLabel,
                        onTap: () => _chooseInterval(settings),
                      ),
                    SettingsSwitchTile(
                      icon: Icons.volume_up_outlined,
                      title: '自动朗读她的消息',
                      subtitle: '使用系统中文语音引擎，把文字读给你听',
                      value: settings.autoSpeak,
                      onChanged: (bool value) {
                        AppFeedback.tap(settings.haptics);
                        unawaited(settings.setAutoSpeak(value));
                      },
                    ),
                    SettingsSwitchTile(
                      icon: Icons.vibration_rounded,
                      title: '轻柔触感',
                      subtitle: '点赞、切换页面和保存时提供轻微震动',
                      value: settings.haptics,
                      onChanged: (bool value) {
                        unawaited(settings.setHaptics(value));
                        if (value) AppFeedback.tap(true);
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  '星屿不会常驻后台。她会在你打开应用或回到前台时，判断是否该主动发来消息；重要纪念日的提醒也会在下次打开时补上。',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted.withOpacity(0.48),
                    fontSize: 8.2,
                    height: 1.6,
                  ),
                ),
                const SizedBox(height: 20),
                const SettingsSectionLabel(title: 'NOW · 现在就试试'),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: <Widget>[
                    _ActionChip(
                      icon: Icons.chat_bubble_outline_rounded,
                      label: _messaging ? '正在发消息…' : '让她主动找我',
                      busy: _messaging,
                      onTap: _messaging ? null : _triggerMessage,
                    ),
                    _ActionChip(
                      icon: Icons.explore_outlined,
                      label: _posting || moments.generating
                          ? '正在发动态…'
                          : '让她发条动态',
                      busy: _posting || moments.generating,
                      onTap: _posting || moments.generating
                          ? null
                          : _triggerMoment,
                    ),
                    _ActionChip(
                      icon: Icons.auto_awesome_rounded,
                      label: _evolving ? '正在变化…' : '换个造型',
                      busy: _evolving,
                      onTap: _evolving ? null : _evolve,
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                Center(
                  child: Text(
                    '人设不是牢笼。她会在你们的相处里慢慢长出自己的样子。',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: palette.muted.withOpacity(0.36),
                      fontSize: 8.3,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
            child: GradientButton(
              label: _saving ? '正在保存…' : '保存她的设定',
              icon: Icons.check_rounded,
              height: 50,
              borderRadius: 16,
              busy: _saving,
              onPressed: _saving ? null : _saveIdentity,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHero(
    BuildContext context,
    CompanionProfile profile,
    AppPalette palette,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[palette.auroraA.withOpacity(0.20), palette.glass],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: palette.border),
      ),
      child: Row(
        children: <Widget>[
          CompanionAvatar(
            seed: profile.avatarSeed,
            size: 62,
            nickname: profile.nickname,
            showOnline: true,
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Flexible(
                      child: Text(
                        _aiName.text.trim().isEmpty
                            ? profile.nickname
                            : _aiName.text.trim(),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.w800),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      '现在',
                      style: Theme.of(context).textTheme.labelSmall
                          ?.copyWith(color: palette.muted, fontSize: 7.5),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  profile.signature,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted,
                    fontSize: 9,
                    height: 1.5,
                    fontStyle: FontStyle.italic,
                  ),
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 5,
                  runSpacing: 4,
                  children: <Widget>[
                    _miniTag('${profile.toneLabel}', palette),
                    _miniTag('相伴 ${profile.daysTogether} 天', palette),
                    _miniTag('心动 ${profile.affection}%', palette),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniTag(String label, AppPalette palette) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: palette.glassStrong.withOpacity(0.55),
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: palette.border),
      ),
      child: Text(
        label,
        style: Theme.of(context).textTheme.labelSmall
            ?.copyWith(color: palette.muted, fontSize: 7.5),
      ),
    );
  }
}

class _ToneChoice {
  const _ToneChoice(this.id, this.label, this.caption);

  final String id;
  final String label;
  final String caption;
}

class _ActionChip extends StatelessWidget {
  const _ActionChip({
    required this.icon,
    required this.label,
    required this.busy,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool busy;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    return PressableScale(
      onTap: onTap,
      enabled: onTap != null,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(
          color: palette.glass,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: palette.border),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (busy)
              SizedBox(
                width: 13,
                height: 13,
                child: CircularProgressIndicator(
                  strokeWidth: 1.5,
                  color: Theme.of(context).colorScheme.primary,
                ),
              )
            else
              Icon(
                icon,
                size: 13,
                color: Theme.of(context).colorScheme.primary,
              ),
            const SizedBox(width: 6),
            Text(
              label,
              style: Theme.of(context).textTheme.labelSmall
                  ?.copyWith(color: palette.muted, fontSize: 9.5),
            ),
          ],
        ),
      ),
    );
  }
}
