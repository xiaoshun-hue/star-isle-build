import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/widgets/app_feedback_widgets.dart';
import '../../../core/widgets/detail_scaffold.dart';
import '../../../core/widgets/glass_panel.dart';
import '../../../services/free_edge_tts_service.dart';
import '../../../services/sense_audio_tts_service.dart';
import '../../../services/tts_service.dart';
import '../../../state/settings_controller.dart';
import 'widgets/settings_tile.dart';

class VoiceSettingsScreen extends StatefulWidget {
  const VoiceSettingsScreen({super.key});

  @override
  State<VoiceSettingsScreen> createState() => _VoiceSettingsScreenState();
}

class _VoiceSettingsScreenState extends State<VoiceSettingsScreen> {
  double _rate = 1.0;
  double _pitch = 0.0;
  double _senseRate = 1.0;
  double _sensePitch = 0.0;
  bool _testing = false;
  bool _clearing = false;

  @override
  void initState() {
    super.initState();
    final SettingsController settings = context.read<SettingsController>();
    _rate = settings.edgeRate;
    _pitch = settings.edgePitch;
    _senseRate = settings.senseRate;
    _sensePitch = settings.sensePitch;
  }

  void _applyTts(SettingsController settings) {
    context.read<TtsService>().configure(
      engine: settings.ttsEngine,
      edgeVoice: settings.edgeVoice,
      edgeRate: settings.edgeRate,
      edgePitch: settings.edgePitch,
      senseApiKey: settings.senseAudioApiKey,
      senseVoice: settings.senseVoice,
      senseRate: settings.senseRate,
      sensePitch: settings.sensePitch,
    );
  }

  Future<void> _selectEngine(SettingsController settings, String engine) async {
    if (settings.ttsEngine == engine) return;
    await settings.setTtsEngine(engine);
    if (!mounted) return;
    _applyTts(settings);
  }

  Future<void> _selectVoice(SettingsController settings, String voice) async {
    if (settings.edgeVoice == voice) return;
    await settings.setEdgeVoice(voice);
    if (!mounted) return;
    _applyTts(settings);
  }

  Future<void> _selectSenseVoice(
    SettingsController settings,
    String voice,
  ) async {
    if (settings.senseVoice == voice) return;
    await settings.setSenseVoice(voice);
    if (!mounted) return;
    _applyTts(settings);
  }

  Future<void> _editSenseKey(SettingsController settings) async {
    final TextEditingController controller = TextEditingController(
      text: settings.senseAudioApiKey,
    );
    final String? key = await showDialog<String>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('SenseAudio API Key'),
          content: TextField(
            controller: controller,
            autofocus: true,
            obscureText: true,
            enableSuggestions: false,
            autocorrect: false,
            decoration: const InputDecoration(
              hintText: 'Bearer Key，只保存在本机',
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('取消'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(controller.text),
              child: const Text('保存'),
            ),
          ],
        );
      },
    );
    controller.dispose();
    if (key == null) return;
    await settings.saveSenseAudioApiKey(key);
    if (mounted) {
      _applyTts(settings);
      showAppToast(context, 'SenseAudio Key 已保存');
    }
  }

  Future<void> _testVoice(SettingsController settings) async {
    if (_testing) return;
    setState(() => _testing = true);
    try {
      _applyTts(settings);
      final bool ok = await context.read<TtsService>().speak(
        'voice_test',
        '讲道理说哈，今天也认真陪你。',
      );
      if (!mounted) return;
      showAppToast(
        context,
        ok ? '已开始试听' : '语音暂时不可用，已尝试系统朗读。',
        icon: Icons.record_voice_over_outlined,
      );
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  Future<void> _clearCache() async {
    if (_clearing) return;
    setState(() => _clearing = true);
    try {
      final int removed = await FreeEdgeTtsService.instance.clearCache();
      if (!mounted) return;
      showAppToast(context, removed > 0 ? '已清理 $removed 个语音缓存' : '没有可清理的语音缓存');
    } finally {
      if (mounted) setState(() => _clearing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final SettingsController settings = context.watch<SettingsController>();
    final bool edge = settings.ttsEngine == 'edge';
    final bool sense = settings.ttsEngine == 'sense';
    return DetailScaffold(
      title: '语音与主动消息',
      subtitle: '朗读引擎，以及她主动出现的方式',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 30),
        physics: const BouncingScrollPhysics(),
        children: <Widget>[
          const SettingsSectionLabel(title: 'VOICE ENGINE · 朗读引擎'),
          _engineCard(
            context,
            settings,
            id: 'system',
            icon: Icons.phone_android_rounded,
            title: '系统本地朗读',
            subtitle: '不联网，使用手机自带的中文语音引擎',
            selected: !edge && !sense,
          ),
          const SizedBox(height: 10),
          _engineCard(
            context,
            settings,
            id: 'edge',
            icon: Icons.cloud_outlined,
            title: '免费在线 AI 音色',
            subtitle: 'Edge-TTS · 免密钥，需要联网；接口存在远期失效风险',
            selected: edge,
          ),
          const SizedBox(height: 10),
          _engineCard(
            context,
            settings,
            id: 'sense',
            icon: Icons.cloud_done_outlined,
            title: 'SenseAudio 云端音色',
            subtitle: '官方云端 TTS · 需要 API Key；失败自动系统朗读',
            selected: sense,
          ),
          if (sense) ...<Widget>[
            const SizedBox(height: 18),
            const SettingsSectionLabel(title: 'SENSEAUDIO · API 与音色'),
            GlassPanel(
              child: ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.key_outlined, color: palette.muted),
                title: const Text('SenseAudio API Key'),
                subtitle: Text(
                  settings.hasSenseAudioKey
                      ? '已保存：${_maskedKey(settings.senseAudioApiKey)}'
                      : '未配置，语音会降级系统朗读',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted,
                  ),
                ),
                trailing: TextButton(
                  onPressed: () => unawaited(_editSenseKey(settings)),
                  child: Text(settings.hasSenseAudioKey ? '修改' : '设置'),
                ),
              ),
            ),
            const SizedBox(height: 12),
            GlassPanel(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(
                children: SenseAudioTtsService.voices.map((SenseAudioVoice voice) {
                  final bool selected = settings.senseVoice == voice.id;
                  return RadioListTile<String>(
                    value: voice.id,
                    groupValue: settings.senseVoice,
                    onChanged: (String? value) {
                      if (value != null) {
                        unawaited(_selectSenseVoice(settings, value));
                      }
                    },
                    activeColor: Theme.of(context).colorScheme.primary,
                    title: Text(
                      voice.name,
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    subtitle: Text(
                      voice.description,
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: palette.muted,
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 14),
            GlassPanel(
              padding: const EdgeInsets.fromLTRB(15, 13, 15, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Text('SenseAudio 语速', style: Theme.of(context).textTheme.titleSmall),
                      const Spacer(),
                      Text(
                        '${_senseRate.toStringAsFixed(2)}×',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: palette.muted,
                        ),
                      ),
                    ],
                  ),
                  Slider(
                    value: _senseRate,
                    min: 0.5,
                    max: 2.0,
                    divisions: 15,
                    onChanged: (double value) => setState(() => _senseRate = value),
                    onChangeEnd: (double value) async {
                      await settings.setSenseRate(value);
                      if (mounted) _applyTts(settings);
                    },
                  ),
                  Row(
                    children: <Widget>[
                      Text('SenseAudio 音调', style: Theme.of(context).textTheme.titleSmall),
                      const Spacer(),
                      Text(
                        _sensePitch == 0 ? '默认' : '${_sensePitch > 0 ? '+' : ''}${_sensePitch.round()}',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: palette.muted,
                        ),
                      ),
                    ],
                  ),
                  Slider(
                    value: _sensePitch,
                    min: -12,
                    max: 12,
                    divisions: 24,
                    onChanged: (double value) => setState(() => _sensePitch = value),
                    onChangeEnd: (double value) async {
                      await settings.setSensePitch(value);
                      if (mounted) _applyTts(settings);
                    },
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      onPressed: _testing
                          ? null
                          : () => unawaited(_testVoice(settings)),
                      icon: _testing
                          ? const SizedBox(
                              width: 14,
                              height: 14,
                              child: CircularProgressIndicator(strokeWidth: 1.5),
                            )
                          : const Icon(Icons.play_circle_outline_rounded, size: 17),
                      label: const Text('试听'),
                    ),
                  ),
                ],
              ),
            ),
            Text(
              '音色是否可调用取决于你的 SenseAudio 套餐；失败会自动降级系统朗读。',
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: palette.muted.withOpacity(0.6),
                fontSize: 8.5,
                height: 1.5,
              ),
            ),
          ],
          if (edge) ...<Widget>[
            const SizedBox(height: 18),
            const SettingsSectionLabel(title: 'VOICE · 音色'),
            GlassPanel(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(
                children: FreeEdgeTtsService.voices.map((EdgeTtsVoice voice) {
                  final bool selected = settings.edgeVoice == voice.id;
                  return RadioListTile<String>(
                    value: voice.id,
                    groupValue: settings.edgeVoice,
                    onChanged: (String? value) {
                      if (value != null) {
                        unawaited(_selectVoice(settings, value));
                      }
                    },
                    activeColor: Theme.of(context).colorScheme.primary,
                    title: Text(
                      voice.name,
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    subtitle: Text(
                      voice.description,
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: palette.muted,
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 14),
            GlassPanel(
              padding: const EdgeInsets.fromLTRB(15, 13, 15, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Text('语速', style: Theme.of(context).textTheme.titleSmall),
                      const Spacer(),
                      Text(
                        '${_rate.toStringAsFixed(2)}×',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: palette.muted,
                        ),
                      ),
                    ],
                  ),
                  Slider(
                    value: _rate,
                    min: 0.70,
                    max: 1.30,
                    divisions: 12,
                    onChanged: (double value) => setState(() => _rate = value),
                    onChangeEnd: (double value) async {
                      await settings.setEdgeRate(value);
                      if (mounted) _applyTts(settings);
                    },
                  ),
                  Row(
                    children: <Widget>[
                      Text('音调', style: Theme.of(context).textTheme.titleSmall),
                      const Spacer(),
                      Text(
                        _pitch == 0 ? '默认' : '${_pitch > 0 ? '+' : ''}${_pitch.round()} Hz',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: palette.muted,
                        ),
                      ),
                    ],
                  ),
                  Slider(
                    value: _pitch,
                    min: -12,
                    max: 12,
                    divisions: 24,
                    onChanged: (double value) => setState(() => _pitch = value),
                    onChangeEnd: (double value) async {
                      await settings.setEdgePitch(value);
                      if (mounted) _applyTts(settings);
                    },
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      onPressed: _testing
                          ? null
                          : () => unawaited(_testVoice(settings)),
                      icon: _testing
                          ? const SizedBox(
                              width: 14,
                              height: 14,
                              child: CircularProgressIndicator(strokeWidth: 1.5),
                            )
                          : const Icon(Icons.play_circle_outline_rounded, size: 17),
                      label: const Text('试听'),
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 18),
          const SettingsSectionLabel(title: 'PROACTIVE · 主动消息形式'),
          GlassPanel(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(
              children: <Widget>[
                _modeTile(
                  context,
                  settings,
                  id: 'text',
                  icon: Icons.chat_bubble_outline_rounded,
                  title: '文字消息',
                  subtitle: '主动私聊全部是文字气泡（默认）',
                ),
                _modeTile(
                  context,
                  settings,
                  id: 'voice',
                  icon: Icons.graphic_eq_rounded,
                  title: '语音气泡',
                  subtitle: '带字幕，点击才播放，不自动出声',
                ),
                _modeTile(
                  context,
                  settings,
                  id: 'random',
                  icon: Icons.shuffle_rounded,
                  title: '随机文字/语音',
                  subtitle: '每次主动消息随机选择一种形式',
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          GlassPanel(
            padding: EdgeInsets.zero,
            child: SwitchListTile.adaptive(
              value: settings.replyVoiceEnabled,
              activeColor: Theme.of(context).colorScheme.primary,
              onChanged: (bool value) {
                unawaited(settings.setReplyVoiceEnabled(value));
              },
              secondary: Icon(
                Icons.multitrack_audio_rounded,
                color: palette.muted,
              ),
              title: const Text('普通聊天也用语音条'),
              subtitle: const Text('默认关闭；开启后 AI 的普通回复会变成带字幕语音条'),
            ),
          ),
          const SizedBox(height: 14),
          GlassPanel(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Icon(
                      Icons.cleaning_services_outlined,
                      size: 18,
                      color: palette.muted,
                    ),
                    const SizedBox(width: 9),
                    Expanded(
                      child: Text(
                        '语音缓存清理',
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                    ),
                    TextButton(
                      onPressed: _clearing
                          ? null
                          : () => unawaited(_clearCache()),
                      child: Text(_clearing ? '清理中…' : '清理'),
                    ),
                  ],
                ),
                Text(
                  '主动语音气泡会缓存本地 MP3，超过 7 天的文件会自动清理。',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Icon(
                Icons.info_outline_rounded,
                size: 13,
                color: palette.muted.withOpacity(0.6),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'Edge-TTS 使用非官方公开接口，免密钥但不保证长期可用；'
                  '断网、接口失效或解码失败时会自动降级为系统本地朗读。',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted.withOpacity(0.6),
                    fontSize: 8.8,
                    height: 1.6,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _maskedKey(String key) {
    final String value = key.trim();
    if (value.length <= 8) return '已保存';
    return '${value.substring(0, 4)}…${value.substring(value.length - 4)}';
  }

  Widget _engineCard(
    BuildContext context,
    SettingsController settings, {
    required String id,
    required IconData icon,
    required String title,
    required String subtitle,
    required bool selected,
  }) {
    final AppPalette palette = context.palette;
    return GlassPanel(
      onTap: () => unawaited(_selectEngine(settings, id)),
      border: Border.all(
        color: selected
            ? Theme.of(context).colorScheme.primary.withOpacity(0.7)
            : palette.border,
        width: selected ? 1.2 : 0.8,
      ),
      child: Row(
        children: <Widget>[
          Icon(icon, size: 21, color: selected ? Theme.of(context).colorScheme.primary : palette.muted),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(title, style: Theme.of(context).textTheme.titleSmall),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            selected ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded,
            size: 19,
            color: selected ? Theme.of(context).colorScheme.primary : palette.muted,
          ),
        ],
      ),
    );
  }

  Widget _modeTile(
    BuildContext context,
    SettingsController settings, {
    required String id,
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    final AppPalette palette = context.palette;
    final bool selected = settings.proactiveMessageMode == id;
    return ListTile(
      onTap: () {
        unawaited(settings.setProactiveMessageMode(id));
      },
      leading: Icon(
        icon,
        size: 20,
        color: selected ? Theme.of(context).colorScheme.primary : palette.muted,
      ),
      title: Text(title, style: Theme.of(context).textTheme.titleSmall),
      subtitle: Text(
        subtitle,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
          color: palette.muted,
        ),
      ),
      trailing: Icon(
        selected ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded,
        size: 19,
        color: selected ? Theme.of(context).colorScheme.primary : palette.muted,
      ),
    );
  }
}
