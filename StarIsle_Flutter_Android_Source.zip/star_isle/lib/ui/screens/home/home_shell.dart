import 'dart:async';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/utils/app_feedback.dart';
import '../../../core/widgets/aurora_background.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../services/tts_service.dart';
import '../../../state/album_controller.dart';
import '../../../state/anniversary_controller.dart';
import '../../../state/companion_controller.dart';
import '../../../state/moments_controller.dart';
import '../../../state/settings_controller.dart';
import '../album/album_screen.dart';
import '../anniversary/anniversary_screen.dart';
import '../chat/chat_screen.dart';
import '../moments/moments_screen.dart';
import '../profile/profile_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> with WidgetsBindingObserver {
  final PageController _pageController = PageController();
  int _index = 0;
  bool _keyboardVisible = false;

  static const List<Widget> _pages = <Widget>[
    ChatScreen(),
    MomentsScreen(),
    AnniversaryScreen(),
    AlbumScreen(),
    ProfileScreen(),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final CompanionController chat = context.read<CompanionController>();
      chat.setChatVisible(true);
      context.read<MomentsController>().startAutoPilot();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pageController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (!mounted) return;
    final CompanionController chat = context.read<CompanionController>();
    final TtsService tts = context.read<TtsService>();
    if (state == AppLifecycleState.resumed) {
      chat.setAppActive(true);
      if (_index == 1) {
        context.read<MomentsController>().markSeen();
      }
      chat.setChatVisible(_index == 0);
      unawaited(context.read<MomentsController>().autoPilotNow());
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      chat.setAppActive(false);
      unawaited(tts.stop());
    }
  }

  void _onPageChanged(int index) {
    if (!mounted) return;
    FocusManager.instance.primaryFocus?.unfocus();
    setState(() => _index = index);
    final SettingsController settings = context.read<SettingsController>();
    AppFeedback.tap(settings.haptics);
    final CompanionController chat = context.read<CompanionController>();
    chat.setChatVisible(index == 0);
    switch (index) {
      case 1:
        context.read<MomentsController>().markSeen();
        break;
      case 2:
        unawaited(context.read<AnniversaryController>().refresh());
        break;
      case 3:
        unawaited(context.read<AlbumController>().refresh());
        break;
      default:
        break;
    }
  }

  void _selectTab(int index) {
    if (index == _index) return;
    final SettingsController settings = context.read<SettingsController>();
    AppFeedback.tap(settings.haptics);
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 440),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    _keyboardVisible = MediaQuery.viewInsetsOf(context).bottom > 0;
    final AppPalette palette = context.palette;
    return AuroraBackground(
      showStars: true,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        resizeToAvoidBottomInset: true,
        body: Column(
          children: <Widget>[
            Expanded(
              child: PageView(
                controller: _pageController,
                physics: const BouncingScrollPhysics(),
                onPageChanged: _onPageChanged,
                children: _pages,
              ),
            ),
            AnimatedSize(
              duration: const Duration(milliseconds: 260),
              curve: Curves.easeOutCubic,
              child: _keyboardVisible
                  ? const SizedBox.shrink()
                  : _buildNavigationBar(context, palette),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavigationBar(BuildContext context, AppPalette palette) {
    final int unread = context.select<CompanionController, int>(
      (CompanionController controller) => controller.unreadCount,
    );
    final bool newMoments = context.select<MomentsController, bool>(
      (MomentsController controller) => controller.hasNewAiMoment,
    );
    final int todayAnniversaries = context.select<AnniversaryController, int>(
      (AnniversaryController controller) => controller.todayCount,
    );

    final List<_NavItem> items = <_NavItem>[
      _NavItem(
        label: '消息',
        icon: Icons.chat_bubble_outline_rounded,
        selectedIcon: Icons.chat_bubble_rounded,
        badge: unread,
      ),
      _NavItem(
        label: '动态',
        icon: Icons.explore_outlined,
        selectedIcon: Icons.explore_rounded,
        dot: newMoments,
      ),
      _NavItem(
        label: '纪念',
        icon: Icons.event_outlined,
        selectedIcon: Icons.event_rounded,
        dot: todayAnniversaries > 0,
      ),
      _NavItem(
        label: '相册',
        icon: Icons.photo_library_outlined,
        selectedIcon: Icons.photo_library_rounded,
      ),
      _NavItem(
        label: '我们',
        icon: Icons.favorite_border_rounded,
        selectedIcon: Icons.favorite_rounded,
      ),
    ];

    return SafeArea(
      top: false,
      minimum: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(26),
          child: BackdropFilter(
            filter: ui.ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              height: 67,
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
              decoration: BoxDecoration(
                color: palette.navBar,
                borderRadius: BorderRadius.circular(26),
                border: Border.all(color: palette.border, width: 0.8),
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: palette.shadow.withOpacity(
                      palette.isDark ? 0.28 : 0.10,
                    ),
                    blurRadius: 28,
                    offset: const Offset(0, 12),
                  ),
                ],
              ),
              child: Row(
                children: List<Widget>.generate(items.length, (int index) {
                  final _NavItem item = items[index];
                  final bool selected = _index == index;
                  final Color accent = Theme.of(context).colorScheme.primary;
                  return Expanded(
                    child: PressableScale(
                      onTap: () => _selectTab(index),
                      scale: 0.95,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 280),
                        curve: Curves.easeOutCubic,
                        margin: const EdgeInsets.symmetric(horizontal: 1),
                        decoration: BoxDecoration(
                          color: selected
                              ? accent.withOpacity(palette.isDark ? 0.13 : 0.10)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            SizedBox(
                              height: 25,
                              child: Stack(
                                clipBehavior: Clip.none,
                                alignment: Alignment.center,
                                children: <Widget>[
                                  AnimatedScale(
                                    scale: selected ? 1.07 : 1,
                                    duration: const Duration(milliseconds: 260),
                                    curve: Curves.easeOutBack,
                                    child: Icon(
                                      selected ? item.selectedIcon : item.icon,
                                      size: 22,
                                      color: selected
                                          ? accent
                                          : palette.muted.withOpacity(0.72),
                                    ),
                                  ),
                                  if (item.badge > 0)
                                    Positioned(
                                      top: -3,
                                      right: 5,
                                      child: Container(
                                        constraints: const BoxConstraints(
                                          minWidth: 16,
                                          minHeight: 16,
                                        ),
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 4,
                                        ),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFFF718B),
                                          borderRadius: BorderRadius.circular(
                                            99,
                                          ),
                                          border: Border.all(
                                            color: palette.navBar,
                                            width: 1.4,
                                          ),
                                        ),
                                        child: Center(
                                          child: Text(
                                            item.badge > 9
                                                ? '9+'
                                                : '${item.badge}',
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 8.5,
                                              fontWeight: FontWeight.w700,
                                              height: 1.1,
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                  else if (item.dot)
                                    Positioned(
                                      top: 0,
                                      right: 9,
                                      child: Container(
                                        width: 6.5,
                                        height: 6.5,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: palette.auroraB,
                                          boxShadow: <BoxShadow>[
                                            BoxShadow(
                                              color: palette.auroraB
                                                  .withOpacity(0.5),
                                              blurRadius: 5,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 2),
                            AnimatedDefaultTextStyle(
                              duration: const Duration(milliseconds: 240),
                              style: Theme.of(context).textTheme.labelSmall!
                                  .copyWith(
                                    fontSize: 9.5,
                                    height: 1,
                                    fontWeight: selected
                                        ? FontWeight.w700
                                        : FontWeight.w500,
                                    letterSpacing: 0.2,
                                    color: selected
                                        ? accent
                                        : palette.muted.withOpacity(0.66),
                                  ),
                              child: Text(item.label),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem {
  const _NavItem({
    required this.label,
    required this.icon,
    required this.selectedIcon,
    this.badge = 0,
    this.dot = false,
  });

  final String label;
  final IconData icon;
  final IconData selectedIcon;
  final int badge;
  final bool dot;
}
