import 'dart:math' as math;
import 'dart:ui' show BlurStyle, MaskFilter;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/widgets/aurora_background.dart';
import '../../../core/widgets/gradient_button.dart';
import '../../../core/widgets/typing_dots.dart';
import '../../../state/album_controller.dart';
import '../../../state/anniversary_controller.dart';
import '../../../state/companion_controller.dart';
import '../../../state/moments_controller.dart';
import '../../../state/settings_controller.dart';
import '../../../services/tts_service.dart';
import '../home/home_shell.dart';
import '../onboarding/onboarding_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late final AnimationController _ambient;
  late final AnimationController _entrance;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;

  bool _bootStarted = false;
  bool _loading = true;
  bool _navigated = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 14),
    )..repeat();
    _entrance = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..forward();
    final CurvedAnimation curved = CurvedAnimation(
      parent: _entrance,
      curve: Curves.easeOutCubic,
    );
    _fade = curved;
    _slide = Tween<Offset>(
      begin: const Offset(0, 0.06),
      end: Offset.zero,
    ).animate(curved);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _bootstrap();
    });
  }

  Future<void> _bootstrap() async {
    if (_bootStarted || !mounted) return;
    _bootStarted = true;
    if (_error != null) {
      setState(() {
        _error = null;
        _loading = true;
      });
    }
    final Stopwatch watch = Stopwatch()..start();
    try {
      final CompanionController companion = context.read<CompanionController>();
      final MomentsController moments = context.read<MomentsController>();
      final AnniversaryController anniversaries = context
          .read<AnniversaryController>();
      final AlbumController album = context.read<AlbumController>();
      final TtsService tts = context.read<TtsService>();

      await companion.initialize();
      await Future.wait<void>(<Future<void>>[
        moments.initialize(),
        anniversaries.initialize(),
        album.initialize(),
        tts.initialize(),
      ]).timeout(const Duration(seconds: 18));

      final int remaining = 1500 - watch.elapsedMilliseconds;
      if (remaining > 0) {
        await Future<void>.delayed(Duration(milliseconds: remaining));
      }
      if (!mounted || _navigated) return;
      _navigated = true;
      final SettingsController settings = context.read<SettingsController>();
      final Widget destination = settings.onboardingDone
          ? const HomeShell()
          : const OnboardingScreen();
      await Navigator.of(context).pushReplacement(
        PageRouteBuilder<void>(
          transitionDuration: const Duration(milliseconds: 620),
          reverseTransitionDuration: const Duration(milliseconds: 400),
          pageBuilder: (_, __, ___) => destination,
          transitionsBuilder:
              (_, Animation<double> animation, __, Widget child) {
                final CurvedAnimation curve = CurvedAnimation(
                  parent: animation,
                  curve: Curves.easeOutCubic,
                );
                return FadeTransition(
                  opacity: curve,
                  child: ScaleTransition(
                    scale: Tween<double>(begin: 1.015, end: 1.0).animate(curve),
                    child: child,
                  ),
                );
              },
        ),
      );
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = error.toString();
        _bootStarted = false;
      });
    }
  }

  @override
  void dispose() {
    _ambient.dispose();
    _entrance.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    return PopScope(
      canPop: false,
      child: AuroraBackground(
        showStars: true,
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Column(
                children: <Widget>[
                  const Spacer(flex: 3),
                  FadeTransition(
                    opacity: _fade,
                    child: SlideTransition(
                      position: _slide,
                      child: _buildBrand(context, palette),
                    ),
                  ),
                  const Spacer(flex: 2),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 350),
                    child: _error == null
                        ? _buildLoading(context, palette)
                        : _buildError(context, palette),
                  ),
                  const SizedBox(height: 28),
                  Text(
                    '本地优先 · 只属于你',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: palette.muted.withOpacity(0.62),
                      letterSpacing: 1.6,
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBrand(BuildContext context, AppPalette palette) {
    return Column(
      children: <Widget>[
        AnimatedBuilder(
          animation: _ambient,
          builder: (BuildContext context, _) {
            final double pulse =
                0.5 + math.sin(_ambient.value * math.pi * 2) * 0.5;
            return SizedBox(
              width: 258,
              height: 258,
              child: Stack(
                alignment: Alignment.center,
                children: <Widget>[
                  CustomPaint(
                    size: const Size(258, 258),
                    painter: _OrbitPainter(
                      progress: _ambient.value,
                      accent: palette.auroraB,
                      glow: palette.auroraA,
                    ),
                  ),
                  Transform.scale(
                    scale: 1 + pulse * 0.022,
                    child: Container(
                      width: 144,
                      height: 144,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: <Color>[
                            palette.auroraA.withOpacity(0.95),
                            palette.auroraB.withOpacity(0.92),
                            const Color(0xFFF8D8B0),
                          ],
                        ),
                        boxShadow: <BoxShadow>[
                          BoxShadow(
                            color: palette.auroraB.withOpacity(0.28),
                            blurRadius: 54,
                            spreadRadius: 7,
                          ),
                          BoxShadow(
                            color: palette.auroraA.withOpacity(0.18),
                            blurRadius: 90,
                            spreadRadius: 18,
                          ),
                        ],
                      ),
                      child: Stack(
                        alignment: Alignment.center,
                        children: <Widget>[
                          Icon(
                            Icons.nights_stay_rounded,
                            size: 57,
                            color: Colors.white.withOpacity(0.95),
                          ),
                          Positioned(
                            top: 30,
                            right: 33,
                            child: Icon(
                              Icons.auto_awesome,
                              size: 14,
                              color: Colors.white.withOpacity(0.8),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 23,
                    child: Container(
                      width: 62,
                      height: 2,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(99),
                        gradient: LinearGradient(
                          colors: <Color>[
                            Colors.transparent,
                            palette.auroraB.withOpacity(0.7),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 5),
        ShaderMask(
          shaderCallback: (Rect bounds) {
            return LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: <Color>[
                Theme.of(context).colorScheme.onSurface,
                palette.auroraB,
                Theme.of(context).colorScheme.onSurface.withOpacity(0.84),
              ],
            ).createShader(bounds);
          },
          child: Text(
            '星屿',
            style: Theme.of(context).textTheme.displaySmall?.copyWith(
              color: Colors.white,
              fontSize: 46,
              fontWeight: FontWeight.w800,
              letterSpacing: 9,
            ),
          ),
        ),
        const SizedBox(height: 13),
        Text(
          '把晚风留在身边',
          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.64),
            letterSpacing: 4,
            fontSize: 14,
          ),
        ),
        const SizedBox(height: 7),
        Text(
          'S T A R   I S L E',
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
            color: palette.muted.withOpacity(0.55),
            letterSpacing: 3.4,
            fontSize: 9,
          ),
        ),
      ],
    );
  }

  Widget _buildLoading(BuildContext context, AppPalette palette) {
    if (_error != null) return const SizedBox.shrink();
    return Column(
      key: const ValueKey<String>('loading'),
      children: <Widget>[
        TypingDots(
          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.36),
          size: 5,
          spacing: 6,
        ),
        const SizedBox(height: 16),
        Text(
          _loading ? '正在点亮小岛…' : '马上就好',
          style: Theme.of(context).textTheme.bodySmall
              ?.copyWith(color: palette.muted, letterSpacing: 1),
        ),
      ],
    );
  }

  Widget _buildError(BuildContext context, AppPalette palette) {
    return Container(
      key: const ValueKey<String>('error'),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: palette.glass,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: palette.border),
      ),
      child: Column(
        children: <Widget>[
          Icon(
            Icons.cloud_off_rounded,
            color: Theme.of(context).colorScheme.error,
            size: 26,
          ),
          const SizedBox(height: 10),
          Text(
            '小岛暂时没能亮起来',
            style: Theme.of(context).textTheme.titleSmall
                ?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 6),
          Text(
            _error ?? '请稍后重试',
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall
                ?.copyWith(color: palette.muted, height: 1.5),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: 170,
            child: GradientButton(
              label: '重新点亮',
              icon: Icons.refresh_rounded,
              height: 46,
              borderRadius: 15,
              onPressed: _bootstrap,
            ),
          ),
        ],
      ),
    );
  }
}

class _OrbitPainter extends CustomPainter {
  _OrbitPainter({
    required this.progress,
    required this.accent,
    required this.glow,
  });

  final double progress;
  final Color accent;
  final Color glow;

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = Offset(size.width / 2, size.height / 2);
    final Paint ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8
      ..color = Colors.white.withOpacity(0.10);
    canvas.drawCircle(center, size.width * 0.38, ring);
    canvas.drawCircle(
      center,
      size.width * 0.45,
      ring..color = accent.withOpacity(0.14),
    );

    final Paint arc = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        colors: <Color>[
          Colors.transparent,
          accent.withOpacity(0.55),
          glow.withOpacity(0.08),
          Colors.transparent,
        ],
        stops: const <double>[0.0, 0.35, 0.72, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: 110));
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: size.width * 0.45),
      progress * math.pi * 2,
      1.9,
      false,
      arc,
    );

    final double angle = progress * math.pi * 2;
    for (int i = 0; i < 3; i++) {
      final double a = angle + i * 2.1;
      final double radius = size.width * (0.36 + i * 0.045);
      final Offset point =
          center + Offset(math.cos(a) * radius, math.sin(a) * radius);
      final double dotSize = i == 0 ? 3.6 : (i == 1 ? 2.4 : 1.8);
      canvas.drawCircle(
        point,
        dotSize,
        Paint()
          ..color = (i == 0 ? Colors.white : accent).withOpacity(0.72)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.1),
      );
    }

    final Paint star = Paint()..color = Colors.white.withOpacity(0.65);
    final List<Offset> points = <Offset>[
      Offset(size.width * 0.11, size.height * 0.30),
      Offset(size.width * 0.86, size.height * 0.18),
      Offset(size.width * 0.91, size.height * 0.66),
      Offset(size.width * 0.18, size.height * 0.82),
    ];
    for (int i = 0; i < points.length; i++) {
      canvas.drawCircle(points[i], i.isEven ? 1.4 : 0.9, star);
    }
  }

  @override
  bool shouldRepaint(covariant _OrbitPainter oldDelegate) =>
      oldDelegate.progress != progress ||
      oldDelegate.accent != accent ||
      oldDelegate.glow != glow;
}
