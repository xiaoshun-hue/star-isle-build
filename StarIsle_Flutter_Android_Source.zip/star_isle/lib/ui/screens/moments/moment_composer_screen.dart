import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/utils/app_feedback.dart';
import '../../../core/widgets/app_feedback_widgets.dart';
import '../../../core/widgets/aurora_background.dart';
import '../../../core/widgets/companion_avatar.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../services/media_service.dart';
import '../../../state/moments_controller.dart';
import '../../../state/settings_controller.dart';

class MomentComposerScreen extends StatefulWidget {
  const MomentComposerScreen({super.key});

  @override
  State<MomentComposerScreen> createState() => _MomentComposerScreenState();
}

class _MomentComposerScreenState extends State<MomentComposerScreen> {
  final TextEditingController _text = TextEditingController();
  String? _imagePath;
  bool _picking = false;
  bool _publishing = false;
  bool _generateArt = true;

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  bool get _canPublish =>
      !_publishing && (_text.text.trim().isNotEmpty || _imagePath != null);

  Future<void> _pickImage() async {
    if (_picking) return;
    setState(() => _picking = true);
    try {
      final file = await MediaService.pickImageFromGallery();
      if (!mounted) return;
      if (file != null) {
        setState(() => _imagePath = file.path);
      }
    } finally {
      if (mounted) setState(() => _picking = false);
    }
  }

  Future<void> _publish() async {
    if (!_canPublish) return;
    final MomentsController controller = context.read<MomentsController>();
    final SettingsController settings = context.read<SettingsController>();
    if (controller.generating) {
      showAppToast(context, '晚晚那边正在生成内容，稍等一下。');
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() => _publishing = true);
    AppFeedback.impact(settings.haptics);
    try {
      await controller.createUserMoment(
        text: _text.text,
        imagePath: _imagePath,
        generateArt: _generateArt,
      );
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (error) {
      if (!mounted) return;
      setState(() => _publishing = false);
      showAppToast(context, '这一刻没有发送成功，再试一次吧。');
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final SettingsController settings = context.watch<SettingsController>();
    return PopScope(
      canPop: !_publishing,
      child: AuroraBackground(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          resizeToAvoidBottomInset: true,
          body: SafeArea(
            child: Column(
              children: <Widget>[
                _buildTopBar(context, palette),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
                    physics: const BouncingScrollPhysics(),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          '记录此刻',
                          style: Theme.of(context).textTheme.headlineMedium
                              ?.copyWith(
                                fontWeight: FontWeight.w800,
                                letterSpacing: -0.6,
                              ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '生活值得被留下一点证据。',
                          style: Theme.of(context).textTheme.bodySmall
                              ?.copyWith(color: palette.muted, height: 1.6),
                        ),
                        const SizedBox(height: 18),
                        Container(
                          decoration: BoxDecoration(
                            color: palette.glass,
                            borderRadius: BorderRadius.circular(26),
                            border: Border.all(color: palette.border),
                          ),
                          padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  UserAvatar(name: settings.userName, size: 36),
                                  const SizedBox(width: 10),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text(
                                        settings.userName,
                                        style: Theme.of(context)
                                            .textTheme
                                            .labelLarge
                                            ?.copyWith(
                                              fontWeight: FontWeight.w700,
                                            ),
                                      ),
                                      const SizedBox(height: 2),
                                      Row(
                                        children: <Widget>[
                                          Icon(
                                            Icons.lock_outline_rounded,
                                            size: 10,
                                            color: palette.muted,
                                          ),
                                          const SizedBox(width: 3),
                                          Text(
                                            '仅晚晚可见',
                                            style: Theme.of(context)
                                                .textTheme
                                                .labelSmall
                                                ?.copyWith(
                                                  color: palette.muted,
                                                  fontSize: 8.5,
                                                ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              TextField(
                                controller: _text,
                                autofocus: false,
                                minLines: 5,
                                maxLines: 9,
                                maxLength: 240,
                                textInputAction: TextInputAction.newline,
                                onChanged: (_) => setState(() {}),
                                style: Theme.of(context).textTheme.bodyLarge
                                    ?.copyWith(fontSize: 16, height: 1.7),
                                decoration: InputDecoration(
                                  filled: false,
                                  border: InputBorder.none,
                                  enabledBorder: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: '这一刻，发生了什么？\n一个念头，一阵风，或者一句没说出口的话。',
                                  hintStyle: Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.copyWith(
                                        color: palette.muted.withOpacity(0.55),
                                        height: 1.65,
                                      ),
                                  contentPadding: const EdgeInsets.symmetric(
                                    vertical: 8,
                                  ),
                                  counterStyle: TextStyle(
                                    color: palette.muted.withOpacity(0.5),
                                    fontSize: 9,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                        _imagePath != null
                            ? _buildImagePreview(context, palette)
                            : _buildAddImage(context, palette),
                        const SizedBox(height: 14),
                        Container(
                          padding: const EdgeInsets.fromLTRB(15, 13, 11, 13),
                          decoration: BoxDecoration(
                            color: palette.glass,
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: palette.border),
                          ),
                          child: Row(
                            children: <Widget>[
                              Container(
                                width: 37,
                                height: 37,
                                decoration: BoxDecoration(
                                  color: palette.auroraA.withOpacity(0.12),
                                  borderRadius: BorderRadius.circular(13),
                                ),
                                child: Icon(
                                  Icons.auto_awesome_rounded,
                                  size: 18,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                              ),
                              const SizedBox(width: 11),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Text(
                                      '让星屿为文字配一张画卡',
                                      style: Theme.of(context)
                                          .textTheme
                                          .labelLarge
                                          ?.copyWith(
                                            fontWeight: FontWeight.w600,
                                          ),
                                    ),
                                    const SizedBox(height: 3),
                                    Text(
                                      '在本地生成，不额外消耗 API 额度',
                                      style: Theme.of(context)
                                          .textTheme
                                          .labelSmall
                                          ?.copyWith(
                                            color: palette.muted,
                                            fontSize: 8.8,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                              Switch.adaptive(
                                value: _generateArt,
                                activeColor: Theme.of(context)
                                    .colorScheme
                                    .primary,
                                onChanged: _imagePath == null && !_publishing
                                    ? (bool value) {
                                        setState(() => _generateArt = value);
                                      }
                                    : null,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 18),
                        Row(
                          children: <Widget>[
                            Icon(
                              Icons.lock_outline_rounded,
                              size: 12,
                              color: palette.muted.withOpacity(0.55),
                            ),
                            const SizedBox(width: 5),
                            Expanded(
                              child: Text(
                                '发布后只有你和晚晚能看到。晚晚可能会来点赞，或者在评论里和你说说话。',
                                style: Theme.of(context).textTheme.labelSmall
                                    ?.copyWith(
                                      color: palette.muted.withOpacity(0.58),
                                      height: 1.6,
                                      fontSize: 9,
                                    ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 4, 18, 12),
                  child: PressableScale(
                    onTap: _canPublish ? _publish : null,
                    enabled: _canPublish,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      height: 52,
                      decoration: BoxDecoration(
                        gradient: _canPublish
                            ? LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: <Color>[
                                  palette.bubbleUserStart,
                                  palette.bubbleUserEnd,
                                ],
                              )
                            : null,
                        color: _canPublish
                            ? null
                            : palette.muted.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(18),
                        boxShadow: _canPublish
                            ? <BoxShadow>[
                                BoxShadow(
                                  color: palette.bubbleUserStart.withOpacity(
                                    0.25,
                                  ),
                                  blurRadius: 18,
                                  offset: const Offset(0, 8),
                                ),
                              ]
                            : null,
                      ),
                      child: Center(
                        child: _publishing
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Row(
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Icon(
                                    Icons.auto_awesome_rounded,
                                    size: 17,
                                    color: _canPublish
                                        ? Colors.white
                                        : palette.muted.withOpacity(0.4),
                                  ),
                                  const SizedBox(width: 7),
                                  Text(
                                    _publishing ? '正在留住这一刻…' : '发布这一刻',
                                    style: TextStyle(
                                      color: _canPublish
                                          ? Colors.white
                                          : palette.muted.withOpacity(0.4),
                                      fontSize: 13,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar(BuildContext context, AppPalette palette) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 5, 16, 3),
      child: Row(
        children: <Widget>[
          GestureDetector(
            onTap: _publishing ? null : () => Navigator.of(context).pop(false),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: palette.glass,
                border: Border.all(color: palette.border),
              ),
              child: Icon(
                Icons.close_rounded,
                size: 21,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            ),
          ),
          const Spacer(),
          Text(
            _publishing ? '正在生成画卡…' : '一个新的瞬间',
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: palette.muted,
              fontSize: 9.5,
              letterSpacing: 0.3,
            ),
          ),
          const Spacer(),
          const SizedBox(width: 40),
        ],
      ),
    );
  }

  Widget _buildImagePreview(BuildContext context, AppPalette palette) {
    return Stack(
      children: <Widget>[
        ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: AspectRatio(
            aspectRatio: 4 / 5,
            child: Image.file(
              File(_imagePath!),
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: palette.glass,
                child: const Center(
                  child: Icon(
                    Icons.broken_image_outlined,
                    color: Colors.white38,
                  ),
                ),
              ),
            ),
          ),
        ),
        Positioned(
          top: 10,
          right: 10,
          child: GestureDetector(
            onTap: () => setState(() => _imagePath = null),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.42),
                borderRadius: BorderRadius.circular(99),
                border: Border.all(color: Colors.white12),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Icon(Icons.close_rounded, color: Colors.white, size: 13),
                  SizedBox(width: 4),
                  Text(
                    '移除',
                    style: TextStyle(color: Colors.white, fontSize: 10),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAddImage(BuildContext context, AppPalette palette) {
    return CustomPaint(
      painter: _DashedBorderPainter(color: palette.border, radius: 22),
      child: InkWell(
        onTap: _picking ? null : _pickImage,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          height: 130,
          decoration: BoxDecoration(
            color: palette.isDark
                ? Colors.white.withOpacity(0.018)
                : Colors.white.withOpacity(0.25),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Center(
            child: _picking
                ? const SizedBox(
                    width: 23,
                    height: 23,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: palette.auroraA.withOpacity(0.12),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.add_photo_alternate_outlined,
                          color: Theme.of(context).colorScheme.primary,
                          size: 19,
                        ),
                      ),
                      const SizedBox(height: 9),
                      Text(
                        '添加一张照片',
                        style: Theme.of(context).textTheme.labelMedium
                            ?.copyWith(
                              color: Theme.of(context).colorScheme.onSurface
                                  .withOpacity(0.72),
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        '照片会同时收藏进相册',
                        style: Theme.of(context).textTheme.labelSmall
                            ?.copyWith(color: palette.muted, fontSize: 8.5),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

class _DashedBorderPainter extends CustomPainter {
  _DashedBorderPainter({required this.color, required this.radius});

  final Color color;
  final double radius;

  @override
  void paint(Canvas canvas, Size size) {
    final RRect rrect = RRect.fromRectAndRadius(
      Offset.zero & size,
      Radius.circular(radius),
    );
    final Path path = Path()..addRRect(rrect);
    final Paint paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = color;
    for (final metric in path.computeMetrics()) {
      double distance = 0;
      while (distance < metric.length) {
        final double end = (distance + 5).clamp(0.0, metric.length).toDouble();
        canvas.drawPath(metric.extractPath(distance, end), paint);
        distance += 10;
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DashedBorderPainter oldDelegate) =>
      oldDelegate.color != color || oldDelegate.radius != radius;
}
