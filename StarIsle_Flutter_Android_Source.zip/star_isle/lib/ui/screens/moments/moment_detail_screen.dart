import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/utils/app_dates.dart';
import '../../../core/utils/app_feedback.dart';
import '../../../core/widgets/aurora_background.dart';
import '../../../core/widgets/companion_avatar.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../core/widgets/typing_dots.dart';
import '../../../data/models/companion_profile.dart';
import '../../../data/models/moment_entry.dart';
import '../../../state/companion_controller.dart';
import '../../../state/moments_controller.dart';
import '../../../state/settings_controller.dart';
import '../album/photo_viewer_screen.dart';

class MomentDetailScreen extends StatefulWidget {
  const MomentDetailScreen({super.key, required this.momentId});

  final String momentId;

  @override
  State<MomentDetailScreen> createState() => _MomentDetailScreenState();
}

class _MomentDetailScreenState extends State<MomentDetailScreen> {
  final TextEditingController _commentController = TextEditingController();
  final FocusNode _commentFocus = FocusNode();
  final ScrollController _scrollController = ScrollController();
  int _lastComments = -1;
  bool _wasPending = false;

  @override
  void dispose() {
    _commentController.dispose();
    _commentFocus.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  MomentEntry? _findMoment(MomentsController controller) {
    for (final MomentEntry moment in controller.moments) {
      if (moment.id == widget.momentId) return moment;
    }
    return null;
  }

  void _scrollToBottom({bool animate = true}) {
    if (!_scrollController.hasClients) return;
    final double target = _scrollController.position.maxScrollExtent;
    if (animate) {
      _scrollController.animateTo(
        target,
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeOutCubic,
      );
    } else {
      _scrollController.jumpTo(target);
    }
  }

  Future<void> _sendComment(
    MomentsController controller,
    SettingsController settings,
  ) async {
    final String content = _commentController.text.trim();
    if (content.isEmpty) return;
    _commentController.clear();
    AppFeedback.impact(settings.haptics);
    await controller.addComment(widget.momentId, content);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _scrollToBottom();
    });
    _commentFocus.requestFocus();
  }

  void _openImage(String path) {
    Navigator.of(context).push(
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 320),
        pageBuilder: (_, __, ___) => PhotoViewerScreen(
          paths: <String>[path],
          title: '动态配图',
          heroTag: 'moment-image-${widget.momentId}',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final MomentsController controller = context.watch<MomentsController>();
    final CompanionController companion = context.watch<CompanionController>();
    final SettingsController settings = context.watch<SettingsController>();
    final MomentEntry? moment = _findMoment(controller);
    final List<MomentComment> comments = controller.commentsFor(
      widget.momentId,
    );
    final bool pending = controller.pendingReplyMoments.contains(
      widget.momentId,
    );

    if (_lastComments < 0) {
      _lastComments = comments.length;
      _wasPending = pending;
    } else if (comments.length != _lastComments || _wasPending != pending) {
      _lastComments = comments.length;
      _wasPending = pending;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _scrollToBottom();
      });
    }

    return AuroraBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        resizeToAvoidBottomInset: true,
        body: SafeArea(
          child: Column(
            children: <Widget>[
              _buildTopBar(controller, palette),
              if (moment == null)
                const Expanded(
                  child: EmptyState(
                    icon: Icons.auto_awesome_rounded,
                    title: '这条动态已经不在了',
                    message: '也许它变成了风，或者只是走错了路口。',
                  ),
                )
              else ...<Widget>[
                Expanded(
                  child: ListView(
                    controller: _scrollController,
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 22),
                    physics: const BouncingScrollPhysics(
                      parent: AlwaysScrollableScrollPhysics(),
                    ),
                    children: <Widget>[
                      _buildAuthorRow(
                        context,
                        moment,
                        companion.profile,
                        settings,
                        palette,
                      ),
                      if (moment.text.trim().isNotEmpty) ...<Widget>[
                        const SizedBox(height: 16),
                        Text(
                          moment.text,
                          style: Theme.of(context).textTheme.bodyLarge
                              ?.copyWith(
                                fontSize: 15.5,
                                height: 1.78,
                                color: Theme.of(context).colorScheme.onSurface
                                    .withOpacity(0.92),
                              ),
                        ),
                      ],
                      if (moment.imagePath != null) ...<Widget>[
                        const SizedBox(height: 16),
                        GestureDetector(
                          onTap: () => _openImage(moment.imagePath!),
                          child: Hero(
                            tag: 'moment-image-${moment.id}',
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(22),
                              child: AspectRatio(
                                aspectRatio: 4 / 5,
                                child: _DetailImage(path: moment.imagePath!),
                              ),
                            ),
                          ),
                        ),
                      ],
                      const SizedBox(height: 13),
                      _buildActions(
                        context,
                        moment,
                        comments,
                        controller,
                        settings,
                        companion.profile,
                        palette,
                      ),
                      if (pending) ...<Widget>[
                        const SizedBox(height: 14),
                        Row(
                          children: <Widget>[
                            CompanionAvatar(
                              seed: companion.profile.avatarSeed,
                              size: 25,
                              nickname: companion.profile.nickname,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              '${companion.profile.nickname}正在评论',
                              style: Theme.of(context).textTheme.labelSmall
                                  ?.copyWith(
                                    color: palette.muted,
                                    fontSize: 10,
                                  ),
                            ),
                            const SizedBox(width: 7),
                            TypingDots(
                              color: palette.muted,
                              size: 3.5,
                              spacing: 3,
                            ),
                          ],
                        ),
                      ],
                      const SizedBox(height: 18),
                      _buildCommentsHeader(context, comments.length, palette),
                      if (comments.isEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 20),
                          child: Text(
                            '还没有评论。让这一刻的第一句回声，由你来写。',
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.bodySmall
                                ?.copyWith(
                                  color: palette.muted.withOpacity(0.6),
                                  height: 1.6,
                                ),
                          ),
                        )
                      else
                        ...comments.map(
                          (MomentComment comment) => _buildComment(
                            context,
                            comment,
                            companion.profile,
                            settings.userName,
                            palette,
                          ),
                        ),
                    ],
                  ),
                ),
                _buildCommentBar(controller, settings, palette),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar(MomentsController controller, AppPalette palette) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 5, 16, 4),
      child: Row(
        children: <Widget>[
          GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: palette.glass,
                border: Border.all(color: palette.border),
              ),
              child: Icon(
                Icons.arrow_back_ios_new_rounded,
                size: 18,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Text(
            '动态',
            style: Theme.of(context).textTheme.titleMedium
                ?.copyWith(fontWeight: FontWeight.w700),
          ),
          const Spacer(),
          Text(
            '只对你们可见',
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: palette.muted.withOpacity(0.5),
              fontSize: 9.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAuthorRow(
    BuildContext context,
    MomentEntry moment,
    CompanionProfile profile,
    SettingsController settings,
    AppPalette palette,
  ) {
    final String name = moment.isAi ? profile.nickname : settings.userName;
    return Padding(
      padding: const EdgeInsets.only(top: 9),
      child: Row(
        children: <Widget>[
          moment.isAi
              ? CompanionAvatar(
                  seed: profile.avatarSeed,
                  size: 43,
                  nickname: profile.nickname,
                )
              : UserAvatar(name: settings.userName, size: 43),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Text(
                      name,
                      style: Theme.of(context).textTheme.titleSmall
                          ?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    if (moment.isAi) ...<Widget>[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 5,
                          vertical: 1.5,
                        ),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primary
                              .withOpacity(0.11),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Text(
                          'AI',
                          style: Theme.of(context).textTheme.labelSmall
                              ?.copyWith(
                                color: Theme.of(context).colorScheme.primary,
                                fontSize: 7.5,
                                fontWeight: FontWeight.w800,
                              ),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                  '${moment.mood.isEmpty ? '此刻' : moment.mood} · ${AppDates.relative(moment.createdAt)}',
                  style: Theme.of(context).textTheme.labelSmall
                      ?.copyWith(color: palette.muted, fontSize: 9.5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActions(
    BuildContext context,
    MomentEntry moment,
    List<MomentComment> comments,
    MomentsController controller,
    SettingsController settings,
    CompanionProfile profile,
    AppPalette palette,
  ) {
    return Row(
      children: <Widget>[
        PressableScale(
          onTap: () {
            AppFeedback.impact(settings.haptics);
            unawaited(controller.toggleLike(moment.id));
          },
          scale: 0.9,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(
              color: moment.userLiked
                  ? const Color(0xFFFF708E).withOpacity(0.10)
                  : palette.glass,
              borderRadius: BorderRadius.circular(99),
              border: Border.all(
                color: moment.userLiked
                    ? const Color(0xFFFF708E).withOpacity(0.22)
                    : palette.border,
              ),
            ),
            child: Row(
              children: <Widget>[
                Icon(
                  moment.userLiked
                      ? Icons.favorite_rounded
                      : Icons.favorite_border_rounded,
                  size: 17,
                  color: moment.userLiked
                      ? const Color(0xFFFF708E)
                      : palette.muted,
                ),
                if (moment.likeCount > 0) ...<Widget>[
                  const SizedBox(width: 5),
                  Text(
                    '${moment.likeCount}',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: moment.userLiked
                          ? const Color(0xFFFF708E)
                          : palette.muted,
                      fontSize: 10,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
          decoration: BoxDecoration(
            color: palette.glass,
            borderRadius: BorderRadius.circular(99),
            border: Border.all(color: palette.border),
          ),
          child: Row(
            children: <Widget>[
              Icon(
                Icons.chat_bubble_outline_rounded,
                size: 16,
                color: palette.muted,
              ),
              const SizedBox(width: 5),
              Text(
                comments.isEmpty ? '评论' : '${comments.length}',
                style: Theme.of(context).textTheme.labelSmall
                    ?.copyWith(color: palette.muted, fontSize: 10),
              ),
            ],
          ),
        ),
        const Spacer(),
        if (moment.aiLiked && !moment.isAi)
          Row(
            children: <Widget>[
              CompanionAvatar(seed: 24, size: 17, ring: false),
              const SizedBox(width: 4),
              Text(
                '她赞过',
                style: Theme.of(context).textTheme.labelSmall
                    ?.copyWith(color: palette.muted, fontSize: 9),
              ),
            ],
          ),
      ],
    );
  }

  Widget _buildCommentsHeader(
    BuildContext context,
    int count,
    AppPalette palette,
  ) {
    return Row(
      children: <Widget>[
        Text(
          '评论',
          style: Theme.of(context).textTheme.titleSmall
              ?.copyWith(fontWeight: FontWeight.w700),
        ),
        const SizedBox(width: 6),
        Text(
          count == 0 ? '' : '$count',
          style: Theme.of(context).textTheme.labelSmall
              ?.copyWith(color: palette.muted, fontSize: 10),
        ),
        const SizedBox(width: 10),
        Expanded(child: Container(height: 0.6, color: palette.border)),
      ],
    );
  }

  Widget _buildComment(
    BuildContext context,
    MomentComment comment,
    CompanionProfile profile,
    String userName,
    AppPalette palette,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 9),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          if (comment.isAi)
            CompanionAvatar(
              seed: profile.avatarSeed,
              size: 29,
              nickname: profile.nickname,
            )
          else
            UserAvatar(name: userName, size: 29),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Text(
                      comment.isAi ? profile.nickname : userName,
                      style: Theme.of(context).textTheme.labelMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                        fontSize: 11.5,
                        color: comment.isAi
                            ? Theme.of(context).colorScheme.primary
                            : Theme.of(context).colorScheme.onSurface
                                  .withOpacity(0.82),
                      ),
                    ),
                    const SizedBox(width: 7),
                    Text(
                      AppDates.relative(comment.createdAt),
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: palette.muted.withOpacity(0.46),
                        fontSize: 8.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  comment.content,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    fontSize: 12.6,
                    height: 1.62,
                    color: Theme.of(context).colorScheme.onSurface
                        .withOpacity(0.82),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCommentBar(
    MomentsController controller,
    SettingsController settings,
    AppPalette palette,
  ) {
    final bool canSend = _commentController.text.trim().isNotEmpty;
    return Container(
      padding: EdgeInsets.fromLTRB(12, 7, 12, 8),
      child: Container(
        padding: const EdgeInsets.fromLTRB(7, 5, 6, 5),
        decoration: BoxDecoration(
          color: palette.glass,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: palette.border),
        ),
        child: Row(
          children: <Widget>[
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _commentController,
                focusNode: _commentFocus,
                maxLength: 300,
                maxLines: 3,
                minLines: 1,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) =>
                    unawaited(_sendComment(controller, settings)),
                onChanged: (_) => setState(() {}),
                style: Theme.of(context).textTheme.bodySmall
                    ?.copyWith(fontSize: 13),
                decoration: InputDecoration(
                  filled: false,
                  isDense: true,
                  counterText: '',
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    vertical: 9,
                    horizontal: 2,
                  ),
                  hintText: '写下你的回应…',
                  hintStyle: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: palette.muted.withOpacity(0.6),
                    fontSize: 12.5,
                  ),
                ),
              ),
            ),
            PressableScale(
              onTap: canSend
                  ? () => unawaited(_sendComment(controller, settings))
                  : null,
              enabled: canSend,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 37,
                height: 37,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: canSend
                      ? LinearGradient(
                          colors: <Color>[
                            palette.bubbleUserStart,
                            palette.bubbleUserEnd,
                          ],
                        )
                      : null,
                  color: canSend ? null : palette.muted.withOpacity(0.10),
                ),
                child: Icon(
                  Icons.arrow_upward_rounded,
                  size: 18,
                  color: canSend
                      ? Colors.white
                      : palette.muted.withOpacity(0.34),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DetailImage extends StatelessWidget {
  const _DetailImage({required this.path});

  final String path;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    final File file = File(path);
    if (!file.existsSync()) {
      return Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: <Color>[
              palette.auroraA.withOpacity(0.4),
              palette.auroraB.withOpacity(0.25),
            ],
          ),
        ),
        child: const Center(
          child: Icon(
            Icons.auto_awesome_rounded,
            color: Colors.white70,
            size: 42,
          ),
        ),
      );
    }
    return Image.file(
      file,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => const ColoredBox(
        color: Colors.black26,
        child: Center(
          child: Icon(Icons.broken_image_outlined, color: Colors.white54),
        ),
      ),
    );
  }
}
