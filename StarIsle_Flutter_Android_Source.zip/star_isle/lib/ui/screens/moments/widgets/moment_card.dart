import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../../core/theme/app_palette.dart';
import '../../../../core/utils/app_dates.dart';
import '../../../../core/widgets/companion_avatar.dart';
import '../../../../core/widgets/pressable_scale.dart';
import '../../../../core/widgets/typing_dots.dart';
import '../../../../data/models/companion_profile.dart';
import '../../../../data/models/moment_entry.dart';

class MomentCard extends StatelessWidget {
  const MomentCard({
    super.key,
    required this.moment,
    required this.comments,
    required this.profile,
    required this.userName,
    required this.pendingAiReply,
    required this.onLike,
    required this.onComment,
    required this.onImageTap,
    this.onMore,
  });

  final MomentEntry moment;
  final List<MomentComment> comments;
  final CompanionProfile profile;
  final String userName;
  final bool pendingAiReply;
  final VoidCallback onLike;
  final VoidCallback onComment;
  final VoidCallback onImageTap;
  final VoidCallback? onMore;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    final String author = moment.isAi ? profile.nickname : userName;
    final String moodLine = moment.isAi
        ? '${moment.mood.isEmpty ? profile.mood : moment.mood}'
        : '分享了一个瞬间';
    return RepaintBoundary(
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: palette.glass,
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: palette.border, width: 0.8),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: palette.shadow.withOpacity(palette.isDark ? 0.13 : 0.05),
              blurRadius: 24,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 15, 12, 0),
              child: Row(
                children: <Widget>[
                  moment.isAi
                      ? CompanionAvatar(
                          seed: profile.avatarSeed,
                          size: 40,
                          nickname: profile.nickname,
                        )
                      : UserAvatar(name: userName, size: 40),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            Flexible(
                              child: Text(
                                author,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(context).textTheme.titleSmall
                                    ?.copyWith(
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: -0.2,
                                    ),
                              ),
                            ),
                            if (moment.isAi) ...<Widget>[
                              const SizedBox(width: 5),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 5,
                                  vertical: 1.5,
                                ),
                                decoration: BoxDecoration(
                                  color: Theme.of(context).colorScheme.primary
                                      .withOpacity(0.11),
                                  borderRadius: BorderRadius.circular(5),
                                ),
                                child: Text(
                                  'AI',
                                  style: Theme.of(context).textTheme.labelSmall
                                      ?.copyWith(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .primary,
                                        fontSize: 7.5,
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: 0.4,
                                      ),
                                ),
                              ),
                            ],
                          ],
                        ),
                        const SizedBox(height: 3),
                        Text(
                          '$moodLine · ${AppDates.relative(moment.createdAt)}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.labelSmall
                              ?.copyWith(
                                color: palette.muted.withOpacity(0.72),
                                fontSize: 9.5,
                              ),
                        ),
                      ],
                    ),
                  ),
                  if (onMore != null)
                    GestureDetector(
                      onTap: onMore,
                      behavior: HitTestBehavior.opaque,
                      child: Padding(
                        padding: const EdgeInsets.all(7),
                        child: Icon(
                          Icons.more_horiz_rounded,
                          size: 20,
                          color: palette.muted.withOpacity(0.68),
                        ),
                      ),
                    )
                  else
                    Icon(
                      Icons.auto_awesome_rounded,
                      size: 15,
                      color: palette.auroraB.withOpacity(0.5),
                    ),
                ],
              ),
            ),
            if (moment.text.trim().isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: Text(
                  moment.text,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    height: 1.72,
                    fontSize: 14.2,
                    color: Theme.of(context).colorScheme.onSurface
                        .withOpacity(0.90),
                  ),
                ),
              ),
            if (moment.imagePath != null)
              Padding(
                padding: EdgeInsets.fromLTRB(
                  14,
                  moment.text.trim().isEmpty ? 13 : 12,
                  14,
                  0,
                ),
                child: GestureDetector(
                  onTap: onImageTap,
                  child: Hero(
                    tag: 'moment-image-${moment.id}',
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: AspectRatio(
                        aspectRatio: 4 / 5,
                        child: _MomentImage(
                          path: moment.imagePath!,
                          palette: palette,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(9, 7, 12, 0),
              child: Row(
                children: <Widget>[
                  _LikeButton(
                    liked: moment.userLiked,
                    count: moment.likeCount,
                    onTap: onLike,
                  ),
                  const SizedBox(width: 1),
                  _TapStat(
                    icon: Icons.chat_bubble_outline_rounded,
                    label: comments.isEmpty ? '评论' : '${comments.length} 条评论',
                    onTap: onComment,
                  ),
                  const Spacer(),
                  if (moment.aiLiked && !moment.isAi)
                    Row(
                      children: <Widget>[
                        CompanionAvatar(
                          seed: profile.avatarSeed,
                          size: 17,
                          ring: false,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '她赞过',
                          style: Theme.of(context).textTheme.labelSmall
                              ?.copyWith(color: palette.muted, fontSize: 9),
                        ),
                      ],
                    ),
                ],
              ),
            ),
            if (comments.isNotEmpty || pendingAiReply)
              Container(
                margin: const EdgeInsets.fromLTRB(14, 6, 14, 13),
                padding: const EdgeInsets.fromLTRB(11, 8, 11, 8),
                decoration: BoxDecoration(
                  color: palette.isDark
                      ? Colors.white.withOpacity(0.025)
                      : Colors.white.withOpacity(0.38),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    ...comments
                        .take(2)
                        .map(
                          (MomentComment comment) => Padding(
                            padding: const EdgeInsets.symmetric(vertical: 2.5),
                            child: Text.rich(
                              TextSpan(
                                children: <InlineSpan>[
                                  TextSpan(
                                    text:
                                        '${comment.isAi ? profile.nickname : userName}：',
                                    style: TextStyle(
                                      color: comment.isAi
                                          ? Theme.of(context)
                                                .colorScheme
                                                .primary
                                          : Theme.of(context)
                                                .colorScheme
                                                .onSurface
                                                .withOpacity(0.75),
                                      fontWeight: FontWeight.w700,
                                      fontSize: 12,
                                    ),
                                  ),
                                  TextSpan(
                                    text: comment.content,
                                    style: TextStyle(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurface
                                          .withOpacity(0.72),
                                      fontSize: 12,
                                      height: 1.5,
                                    ),
                                  ),
                                ],
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                    if (pendingAiReply)
                      Padding(
                        padding: const EdgeInsets.only(top: 4, bottom: 2),
                        child: Row(
                          children: <Widget>[
                            Text(
                              '${profile.nickname}正在评论',
                              style: Theme.of(context).textTheme.labelSmall
                                  ?.copyWith(
                                    color: palette.muted,
                                    fontSize: 10,
                                  ),
                            ),
                            const SizedBox(width: 7),
                            TypingDots(
                              color: palette.muted,
                              size: 3,
                              spacing: 2.5,
                            ),
                          ],
                        ),
                      ),
                    if (comments.length > 2)
                      GestureDetector(
                        onTap: onComment,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 5),
                          child: Text(
                            '查看全部 ${comments.length} 条评论',
                            style: Theme.of(context).textTheme.labelSmall
                                ?.copyWith(
                                  color: Theme.of(context).colorScheme.primary
                                      .withOpacity(0.85),
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                        ),
                      ),
                  ],
                ),
              )
            else
              GestureDetector(
                onTap: onComment,
                behavior: HitTestBehavior.opaque,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 13),
                  child: Text(
                    '说点什么，让这一刻留下回声…',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: palette.muted.withOpacity(0.47),
                      fontSize: 10,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _MomentImage extends StatelessWidget {
  const _MomentImage({required this.path, required this.palette});

  final String path;
  final AppPalette palette;

  @override
  Widget build(BuildContext context) {
    final File file = File(path);
    if (!file.existsSync()) {
      return _fallback(context);
    }
    return Image.file(
      file,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => _fallback(context),
    );
  }

  Widget _fallback(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            palette.auroraA.withOpacity(0.42),
            palette.auroraB.withOpacity(0.26),
          ],
        ),
      ),
      child: Center(
        child: Icon(
          Icons.auto_awesome_rounded,
          size: 38,
          color: Colors.white.withOpacity(0.65),
        ),
      ),
    );
  }
}

class _LikeButton extends StatefulWidget {
  const _LikeButton({
    required this.liked,
    required this.count,
    required this.onTap,
  });

  final bool liked;
  final int count;
  final VoidCallback onTap;

  @override
  State<_LikeButton> createState() => _LikeButtonState();
}

class _LikeButtonState extends State<_LikeButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 420),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _tap() {
    if (!widget.liked) {
      _controller.forward(from: 0);
    }
    widget.onTap();
  }

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    final Color color = widget.liked
        ? const Color(0xFFFF708E)
        : palette.muted.withOpacity(0.66);
    return PressableScale(
      onTap: _tap,
      scale: 0.9,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (BuildContext context, Widget? child) {
          final double t = _controller.value;
          final double scale = 1 + math.sin(t * math.pi) * 0.24;
          return Row(
            children: <Widget>[
              Transform.scale(scale: scale, child: child),
              if (widget.count > 0) ...<Widget>[
                const SizedBox(width: 5),
                Text(
                  '${widget.count}',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: color,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ],
          );
        },
        child: Icon(
          widget.liked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
          size: 18,
          color: color,
        ),
      ),
    );
  }
}

class _TapStat extends StatelessWidget {
  const _TapStat({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    return PressableScale(
      onTap: onTap,
      scale: 0.93,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
        child: Row(
          children: <Widget>[
            Icon(icon, size: 18, color: palette.muted.withOpacity(0.66)),
            const SizedBox(width: 5),
            Text(
              label,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: palette.muted.withOpacity(0.66),
                fontSize: 10,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
