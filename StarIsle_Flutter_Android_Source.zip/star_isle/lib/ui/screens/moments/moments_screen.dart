import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/utils/app_dates.dart';
import '../../../core/utils/app_feedback.dart';
import '../../../core/widgets/app_feedback_widgets.dart';
import '../../../core/widgets/app_sheet.dart';
import '../../../core/widgets/companion_avatar.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/fade_slide_in.dart';
import '../../../core/widgets/glass_icon_button.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../data/models/companion_profile.dart';
import '../../../data/models/moment_entry.dart';
import '../../../state/companion_controller.dart';
import '../../../state/moments_controller.dart';
import '../../../state/settings_controller.dart';
import 'moment_composer_screen.dart';
import 'moment_detail_screen.dart';
import 'widgets/moment_card.dart';

class MomentsScreen extends StatefulWidget {
  const MomentsScreen({super.key});

  @override
  State<MomentsScreen> createState() => _MomentsScreenState();
}

class _MomentsScreenState extends State<MomentsScreen>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  Future<void> _refresh() async {
    await context.read<MomentsController>().refresh();
    await Future<void>.delayed(const Duration(milliseconds: 300));
  }

  Future<void> _askAiMoment() async {
    final MomentsController controller = context.read<MomentsController>();
    if (controller.generating) return;
    AppFeedback.impact(true);
    await controller.createAiMoment(force: true);
    if (!mounted) return;
    showAppToast(
      context,
      controller.moments.isNotEmpty ? '她刚刚发了一条新动态' : '她好像还在想写什么',
      icon: Icons.auto_awesome_rounded,
    );
  }

  Future<void> _openComposer() async {
    final bool? posted = await Navigator.of(context).push<bool>(
      PageRouteBuilder<bool>(
        transitionDuration: const Duration(milliseconds: 380),
        reverseTransitionDuration: const Duration(milliseconds: 300),
        pageBuilder: (_, __, ___) => const MomentComposerScreen(),
        transitionsBuilder: (_, Animation<double> animation, __, Widget child) {
          final CurvedAnimation curve = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
          );
          return FadeTransition(opacity: curve, child: child);
        },
      ),
    );
    if (posted == true && mounted) {
      showAppToast(context, '这一刻已经留在星屿了', icon: Icons.favorite_rounded);
    }
  }

  void _openDetail(MomentEntry moment) {
    Navigator.of(context).push(
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 420),
        reverseTransitionDuration: const Duration(milliseconds: 320),
        pageBuilder: (_, __, ___) => MomentDetailScreen(momentId: moment.id),
        transitionsBuilder: (_, Animation<double> animation, __, Widget child) {
          final CurvedAnimation curve = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
          );
          return FadeTransition(
            opacity: curve,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.045, 0),
                end: Offset.zero,
              ).animate(curve),
              child: child,
            ),
          );
        },
      ),
    );
  }

  Future<void> _showMomentMenu(MomentEntry moment) async {
    final MomentsController controller = context.read<MomentsController>();
    final BuildContext outer = context;
    await showGlassSheet<void>(
      context,
      title: '这条动态',
      child: SheetBody(
        scroll: false,
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            _MomentAction(
              icon: Icons.chat_bubble_outline_rounded,
              label: '查看评论',
              onTap: () {
                Navigator.of(context).pop();
                _openDetail(moment);
              },
            ),
            _MomentAction(
              icon: Icons.delete_outline_rounded,
              label: '删除这条动态',
              destructive: true,
              onTap: () async {
                Navigator.of(context).pop();
                final bool confirmed = await showAppConfirm(
                  outer,
                  title: '删除这条动态？',
                  message: '动态和评论会被删除，已经收藏进相册的配图仍会保留。',
                  confirmLabel: '删除',
                  destructive: true,
                );
                if (!confirmed) return;
                await controller.deleteMoment(moment.id);
                if (outer.mounted) {
                  showAppToast(outer, '动态已删除');
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final AppPalette palette = context.palette;
    final MomentsController moments = context.watch<MomentsController>();
    final CompanionController companion = context.watch<CompanionController>();
    final SettingsController settings = context.watch<SettingsController>();
    final CompanionProfile profile = companion.profile;

    return SafeArea(
      bottom: false,
      child: Stack(
        children: <Widget>[
          RefreshIndicator(
            onRefresh: _refresh,
            color: Theme.of(context).colorScheme.primary,
            backgroundColor: palette.glassStrong,
            child: ListView(
              physics: const BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics(),
              ),
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 104),
              children: <Widget>[
                _buildHeader(context, moments, palette),
                const SizedBox(height: 16),
                _buildPresenceBanner(
                  context,
                  profile,
                  settings,
                  palette,
                  moments,
                ),
                const SizedBox(height: 22),
                Row(
                  children: <Widget>[
                    Text(
                      '最近动态',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                        letterSpacing: -0.2,
                      ),
                    ),
                    const SizedBox(width: 7),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 1.5,
                      ),
                      decoration: BoxDecoration(
                        color: palette.glass,
                        borderRadius: BorderRadius.circular(99),
                        border: Border.all(color: palette.border),
                      ),
                      child: Text(
                        '${moments.moments.length}',
                        style: Theme.of(context).textTheme.labelSmall
                            ?.copyWith(color: palette.muted, fontSize: 9),
                      ),
                    ),
                    const Spacer(),
                    if (moments.generating)
                      Row(
                        children: <Widget>[
                          SizedBox(
                            width: 12,
                            height: 12,
                            child: CircularProgressIndicator(
                              strokeWidth: 1.5,
                              color: Theme.of(context).colorScheme.primary,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            '她正在记录…',
                            style: Theme.of(context).textTheme.labelSmall
                                ?.copyWith(color: palette.muted, fontSize: 9.5),
                          ),
                        ],
                      )
                    else
                      GestureDetector(
                        onTap: _askAiMoment,
                        behavior: HitTestBehavior.opaque,
                        child: Row(
                          children: <Widget>[
                            Icon(
                              Icons.auto_awesome_rounded,
                              size: 13,
                              color: Theme.of(context).colorScheme.primary,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '让她发一条',
                              style: Theme.of(context).textTheme.labelSmall
                                  ?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .primary,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                  ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                if (moments.moments.isEmpty)
                  EmptyState(
                    icon: Icons.auto_awesome_rounded,
                    title: moments.generating ? '她正在写下第一段生活' : '还没有动态',
                    message: moments.generating
                        ? '配图会在本地生成，很快就好。'
                        : '让她发一条，或者由你记录此刻。',
                    actionLabel: moments.generating ? null : '让她发第一条',
                    onAction: _askAiMoment,
                  )
                else
                  ...moments.moments.asMap().entries.map((
                    MapEntry<int, MomentEntry> entry,
                  ) {
                    final MomentEntry moment = entry.value;
                    final List<MomentComment> comments = moments.commentsFor(
                      moment.id,
                    );
                    return FadeSlideIn(
                      key: ValueKey<String>('moment-fade-${moment.id}'),
                      delay: Duration(
                        milliseconds: 40 + (entry.key.clamp(0, 5).toInt() * 55),
                      ),
                      child: MomentCard(
                        key: ValueKey<String>(moment.id),
                        moment: moment,
                        comments: comments,
                        profile: profile,
                        userName: settings.userName,
                        pendingAiReply: moments.pendingReplyMoments.contains(
                          moment.id,
                        ),
                        onLike: () {
                          AppFeedback.impact(settings.haptics);
                          unawaited(moments.toggleLike(moment.id));
                        },
                        onComment: () => _openDetail(moment),
                        onImageTap: () => _openDetail(moment),
                        onMore: moment.isAi
                            ? null
                            : () => unawaited(_showMomentMenu(moment)),
                      ),
                    );
                  }),
                const SizedBox(height: 4),
                Center(
                  child: Text(
                    moments.moments.isEmpty ? '' : '这些片段，只对你们两个人可见',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: palette.muted.withOpacity(0.4),
                      fontSize: 9,
                      letterSpacing: 0.7,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            right: 18,
            bottom: 18,
            child: PressableScale(
              onTap: _openComposer,
              scale: 0.94,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 15,
                  vertical: 11,
                ),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: <Color>[
                      palette.bubbleUserStart,
                      palette.bubbleUserEnd,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(99),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: palette.bubbleUserStart.withOpacity(0.34),
                      blurRadius: 22,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Icon(Icons.add_rounded, color: Colors.white, size: 18),
                    SizedBox(width: 4),
                    Text(
                      '记录',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(
    BuildContext context,
    MomentsController moments,
    AppPalette palette,
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(
                    '动态',
                    style: Theme.of(context).textTheme.displaySmall?.copyWith(
                      fontSize: 31,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.8,
                      height: 1.05,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 3),
                    child: Icon(
                      Icons.auto_awesome_rounded,
                      size: 15,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                '${AppDates.monthDay(DateTime.now())} · ${AppDates.weekday(DateTime.now())}',
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: palette.muted,
                  fontSize: 10,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
        GlassIconButton(
          icon: Icons.refresh_rounded,
          size: 39,
          iconSize: 18,
          tooltip: '刷新动态',
          onTap: _refresh,
        ),
        const SizedBox(width: 7),
        GlassIconButton(
          icon: Icons.auto_awesome_rounded,
          size: 39,
          iconSize: 18,
          active: moments.generating,
          tooltip: '让晚晚发一条动态',
          onTap: moments.generating ? null : _askAiMoment,
        ),
      ],
    );
  }

  Widget _buildPresenceBanner(
    BuildContext context,
    CompanionProfile profile,
    SettingsController settings,
    AppPalette palette,
    MomentsController moments,
  ) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            palette.auroraA.withOpacity(0.20),
            palette.glass,
            palette.auroraB.withOpacity(0.11),
          ],
        ),
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: palette.border, width: 0.8),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: palette.shadow.withOpacity(palette.isDark ? 0.15 : 0.05),
            blurRadius: 26,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Stack(
        children: <Widget>[
          Positioned(
            right: -22,
            top: -30,
            child: Container(
              width: 130,
              height: 130,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: <Color>[
                    palette.auroraB.withOpacity(0.20),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            left: 24,
            bottom: 23,
            child: Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: <Color>[
                    palette.auroraA.withOpacity(0.15),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 15, 16, 15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    CompanionAvatar(
                      seed: profile.avatarSeed,
                      size: 43,
                      nickname: profile.nickname,
                      showOnline: true,
                    ),
                    const SizedBox(width: 11),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Flexible(
                                child: Text(
                                  '${profile.nickname}的此刻',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.titleSmall
                                      ?.copyWith(fontWeight: FontWeight.w700),
                                ),
                              ),
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 5,
                                  vertical: 1.5,
                                ),
                                decoration: BoxDecoration(
                                  color: palette.glassStrong,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  settings.onlineReady ? 'ONLINE' : 'LOCAL',
                                  style: Theme.of(context).textTheme.labelSmall
                                      ?.copyWith(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .primary,
                                        fontSize: 7,
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: 0.5,
                                      ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            '${profile.mood} · 只对你可见',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.labelSmall
                                ?.copyWith(color: palette.muted, fontSize: 9.5),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Icon(
                      Icons.waves_rounded,
                      size: 20,
                      color: palette.auroraB.withOpacity(0.6),
                    ),
                  ],
                ),
                const SizedBox(height: 13),
                Text(
                  profile.signature,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface
                        .withOpacity(0.82),
                    fontSize: 12.5,
                    height: 1.55,
                    fontStyle: FontStyle.italic,
                  ),
                ),
                const SizedBox(height: 11),
                Row(
                  children: <Widget>[
                    Icon(
                      Icons.public_rounded,
                      size: 11,
                      color: palette.muted.withOpacity(0.55),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      moments.generating ? '正在记录生活…' : '刚刚路过你的世界',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: palette.muted.withOpacity(0.55),
                        fontSize: 9,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      AppDates.dayPeriod(),
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: palette.muted.withOpacity(0.4),
                        fontSize: 9,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MomentAction extends StatelessWidget {
  const _MomentAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.destructive = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool destructive;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    final Color color = destructive
        ? const Color(0xFFFF708A)
        : Theme.of(context).colorScheme.onSurface.withOpacity(0.86);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
        child: Row(
          children: <Widget>[
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: destructive ? color.withOpacity(0.09) : palette.glass,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, size: 18, color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: Theme.of(context).textTheme.bodyMedium
                    ?.copyWith(color: color, fontWeight: FontWeight.w500),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
