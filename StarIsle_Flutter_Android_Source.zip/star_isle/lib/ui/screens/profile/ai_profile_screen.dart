import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/navigation/app_navigator.dart';
import '../../../core/theme/app_palette.dart';
import '../../../core/utils/app_feedback.dart';
import '../../../core/widgets/app_feedback_widgets.dart';
import '../../../core/widgets/aurora_background.dart';
import '../../../core/widgets/companion_avatar.dart';
import '../../../core/widgets/glass_icon_button.dart';
import '../../../core/widgets/glass_panel.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../core/widgets/section_heading.dart';
import '../../../data/models/companion_profile.dart';
import '../../../data/models/memory_entry.dart';
import '../../../services/tts_service.dart';
import '../../../state/companion_controller.dart';
import '../../../state/settings_controller.dart';
import '../settings/companion_settings_screen.dart';
import 'memory_book_screen.dart';

class AiProfileScreen extends StatefulWidget {
  const AiProfileScreen({super.key});

  @override
  State<AiProfileScreen> createState() => _AiProfileScreenState();
}

class _AiProfileScreenState extends State<AiProfileScreen> {
  bool _evolving = false;

  Future<void> _evolve() async {
    if (_evolving) return;
    AppFeedback.impact(context.read<SettingsController>().haptics);
    setState(() => _evolving = true);
    try {
      await context.read<CompanionController>().evolveCompanion();
      if (mounted) {
        showAppToast(context, '她换了一个新的样子', icon: Icons.auto_awesome_rounded);
      }
    } finally {
      if (mounted) setState(() => _evolving = false);
    }
  }

  Future<void> _speakSignature(CompanionProfile profile) async {
    final TtsService tts = context.read<TtsService>();
    if (tts.speakingId == 'signature') {
      await tts.stop();
    } else {
      await tts.speak('signature', profile.signature);
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final CompanionController companion = context.watch<CompanionController>();
    final SettingsController settings = context.watch<SettingsController>();
    final TtsService tts = context.watch<TtsService>();
    final CompanionProfile profile = companion.profile;
    return AuroraBackground(
      showStars: true,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 6, 16, 4),
                child: Row(
                  children: <Widget>[
                    GlassIconButton(
                      icon: Icons.arrow_back_ios_new_rounded,
                      size: 40,
                      iconSize: 18,
                      onTap: () => Navigator.of(context).pop(),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      '角色档案',
                      style: Theme.of(context).textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const Spacer(),
                    Text(
                      'AI COMPANION',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: palette.muted,
                        fontSize: 7.5,
                        letterSpacing: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 6, 16, 30),
                  physics: const BouncingScrollPhysics(),
                  children: <Widget>[
                    _buildPortrait(context, profile, palette, tts),
                    const SizedBox(height: 13),
                    _buildStats(context, profile, companion, palette),
                    const SizedBox(height: 20),
                    SectionHeading(
                      title: '关于她',
                      subtitle: '不是设定，是她正在成为的样子',
                      padding: const EdgeInsets.fromLTRB(3, 0, 3, 10),
                    ),
                    _buildPersona(context, profile, palette),
                    const SizedBox(height: 20),
                    SectionHeading(
                      title: '她记得',
                      subtitle: '${companion.memories.length} 条关于你的细节',
                      actionLabel: '全部记忆',
                      onAction: () =>
                          pushAppPage(context, const MemoryBookScreen()),
                      padding: const EdgeInsets.fromLTRB(3, 0, 3, 10),
                    ),
                    _buildMemories(context, companion, palette),
                    const SizedBox(height: 22),
                    Center(
                      child: Text(
                        '她住在${settings.onlineReady ? ' DeepSeek 与本地 ' : '本地'}星屿里 · 只属于你',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: palette.muted.withOpacity(0.40),
                          fontSize: 8.5,
                          letterSpacing: 0.2,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPortrait(
    BuildContext context,
    CompanionProfile profile,
    AppPalette palette,
    TtsService tts,
  ) {
    final bool speaking = tts.speakingId == 'signature';
    return Container(
      height: 390,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Color.lerp(palette.auroraA, Colors.black, 0.24)!,
            Color.lerp(palette.backgroundMid, Colors.black, 0.28)!,
            Color.lerp(palette.auroraB, Colors.black, 0.30)!,
          ],
          stops: const <double>[0.0, 0.55, 1.0],
        ),
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: Colors.black.withOpacity(0.18),
            blurRadius: 30,
            offset: const Offset(0, 15),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(32),
        child: Stack(
          children: <Widget>[
            Positioned.fill(
              child: CustomPaint(
                painter: _PortraitPainter(
                  accent: palette.auroraA,
                  secondary: palette.auroraB,
                ),
              ),
            ),
            Positioned(
              top: 16,
              left: 17,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(99),
                  border: Border.all(color: Colors.white12),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      width: 4,
                      height: 4,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFF6FE4B1),
                      ),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      '她正在你的世界里',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.62),
                        fontSize: 8,
                        letterSpacing: 0.4,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              top: 16,
              right: 17,
              child: GestureDetector(
                onTap: () => _speakSignature(profile),
                child: Container(
                  width: 33,
                  height: 33,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.08),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Icon(
                    speaking
                        ? Icons.graphic_eq_rounded
                        : Icons.volume_up_outlined,
                    size: 16,
                    color: Colors.white.withOpacity(0.72),
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.topCenter,
              child: Padding(
                padding: const EdgeInsets.only(top: 48),
                child: CompanionAvatar(
                  seed: profile.avatarSeed,
                  size: 116,
                  nickname: profile.nickname,
                  showOnline: true,
                ),
              ),
            ),
            Positioned(
              left: 24,
              right: 24,
              bottom: 22,
              child: Column(
                children: <Widget>[
                  Text(
                    profile.nickname,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.6,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${profile.relationshipStage} · 相伴第 ${profile.daysTogether} 天',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.50),
                      fontSize: 9,
                      letterSpacing: 0.2,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.075),
                      borderRadius: BorderRadius.circular(99),
                      border: Border.all(color: Colors.white10),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Icon(
                          Icons.blur_on_rounded,
                          size: 11,
                          color: Colors.white.withOpacity(0.54),
                        ),
                        const SizedBox(width: 5),
                        Flexible(
                          child: Text(
                            profile.mood,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.70),
                              fontSize: 9,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 9),
                  Text(
                    profile.signature,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.68),
                      fontSize: 10.5,
                      height: 1.55,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                  const SizedBox(height: 13),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: PressableScale(
                          onTap: _evolving ? null : _evolve,
                          enabled: !_evolving,
                          child: Container(
                            height: 40,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.11),
                              borderRadius: BorderRadius.circular(13),
                              border: Border.all(color: Colors.white12),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                if (_evolving)
                                  const SizedBox(
                                    width: 13,
                                    height: 13,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 1.5,
                                      color: Colors.white,
                                    ),
                                  )
                                else
                                  Icon(
                                    Icons.auto_awesome_rounded,
                                    size: 14,
                                    color: Colors.white.withOpacity(0.82),
                                  ),
                                const SizedBox(width: 6),
                                Text(
                                  _evolving ? '正在变化…' : '让她自由生长',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.85),
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: PressableScale(
                          onTap: () => pushAppPage(
                            context,
                            const CompanionSettingsScreen(),
                          ),
                          child: Container(
                            height: 40,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.05),
                              borderRadius: BorderRadius.circular(13),
                              border: Border.all(color: Colors.white10),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Icon(
                                  Icons.edit_outlined,
                                  size: 13,
                                  color: Colors.white.withOpacity(0.68),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  '调整人设',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.72),
                                    fontSize: 10,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStats(
    BuildContext context,
    CompanionProfile profile,
    CompanionController companion,
    AppPalette palette,
  ) {
    return GlassPanel(
      padding: const EdgeInsets.fromLTRB(16, 15, 16, 16),
      borderRadius: 24,
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              _ProfileStat(value: '${profile.daysTogether}', label: '相伴'),
              _ProfileStat(value: '${profile.totalTurns}', label: '对话'),
              _ProfileStat(value: '${companion.memories.length}', label: '记忆'),
              _ProfileStat(value: '${profile.affection}%', label: '心动'),
            ],
          ),
          const SizedBox(height: 15),
          Row(
            children: <Widget>[
              Text(
                '关系阶段',
                style: Theme.of(context).textTheme.labelSmall
                    ?.copyWith(color: palette.muted, fontSize: 8.5),
              ),
              const SizedBox(width: 8),
              Text(
                profile.relationshipStage,
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: Theme.of(context).colorScheme.primary,
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const Spacer(),
              Text(
                profile.toneLabel,
                style: Theme.of(context).textTheme.labelSmall
                    ?.copyWith(color: palette.muted, fontSize: 8.5),
              ),
            ],
          ),
          const SizedBox(height: 7),
          ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: LinearProgressIndicator(
              value: profile.affection / 100,
              minHeight: 5,
              backgroundColor: palette.border,
              valueColor: AlwaysStoppedAnimation<Color>(
                Theme.of(context).colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPersona(
    BuildContext context,
    CompanionProfile profile,
    AppPalette palette,
  ) {
    return GlassPanel(
      padding: const EdgeInsets.all(17),
      borderRadius: 23,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                decoration: BoxDecoration(
                  color: palette.auroraB.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  profile.toneLabel,
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.auroraB,
                    fontSize: 8,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Text(
                '温柔但不失去自己',
                style: Theme.of(context).textTheme.labelSmall
                    ?.copyWith(color: palette.muted, fontSize: 8),
              ),
            ],
          ),
          const SizedBox(height: 11),
          Text(
            profile.persona,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.72),
              fontSize: 11.5,
              height: 1.72,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMemories(
    BuildContext context,
    CompanionController companion,
    AppPalette palette,
  ) {
    if (companion.memories.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: palette.glass,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: palette.border),
        ),
        child: Text(
          '还没有记忆。和她多说一些关于你的事吧。',
          style: Theme.of(context).textTheme.bodySmall
              ?.copyWith(color: palette.muted),
        ),
      );
    }
    return Column(
      children: companion.memories.take(3).map((MemoryEntry memory) {
        return Container(
          margin: const EdgeInsets.only(bottom: 7),
          padding: const EdgeInsets.fromLTRB(13, 11, 13, 11),
          decoration: BoxDecoration(
            color: palette.glass,
            borderRadius: BorderRadius.circular(17),
            border: Border.all(color: palette.border),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                width: 27,
                height: 27,
                decoration: BoxDecoration(
                  color: palette.auroraB.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Icon(
                  _memoryIcon(memory.category),
                  size: 13,
                  color: palette.auroraB,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  memory.content,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface
                        .withOpacity(0.75),
                    fontSize: 10.5,
                    height: 1.55,
                  ),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  IconData _memoryIcon(String category) {
    return switch (category) {
      'preference' => Icons.favorite_border_rounded,
      'date' => Icons.calendar_today_outlined,
      'promise' => Icons.handshake_outlined,
      'emotion' => Icons.water_drop_outlined,
      'life' => Icons.coffee_outlined,
      _ => Icons.auto_awesome_rounded,
    };
  }
}

class _ProfileStat extends StatelessWidget {
  const _ProfileStat({required this.value, required this.label});

  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    return Expanded(
      child: Column(
        children: <Widget>[
          Text(
            value,
            style: Theme.of(context).textTheme.titleMedium
                ?.copyWith(fontWeight: FontWeight.w800, fontSize: 16),
          ),
          const SizedBox(height: 3),
          Text(
            label,
            style: Theme.of(context).textTheme.labelSmall
                ?.copyWith(color: palette.muted, fontSize: 8),
          ),
        ],
      ),
    );
  }
}

class _PortraitPainter extends CustomPainter {
  _PortraitPainter({required this.accent, required this.secondary});

  final Color accent;
  final Color secondary;

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = Offset(size.width / 2, 116);
    final Paint ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.7
      ..color = Colors.white.withOpacity(0.11);
    canvas.drawCircle(center, 100, ring);
    canvas.drawCircle(
      center,
      135,
      ring..color = Colors.white.withOpacity(0.055),
    );
    final Paint arc = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = secondary.withOpacity(0.34);
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: 122),
      -0.7,
      1.5,
      false,
      arc,
    );
    final Paint arc2 = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8
      ..color = accent.withOpacity(0.24);
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: 158),
      2.0,
      1.2,
      false,
      arc2,
    );
    final Paint dot = Paint();
    for (int i = 0; i < 26; i++) {
      final double x = size.width * (0.08 + (i * 47 % 100) / 112);
      final double y = size.height * (0.04 + (i * 83 % 100) / 135);
      dot.color = Colors.white.withOpacity(0.10 + (i % 4) * 0.035);
      canvas.drawCircle(Offset(x, y), i % 7 == 0 ? 1.2 : 0.65, dot);
    }
    final Paint bottomGlow = Paint()
      ..shader =
          RadialGradient(
            colors: <Color>[accent.withOpacity(0.23), Colors.transparent],
          ).createShader(
            Rect.fromCircle(
              center: Offset(size.width * 0.3, size.height * 0.85),
              radius: size.width * 0.5,
            ),
          );
    canvas.drawRect(Offset.zero & size, bottomGlow);
    final Paint sideGlow = Paint()
      ..shader =
          RadialGradient(
            colors: <Color>[secondary.withOpacity(0.16), Colors.transparent],
          ).createShader(
            Rect.fromCircle(
              center: Offset(size.width * 0.9, size.height * 0.3),
              radius: size.width * 0.55,
            ),
          );
    canvas.drawRect(Offset.zero & size, sideGlow);
  }

  @override
  bool shouldRepaint(covariant _PortraitPainter oldDelegate) =>
      oldDelegate.accent != accent || oldDelegate.secondary != secondary;
}
