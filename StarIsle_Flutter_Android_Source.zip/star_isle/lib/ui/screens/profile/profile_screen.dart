import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/navigation/app_navigator.dart';
import '../../../core/theme/app_palette.dart';
import '../../../core/widgets/app_feedback_widgets.dart';
import '../../../core/widgets/companion_avatar.dart';
import '../../../core/widgets/fade_slide_in.dart';
import '../../../core/widgets/glass_icon_button.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../core/widgets/section_heading.dart';
import '../../../data/models/companion_profile.dart';
import '../../../data/models/memory_entry.dart';
import '../../../state/companion_controller.dart';
import '../../../state/moments_controller.dart';
import '../../../state/settings_controller.dart';
import '../settings/about_screen.dart';
import '../settings/ai_settings_screen.dart';
import '../settings/companion_settings_screen.dart';
import '../settings/theme_settings_screen.dart';
import '../../pages/decoration_page.dart';
import '../settings/widgets/settings_tile.dart';
import 'ai_profile_screen.dart';
import 'memory_book_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen>
    with AutomaticKeepAliveClientMixin {
  bool _evolving = false;

  @override
  bool get wantKeepAlive => true;

  Future<void> _evolve() async {
    if (_evolving) return;
    setState(() => _evolving = true);
    try {
      await context.read<CompanionController>().evolveCompanion();
      if (mounted) {
        showAppToast(
          context,
          '她换了一个新的样子，去主页看看吧。',
          icon: Icons.auto_awesome_rounded,
        );
      }
    } finally {
      if (mounted) setState(() => _evolving = false);
    }
  }

  void _open(Widget page) {
    FocusScope.of(context).unfocus();
    unawaited(pushAppPage(context, page));
  }

  String _themeModeLabel(ThemeMode mode) => switch (mode) {
    ThemeMode.light => '浅色',
    ThemeMode.system => '跟随系统',
    ThemeMode.dark => '深色',
  };

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final AppPalette palette = context.palette;
    final CompanionController companion = context.watch<CompanionController>();
    final SettingsController settings = context.watch<SettingsController>();
    final MomentsController moments = context.watch<MomentsController>();
    final CompanionProfile profile = companion.profile;

    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 30),
        physics: const BouncingScrollPhysics(),
        children: <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Text(
                          '我们',
                          style: Theme.of(context).textTheme.displaySmall
                              ?.copyWith(
                                fontSize: 31,
                                fontWeight: FontWeight.w800,
                                letterSpacing: -0.8,
                                height: 1.05,
                              ),
                        ),
                        const SizedBox(width: 8),
                        Icon(
                          Icons.favorite_rounded,
                          size: 13,
                          color: palette.auroraB.withOpacity(0.78),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '只有两个人的小岛',
                      style: Theme.of(context).textTheme.labelSmall
                          ?.copyWith(color: palette.muted, fontSize: 10),
                    ),
                  ],
                ),
              ),
              GlassIconButton(
                icon: Icons.tune_rounded,
                size: 41,
                iconSize: 18,
                tooltip: '偏好设置',
                onTap: () => _open(const CompanionSettingsScreen()),
              ),
            ],
          ),
          const SizedBox(height: 17),
          FadeSlideIn(
            child: _buildHero(context, companion, moments, profile, palette),
          ),
          const SizedBox(height: 21),
          SectionHeading(
            title: '她记得的',
            subtitle: '被认真收藏的生活细节',
            actionLabel: '记忆簿',
            onAction: () => _open(const MemoryBookScreen()),
            padding: const EdgeInsets.fromLTRB(3, 0, 3, 10),
          ),
          _buildMemoryStrip(context, companion, palette),
          const SizedBox(height: 19),
          const SettingsSectionLabel(title: 'COMPANION · 关于她'),
          SettingsGroup(
            children: <Widget>[
              SettingsTile(
                icon: Icons.favorite_outline_rounded,
                title: '她的主页',
                subtitle: '${profile.nickname}的样子、人设和关系',
                iconColor: palette.auroraB,
                onTap: () => _open(const AiProfileScreen()),
              ),
              SettingsTile(
                icon: Icons.auto_stories_outlined,
                title: '长期记忆簿',
                subtitle: '${companion.memories.length} 条记忆 · 会影响之后的对话',
                trailingText: '${companion.memories.length}',
                onTap: () => _open(const MemoryBookScreen()),
              ),
            ],
          ),
          const SettingsSectionLabel(title: 'PREFERENCES · 偏好'),
          SettingsGroup(
            children: <Widget>[
              SettingsTile(
                icon: Icons.palette_outlined,
                title: '主题与外观',
                subtitle:
                    '${settings.themeSpec.name} · ${_themeModeLabel(settings.themeMode)}',
                trailingText: settings.themeSpec.name,
                onTap: () => _open(const ThemeSettingsScreen()),
              ),
              SettingsTile(
                icon: Icons.dashboard_customize_outlined,
                title: '装扮与气泡',
                subtitle: '头像框、聊天气泡和主题配色',
                trailingText: '装扮',
                onTap: () => _open(const DecorationPage()),
              ),
              SettingsTile(
                icon: Icons.wifi_tethering_rounded,
                title: 'AI 与网络',
                subtitle: settings.onlineReady
                    ? 'DeepSeek · ${settings.model}'
                    : '单机陪伴 · 不发起网络请求',
                trailingText: settings.onlineReady ? '联网' : '单机',
                onTap: () => _open(const AiSettingsScreen()),
              ),
              SettingsTile(
                icon: Icons.psychology_alt_outlined,
                title: '人格与主动陪伴',
                subtitle: '称呼、语气、自动成长与提醒频率',
                onTap: () => _open(const CompanionSettingsScreen()),
              ),
            ],
          ),
          const SettingsSectionLabel(title: 'ABOUT · 关于'),
          SettingsGroup(
            children: <Widget>[
              SettingsTile(
                icon: Icons.lock_outline_rounded,
                title: '星屿的隐私说明',
                subtitle: '对话只在本机 · 联网时才会发送上下文',
                onTap: () => _open(const AboutScreen()),
              ),
              SettingsTile(
                icon: Icons.info_outline_rounded,
                title: '关于星屿',
                subtitle: '版本 1.3.3 · 单人专属 AI 陪伴',
                trailingText: 'v1.3.3',
                onTap: () => _open(const AboutScreen()),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Center(
            child: Column(
              children: <Widget>[
                Icon(
                  Icons.nights_stay_rounded,
                  size: 17,
                  color: palette.muted.withOpacity(0.34),
                ),
                const SizedBox(height: 6),
                Text(
                  '星屿 · 把晚风留在身边',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted.withOpacity(0.36),
                    fontSize: 8.5,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHero(
    BuildContext context,
    CompanionController companion,
    MomentsController moments,
    CompanionProfile profile,
    AppPalette palette,
  ) {
    final List<Color> heroColors = palette.isDark
        ? <Color>[
            Color.lerp(palette.auroraA, Colors.black, 0.10)!,
            Color.lerp(palette.backgroundMid, palette.auroraB, 0.20)!,
            Color.lerp(palette.backgroundBottom, Colors.black, 0.14)!,
          ]
        : <Color>[
            Color.lerp(palette.auroraA, Colors.black, 0.32)!,
            Color.lerp(palette.backgroundMid, Colors.black, 0.22)!,
            Color.lerp(palette.auroraB, Colors.black, 0.34)!,
          ];
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: heroColors,
          stops: const <double>[0.0, 0.56, 1.0],
        ),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: palette.auroraA.withOpacity(0.13),
            blurRadius: 32,
            offset: const Offset(0, 14),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: Stack(
          children: <Widget>[
            Positioned(
              right: -39,
              top: -58,
              child: Container(
                width: 190,
                height: 190,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white.withOpacity(0.09)),
                ),
              ),
            ),
            Positioned(
              right: 0,
              bottom: -65,
              child: Container(
                width: 180,
                height: 180,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: <Color>[
                      palette.auroraB.withOpacity(0.18),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      PressableScale(
                        onTap: () => _open(const AiProfileScreen()),
                        scale: 0.95,
                        child: CompanionAvatar(
                          seed: profile.avatarSeed,
                          size: 76,
                          nickname: profile.nickname,
                          showOnline: true,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(top: 3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  Flexible(
                                    child: Text(
                                      profile.nickname,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: Theme.of(context)
                                          .textTheme
                                          .headlineSmall
                                          ?.copyWith(
                                            fontWeight: FontWeight.w800,
                                            letterSpacing: -0.5,
                                          ),
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 6,
                                      vertical: 2,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.white.withOpacity(0.10),
                                      borderRadius: BorderRadius.circular(6),
                                      border: Border.all(color: Colors.white12),
                                    ),
                                    child: Text(
                                      '专属',
                                      style: TextStyle(
                                        color: Colors.white.withOpacity(0.74),
                                        fontSize: 7,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 5),
                              Row(
                                children: <Widget>[
                                  Icon(
                                    Icons.blur_on_rounded,
                                    size: 12,
                                    color: palette.auroraB.withOpacity(0.8),
                                  ),
                                  const SizedBox(width: 4),
                                  Flexible(
                                    child: Text(
                                      profile.mood,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: Theme.of(context)
                                          .textTheme
                                          .labelSmall
                                          ?.copyWith(
                                            color: palette.muted,
                                            fontSize: 9.5,
                                          ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text(
                                profile.signature,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(context).textTheme.bodySmall
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurface
                                          .withOpacity(0.68),
                                      height: 1.5,
                                      fontStyle: FontStyle.italic,
                                      fontSize: 10.5,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: PressableScale(
                          onTap: () => _open(const AiProfileScreen()),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.11),
                              borderRadius: BorderRadius.circular(13),
                              border: Border.all(color: Colors.white12),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Icon(
                                  Icons.favorite_border_rounded,
                                  size: 14,
                                  color: Colors.white.withOpacity(0.8),
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  '她的主页',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.82),
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: PressableScale(
                          onTap: _evolving ? null : _evolve,
                          enabled: !_evolving,
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: <Color>[
                                  palette.auroraB.withOpacity(0.34),
                                  palette.auroraA.withOpacity(0.24),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(13),
                              border: Border.all(color: Colors.white12),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                if (_evolving)
                                  const SizedBox(
                                    width: 13,
                                    height: 13,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 1.5,
                                      color: Colors.white,
                                    ),
                                  )
                                else
                                  Icon(
                                    Icons.auto_awesome_rounded,
                                    size: 14,
                                    color: Colors.white.withOpacity(0.82),
                                  ),
                                const SizedBox(width: 5),
                                Text(
                                  _evolving ? '正在变化…' : '换个造型',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.82),
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Container(height: 0.6, color: Colors.white.withOpacity(0.10)),
                  const SizedBox(height: 14),
                  Row(
                    children: <Widget>[
                      _HeroStat(
                        value: '${profile.daysTogether}',
                        label: '相伴天数',
                      ),
                      _HeroStat(value: '${profile.totalTurns}', label: '对话回合'),
                      _HeroStat(
                        value: '${companion.memories.length}',
                        label: '记得的事',
                      ),
                      _HeroStat(
                        value: '${moments.moments.length}',
                        label: '共同动态',
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: <Widget>[
                      Text(
                        '心动值',
                        style: TextStyle(
                          color: palette.muted,
                          fontSize: 9,
                          letterSpacing: 0.4,
                        ),
                      ),
                      const SizedBox(width: 7),
                      Text(
                        '${profile.affection}%',
                        style: TextStyle(
                          color: palette.auroraB,
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        profile.relationshipStage,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.68),
                          fontSize: 9,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 7),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(99),
                    child: Container(
                      height: 5,
                      color: Colors.white.withOpacity(0.08),
                      child: FractionallySizedBox(
                        alignment: Alignment.centerLeft,
                        widthFactor: profile.affection / 100,
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: <Color>[palette.auroraA, palette.auroraB],
                            ),
                            borderRadius: BorderRadius.circular(99),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMemoryStrip(
    BuildContext context,
    CompanionController companion,
    AppPalette palette,
  ) {
    if (companion.memories.isEmpty) {
      return GestureDetector(
        onTap: () => _open(const MemoryBookScreen()),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: palette.glass,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: palette.border),
          ),
          child: Row(
            children: <Widget>[
              Icon(
                Icons.auto_stories_outlined,
                size: 19,
                color: palette.muted.withOpacity(0.6),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  '还没有记忆。多聊一会儿，她会慢慢记住关于你的事。',
                  style: Theme.of(context).textTheme.labelSmall
                      ?.copyWith(color: palette.muted, height: 1.6),
                ),
              ),
            ],
          ),
        ),
      );
    }
    final List<MemoryEntry> items = companion.memories.take(4).toList();
    return SizedBox(
      height: 100,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (BuildContext context, int index) {
          final MemoryEntry memory = items[index];
          return GestureDetector(
            onTap: () => _open(const MemoryBookScreen()),
            child: Container(
              width: 202,
              padding: const EdgeInsets.all(13),
              decoration: BoxDecoration(
                color: palette.glass,
                borderRadius: BorderRadius.circular(19),
                border: Border.all(color: palette.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Icon(
                        _memoryIcon(memory.category),
                        size: 12,
                        color: palette.auroraB,
                      ),
                      const SizedBox(width: 5),
                      Text(
                        memory.categoryLabel,
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: palette.auroraB,
                          fontSize: 8,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '“',
                        style: TextStyle(
                          color: palette.auroraB.withOpacity(0.3),
                          fontSize: 20,
                          height: 1,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: Text(
                      memory.content,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface
                            .withOpacity(0.76),
                        fontSize: 10.5,
                        height: 1.52,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  IconData _memoryIcon(String category) {
    return switch (category) {
      'preference' => Icons.favorite_border_rounded,
      'date' => Icons.calendar_today_outlined,
      'promise' => Icons.handshake_outlined,
      'emotion' => Icons.water_drop_outlined,
      'life' => Icons.coffee_outlined,
      _ => Icons.auto_awesome_rounded,
    };
  }
}

class _HeroStat extends StatelessWidget {
  const _HeroStat({required this.value, required this.label});

  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: <Widget>[
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 17,
              fontWeight: FontWeight.w800,
              height: 1.1,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(0.48),
              fontSize: 8,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }
}
