import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/utils/app_dates.dart';
import '../../../core/widgets/app_feedback_widgets.dart';
import '../../../core/widgets/app_sheet.dart';
import '../../../core/widgets/companion_avatar.dart';
import '../../../core/widgets/detail_scaffold.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/fade_slide_in.dart';
import '../../../core/widgets/glass_icon_button.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../data/models/memory_entry.dart';
import '../../../state/companion_controller.dart';

class MemoryBookScreen extends StatefulWidget {
  const MemoryBookScreen({super.key});

  @override
  State<MemoryBookScreen> createState() => _MemoryBookScreenState();
}

class _MemoryBookScreenState extends State<MemoryBookScreen> {
  String _filter = 'all';

  List<MemoryEntry> _filtered(List<MemoryEntry> memories) {
    if (_filter == 'all') return memories;
    return memories
        .where((MemoryEntry memory) => memory.category == _filter)
        .toList();
  }

  Future<void> _addMemory() async {
    final bool? saved = await showGlassSheet<bool>(
      context,
      title: '记住一件事',
      child: const _AddMemorySheet(),
    );
    if (saved == true && mounted) {
      showAppToast(context, '已经写进她的记忆里了', icon: Icons.auto_stories_rounded);
    }
  }

  Future<bool> _confirmForget(MemoryEntry memory) {
    return showAppConfirm(
      context,
      title: '让她忘记这件事？',
      message: '这条记忆会从长期上下文里移除，之后的对话不会再引用它。',
      confirmLabel: '忘记',
      destructive: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    final CompanionController companion = context.watch<CompanionController>();
    final List<MemoryEntry> filtered = _filtered(companion.memories);
    final List<_MemoryFilter> filters = <_MemoryFilter>[
      _MemoryFilter('all', '全部', companion.memories.length),
      _MemoryFilter(
        'preference',
        '喜欢',
        companion.memories
            .where((MemoryEntry m) => m.category == 'preference')
            .length,
      ),
      _MemoryFilter(
        'life',
        '生活',
        companion.memories
            .where((MemoryEntry m) => m.category == 'life')
            .length,
      ),
      _MemoryFilter(
        'promise',
        '约定',
        companion.memories
            .where((MemoryEntry m) => m.category == 'promise')
            .length,
      ),
      _MemoryFilter(
        'date',
        '日期',
        companion.memories
            .where((MemoryEntry m) => m.category == 'date')
            .length,
      ),
      _MemoryFilter(
        'emotion',
        '心事',
        companion.memories
            .where((MemoryEntry m) => m.category == 'emotion')
            .length,
      ),
    ];

    return DetailScaffold(
      title: '长期记忆簿',
      subtitle: '${companion.memories.length} 条关于你的细节',
      actions: <Widget>[
        GlassIconButton(
          icon: Icons.add_rounded,
          size: 40,
          iconSize: 20,
          active: true,
          tooltip: '手动添加记忆',
          onTap: _addMemory,
        ),
      ],
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 30),
        physics: const BouncingScrollPhysics(),
        children: <Widget>[
          FadeSlideIn(
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[
                    palette.auroraA.withOpacity(0.20),
                    palette.glass,
                  ],
                ),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: palette.border),
              ),
              child: Row(
                children: <Widget>[
                  CompanionAvatar(
                    seed: companion.profile.avatarSeed,
                    size: 42,
                    nickname: companion.profile.nickname,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          '${companion.profile.nickname}会认真记住这些',
                          style: Theme.of(context).textTheme.titleSmall
                              ?.copyWith(fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '每次聊天时，她都会带上这些细节。左滑可以让她忘记。',
                          style: Theme.of(context).textTheme.labelSmall
                              ?.copyWith(
                                color: palette.muted,
                                height: 1.5,
                                fontSize: 9,
                              ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 15),
          SizedBox(
            height: 31,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: filters.length,
              separatorBuilder: (_, __) => const SizedBox(width: 6),
              itemBuilder: (BuildContext context, int index) {
                final _MemoryFilter filter = filters[index];
                final bool selected = _filter == filter.id;
                return PressableScale(
                  onTap: () {
                    if (_filter == filter.id) return;
                    setState(() => _filter = filter.id);
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 11,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: selected
                          ? Theme.of(context).colorScheme.primary
                                .withOpacity(0.13)
                          : palette.glass,
                      borderRadius: BorderRadius.circular(99),
                      border: Border.all(
                        color: selected
                            ? Theme.of(context).colorScheme.primary
                                  .withOpacity(0.3)
                            : palette.border,
                      ),
                    ),
                    child: Row(
                      children: <Widget>[
                        Text(
                          filter.label,
                          style: Theme.of(context).textTheme.labelSmall
                              ?.copyWith(
                                fontSize: 9.5,
                                color: selected
                                    ? Theme.of(context).colorScheme.primary
                                    : palette.muted,
                                fontWeight: selected
                                    ? FontWeight.w600
                                    : FontWeight.w500,
                              ),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${filter.count}',
                          style: Theme.of(context).textTheme.labelSmall
                              ?.copyWith(
                                fontSize: 7.5,
                                color: palette.muted.withOpacity(0.5),
                              ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 13),
          if (filtered.isEmpty)
            SizedBox(
              height: 260,
              child: EmptyState(
                icon: Icons.auto_stories_outlined,
                compact: true,
                title: companion.memories.isEmpty ? '记忆簿还是空的' : '这个分类还没有记忆',
                message: companion.memories.isEmpty
                    ? '聊到你在意的事、喜欢的味道、约好的日期，她会自动记住。也可以手动补充一条。'
                    : '换一个分类看看，或者手动补充一条新的记忆。',
                actionLabel: '添加一条记忆',
                onAction: _addMemory,
              ),
            )
          else
            ...filtered.asMap().entries.map((MapEntry<int, MemoryEntry> entry) {
              final MemoryEntry memory = entry.value;
              return FadeSlideIn(
                key: ValueKey<String>('memory-${memory.id}'),
                delay: Duration(
                  milliseconds: 30 + entry.key.clamp(0, 6).toInt() * 40,
                ),
                child: Dismissible(
                  key: ValueKey<String>('dismiss-${memory.id}'),
                  direction: DismissDirection.endToStart,
                  confirmDismiss: (_) => _confirmForget(memory),
                  onDismissed: (_) {
                    unawaited(
                      context.read<CompanionController>().deleteMemory(
                        memory.id,
                      ),
                    );
                  },
                  background: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.only(right: 20),
                    alignment: Alignment.centerRight,
                    decoration: BoxDecoration(
                      color: const Color(0xFFFF708A).withOpacity(0.14),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: const Icon(
                      Icons.auto_delete_outlined,
                      color: Color(0xFFFF708A),
                      size: 20,
                    ),
                  ),
                  child: _MemoryCard(memory: memory, palette: palette),
                ),
              );
            }),
          if (companion.memories.isNotEmpty) ...<Widget>[
            const SizedBox(height: 18),
            Center(
              child: Text(
                '记忆只保存在本机 · 你可以随时改变它们',
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: palette.muted.withOpacity(0.38),
                  fontSize: 8.5,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _MemoryCard extends StatelessWidget {
  const _MemoryCard({required this.memory, required this.palette});

  final MemoryEntry memory;
  final AppPalette palette;

  @override
  Widget build(BuildContext context) {
    final Color accent = _categoryColor(context, memory.category, palette);
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: palette.glass,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: palette.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            width: 35,
            height: 35,
            decoration: BoxDecoration(
              color: accent.withOpacity(0.10),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(
              _categoryIcon(memory.category),
              size: 16,
              color: accent,
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  memory.content,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface
                        .withOpacity(0.82),
                    fontSize: 11.8,
                    height: 1.6,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 5,
                        vertical: 1.5,
                      ),
                      decoration: BoxDecoration(
                        color: accent.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        memory.categoryLabel,
                        style: Theme.of(context).textTheme.labelSmall
                            ?.copyWith(color: accent, fontSize: 7.5),
                      ),
                    ),
                    const SizedBox(width: 7),
                    Text(
                      AppDates.relative(memory.createdAt),
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: palette.muted.withOpacity(0.5),
                        fontSize: 8,
                      ),
                    ),
                    const Spacer(),
                    if (memory.importance >= 3)
                      Icon(
                        Icons.star_rounded,
                        size: 11,
                        color: palette.auroraB.withOpacity(0.65),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _categoryColor(
    BuildContext context,
    String category,
    AppPalette palette,
  ) {
    return switch (category) {
      'preference' => const Color(0xFFFF8EA2),
      'date' => const Color(0xFFF0BC68),
      'promise' => palette.auroraB,
      'emotion' => const Color(0xFF8DB7E8),
      _ => Theme.of(context).colorScheme.primary,
    };
  }

  IconData _categoryIcon(String category) {
    return switch (category) {
      'preference' => Icons.favorite_border_rounded,
      'life' => Icons.coffee_outlined,
      'promise' => Icons.handshake_outlined,
      'date' => Icons.calendar_today_outlined,
      'emotion' => Icons.water_drop_outlined,
      _ => Icons.auto_awesome_rounded,
    };
  }
}

class _AddMemorySheet extends StatefulWidget {
  const _AddMemorySheet();

  @override
  State<_AddMemorySheet> createState() => _AddMemorySheetState();
}

class _AddMemorySheetState extends State<_AddMemorySheet> {
  final TextEditingController _controller = TextEditingController();
  String _category = 'preference';
  bool _saving = false;

  static const List<_MemoryCategory> _categories = <_MemoryCategory>[
    _MemoryCategory('preference', '喜欢', Icons.favorite_border_rounded),
    _MemoryCategory('life', '生活', Icons.coffee_outlined),
    _MemoryCategory('promise', '约定', Icons.handshake_outlined),
    _MemoryCategory('date', '日期', Icons.calendar_today_outlined),
    _MemoryCategory('emotion', '心事', Icons.water_drop_outlined),
  ];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final String content = _controller.text.trim();
    if (content.isEmpty) {
      showAppToast(context, '写下一件想让她记住的事吧。');
      return;
    }
    if (_saving) return;
    setState(() => _saving = true);
    try {
      await context.read<CompanionController>().addMemory(
        content,
        category: _category,
      );
      if (mounted) Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    return SheetBody(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          TextField(
            controller: _controller,
            maxLength: 100,
            maxLines: 3,
            autofocus: true,
            decoration: const InputDecoration(
              hintText: '例如：我喜欢在雨天听老歌，讨厌香菜。',
              counterText: '',
            ),
          ),
          const SizedBox(height: 13),
          Text(
            '归入哪一格记忆',
            style: Theme.of(context).textTheme.labelSmall
                ?.copyWith(color: palette.muted),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 7,
            runSpacing: 7,
            children: _categories.map((_MemoryCategory category) {
              final bool selected = _category == category.id;
              return PressableScale(
                onTap: () => setState(() => _category = category.id),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 11,
                    vertical: 7,
                  ),
                  decoration: BoxDecoration(
                    color: selected
                        ? Theme.of(context).colorScheme.primary
                              .withOpacity(0.12)
                        : palette.glass,
                    borderRadius: BorderRadius.circular(99),
                    border: Border.all(
                      color: selected
                          ? Theme.of(context).colorScheme.primary
                                .withOpacity(0.35)
                          : palette.border,
                    ),
                  ),
                  child: Row(
                    children: <Widget>[
                      Icon(
                        category.icon,
                        size: 13,
                        color: selected
                            ? Theme.of(context).colorScheme.primary
                            : palette.muted,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        category.label,
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: selected
                              ? Theme.of(context).colorScheme.primary
                              : palette.muted,
                          fontSize: 9.5,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 18),
          Text(
            '手动添加的记忆会和自动记忆一起进入之后的对话上下文。',
            style: Theme.of(context).textTheme.labelSmall
                ?.copyWith(color: palette.muted, height: 1.55, fontSize: 8.8),
          ),
          const SizedBox(height: 16),
          PressableScale(
            onTap: _saving ? null : _save,
            enabled: !_saving,
            child: Container(
              height: 50,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: <Color>[
                    palette.bubbleUserStart,
                    palette.bubbleUserEnd,
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Center(
                child: _saving
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Text(
                        '写进记忆簿',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MemoryFilter {
  const _MemoryFilter(this.id, this.label, this.count);

  final String id;
  final String label;
  final int count;
}

class _MemoryCategory {
  const _MemoryCategory(this.id, this.label, this.icon);

  final String id;
  final String label;
  final IconData icon;
}
