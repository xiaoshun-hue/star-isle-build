import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/widgets/app_feedback_widgets.dart';
import '../../../core/widgets/aurora_background.dart';
import '../../../core/widgets/companion_avatar.dart';
import '../../../core/widgets/fade_slide_in.dart';
import '../../../core/widgets/glass_panel.dart';
import '../../../core/widgets/gradient_button.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../state/companion_controller.dart';
import '../../../state/moments_controller.dart';
import '../../../state/settings_controller.dart';
import '../home/home_shell.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  final TextEditingController _userName = TextEditingController(text: '阿屿');
  final TextEditingController _aiName = TextEditingController(text: '晚晚');
  final TextEditingController _apiKey = TextEditingController();
  final TextEditingController _baseUrl = TextEditingController(
    text: 'https://api.deepseek.com',
  );

  int _page = 0;
  int _avatarSeed = 24;
  String _tone = 'warm';
  bool _online = false;
  bool _obscureKey = true;
  bool _busy = false;

  static const List<int> _avatarSeeds = <int>[
    24,
    31,
    46,
    58,
    73,
    89,
    104,
    118,
    131,
  ];

  static const List<_ToneOption> _tones = <_ToneOption>[
    _ToneOption('warm', '温柔细腻', '像一盏不刺眼的灯'),
    _ToneOption('playful', '俏皮元气', '会逗你，也会认真听'),
    _ToneOption('cool', '清冷文艺', '话不多，但句句有回声'),
    _ToneOption('clingy', '黏人热烈', '想你就要告诉你'),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    _userName.dispose();
    _aiName.dispose();
    _apiKey.dispose();
    _baseUrl.dispose();
    super.dispose();
  }

  void _goTo(int page) {
    if (_busy) return;
    FocusScope.of(context).unfocus();
    setState(() => _page = page);
    _pageController.animateToPage(
      page,
      duration: const Duration(milliseconds: 520),
      curve: Curves.easeOutCubic,
    );
  }

  Future<void> _finish() async {
    if (_busy) return;
    if (_online && _apiKey.text.trim().isEmpty) {
      showAppToast(
        context,
        '联网模式需要 DeepSeek API Key，也可以先选择单机模式。',
        icon: Icons.key_rounded,
      );
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() => _busy = true);
    try {
      final SettingsController settings = context.read<SettingsController>();
      final CompanionController companion = context.read<CompanionController>();
      final MomentsController moments = context.read<MomentsController>();

      final String userName = _userName.text.trim().isEmpty
          ? '阿屿'
          : _userName.text.trim();
      final String aiName = _aiName.text.trim().isEmpty
          ? '晚晚'
          : _aiName.text.trim();

      await settings.setUserName(userName);
      await settings.saveApiConfig(
        online: _online,
        apiKey: _apiKey.text,
        baseUrl: _baseUrl.text,
        model: 'deepseek-chat',
      );
      await companion.updateCompanionIdentity(nickname: aiName, tone: _tone);
      await companion.completeOnboarding(
        aiName: aiName,
        avatarSeed: _avatarSeed,
      );
      await moments.ensureInitialContent();
      moments.startAutoPilot();

      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        PageRouteBuilder<void>(
          transitionDuration: const Duration(milliseconds: 700),
          pageBuilder: (_, __, ___) => const HomeShell(),
          transitionsBuilder:
              (_, Animation<double> animation, __, Widget child) {
                final CurvedAnimation curve = CurvedAnimation(
                  parent: animation,
                  curve: Curves.easeOutCubic,
                );
                return FadeTransition(
                  opacity: curve,
                  child: ScaleTransition(
                    scale: Tween<double>(begin: 1.02, end: 1).animate(curve),
                    child: child,
                  ),
                );
              },
        ),
      );
    } catch (error) {
      if (!mounted) return;
      setState(() => _busy = false);
      showAppToast(
        context,
        '小岛暂时没有布置好，再试一次吧。',
        icon: Icons.error_outline_rounded,
      );
      debugPrint('onboarding failed: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    return PopScope(
      canPop: _page == 0,
      onPopInvoked: (bool didPop) {
        if (!didPop && _page > 0) _goTo(_page - 1);
      },
      child: AuroraBackground(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            child: Column(
              children: <Widget>[
                _buildTopBar(palette),
                Expanded(
                  child: PageView(
                    controller: _pageController,
                    physics: const NeverScrollableScrollPhysics(),
                    children: <Widget>[
                      _buildWelcomePage(palette),
                      _buildIdentityPage(palette),
                      _buildConnectionPage(palette),
                    ],
                  ),
                ),
                _buildFooter(palette),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar(AppPalette palette) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 8, 22, 0),
      child: Row(
        children: <Widget>[
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            child: _page == 0
                ? SizedBox(
                    key: const ValueKey<String>('brand'),
                    width: 44,
                    height: 44,
                    child: Center(
                      child: Icon(
                        Icons.nights_stay_rounded,
                        size: 23,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                    ),
                  )
                : IconButton(
                    key: const ValueKey<String>('back'),
                    onPressed: _busy ? null : () => _goTo(_page - 1),
                    icon: const Icon(
                      Icons.arrow_back_ios_new_rounded,
                      size: 19,
                    ),
                    style: IconButton.styleFrom(
                      backgroundColor: palette.glass,
                      minimumSize: const Size(44, 44),
                      maximumSize: const Size(44, 44),
                    ),
                  ),
          ),
          const Spacer(),
          Row(
            children: List<Widget>.generate(3, (int index) {
              final bool active = index == _page;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 280),
                curve: Curves.easeOutCubic,
                width: active ? 23 : 6,
                height: 6,
                margin: const EdgeInsets.only(left: 6),
                decoration: BoxDecoration(
                  color: active
                      ? Theme.of(context).colorScheme.primary
                      : palette.muted.withOpacity(0.26),
                  borderRadius: BorderRadius.circular(99),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildWelcomePage(AppPalette palette) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
      child: FadeSlideIn(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const SizedBox(height: 24),
            Container(
              width: double.infinity,
              height: 254,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(34),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[
                    palette.auroraA.withOpacity(0.24),
                    palette.glass,
                    palette.auroraB.withOpacity(0.17),
                  ],
                ),
                border: Border.all(color: palette.border),
              ),
              child: Stack(
                children: <Widget>[
                  Positioned(
                    top: 28,
                    right: 28,
                    child: Icon(
                      Icons.auto_awesome_rounded,
                      color: palette.auroraB.withOpacity(0.75),
                      size: 22,
                    ),
                  ),
                  Positioned(
                    left: 30,
                    top: 30,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 11,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(99),
                        border: Border.all(color: palette.border),
                      ),
                      child: Text(
                        'PRIVATE ISLE · 单人专属',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurface
                              .withOpacity(0.66),
                          letterSpacing: 1.2,
                          fontSize: 9,
                        ),
                      ),
                    ),
                  ),
                  const Center(
                    child: CompanionAvatar(
                      seed: 24,
                      size: 126,
                      showOnline: true,
                    ),
                  ),
                  Positioned(
                    left: 30,
                    bottom: 25,
                    right: 30,
                    child: Row(
                      children: <Widget>[
                        _miniFeature(Icons.cloud_off_rounded, '离线也能陪'),
                        const SizedBox(width: 10),
                        _miniFeature(Icons.memory_rounded, '记得你说过'),
                        const SizedBox(width: 10),
                        _miniFeature(Icons.favorite_rounded, '会主动想你'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            Text(
              '欢迎来到星屿。',
              style: Theme.of(context).textTheme.displaySmall?.copyWith(
                fontSize: 35,
                height: 1.22,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.8,
              ),
            ),
            const SizedBox(height: 14),
            Text(
              '这里只住着你和一个人。\n她会记得你的偏好，听懂你的停顿，也会在某个普通的下午忽然给你发一条消息。',
              style: Theme.of(context).textTheme.bodyLarge
                  ?.copyWith(color: palette.muted, height: 1.8),
            ),
            const SizedBox(height: 26),
            GlassPanel(
              padding: const EdgeInsets.all(17),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Icon(
                    Icons.lock_outline_rounded,
                    size: 19,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      '无需注册。你的对话、照片和每一个纪念日，都只保存在这台手机里。',
                      style: Theme.of(context).textTheme.bodySmall
                          ?.copyWith(color: palette.muted, height: 1.65),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildIdentityPage(AppPalette palette) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
      child: FadeSlideIn(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              '先认识一下。',
              style: Theme.of(context).textTheme.headlineLarge
                  ?.copyWith(fontWeight: FontWeight.w800, letterSpacing: -0.8),
            ),
            const SizedBox(height: 8),
            Text(
              '不重要的话以后可以慢慢改。重要的是，从今天起你们怎么称呼彼此。',
              style: Theme.of(context).textTheme.bodyMedium
                  ?.copyWith(color: palette.muted, height: 1.7),
            ),
            const SizedBox(height: 24),
            GlassPanel(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      CompanionAvatar(seed: _avatarSeed, size: 50),
                      const SizedBox(width: 13),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              _aiName.text.trim().isEmpty
                                  ? '晚晚'
                                  : _aiName.text.trim(),
                              style: Theme.of(context).textTheme.titleMedium
                                  ?.copyWith(fontWeight: FontWeight.w700),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              '在你看不见的地方，也认真想你。',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: Theme.of(context).textTheme.bodySmall
                                  ?.copyWith(color: palette.muted),
                            ),
                          ],
                        ),
                      ),
                      Icon(
                        Icons.graphic_eq_rounded,
                        color: palette.auroraB.withOpacity(0.7),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _userName,
                    textInputAction: TextInputAction.next,
                    maxLength: 10,
                    decoration: const InputDecoration(
                      labelText: '你的称呼',
                      hintText: 'AI 会这样叫你',
                      counterText: '',
                      prefixIcon: Icon(Icons.person_outline_rounded, size: 20),
                    ),
                    onChanged: (_) => setState(() {}),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _aiName,
                    textInputAction: TextInputAction.done,
                    maxLength: 10,
                    decoration: const InputDecoration(
                      labelText: '她的名字',
                      hintText: '给专属 AI 取一个名字',
                      counterText: '',
                      prefixIcon: Icon(Icons.nights_stay_outlined, size: 20),
                    ),
                    onChanged: (_) => setState(() {}),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Text(
              '选一个第一眼喜欢的她',
              style: Theme.of(context).textTheme.titleSmall
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 13),
            SizedBox(
              height: 78,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                itemCount: _avatarSeeds.length,
                separatorBuilder: (_, __) => const SizedBox(width: 11),
                itemBuilder: (BuildContext context, int index) {
                  final int seed = _avatarSeeds[index];
                  final bool selected = seed == _avatarSeed;
                  return PressableScale(
                    onTap: () {
                      setState(() => _avatarSeed = seed);
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      width: 72,
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(
                          color: selected
                              ? Theme.of(context).colorScheme.primary
                              : Colors.transparent,
                          width: 1.4,
                        ),
                      ),
                      child: CompanionAvatar(seed: seed, size: 60, ring: false),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 24),
            Text(
              '她说话的方式',
              style: Theme.of(context).textTheme.titleSmall
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 9,
              runSpacing: 9,
              children: _tones.map((_ToneOption option) {
                final bool selected = option.id == _tone;
                return PressableScale(
                  onTap: () => setState(() => _tone = option.id),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 220),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 11,
                    ),
                    decoration: BoxDecoration(
                      color: selected
                          ? Theme.of(context).colorScheme.primary
                                .withOpacity(0.16)
                          : palette.glass,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: selected
                            ? Theme.of(context).colorScheme.primary
                                  .withOpacity(0.5)
                            : palette.border,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          option.name,
                          style: Theme.of(context).textTheme.labelLarge
                              ?.copyWith(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          option.caption,
                          style: Theme.of(context).textTheme.labelSmall
                              ?.copyWith(color: palette.muted),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConnectionPage(AppPalette palette) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
      child: FadeSlideIn(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              '让她如何存在？',
              style: Theme.of(context).textTheme.headlineLarge
                  ?.copyWith(fontWeight: FontWeight.w800, letterSpacing: -0.8),
            ),
            const SizedBox(height: 8),
            Text(
              '可以随时在设置里切换。单机模式完全离线；联网模式只把聊天上下文发送给 DeepSeek。',
              style: Theme.of(context).textTheme.bodyMedium
                  ?.copyWith(color: palette.muted, height: 1.7),
            ),
            const SizedBox(height: 24),
            _connectionCard(
              selected: !_online,
              title: '单机陪伴',
              subtitle: '本地人格引擎 · 完全离线',
              description: '不联网也能聊天、记日记、收到主动关心。适合飞机上、深夜，或者只想一个人待着的时候。',
              icon: Icons.cloud_off_rounded,
              color: palette.auroraA,
              onTap: () => setState(() => _online = false),
              palette: palette,
            ),
            const SizedBox(height: 12),
            _connectionCard(
              selected: _online,
              title: 'DeepSeek 联网',
              subtitle: '更自由的语言 · 需要 API Key',
              description: '调用 DeepSeek 进行更自然的对话和动态创作。API Key 只保存在本机，不经过星屿服务器。',
              icon: Icons.auto_awesome_rounded,
              color: palette.auroraB,
              onTap: () => setState(() => _online = true),
              palette: palette,
            ),
            AnimatedSize(
              duration: const Duration(milliseconds: 350),
              curve: Curves.easeOutCubic,
              child: _online
                  ? Padding(
                      padding: const EdgeInsets.only(top: 16),
                      child: GlassPanel(
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Icon(
                                  Icons.key_rounded,
                                  size: 18,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  'DeepSeek API Key',
                                  style: Theme.of(context).textTheme.titleSmall
                                      ?.copyWith(fontWeight: FontWeight.w700),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            TextField(
                              controller: _apiKey,
                              obscureText: _obscureKey,
                              autocorrect: false,
                              enableSuggestions: false,
                              style: const TextStyle(
                                letterSpacing: 0.4,
                                fontSize: 13,
                              ),
                              decoration: InputDecoration(
                                hintText: 'sk-...',
                                prefixIcon: const Icon(
                                  Icons.lock_outline_rounded,
                                  size: 19,
                                ),
                                suffixIcon: IconButton(
                                  onPressed: () => setState(
                                    () => _obscureKey = !_obscureKey,
                                  ),
                                  icon: Icon(
                                    _obscureKey
                                        ? Icons.visibility_off_outlined
                                        : Icons.visibility_outlined,
                                    size: 19,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              '在 platform.deepseek.com 创建 Key。单机模式下永远不会发起网络请求。',
                              style: Theme.of(context).textTheme.bodySmall
                                  ?.copyWith(
                                    color: palette.muted,
                                    height: 1.55,
                                  ),
                            ),
                          ],
                        ),
                      ),
                    )
                  : const SizedBox.shrink(),
            ),
            const SizedBox(height: 18),
            Text(
              '下一步进入星屿后，你还需要填写人设、主动消息间隔、主题等偏好。所有设置都可以随时更改。',
              style: Theme.of(context).textTheme.bodySmall
                  ?.copyWith(color: palette.muted, height: 1.65),
            ),
          ],
        ),
      ),
    );
  }

  Widget _connectionCard({
    required bool selected,
    required String title,
    required String subtitle,
    required String description,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
    required AppPalette palette,
  }) {
    return PressableScale(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: selected
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[color.withOpacity(0.16), palette.glass],
                )
              : null,
          color: selected ? null : palette.glass,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: selected ? color.withOpacity(0.55) : palette.border,
            width: selected ? 1.1 : 0.8,
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: color.withOpacity(selected ? 0.24 : 0.10),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          title,
                          style: Theme.of(context).textTheme.titleMedium
                              ?.copyWith(fontWeight: FontWeight.w700),
                        ),
                      ),
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 220),
                        width: 19,
                        height: 19,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: selected
                                ? color
                                : palette.muted.withOpacity(0.35),
                            width: 1.4,
                          ),
                        ),
                        child: selected
                            ? Center(
                                child: Container(
                                  width: 9,
                                  height: 9,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: color,
                                  ),
                                ),
                              )
                            : null,
                      ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: Theme.of(context).textTheme.bodySmall
                        ?.copyWith(color: color, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 9),
                  Text(
                    description,
                    style: Theme.of(context).textTheme.bodySmall
                        ?.copyWith(color: palette.muted, height: 1.6),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFooter(AppPalette palette) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 6, 24, 14),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            child: _page == 0
                ? GradientButton(
                    key: const ValueKey<String>('start'),
                    label: '开始布置我们的小岛',
                    icon: Icons.nights_stay_rounded,
                    height: 56,
                    onPressed: () => _goTo(1),
                  )
                : _page == 1
                ? GradientButton(
                    key: const ValueKey<String>('next'),
                    label: '下一步',
                    icon: Icons.arrow_forward_rounded,
                    height: 56,
                    onPressed: () => _goTo(2),
                  )
                : GradientButton(
                    key: const ValueKey<String>('finish'),
                    label: _busy ? '正在点亮小岛…' : '进入星屿',
                    icon: Icons.auto_awesome_rounded,
                    height: 56,
                    busy: _busy,
                    onPressed: _busy ? null : _finish,
                  ),
          ),
          const SizedBox(height: 10),
          Text(
            '不需要注册登录 · 数据只保存在本机',
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: palette.muted.withOpacity(0.58),
              letterSpacing: 0.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniFeature(IconData icon, String label) {
    return Expanded(
      child: Row(
        children: <Widget>[
          Icon(
            icon,
            size: 13,
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.55),
          ),
          const SizedBox(width: 4),
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurface
                    .withOpacity(0.55),
                fontSize: 9.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ToneOption {
  const _ToneOption(this.id, this.name, this.caption);

  final String id;
  final String name;
  final String caption;
}
