import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/utils/app_dates.dart';
import '../../../core/utils/app_feedback.dart';
import '../../../core/widgets/app_feedback_widgets.dart';
import '../../../core/widgets/app_sheet.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/fade_slide_in.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../data/models/album_entry.dart';
import '../../../state/album_controller.dart';
import '../../../state/settings_controller.dart';
import 'photo_viewer_screen.dart';

class AlbumScreen extends StatefulWidget {
  const AlbumScreen({super.key});

  @override
  State<AlbumScreen> createState() => _AlbumScreenState();
}

class _AlbumScreenState extends State<AlbumScreen>
    with AutomaticKeepAliveClientMixin {
  String _filter = 'all';

  @override
  bool get wantKeepAlive => true;

  List<AlbumEntry> _filtered(List<AlbumEntry> items) {
    if (_filter == 'all') return items;
    return items.where((AlbumEntry item) => item.source == _filter).toList();
  }

  Future<void> _import() async {
    final AlbumController controller = context.read<AlbumController>();
    final SettingsController settings = context.read<SettingsController>();
    if (controller.importing) return;
    AppFeedback.tap(settings.haptics);
    final bool imported = await controller.importFromGallery();
    if (!mounted || !imported) return;
    showAppToast(context, '照片已经收进相册', icon: Icons.photo_library_rounded);
  }

  Future<void> _refresh() async {
    await context.read<AlbumController>().refresh();
    await Future<void>.delayed(const Duration(milliseconds: 220));
  }

  void _openViewer(List<AlbumEntry> items, int index) {
    final List<String> paths = items
        .map((AlbumEntry item) => item.path)
        .whereType<String>()
        .toList();
    if (paths.isEmpty) return;
    final String? tappedPath = items[index].path;
    int initialIndex = tappedPath == null ? 0 : paths.indexOf(tappedPath);
    if (initialIndex < 0) initialIndex = 0;
    Navigator.of(context).push(
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 320),
        pageBuilder: (_, __, ___) => PhotoViewerScreen(
          paths: paths,
          initialIndex: initialIndex,
          title: items[index].title,
        ),
      ),
    );
  }

  Future<void> _showPhotoMenu(
    AlbumEntry entry,
    List<AlbumEntry> filtered,
  ) async {
    final AlbumController controller = context.read<AlbumController>();
    final BuildContext outer = context;
    await showGlassSheet<void>(
      context,
      title: entry.title,
      child: SheetBody(
        scroll: false,
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            _AlbumAction(
              icon: Icons.fullscreen_rounded,
              label: '查看大图',
              onTap: () {
                Navigator.of(context).pop();
                _openViewer(filtered, filtered.indexOf(entry));
              },
            ),
            _AlbumAction(
              icon: Icons.photo_library_outlined,
              label: '从相册移除',
              destructive: true,
              onTap: () async {
                Navigator.of(context).pop();
                final bool confirmed = await showAppConfirm(
                  outer,
                  title: '从相册移除？',
                  message: '只会从相册移除，聊天里或动态里的原图不会消失。',
                  confirmLabel: '移除',
                  destructive: true,
                );
                if (!confirmed) return;
                await controller.delete(entry.id);
                if (outer.mounted) {
                  showAppToast(outer, '已从相册移除');
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final AppPalette palette = context.palette;
    final AlbumController controller = context.watch<AlbumController>();
    final List<AlbumEntry> filtered = _filtered(controller.items);
    final AlbumEntry? latest = controller.items.isEmpty
        ? null
        : controller.items.first;

    return SafeArea(
      bottom: false,
      child: RefreshIndicator(
        onRefresh: _refresh,
        color: Theme.of(context).colorScheme.primary,
        backgroundColor: palette.glassStrong,
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics(),
          ),
          slivers: <Widget>[
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
                child: _buildHeader(context, controller, palette),
              ),
            ),
            if (latest != null)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 17, 16, 0),
                  child: _buildFeatured(context, latest, controller, palette),
                ),
              ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 18, 16, 12),
                child: _buildFilters(context, controller, palette),
              ),
            ),
            if (filtered.isEmpty)
              SliverFillRemaining(
                hasScrollBody: false,
                child: EmptyState(
                  icon: Icons.photo_library_outlined,
                  title: _filter == 'all' ? '相册还是空的' : '这里还没有照片',
                  message: _filter == 'all'
                      ? '聊天里发过的图片、动态的配图，都会自动收进这里。也可以从手机相册带一张进来。'
                      : '换一个分类看看，或者从手机里添加一张新的照片。',
                  actionLabel: '从手机相册添加',
                  onAction: _import,
                ),
              )
            else ...<Widget>[
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
                sliver: SliverGrid(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 9,
                    crossAxisSpacing: 9,
                    childAspectRatio: 0.78,
                  ),
                  delegate: SliverChildBuilderDelegate((
                    BuildContext context,
                    int index,
                  ) {
                    final AlbumEntry entry = filtered[index];
                    return FadeSlideIn(
                      key: ValueKey<String>('album-${entry.id}'),
                      delay: Duration(
                        milliseconds: 30 + (index.clamp(0, 6).toInt() * 40),
                      ),
                      child: _buildTile(
                        context,
                        entry,
                        index,
                        filtered,
                        palette,
                      ),
                    );
                  }, childCount: filtered.length),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 24, 16, 34),
                  child: Center(
                    child: Text(
                      '共 ${controller.items.length} 张画面 · 全部保存在本机',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: palette.muted.withOpacity(0.42),
                        fontSize: 9,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(
    BuildContext context,
    AlbumController controller,
    AppPalette palette,
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Text(
                    '相册',
                    style: Theme.of(context).textTheme.displaySmall?.copyWith(
                      fontSize: 31,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.8,
                      height: 1.05,
                    ),
                  ),
                  const SizedBox(width: 7),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 7,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: palette.glass,
                      borderRadius: BorderRadius.circular(99),
                      border: Border.all(color: palette.border),
                    ),
                    child: Text(
                      '${controller.items.length}',
                      style: Theme.of(context).textTheme.labelSmall
                          ?.copyWith(color: palette.muted, fontSize: 9),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                '照片会替我们，记住那一天的光。',
                style: Theme.of(context).textTheme.labelSmall
                    ?.copyWith(color: palette.muted, fontSize: 10),
              ),
            ],
          ),
        ),
        PressableScale(
          onTap: controller.importing ? null : _import,
          enabled: !controller.importing,
          child: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: palette.glass,
              border: Border.all(color: palette.border),
            ),
            child: controller.importing
                ? const Padding(
                    padding: EdgeInsets.all(12),
                    child: CircularProgressIndicator(strokeWidth: 1.8),
                  )
                : Icon(
                    Icons.add_photo_alternate_outlined,
                    size: 19,
                    color: Theme.of(context).colorScheme.primary,
                  ),
          ),
        ),
      ],
    );
  }

  Widget _buildFeatured(
    BuildContext context,
    AlbumEntry latest,
    AlbumController controller,
    AppPalette palette,
  ) {
    final int index = controller.items.indexOf(latest);
    return GestureDetector(
      onTap: () => _openViewer(controller.items, index < 0 ? 0 : index),
      child: Container(
        height: 174,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: palette.border),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: palette.shadow.withOpacity(palette.isDark ? 0.20 : 0.07),
              blurRadius: 24,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(26),
          child: Stack(
            fit: StackFit.expand,
            children: <Widget>[
              _AlbumImage(
                path: latest.path,
                palette: palette,
                fit: BoxFit.cover,
              ),
              Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: <Color>[Colors.transparent, Colors.black54],
                    stops: <double>[0.35, 1.0],
                  ),
                ),
              ),
              Positioned(
                top: 13,
                left: 14,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 9,
                    vertical: 4.5,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.26),
                    borderRadius: BorderRadius.circular(99),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      const Icon(
                        Icons.auto_awesome_rounded,
                        size: 11,
                        color: Colors.white70,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '最近的画面',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.82),
                          fontSize: 8.5,
                          letterSpacing: 0.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 16,
                right: 16,
                bottom: 14,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      latest.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${latest.sourceLabel} · ${AppDates.relative(latest.createdAt)}',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.62),
                        fontSize: 9,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFilters(
    BuildContext context,
    AlbumController controller,
    AppPalette palette,
  ) {
    final int chats = controller.items
        .where((AlbumEntry item) => item.source == 'chat')
        .length;
    final int moments = controller.items
        .where((AlbumEntry item) => item.source == 'moment')
        .length;
    final int saved = controller.items
        .where((AlbumEntry item) => item.source == 'manual')
        .length;
    final List<_FilterItem> filters = <_FilterItem>[
      _FilterItem('all', '全部', controller.items.length),
      _FilterItem('chat', '聊天', chats),
      _FilterItem('moment', '动态', moments),
      _FilterItem('manual', '珍藏', saved),
    ];
    return SizedBox(
      height: 34,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: filters.length,
        separatorBuilder: (_, __) => const SizedBox(width: 7),
        itemBuilder: (BuildContext context, int index) {
          final _FilterItem item = filters[index];
          final bool selected = _filter == item.id;
          return PressableScale(
            onTap: () {
              if (_filter == item.id) return;
              setState(() => _filter = item.id);
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 6),
              decoration: BoxDecoration(
                color: selected
                    ? Theme.of(context).colorScheme.primary.withOpacity(0.13)
                    : palette.glass,
                borderRadius: BorderRadius.circular(99),
                border: Border.all(
                  color: selected
                      ? Theme.of(context).colorScheme.primary.withOpacity(0.3)
                      : palette.border,
                ),
              ),
              child: Row(
                children: <Widget>[
                  Text(
                    item.label,
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      fontSize: 10,
                      color: selected
                          ? Theme.of(context).colorScheme.primary
                          : palette.muted,
                      fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '${item.count}',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      fontSize: 8,
                      color: palette.muted.withOpacity(0.55),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildTile(
    BuildContext context,
    AlbumEntry entry,
    int index,
    List<AlbumEntry> filtered,
    AppPalette palette,
  ) {
    return GestureDetector(
      onTap: () => _openViewer(filtered, index),
      onLongPress: () => unawaited(_showPhotoMenu(entry, filtered)),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(19),
          border: Border.all(color: palette.border, width: 0.8),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: palette.shadow.withOpacity(palette.isDark ? 0.13 : 0.04),
              blurRadius: 16,
              offset: const Offset(0, 7),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(19),
          child: Stack(
            fit: StackFit.expand,
            children: <Widget>[
              _AlbumImage(
                path: entry.path,
                palette: palette,
                fit: BoxFit.cover,
              ),
              Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: <Color>[Colors.transparent, Colors.black45],
                    stops: <double>[0.52, 1.0],
                  ),
                ),
              ),
              Positioned(
                left: 9,
                right: 9,
                bottom: 9,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 5,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.14),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        entry.sourceLabel,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.76),
                          fontSize: 7,
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      entry.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w600,
                        shadows: <Shadow>[
                          Shadow(color: Colors.black26, blurRadius: 8),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AlbumImage extends StatelessWidget {
  const _AlbumImage({
    required this.path,
    required this.palette,
    required this.fit,
  });

  final String? path;
  final AppPalette palette;
  final BoxFit fit;

  @override
  Widget build(BuildContext context) {
    if (path == null) return _fallback();
    final File file = File(path!);
    if (!file.existsSync()) return _fallback();
    return Image.file(
      file,
      fit: fit,
      errorBuilder: (_, __, ___) => _fallback(),
    );
  }

  Widget _fallback() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            palette.auroraA.withOpacity(0.42),
            palette.auroraB.withOpacity(0.26),
          ],
        ),
      ),
      child: const Center(
        child: Icon(
          Icons.auto_awesome_rounded,
          color: Colors.white54,
          size: 30,
        ),
      ),
    );
  }
}

class _FilterItem {
  const _FilterItem(this.id, this.label, this.count);

  final String id;
  final String label;
  final int count;
}

class _AlbumAction extends StatelessWidget {
  const _AlbumAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.destructive = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool destructive;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    final Color color = destructive
        ? const Color(0xFFFF708A)
        : Theme.of(context).colorScheme.onSurface.withOpacity(0.86);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
        child: Row(
          children: <Widget>[
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: destructive ? color.withOpacity(0.09) : palette.glass,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, size: 18, color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: Theme.of(context).textTheme.bodyMedium
                    ?.copyWith(color: color, fontWeight: FontWeight.w500),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
