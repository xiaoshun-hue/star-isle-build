import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/theme/app_palette.dart';
import '../../../../core/utils/app_dates.dart';
import '../../../../core/widgets/app_feedback_widgets.dart';
import '../../../../core/widgets/app_sheet.dart';
import '../../../../core/widgets/gradient_button.dart';
import '../../../../core/widgets/pressable_scale.dart';
import '../../../../data/models/anniversary_entry.dart';
import '../../../../state/anniversary_controller.dart';

class AnniversaryEditorSheet extends StatefulWidget {
  const AnniversaryEditorSheet({super.key, this.entry});

  final AnniversaryEntry? entry;

  @override
  State<AnniversaryEditorSheet> createState() => _AnniversaryEditorSheetState();
}

class _AnniversaryEditorSheetState extends State<AnniversaryEditorSheet> {
  late final TextEditingController _title;
  late final TextEditingController _note;
  late DateTime _date;
  late String _category;
  late bool _repeatYearly;
  late int _remindDays;
  bool _saving = false;

  static const List<_CategoryOption> _categories = <_CategoryOption>[
    _CategoryOption('anniversary', '纪念日', Icons.favorite_outline_rounded),
    _CategoryOption('birthday', '生日', Icons.cake_outlined),
    _CategoryOption('memo', '备忘', Icons.push_pin_outlined),
  ];

  static const List<int> _remindOptions = <int>[0, 1, 3, 7, 14];

  @override
  void initState() {
    super.initState();
    final AnniversaryEntry? entry = widget.entry;
    _title = TextEditingController(text: entry?.title ?? '');
    _note = TextEditingController(text: entry?.note ?? '');
    _date = entry?.date ?? DateTime.now();
    _category = entry?.category ?? 'anniversary';
    _repeatYearly = entry?.repeatYearly ?? true;
    _remindDays = entry?.remindDays ?? 3;
  }

  @override
  void dispose() {
    _title.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    FocusScope.of(context).unfocus();
    final DateTime now = DateTime.now();
    final DateTime initial = _date.year >= 1950 && _date.year <= 2100
        ? _date
        : now;
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(1950),
      lastDate: DateTime(2100),
      helpText: '选择哪一天',
      cancelText: '取消',
      confirmText: '记下',
    );
    if (picked != null && mounted) {
      setState(() => _date = AppDates.dateOnly(picked));
    }
  }

  Future<void> _save() async {
    if (_saving) return;
    final String title = _title.text.trim();
    if (title.isEmpty) {
      showAppToast(context, '给这一天取一个名字吧。', icon: Icons.edit_outlined);
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() => _saving = true);
    try {
      final AnniversaryController controller = context
          .read<AnniversaryController>();
      if (widget.entry == null) {
        await controller.add(
          title: title,
          date: _date,
          note: _note.text,
          category: _category,
          repeatYearly: _repeatYearly,
          remindDays: _remindDays,
        );
      } else {
        await controller.update(
          widget.entry!.copyWith(
            title: title,
            note: _note.text,
            date: _date,
            category: _category,
            repeatYearly: _repeatYearly,
            remindDays: _remindDays,
          ),
        );
      }
      if (mounted) Navigator.of(context).pop(true);
    } catch (error) {
      if (!mounted) return;
      setState(() => _saving = false);
      showAppToast(context, '没有保存成功，再试一次吧。');
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final ThemeData theme = Theme.of(context);
    final bool editing = widget.entry != null;
    return SheetBody(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          TextField(
            controller: _title,
            maxLength: 24,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(
              labelText: '这一天的名字',
              hintText: '例如：我们第一次见面',
              counterText: '',
              prefixIcon: Icon(Icons.edit_calendar_outlined, size: 20),
            ),
          ),
          const SizedBox(height: 9),
          Wrap(
            spacing: 7,
            runSpacing: 7,
            children: <String>['在一起', '第一次见面', '生日', '旅行出发'].map((
              String preset,
            ) {
              return PressableScale(
                onTap: () => setState(() => _title.text = preset),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 11,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: palette.glass,
                    borderRadius: BorderRadius.circular(99),
                    border: Border.all(color: palette.border),
                  ),
                  child: Text(
                    preset,
                    style: theme.textTheme.labelSmall?.copyWith(
                      color: palette.muted,
                      fontSize: 9.5,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 16),
          Text(
            '日子类型',
            style: theme.textTheme.labelMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: palette.muted,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: _categories.map((_CategoryOption option) {
              final bool selected = _category == option.id;
              return Expanded(
                child: Padding(
                  padding: EdgeInsets.only(
                    right: option.id == _categories.last.id ? 0 : 7,
                  ),
                  child: PressableScale(
                    onTap: () => setState(() => _category = option.id),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: selected
                            ? Theme.of(context).colorScheme.primary
                                  .withOpacity(0.12)
                            : palette.glass,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: selected
                              ? Theme.of(context).colorScheme.primary
                                    .withOpacity(0.35)
                              : palette.border,
                        ),
                      ),
                      child: Column(
                        children: <Widget>[
                          Icon(
                            option.icon,
                            size: 17,
                            color: selected
                                ? Theme.of(context).colorScheme.primary
                                : palette.muted,
                          ),
                          const SizedBox(height: 5),
                          Text(
                            option.label,
                            style: theme.textTheme.labelSmall?.copyWith(
                              color: selected
                                  ? Theme.of(context).colorScheme.primary
                                  : palette.muted,
                              fontSize: 9.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 16),
          PressableScale(
            onTap: _pickDate,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
              decoration: BoxDecoration(
                color: palette.glass,
                borderRadius: BorderRadius.circular(17),
                border: Border.all(color: palette.border),
              ),
              child: Row(
                children: <Widget>[
                  Icon(
                    Icons.calendar_today_outlined,
                    size: 18,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: Text(
                      AppDates.fullDateWithWeek(_date),
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Icon(
                    Icons.chevron_right_rounded,
                    size: 18,
                    color: palette.muted,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.fromLTRB(16, 5, 9, 5),
            decoration: BoxDecoration(
              color: palette.glass,
              borderRadius: BorderRadius.circular(17),
              border: Border.all(color: palette.border),
            ),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        '每年重复',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _repeatYearly ? '每年这一天都会回来' : '只在这一次日期提醒',
                        style: theme.textTheme.labelSmall?.copyWith(
                          color: palette.muted,
                          fontSize: 8.8,
                        ),
                      ),
                    ],
                  ),
                ),
                Switch.adaptive(
                  value: _repeatYearly,
                  activeColor: Theme.of(context).colorScheme.primary,
                  onChanged: (bool value) =>
                      setState(() => _repeatYearly = value),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Text(
            '什么时候提醒你',
            style: theme.textTheme.labelMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: palette.muted,
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 7,
            runSpacing: 7,
            children: _remindOptions.map((int days) {
              final bool selected = _remindDays == days;
              final String label = days == 0 ? '当天' : '提前 $days 天';
              return PressableScale(
                onTap: () => setState(() => _remindDays = days),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 7,
                  ),
                  decoration: BoxDecoration(
                    color: selected
                        ? Theme.of(context).colorScheme.primary
                              .withOpacity(0.12)
                        : palette.glass,
                    borderRadius: BorderRadius.circular(99),
                    border: Border.all(
                      color: selected
                          ? Theme.of(context).colorScheme.primary
                                .withOpacity(0.35)
                          : palette.border,
                    ),
                  ),
                  child: Text(
                    label,
                    style: theme.textTheme.labelSmall?.copyWith(
                      color: selected
                          ? Theme.of(context).colorScheme.primary
                          : palette.muted,
                      fontSize: 9.5,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _note,
            maxLength: 80,
            maxLines: 3,
            minLines: 2,
            decoration: const InputDecoration(
              labelText: '想留一句话给自己',
              hintText: '为什么这一天重要？',
              counterText: '',
            ),
          ),
          const SizedBox(height: 14),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Icon(
                Icons.notifications_none_rounded,
                size: 14,
                color: palette.muted,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  '晚晚会记住这一天，并通过主动私聊提前提醒你；不依赖系统通知权限。',
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: palette.muted,
                    height: 1.55,
                    fontSize: 8.8,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          GradientButton(
            label: editing ? '保存这份记忆' : '记进我们的日历',
            icon: Icons.favorite_outline_rounded,
            busy: _saving,
            height: 52,
            borderRadius: 17,
            onPressed: _saving ? null : _save,
          ),
        ],
      ),
    );
  }
}

class _CategoryOption {
  const _CategoryOption(this.id, this.label, this.icon);

  final String id;
  final String label;
  final IconData icon;
}
