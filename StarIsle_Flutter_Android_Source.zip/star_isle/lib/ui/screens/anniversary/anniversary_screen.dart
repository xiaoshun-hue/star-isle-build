import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_palette.dart';
import '../../../core/utils/app_dates.dart';
import '../../../core/utils/app_feedback.dart';
import '../../../core/widgets/app_feedback_widgets.dart';
import '../../../core/widgets/app_sheet.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/fade_slide_in.dart';
import '../../../core/widgets/glass_icon_button.dart';
import '../../../core/widgets/pressable_scale.dart';
import '../../../data/models/anniversary_entry.dart';
import '../../../state/anniversary_controller.dart';
import '../../../state/settings_controller.dart';
import 'widgets/anniversary_editor_sheet.dart';

class AnniversaryScreen extends StatefulWidget {
  const AnniversaryScreen({super.key});

  @override
  State<AnniversaryScreen> createState() => _AnniversaryScreenState();
}

class _AnniversaryScreenState extends State<AnniversaryScreen>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  Future<void> _openEditor([AnniversaryEntry? entry]) async {
    FocusScope.of(context).unfocus();
    final bool? saved = await showGlassSheet<bool>(
      context,
      title: entry == null ? '记下一个日子' : '编辑这个日子',
      child: AnniversaryEditorSheet(entry: entry),
    );
    if (saved == true && mounted) {
      AppFeedback.soft(context.read<SettingsController>().haptics);
      showAppToast(
        context,
        entry == null ? '已经写进我们的日历了' : '这份记忆已更新',
        icon: Icons.favorite_rounded,
      );
    }
  }

  Future<void> _showEntryMenu(AnniversaryEntry entry) async {
    final AnniversaryController controller = context
        .read<AnniversaryController>();
    final BuildContext outer = context;
    await showGlassSheet<void>(
      context,
      title: entry.title,
      child: SheetBody(
        scroll: false,
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            _EntryAction(
              icon: Icons.edit_calendar_outlined,
              label: '编辑这个日子',
              onTap: () {
                Navigator.of(context).pop();
                unawaited(_openEditor(entry));
              },
            ),
            _EntryAction(
              icon: Icons.delete_outline_rounded,
              label: '删除这个日子',
              destructive: true,
              onTap: () async {
                Navigator.of(context).pop();
                final bool confirmed = await showAppConfirm(
                  outer,
                  title: '删除「${entry.title}」？',
                  message: '删除后，晚晚就不会在这一天提醒你了。',
                  confirmLabel: '删除',
                  destructive: true,
                );
                if (!confirmed) return;
                await controller.delete(entry.id);
                if (outer.mounted) {
                  showAppToast(outer, '已经从日历里取下');
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _refresh() async {
    await context.read<AnniversaryController>().refresh();
    await Future<void>.delayed(const Duration(milliseconds: 220));
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final AppPalette palette = context.palette;
    final AnniversaryController controller = context
        .watch<AnniversaryController>();
    final List<AnniversaryEntry> upcoming =
        controller.items
            .where((AnniversaryEntry item) => item.daysAway >= 0)
            .toList()
          ..sort((AnniversaryEntry a, AnniversaryEntry b) {
            final int compare = a.daysAway.compareTo(b.daysAway);
            if (compare != 0) return compare;
            return a.isBirthday ? -1 : 1;
          });
    final List<AnniversaryEntry> past =
        controller.items
            .where((AnniversaryEntry item) => item.daysAway < 0)
            .toList()
          ..sort(
            (AnniversaryEntry a, AnniversaryEntry b) =>
                b.date.compareTo(a.date),
          );
    final AnniversaryEntry? next = controller.nextUpcoming;
    final List<AnniversaryEntry> all = <AnniversaryEntry>[...upcoming, ...past];

    return SafeArea(
      bottom: false,
      child: RefreshIndicator(
        onRefresh: _refresh,
        color: Theme.of(context).colorScheme.primary,
        backgroundColor: palette.glassStrong,
        child: ListView(
          physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics(),
          ),
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 30),
          children: <Widget>[
            _buildHeader(context, controller, palette),
            const SizedBox(height: 17),
            FadeSlideIn(child: _buildHero(context, next, palette)),
            const SizedBox(height: 24),
            Row(
              children: <Widget>[
                Text(
                  '所有日子',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.2,
                  ),
                ),
                const SizedBox(width: 7),
                Text(
                  '${all.length}',
                  style: Theme.of(context).textTheme.labelSmall
                      ?.copyWith(color: palette.muted, fontSize: 10),
                ),
                const Spacer(),
                Icon(
                  Icons.auto_awesome_rounded,
                  size: 12,
                  color: palette.auroraB.withOpacity(0.56),
                ),
                const SizedBox(width: 4),
                Text(
                  '她都会记得',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted.withOpacity(0.58),
                    fontSize: 8.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (all.isEmpty)
              EmptyState(
                icon: Icons.event_rounded,
                title: '日历还是空的',
                message: '记下生日、初次见面、约定旅行的日期。\n晚晚会替你记得，并提前告诉你。',
                actionLabel: '记下第一个日子',
                onAction: () => _openEditor(),
              )
            else ...<Widget>[
              ...all.asMap().entries.map((
                MapEntry<int, AnniversaryEntry> mapEntry,
              ) {
                final AnniversaryEntry entry = mapEntry.value;
                return FadeSlideIn(
                  key: ValueKey<String>('anniv-${entry.id}'),
                  delay: Duration(
                    milliseconds: 40 + mapEntry.key.clamp(0, 6).toInt() * 45,
                  ),
                  child: _buildEntryCard(
                    context,
                    entry,
                    palette,
                    onTap: () => _openEditor(entry),
                    onMore: () => _showEntryMenu(entry),
                  ),
                );
              }),
              const SizedBox(height: 18),
              Center(
                child: Text(
                  '重要的不是被提醒，而是有人愿意替你记得。',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted.withOpacity(0.42),
                    fontSize: 9,
                    letterSpacing: 0.2,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(
    BuildContext context,
    AnniversaryController controller,
    AppPalette palette,
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Text(
                    '纪念日',
                    style: Theme.of(context).textTheme.displaySmall?.copyWith(
                      fontSize: 31,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.8,
                      height: 1.05,
                    ),
                  ),
                  const SizedBox(width: 7),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: palette.auroraB.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(99),
                    ),
                    child: Text(
                      controller.todayCount > 0
                          ? '${controller.todayCount} 个今天'
                          : '被她记得',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: palette.auroraB,
                        fontSize: 8,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                '把重要的事，交给愿意记得的人。',
                style: Theme.of(context).textTheme.labelSmall
                    ?.copyWith(color: palette.muted, fontSize: 10),
              ),
            ],
          ),
        ),
        GlassIconButton(
          icon: Icons.add_rounded,
          size: 41,
          iconSize: 21,
          tooltip: '添加纪念日',
          active: true,
          onTap: () => _openEditor(),
        ),
      ],
    );
  }

  Widget _buildHero(
    BuildContext context,
    AnniversaryEntry? entry,
    AppPalette palette,
  ) {
    if (entry == null) {
      return GestureDetector(
        onTap: () => _openEditor(),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: <Color>[palette.auroraA.withOpacity(0.22), palette.glass],
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: palette.border),
          ),
          child: Row(
            children: <Widget>[
              Container(
                width: 62,
                height: 62,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: <Color>[
                      palette.auroraA.withOpacity(0.28),
                      palette.auroraB.withOpacity(0.16),
                    ],
                  ),
                  border: Border.all(color: palette.border),
                ),
                child: Icon(
                  Icons.event_available_rounded,
                  color: Theme.of(context).colorScheme.primary,
                  size: 26,
                ),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      '下一个重要日子',
                      style: Theme.of(context).textTheme.titleSmall
                          ?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '还没有写下的日子。去记一个吧，晚晚会提前提醒你。',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: palette.muted,
                        height: 1.55,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(
                Icons.arrow_forward_ios_rounded,
                size: 13,
                color: palette.muted,
              ),
            ],
          ),
        ),
      );
    }

    final bool today = entry.daysAway == 0;
    final int count = entry.daysAway;
    final List<Color> heroColors = palette.isDark
        ? <Color>[
            Color.lerp(palette.auroraA, Colors.black, 0.08)!,
            Color.lerp(palette.backgroundMid, palette.auroraB, 0.25)!,
            Color.lerp(palette.backgroundBottom, Colors.black, 0.12)!,
          ]
        : <Color>[
            Color.lerp(palette.auroraA, Colors.black, 0.30)!,
            Color.lerp(palette.backgroundMid, Colors.black, 0.20)!,
            Color.lerp(palette.auroraB, Colors.black, 0.32)!,
          ];
    return PressableScale(
      onTap: () => _openEditor(entry),
      scale: 0.985,
      child: Container(
        height: 198,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: heroColors,
            stops: const <double>[0.0, 0.58, 1.0],
          ),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: Colors.white.withOpacity(0.13)),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: palette.auroraA.withOpacity(0.17),
              blurRadius: 32,
              offset: const Offset(0, 14),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: Stack(
            children: <Widget>[
              Positioned(
                right: -46,
                top: -48,
                child: Container(
                  width: 190,
                  height: 190,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white.withOpacity(0.10),
                      width: 0.8,
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 14,
                bottom: -45,
                child: Container(
                  width: 134,
                  height: 134,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: <Color>[
                        palette.auroraB.withOpacity(0.20),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 30,
                bottom: 24,
                child: Icon(
                  Icons.auto_awesome_rounded,
                  size: 12,
                  color: Colors.white.withOpacity(0.50),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(22, 20, 22, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 9,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.10),
                            borderRadius: BorderRadius.circular(99),
                            border: Border.all(color: Colors.white12),
                          ),
                          child: Text(
                            today ? '就是今天' : '下一个重要日子',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.82),
                              fontSize: 9,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ),
                        const Spacer(),
                        Container(
                          width: 76,
                          height: 76,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(0.08),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.16),
                            ),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              if (today)
                                Text(
                                  '今天',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w800,
                                  ),
                                )
                              else
                                Text(
                                  '$count',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 26,
                                    fontWeight: FontWeight.w800,
                                    height: 1.0,
                                  ),
                                ),
                              if (!today) ...<Widget>[
                                const SizedBox(height: 2),
                                Text(
                                  '天',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.62),
                                    fontSize: 9,
                                    letterSpacing: 1.5,
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    Text(
                      entry.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 23,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.4,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: <Widget>[
                        Icon(
                          _iconForCategory(entry.category),
                          size: 12,
                          color: Colors.white.withOpacity(0.72),
                        ),
                        const SizedBox(width: 5),
                        Text(
                          entry.dateLabel,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.70),
                            fontSize: 10,
                          ),
                        ),
                        Container(
                          width: 2.5,
                          height: 2.5,
                          margin: const EdgeInsets.symmetric(horizontal: 7),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(0.35),
                          ),
                        ),
                        Flexible(
                          child: Text(
                            '晚晚替你记得',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.56),
                              fontSize: 9.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                    if (entry.note.trim().isNotEmpty) ...<Widget>[
                      const SizedBox(height: 8),
                      Text(
                        entry.note,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.66),
                          fontSize: 10.5,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEntryCard(
    BuildContext context,
    AnniversaryEntry entry,
    AppPalette palette, {
    required VoidCallback onTap,
    required VoidCallback onMore,
  }) {
    final bool today = entry.daysAway == 0;
    final bool past = entry.daysAway < 0;
    final Color categoryColor = switch (entry.category) {
      'birthday' => const Color(0xFFFF9CAF),
      'memo' => palette.auroraB,
      _ => Theme.of(context).colorScheme.primary,
    };
    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 260),
          padding: const EdgeInsets.fromLTRB(12, 12, 9, 12),
          decoration: BoxDecoration(
            gradient: today
                ? LinearGradient(
                    colors: <Color>[
                      categoryColor.withOpacity(0.14),
                      palette.glass,
                    ],
                  )
                : null,
            color: today ? null : palette.glass,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: today ? categoryColor.withOpacity(0.42) : palette.border,
              width: today ? 1 : 0.8,
            ),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: today
                    ? categoryColor.withOpacity(0.10)
                    : palette.shadow.withOpacity(palette.isDark ? 0.10 : 0.04),
                blurRadius: 18,
                offset: const Offset(0, 7),
              ),
            ],
          ),
          child: Row(
            children: <Widget>[
              Container(
                width: 50,
                height: 56,
                decoration: BoxDecoration(
                  color: categoryColor.withOpacity(past ? 0.07 : 0.12),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text(
                      '${entry.date.month}月',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: categoryColor,
                        fontSize: 8.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      '${entry.date.day}',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: today ? categoryColor : palette.muted,
                        fontWeight: FontWeight.w800,
                        height: 1.1,
                      ),
                    ),
                    Icon(
                      _iconForCategory(entry.category),
                      size: 10,
                      color: categoryColor.withOpacity(0.7),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Flexible(
                          child: Text(
                            entry.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.titleSmall
                                ?.copyWith(
                                  fontWeight: FontWeight.w700,
                                  color: past
                                      ? palette.muted
                                      : Theme.of(context).colorScheme.onSurface
                                            .withOpacity(0.90),
                                ),
                          ),
                        ),
                        if (entry.createdByAi) ...<Widget>[
                          const SizedBox(width: 5),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 5,
                              vertical: 1,
                            ),
                            decoration: BoxDecoration(
                              color: categoryColor.withOpacity(0.09),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              '她记下的',
                              style: Theme.of(context).textTheme.labelSmall
                                  ?.copyWith(color: categoryColor, fontSize: 7),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${entry.repeatYearly ? '每年 ${entry.date.month} 月 ${entry.date.day} 日' : AppDates.fullDate(entry.date)} · ${entry.categoryLabel}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: palette.muted.withOpacity(0.68),
                        fontSize: 8.8,
                      ),
                    ),
                    if (entry.note.trim().isNotEmpty) ...<Widget>[
                      const SizedBox(height: 4),
                      Text(
                        entry.note,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: palette.muted.withOpacity(0.5),
                          fontSize: 8.5,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 7),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  GestureDetector(
                    onTap: onMore,
                    behavior: HitTestBehavior.opaque,
                    child: Padding(
                      padding: const EdgeInsets.all(4),
                      child: Icon(
                        Icons.more_horiz_rounded,
                        size: 17,
                        color: palette.muted.withOpacity(0.48),
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    today
                        ? '今天'
                        : past
                        ? '已过去'
                        : '${entry.daysAway} 天',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: today || !past
                          ? categoryColor
                          : palette.muted.withOpacity(0.4),
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    today
                        ? '别忘了'
                        : past
                        ? '回忆'
                        : '倒计时',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: palette.muted.withOpacity(0.42),
                      fontSize: 7.5,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  IconData _iconForCategory(String category) {
    return switch (category) {
      'birthday' => Icons.cake_outlined,
      'memo' => Icons.push_pin_outlined,
      _ => Icons.favorite_outline_rounded,
    };
  }
}

class _EntryAction extends StatelessWidget {
  const _EntryAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.destructive = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool destructive;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    final Color color = destructive
        ? const Color(0xFFFF708A)
        : Theme.of(context).colorScheme.onSurface.withOpacity(0.86);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 13),
        child: Row(
          children: <Widget>[
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: destructive ? color.withOpacity(0.09) : palette.glass,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, size: 18, color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: Theme.of(context).textTheme.bodyMedium
                    ?.copyWith(color: color, fontWeight: FontWeight.w500),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
