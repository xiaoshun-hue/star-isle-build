import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import '../../core/decoration_pack.dart';
import '../../core/theme/app_palette.dart';
import '../../core/widgets/companion_avatar.dart';
import '../../core/widgets/detail_scaffold.dart';
import '../../core/widgets/glass_panel.dart';
import '../screens/settings/widgets/settings_tile.dart';

/// 装扮设置页。
///
/// 所有装扮默认都不启用；用户点击后才会写入本地。页面只做预览和选择，
/// 不改变原生星屿的主题、聊天逻辑和默认渲染分支。
class DecorationPage extends StatefulWidget {
  const DecorationPage({super.key});

  @override
  State<DecorationPage> createState() => _DecorationPageState();
}

class _DecorationPageState extends State<DecorationPage> {
  final DecorationStore _store = DecorationStore.instance;

  @override
  void initState() {
    super.initState();
    unawaited(_store.load());
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    return DetailScaffold(
      title: '装扮小屋',
      subtitle: '头像框、气泡和配色，只在你选择后生效',
      child: AnimatedBuilder(
        animation: _store,
        builder: (BuildContext context, Widget? child) {
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 30),
            physics: const BouncingScrollPhysics(),
            children: <Widget>[
              _buildIntro(context, palette),
              const SizedBox(height: 18),
              _buildNativeCard(context, palette),
              const SizedBox(height: 18),
              const SettingsSectionLabel(title: 'AVATAR · 用户头像池'),
              _buildAvatarPool(context, palette),
              const SizedBox(height: 18),
              const SettingsSectionLabel(title: 'FRAME · 头像框'),
              SizedBox(
                height: 156,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  itemCount: DecorationCatalog.avatarFrames.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (BuildContext context, int index) {
                    final AvatarFrameDecoration frame =
                        DecorationCatalog.avatarFrames[index];
                    return _FrameCard(
                      frame: frame,
                      selected:
                          _store.selection.avatarFrameId == frame.id,
                      onTap: () => unawaited(
                        _store.selectAvatarFrame(frame.id),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 18),
              const SettingsSectionLabel(title: 'BUBBLE · 聊天气泡'),
              ...DecorationCatalog.bubbleStyles.map(
                (ChatBubbleDecoration style) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _BubbleCard(
                    style: style,
                    selected: _store.selection.bubbleStyleId == style.id,
                    onTap: () => unawaited(
                      _store.selectBubbleStyle(style.id),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const SettingsSectionLabel(title: 'PALETTE · 主题配色'),
              ...DecorationCatalog.colorThemes.map(
                (ThemeColorDecoration theme) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _ColorCard(
                    theme: theme,
                    selected: _store.selection.colorThemeId == theme.id,
                    onTap: () => unawaited(
                      _store.selectColorTheme(theme.id),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Icon(
                    Icons.info_outline_rounded,
                    size: 13,
                    color: palette.muted.withOpacity(0.58),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      '装扮只保存在本机，不会上传。默认状态是原版星屿；'
                      '不选择任何装扮时，聊天外观与之前完全一致。',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: palette.muted.withOpacity(0.58),
                        fontSize: 8.8,
                        height: 1.6,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildAvatarPool(BuildContext context, AppPalette palette) {
    final List<String> pool = _store.userAvatarPool;
    final bool enabled = _store.useUserAvatarPool;
    final bool hasAvatar = _store.effectiveUserAvatarPath != null;
    final String subtitle = !enabled
        ? '关闭中，继续使用 avatarSeed 系统头像'
        : pool.isEmpty
        ? '已开启，但池为空，自动回退系统头像'
        : hasAvatar
        ? 'AI 进化时会从 ${pool.length} 张头像中自动轮换'
        : '当前路径不可用，自动回退系统头像';

    return GlassPanel(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _avatarPreview(_store.avatarFrame),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      enabled ? 'AI 自动轮换用户头像' : '使用系统头像',
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: palette.muted,
                        height: 1.45,
                      ),
                    ),
                  ],
                ),
              ),
              Switch.adaptive(
                value: enabled,
                activeColor: Theme.of(context).colorScheme.primary,
                onChanged: (bool value) => unawaited(
                  _store.setUseUserAvatarPool(value),
                ),
              ),
            ],
          ),
          if (pool.isNotEmpty) ...<Widget>[
            const SizedBox(height: 12),
            SizedBox(
              height: 58,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: pool.length,
                separatorBuilder: (_, __) => const SizedBox(width: 7),
                itemBuilder: (BuildContext context, int index) {
                  final String path = pool[index];
                  return Stack(
                    children: <Widget>[
                      ClipRRect(
                        borderRadius: BorderRadius.circular(11),
                        child: Image.file(
                          File(path),
                          width: 58,
                          height: 58,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            width: 58,
                            height: 58,
                            color: palette.muted.withOpacity(0.12),
                            child: Icon(
                              Icons.broken_image_outlined,
                              size: 18,
                              color: palette.muted,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        right: 0,
                        top: 0,
                        child: GestureDetector(
                          onTap: () => unawaited(
                            _store.removeUserAvatarPath(path),
                          ),
                          child: Container(
                            width: 18,
                            height: 18,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.black.withOpacity(0.55),
                            ),
                            child: const Icon(
                              Icons.close_rounded,
                              size: 12,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
          const SizedBox(height: 7),
          Wrap(
            spacing: 4,
            runSpacing: 4,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: <Widget>[
              TextButton.icon(
                onPressed: () => unawaited(_addAvatarPath()),
                icon: const Icon(Icons.add_photo_alternate_outlined, size: 16),
                label: const Text('添加头像'),
                style: TextButton.styleFrom(
                  visualDensity: VisualDensity.compact,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                ),
              ),
              TextButton.icon(
                onPressed: pool.isEmpty
                    ? null
                    : () => unawaited(_store.clearUserAvatarPool()),
                icon: const Icon(Icons.delete_sweep_outlined, size: 16),
                label: const Text('清空'),
                style: TextButton.styleFrom(
                  visualDensity: VisualDensity.compact,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                ),
              ),
              TextButton.icon(
                onPressed: enabled || pool.isNotEmpty
                    ? () => unawaited(_store.resetUserAvatarPool())
                    : null,
                icon: const Icon(Icons.restart_alt_rounded, size: 16),
                label: const Text('恢复系统头像'),
                style: TextButton.styleFrom(
                  visualDensity: VisualDensity.compact,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                ),
              ),
            ],
          ),
          Text(
            '只保存本地文件路径，不复制、不上传图片。',
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: palette.muted.withOpacity(0.55),
              fontSize: 8,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _addAvatarPath() async {
    final TextEditingController controller = TextEditingController();
    final String? path = await showDialog<String>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('添加头像路径'),
          content: TextField(
            controller: controller,
            autofocus: true,
            maxLines: 2,
            minLines: 1,
            decoration: const InputDecoration(
              hintText: '/storage/emulated/0/Pictures/avatar.jpg',
              helperText: '只保存路径字符串，不读取或复制图片。',
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('取消'),
            ),
            TextButton(
              onPressed: () =>
                  Navigator.of(context).pop(controller.text),
              child: const Text('添加'),
            ),
          ],
        );
      },
    );
    controller.dispose();
    final String clean = path?.trim() ?? '';
    if (clean.isEmpty) return;
    await _store.addUserAvatarPath(clean);
  }

  Widget _buildIntro(BuildContext context, AppPalette palette) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            palette.glass,
            Theme.of(context).colorScheme.primary.withOpacity(0.08),
          ],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: palette.border),
      ),
      child: Row(
        children: <Widget>[
          _avatarPreview(_store.avatarFrame),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  '给晚晚换一点新的光',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  '只改变头像框、气泡和强调色，不改变她的人设和记忆。',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: palette.muted,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNativeCard(BuildContext context, AppPalette palette) {
    final bool selected = !_store.isCustomized;
    return GlassPanel(
      onTap: () => unawaited(_store.resetAll()),
      border: Border.all(
        color: selected
            ? Theme.of(context).colorScheme.primary.withOpacity(0.7)
            : palette.border,
        width: selected ? 1.2 : 0.8,
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: palette.muted.withOpacity(0.1),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              Icons.restart_alt_rounded,
              color: palette.muted,
              size: 22,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  '原版星屿',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '恢复默认头像、气泡和配色',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            selected
                ? Icons.check_circle_rounded
                : Icons.circle_outlined,
            size: 20,
            color: selected
                ? Theme.of(context).colorScheme.primary
                : palette.muted.withOpacity(0.55),
          ),
        ],
      ),
    );
  }

  Widget _avatarPreview(AvatarFrameDecoration? frame) {
    Widget avatar = const CompanionAvatar(
      seed: 24,
      size: 52,
      nickname: '晚晚',
    );
    if (frame == null) return avatar;
    return Container(
      padding: EdgeInsets.all(frame.padding),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[frame.primary, frame.secondary],
        ),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: frame.glow.withOpacity(0.35),
            blurRadius: 16,
            spreadRadius: 1,
          ),
        ],
      ),
      child: avatar,
    );
  }
}

class _FrameCard extends StatelessWidget {
  const _FrameCard({
    required this.frame,
    required this.selected,
    required this.onTap,
  });

  final AvatarFrameDecoration frame;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    return SizedBox(
      width: 142,
      child: GlassPanel(
        padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
        onTap: onTap,
        border: Border.all(
          color: selected
              ? frame.primary.withOpacity(0.85)
              : palette.border,
          width: selected ? 1.3 : 0.8,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Center(
              child: Container(
                padding: EdgeInsets.all(frame.padding),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: <Color>[frame.primary, frame.secondary],
                  ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: frame.glow.withOpacity(0.28),
                      blurRadius: 9,
                    ),
                  ],
                ),
                child: const CompanionAvatar(
                  seed: 24,
                  size: 43,
                  nickname: '晚晚',
                ),
              ),
            ),
            const Spacer(),
            Text(
              frame.name,
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              frame.description,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: palette.muted,
                height: 1.4,
              ),
            ),
            if (selected) ...<Widget>[
              const SizedBox(height: 5),
              Row(
                children: <Widget>[
                  Icon(
                    Icons.check_circle_rounded,
                    size: 13,
                    color: frame.primary,
                  ),
                  const SizedBox(width: 3),
                  Text(
                    '已选择',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: frame.primary,
                      fontSize: 8,
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _BubbleCard extends StatelessWidget {
  const _BubbleCard({
    required this.style,
    required this.selected,
    required this.onTap,
  });

  final ChatBubbleDecoration style;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    return GlassPanel(
      padding: const EdgeInsets.all(14),
      onTap: onTap,
      border: Border.all(
        color: selected ? style.userStart : palette.border,
        width: selected ? 1.2 : 0.8,
      ),
      child: Row(
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _bubble(context, '我今晚有点想你', isUser: true),
              const SizedBox(height: 5),
              _bubble(context, '那就多坐一会儿，晚风还没走。', isUser: false),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  style.name,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  style.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            selected
                ? Icons.check_circle_rounded
                : Icons.circle_outlined,
            size: 19,
            color: selected
                ? style.userStart
                : palette.muted.withOpacity(0.55),
          ),
        ],
      ),
    );
  }

  Widget _bubble(
    BuildContext context,
    String text, {
    required bool isUser,
  }) {
    final List<Color> colors = isUser
        ? <Color>[style.userStart, style.userEnd]
        : <Color>[style.aiColor, style.aiColor];
    return Container(
      constraints: const BoxConstraints(maxWidth: 148),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: colors,
        ),
        borderRadius: BorderRadius.circular(style.radius),
        border: isUser ? null : Border.all(color: style.aiBorder),
      ),
      child: Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
          color: isUser
              ? Colors.white
              : (style.aiColor.computeLuminance() > 0.5
                    ? Colors.black87
                    : Colors.white.withOpacity(0.9)),
          fontSize: 8.8,
        ),
      ),
    );
  }
}

class _ColorCard extends StatelessWidget {
  const _ColorCard({
    required this.theme,
    required this.selected,
    required this.onTap,
  });

  final ThemeColorDecoration theme;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    return GlassPanel(
      padding: const EdgeInsets.all(14),
      onTap: onTap,
      border: Border.all(
        color: selected ? theme.accent : palette.border,
        width: selected ? 1.2 : 0.8,
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[
                  theme.userStart,
                  theme.userEnd,
                  theme.accent,
                ],
              ),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: theme.accent.withOpacity(0.28),
                  blurRadius: 14,
                ),
              ],
            ),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  theme.name,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  theme.description,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: palette.muted,
                  ),
                ),
              ],
            ),
          ),
          Row(
            children: <Widget>[
              _dot(theme.userStart),
              _dot(theme.userEnd),
              _dot(theme.accent),
            ],
          ),
          const SizedBox(width: 7),
          Icon(
            selected
                ? Icons.check_circle_rounded
                : Icons.circle_outlined,
            size: 19,
            color: selected
                ? theme.accent
                : palette.muted.withOpacity(0.55),
          ),
        ],
      ),
    );
  }

  Widget _dot(Color color) {
    return Container(
      width: 11,
      height: 11,
      margin: const EdgeInsets.only(left: 3),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        border: Border.all(color: Colors.white.withOpacity(0.25)),
      ),
    );
  }
}
