import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'data/app_repository.dart';
import 'services/ai/ai_service.dart';
import 'services/tts_service.dart';
import 'state/album_controller.dart';
import 'state/anniversary_controller.dart';
import 'state/companion_controller.dart';
import 'state/moments_controller.dart';
import 'state/settings_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(<DeviceOrientation>[
    DeviceOrientation.portraitUp,
  ]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarDividerColor: Colors.transparent,
      systemNavigationBarIconBrightness: Brightness.light,
      systemNavigationBarContrastEnforced: false,
    ),
  );

  try {
    final SettingsController settings = await SettingsController.load();
    final AppRepository repository = await AppRepository.create();
    final AiService aiService = AiService(settings: settings);
    final TtsService ttsService = TtsService();
    final CompanionController companion = CompanionController(
      repository: repository,
      settings: settings,
      aiService: aiService,
      ttsService: ttsService,
    );
    final MomentsController moments = MomentsController(
      repository: repository,
      settings: settings,
      aiService: aiService,
    );
    final AnniversaryController anniversaries = AnniversaryController(
      repository: repository,
    );
    final AlbumController album = AlbumController(repository: repository);

    runApp(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<SettingsController>.value(value: settings),
          Provider<AppRepository>.value(value: repository),
          Provider<AiService>.value(value: aiService),
          ChangeNotifierProvider<TtsService>.value(value: ttsService),
          ChangeNotifierProvider<CompanionController>.value(value: companion),
          ChangeNotifierProvider<MomentsController>.value(value: moments),
          ChangeNotifierProvider<AnniversaryController>.value(
            value: anniversaries,
          ),
          ChangeNotifierProvider<AlbumController>.value(value: album),
        ],
        child: const StarIsleApp(),
      ),
    );
  } catch (error) {
    runApp(_StartupFailureApp(error: error));
  }
}

class _StartupFailureApp extends StatelessWidget {
  const _StartupFailureApp({required this.error});

  final Object error;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7E9BFF),
          brightness: Brightness.dark,
        ),
      ),
      home: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const Icon(
                  Icons.nights_stay_rounded,
                  size: 64,
                  color: Color(0xFFFFB4C1),
                ),
                const SizedBox(height: 22),
                const Text(
                  '星屿没有亮起来',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  '初始化本地数据时出了点问题。请重新打开应用；如果仍然失败，再查看调试信息。\n\n$error',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    height: 1.6,
                    color: Colors.white.withOpacity(0.62),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
