import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'data/app_repository.dart';
import 'services/ai/ai_service.dart';
import 'services/tts_service.dart';
import 'state/album_controller.dart';
import 'state/anniversary_controller.dart';
import 'state/companion_controller.dart';
import 'state/moments_controller.dart';
import 'state/settings_controller.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Draw a frame immediately. Local data and plugins are initialized below a
  // visible loading screen so a slow first launch can never leave a black
  // native window on screen.
  runApp(const _BootstrapRoot());
}

class _BootstrapRoot extends StatefulWidget {
  const _BootstrapRoot();

  @override
  State<_BootstrapRoot> createState() => _BootstrapRootState();
}

class _BootstrapRootState extends State<_BootstrapRoot> {
  late Future<_AppDependencies> _future;

  @override
  void initState() {
    super.initState();
    _future = _initialize();
  }

  Future<_AppDependencies> _initialize() async {
    // These platform calls used to run before runApp(). Keep them here so the
    // loading frame is already on screen, and do not let an OEM quirk block
    // the whole startup.
    try {
      await SystemChrome.setPreferredOrientations(<DeviceOrientation>[
        DeviceOrientation.portraitUp,
      ]);
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      SystemChrome.setSystemUIOverlayStyle(
        const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
          systemNavigationBarColor: Colors.transparent,
          systemNavigationBarDividerColor: Colors.transparent,
          systemNavigationBarIconBrightness: Brightness.light,
          systemNavigationBarContrastEnforced: false,
        ),
      );
    } catch (_) {
      // Presentation preferences are non-critical.
    }

    final SettingsController settings = await SettingsController.load().timeout(
      const Duration(seconds: 20),
    );
    final AppRepository repository = await AppRepository.create().timeout(
      const Duration(seconds: 20),
    );

    final AiService aiService = AiService(settings: settings);
    final TtsService ttsService = TtsService();
    final CompanionController companion = CompanionController(
      repository: repository,
      settings: settings,
      aiService: aiService,
      ttsService: ttsService,
    );
    final MomentsController moments = MomentsController(
      repository: repository,
      settings: settings,
      aiService: aiService,
    );
    final AnniversaryController anniversaries = AnniversaryController(
      repository: repository,
    );
    final AlbumController album = AlbumController(repository: repository);

    return _AppDependencies(
      settings: settings,
      repository: repository,
      aiService: aiService,
      ttsService: ttsService,
      companion: companion,
      moments: moments,
      anniversaries: anniversaries,
      album: album,
    );
  }

  void _retry() {
    setState(() {
      _future = _initialize();
    });
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_AppDependencies>(
      future: _future,
      builder: (BuildContext context, AsyncSnapshot<_AppDependencies> snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const _LoadingApp();
        }
        if (snapshot.hasError) {
          return _StartupFailureApp(
            error: snapshot.error ?? '未知错误',
            onRetry: _retry,
          );
        }
        final _AppDependencies? dependencies = snapshot.data;
        if (dependencies == null) {
          return const _LoadingApp();
        }
        return MultiProvider(
          providers: [
            ChangeNotifierProvider<SettingsController>.value(
              value: dependencies.settings,
            ),
            Provider<AppRepository>.value(value: dependencies.repository),
            Provider<AiService>.value(value: dependencies.aiService),
            ChangeNotifierProvider<TtsService>.value(
              value: dependencies.ttsService,
            ),
            ChangeNotifierProvider<CompanionController>.value(
              value: dependencies.companion,
            ),
            ChangeNotifierProvider<MomentsController>.value(
              value: dependencies.moments,
            ),
            ChangeNotifierProvider<AnniversaryController>.value(
              value: dependencies.anniversaries,
            ),
            ChangeNotifierProvider<AlbumController>.value(
              value: dependencies.album,
            ),
          ],
          child: const StarIsleApp(),
        );
      },
    );
  }
}

class _AppDependencies {
  const _AppDependencies({
    required this.settings,
    required this.repository,
    required this.aiService,
    required this.ttsService,
    required this.companion,
    required this.moments,
    required this.anniversaries,
    required this.album,
  });

  final SettingsController settings;
  final AppRepository repository;
  final AiService aiService;
  final TtsService ttsService;
  final CompanionController companion;
  final MomentsController moments;
  final AnniversaryController anniversaries;
  final AlbumController album;
}

class _LoadingApp extends StatelessWidget {
  const _LoadingApp();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7E9BFF),
          brightness: Brightness.dark,
        ),
      ),
      home: const Scaffold(
        backgroundColor: Color(0xFF080D1C),
        body: SafeArea(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(
                  Icons.nights_stay_rounded,
                  size: 64,
                  color: Color(0xFFFFB4C1),
                ),
                SizedBox(height: 22),
                Text(
                  '正在点亮星屿',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    letterSpacing: 1.2,
                  ),
                ),
                SizedBox(height: 18),
                SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.2,
                    color: Color(0xFFFFB4C1),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _StartupFailureApp extends StatelessWidget {
  const _StartupFailureApp({required this.error, required this.onRetry});

  final Object error;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7E9BFF),
          brightness: Brightness.dark,
        ),
      ),
      home: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const Icon(
                  Icons.nights_stay_rounded,
                  size: 64,
                  color: Color(0xFFFFB4C1),
                ),
                const SizedBox(height: 22),
                const Text(
                  '星屿没有亮起来',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 10),
                Flexible(
                  child: SingleChildScrollView(
                    child: Text(
                      '初始化本地数据时出了点问题。\n\n$error',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        height: 1.6,
                        color: Colors.white.withOpacity(0.62),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 22),
                FilledButton(
                  onPressed: onRetry,
                  child: const Text('再试一次'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
