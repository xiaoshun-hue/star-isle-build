import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'free_edge_tts_service.dart';

enum VoiceBubbleStatus { generating, ready, failed }

class VoiceBubbleEntry {
  VoiceBubbleEntry({
    required this.messageId,
    required this.text,
    required this.status,
    this.audioPath,
    this.durationMs,
    this.error,
  });

  final String messageId;
  final String text;
  VoiceBubbleStatus status;
  String? audioPath;
  int? durationMs;
  String? error;

  bool get isReady =>
      status == VoiceBubbleStatus.ready &&
      audioPath != null &&
      File(audioPath!).existsSync();

  bool get isGenerating => status == VoiceBubbleStatus.generating;
}

/// 主动消息语音气泡的运行时登记表。
///
/// 不修改 ChatMessage 模型：消息本身照常保存文字字幕，语音路径只在这里
/// 与 messageId 关联，并持久化到 SharedPreferences；音频文件不存在时自动
/// 退回文字气泡。
class VoiceBubbleRegistry extends ChangeNotifier {
  VoiceBubbleRegistry._() {
    unawaited(_load());
  }

  static final VoiceBubbleRegistry instance = VoiceBubbleRegistry._();
  static const String _prefsKey = 'star_isle_voice_bubbles_v1';
  static const int _maxEntries = 80;
  final Map<String, VoiceBubbleEntry> _entries = <String, VoiceBubbleEntry>{};

  VoiceBubbleEntry? entry(String messageId) => _entries[messageId];

  Future<void> _load() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final String? raw = prefs.getString(_prefsKey);
      if (raw == null || raw.trim().isEmpty) return;
      final Object? decoded = jsonDecode(raw);
      if (decoded is! Map<String, dynamic>) return;
      for (final MapEntry<String, dynamic> item in decoded.entries) {
        final Object? value = item.value;
        if (value is! Map) continue;
        final String? text = value['text'] as String?;
        final String? path = value['path'] as String?;
        final int? duration = (value['durationMs'] as num?)?.toInt();
        if (text == null || path == null || !File(path).existsSync()) continue;
        _entries[item.key] = VoiceBubbleEntry(
          messageId: item.key,
          text: text,
          status: VoiceBubbleStatus.ready,
          audioPath: path,
          durationMs: duration,
        );
      }
      if (_entries.isNotEmpty) notifyListeners();
    } catch (error) {
      debugPrint('load voice bubbles failed: $error');
    }
  }

  Future<void> _persist() async {
    try {
      final Map<String, Object?> data = <String, Object?>{};
      for (final VoiceBubbleEntry entry in _entries.values) {
        if (entry.status == VoiceBubbleStatus.ready &&
            entry.audioPath != null &&
            File(entry.audioPath!).existsSync()) {
          data[entry.messageId] = <String, Object>{
            'text': entry.text,
            'path': entry.audioPath!,
            if (entry.durationMs != null) 'durationMs': entry.durationMs!,
          };
        }
      }
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      if (data.isEmpty) {
        await prefs.remove(_prefsKey);
      } else {
        await prefs.setString(_prefsKey, jsonEncode(data));
      }
    } catch (error) {
      debugPrint('save voice bubbles failed: $error');
    }
  }

  Future<void> prepare({
    required String messageId,
    required String text,
    required String voice,
    required double rate,
    required double pitch,
    Future<File?> Function(String text)? fallbackSynthesizer,
  }) async {
    final VoiceBubbleEntry? existing = _entries[messageId];
    if (existing != null &&
        (existing.isGenerating || existing.status == VoiceBubbleStatus.ready)) {
      return;
    }
    final VoiceBubbleEntry entry = VoiceBubbleEntry(
      messageId: messageId,
      text: text,
      status: VoiceBubbleStatus.generating,
    );
    _entries[messageId] = entry;
    notifyListeners();

    File? audio = await FreeEdgeTtsService.instance.synthesize(
      text: text,
      voice: voice,
      rate: rate,
      pitch: pitch,
    );
    if (audio == null && fallbackSynthesizer != null) {
      // Edge 接口失效时，用系统离线 TTS 生成可缓存的兜底语音。
      audio = await fallbackSynthesizer(text);
    }
    if (audio == null) {
      // 两种 TTS 都失败：移除登记，聊天界面自动回到普通文字气泡。
      _entries.remove(messageId);
      notifyListeners();
      unawaited(_persist());
      return;
    }
    entry
      ..status = VoiceBubbleStatus.ready
      ..audioPath = audio.path
      ..durationMs = _estimateDuration(text)
      ..error = null;
    if (_entries.length > _maxEntries) {
      final List<String> keys = _entries.keys.take(_entries.length - _maxEntries).toList();
      for (final String key in keys) {
        _entries.remove(key);
      }
    }
    notifyListeners();
    unawaited(_persist());
  }

  /// 用户录音发送后直接登记为可播放的语音条。
  void registerReady({
    required String messageId,
    required String text,
    required String audioPath,
    required int durationMs,
  }) {
    _entries[messageId] = VoiceBubbleEntry(
      messageId: messageId,
      text: text,
      status: VoiceBubbleStatus.ready,
      audioPath: audioPath,
      durationMs: durationMs,
    );
    notifyListeners();
    unawaited(_persist());
  }

  int _estimateDuration(String text) {
    final int chars = text.runes.length;
    return (chars / 4.2 * 1000).clamp(1200, 60000).toInt();
  }

  void remove(String messageId) {
    if (_entries.remove(messageId) != null) {
      notifyListeners();
      unawaited(_persist());
    }
  }

  void clearAll() {
    if (_entries.isEmpty) return;
    _entries.clear();
    notifyListeners();
    unawaited(_persist());
  }
}
