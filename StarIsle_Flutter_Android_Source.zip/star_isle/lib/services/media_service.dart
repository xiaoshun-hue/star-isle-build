import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../core/utils/id_generator.dart';

class MediaService {
  MediaService._();

  static final ImagePicker _picker = ImagePicker();

  static Future<Directory> ensureDirectory(String name) async {
    final Directory root = await getApplicationDocumentsDirectory();
    final Directory directory = Directory(p.join(root.path, 'star_isle', name));
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    return directory;
  }

  static Future<File?> pickImageFromGallery() async {
    try {
      final XFile? picked = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1800,
        imageQuality: 88,
      );
      if (picked == null) return null;
      return await persistXFile(picked);
    } catch (error) {
      debugPrint('pick image failed: $error');
      return null;
    }
  }

  static Future<File> persistXFile(XFile file) async {
    final Directory directory = await ensureDirectory('images');
    final String sourceName = file.name;
    final String extension = _safeExtension(sourceName);
    final File target = File(
      p.join(directory.path, 'img_${IdGenerator.newId()}$extension'),
    );
    await file.saveTo(target.path);
    return target;
  }

  static Future<File> saveBytes(
    Uint8List bytes, {
    String extension = 'png',
    String folder = 'images',
    String prefix = 'img',
  }) async {
    final Directory directory = await ensureDirectory(folder);
    final File target = File(
      p.join(directory.path, '${prefix}_${IdGenerator.newId()}.$extension'),
    );
    await target.writeAsBytes(bytes, flush: true);
    return target;
  }

  static Future<void> deleteQuietly(String? path) async {
    if (path == null || path.isEmpty) return;
    try {
      final File file = File(path);
      if (await file.exists()) await file.delete();
    } catch (error) {
      debugPrint('delete media failed: $error');
    }
  }

  static bool existsSync(String? path) {
    if (path == null || path.isEmpty) return false;
    try {
      return File(path).existsSync();
    } catch (_) {
      return false;
    }
  }

  static Future<int> sizeOf(String path) async {
    try {
      return await File(path).length();
    } catch (_) {
      return 0;
    }
  }

  static String _safeExtension(String name) {
    final String ext = p.extension(name).toLowerCase();
    const Set<String> allowed = <String>{
      '.jpg',
      '.jpeg',
      '.png',
      '.webp',
      '.gif',
      '.heic',
      '.heif',
    };
    if (allowed.contains(ext)) return ext;
    return '.jpg';
  }
}
