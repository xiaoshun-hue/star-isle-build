import 'dart:convert';

import 'package:http/http.dart' as http;

class VoiceAsrException implements Exception {
  const VoiceAsrException(this.message, {this.statusCode});

  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}

/// SiliconFlow speech-to-text.
///
/// XingChenGSR is preferred because it is the newest Generative Speech
/// Recognition model. The public transcription docs currently list SenseVoice
/// explicitly, so we retry with SenseVoice when XingChen is not accepted by
/// the endpoint.
class VoiceAsrService {
  static const String baseUrl = 'https://api.siliconflow.cn/v1';
  static const List<String> models = <String>[
    'XingChenAGI/XingChenASR-V3.2-Ultra',
    'XingChenAGI/XingChenGSR-V1.0',
    'FunAudioLLM/SenseVoiceSmall',
  ];

  Future<String> transcribe({
    required String apiKey,
    required String filePath,
  }) async {
    if (apiKey.trim().isEmpty) {
      throw const VoiceAsrException('还没有填写语音识别 API Key。');
    }

    final List<String> failures = <String>[];
    for (int index = 0; index < models.length; index++) {
      try {
        return await _transcribe(
          apiKey: apiKey,
          filePath: filePath,
          model: models[index],
        );
      } on VoiceAsrException catch (error) {
        final bool canFallback =
            error.statusCode == 400 ||
            error.statusCode == 404 ||
            error.statusCode == 422;
        if (!canFallback) rethrow;
        failures.add('${models[index]}：${error.message}');
        if (index == models.length - 1) {
          throw VoiceAsrException(failures.join('；'));
        }
      }
    }
    throw const VoiceAsrException('没有可用的语音识别模型。');
  }

  Future<String> _transcribe({
    required String apiKey,
    required String filePath,
    required String model,
  }) async {
    final http.MultipartRequest request = http.MultipartRequest(
      'POST',
      Uri.parse('$baseUrl/audio/transcriptions'),
    );
    request.headers['Authorization'] = 'Bearer ${apiKey.trim()}';
    request.fields['model'] = model;
    request.files.add(
      await http.MultipartFile.fromPath(
        'file',
        filePath,
        filename: 'voice.wav',
      ),
    );

    final http.StreamedResponse streamed;
    try {
      streamed = await request.send().timeout(const Duration(seconds: 90));
    } catch (error) {
      throw VoiceAsrException('语音识别网络失败：$error');
    }

    final http.Response response = await http.Response.fromStream(streamed);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw VoiceAsrException(
        _errorMessage(response),
        statusCode: response.statusCode,
      );
    }

    final Object? decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is! Map<String, dynamic>) {
      throw const VoiceAsrException('语音识别返回格式不正确。');
    }
    final String text = (decoded['text'] as String?)?.trim() ?? '';
    if (text.isEmpty) {
      throw const VoiceAsrException('没有识别出内容，再说一次试试。');
    }
    return text;
  }

  String _errorMessage(http.Response response) {
    if (response.statusCode == 401 || response.statusCode == 403) {
      return '语音识别 Key 无效或没有权限。';
    }
    if (response.statusCode == 429) {
      return '语音识别请求太频繁，稍后再试。';
    }
    String detail = '';
    try {
      final Object? data = jsonDecode(utf8.decode(response.bodyBytes));
      if (data is Map<String, dynamic>) {
        detail = (data['message'] ?? data['error'] ?? '').toString();
      }
    } catch (_) {
      detail = '';
    }
    if (detail.isEmpty) detail = response.body;
    if (detail.length > 160) detail = detail.substring(0, 160);
    return '语音识别失败（${response.statusCode}）'
        '${detail.isEmpty ? '' : '：$detail'}';
  }
}
