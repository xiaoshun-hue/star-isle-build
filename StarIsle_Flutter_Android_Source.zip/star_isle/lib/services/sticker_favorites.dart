import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// 表情收藏。只按 emoji 本身收藏，表情和表情包两个 Tab 共用。
class StickerFavoritesStore extends ChangeNotifier {
  StickerFavoritesStore._() {
    unawaited(_load());
  }

  static final StickerFavoritesStore instance = StickerFavoritesStore._();
  static const String _key = 'star_isle_sticker_favorites_v1';

  final Set<String> _emojis = <String>{};
  bool _loaded = false;

  bool get loaded => _loaded;
  int get count => _emojis.length;

  bool contains(String emoji) => _emojis.contains(emoji.trim());

  Future<void> _load() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final List<String>? saved = prefs.getStringList(_key);
      if (saved != null) {
        _emojis
          ..clear()
          ..addAll(saved.where((String item) => item.trim().isNotEmpty));
      }
    } catch (error) {
      debugPrint('load sticker favorites failed: $error');
    } finally {
      _loaded = true;
      notifyListeners();
    }
  }

  Future<void> toggle(String emoji) async {
    final String value = emoji.trim();
    if (value.isEmpty) return;
    if (!_emojis.add(value)) {
      _emojis.remove(value);
    }
    notifyListeners();
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_key, _emojis.toList(growable: false));
    } catch (error) {
      debugPrint('save sticker favorites failed: $error');
    }
  }

  Future<void> clear() async {
    if (_emojis.isEmpty) return;
    _emojis.clear();
    notifyListeners();
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.remove(_key);
    } catch (error) {
      debugPrint('clear sticker favorites failed: $error');
    }
  }
}
