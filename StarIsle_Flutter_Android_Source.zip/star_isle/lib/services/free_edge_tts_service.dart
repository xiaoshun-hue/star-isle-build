import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// Edge Read Aloud 的免密钥 WebSocket 客户端。
///
/// 这是一个非官方公开接口，随时可能变更或失效。调用方必须准备系统 TTS
/// 作为降级；本服务不记录、不上传用户文本到自己的服务器。
class FreeEdgeTtsService {
  FreeEdgeTtsService._();

  static final FreeEdgeTtsService instance = FreeEdgeTtsService._();

  static const String _trustedToken = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';
  static const String _userAgent =
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0';
  static const String _cacheFolder = 'edge_tts_cache';

  static const List<EdgeTtsVoice> voices = <EdgeTtsVoice>[
    EdgeTtsVoice('zh-CN-XiaoxiaoNeural', '晓晓', '温暖自然的女声'),
    EdgeTtsVoice('zh-CN-XiaoyiNeural', '晓伊', '清亮年轻的女声'),
    EdgeTtsVoice('zh-CN-YunyangNeural', '云扬', '沉稳可靠的男声'),
    EdgeTtsVoice('zh-CN-YunxiNeural', '云希', '轻松阳光的男声'),
    EdgeTtsVoice('zh-CN-YunjianNeural', '云健', '低沉有力量的男声'),
  ];

  final Map<String, Future<File?>> _inFlight = <String, Future<File?>>{};

  /// 合成本地 MP3。失败返回 null，由 TtsService 自动降级系统朗读。
  Future<File?> synthesize({
    required String text,
    String voice = 'zh-CN-XiaoxiaoNeural',
    double rate = 1.0,
    double pitch = 0.0,
  }) {
    final String clean = _normalizeText(text);
    if (clean.isEmpty) return Future<File?>.value();
    final String cacheKey = _cacheKey(clean, voice, rate, pitch);
    final Future<File?>? pending = _inFlight[cacheKey];
    if (pending != null) return pending;

    final Future<File?> task = _synthesizeInternal(
      text: clean,
      voice: voice,
      rate: rate,
      pitch: pitch,
      cacheKey: cacheKey,
    );
    _inFlight[cacheKey] = task;
    return task.whenComplete(() => _inFlight.remove(cacheKey));
  }

  Future<File?> _synthesizeInternal({
    required String text,
    required String voice,
    required double rate,
    required double pitch,
    required String cacheKey,
  }) async {
    final Directory directory = await _cacheDirectory();
    final File target = File(p.join(directory.path, '$cacheKey.mp3'));
    if (await target.exists() && await target.length() > 0) {
      return target;
    }

    WebSocket? socket;
    try {
      final String connectionId = _hexId(16);
      final Uri endpoint = Uri.parse(
        'wss://speech.platform.bing.com/consumer/speech/synthesize/'
        'readaloud/edge/v1',
      ).replace(
        queryParameters: <String, String>{
          'TrustedClientToken': _trustedToken,
          'ConnectionId': connectionId,
          'Sec-MS-GEC': _secMsGec(),
          'Sec-MS-GEC-Version': '1-130.0.2849.68',
        },
      );

      socket = await WebSocket.connect(
        endpoint.toString(),
        headers: <String, String>{
          'Origin':
              'chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold',
          'Pragma': 'no-cache',
          'Cache-Control': 'no-cache',
          'User-Agent': _userAgent,
          'Accept-Language': 'en-US,en;q=0.9',
          'Accept-Encoding': 'gzip, deflate, br',
        },
      ).timeout(const Duration(seconds: 10));

      final String timestamp = DateTime.now().toUtc().toIso8601String();
      final String config =
          'X-Timestamp:$timestamp\r\n'
          'Content-Type:application/json; charset=utf-8\r\n'
          'Path:speech.config\r\n\r\n'
          '{"context":{"synthesis":{"audio":{"metadataoptions":'
          '{"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"false"},'
          '"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}';
      socket.add(config);

      final String requestId = _hexId(16);
      final String ssml =
          '<speak version="1.0" '
          'xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="zh-CN">'
          '<voice name="${_escapeXml(voice)}">'
          '<prosody rate="${_signedPercent(rate)}" '
          'pitch="${_signedHz(pitch)}">${_escapeXml(text)}</prosody>'
          '</voice></speak>';
      socket.add(
        'X-RequestId:$requestId\r\n'
        'Content-Type:application/ssml+xml\r\n'
        'X-Timestamp:$timestamp\r\n'
        'Path:ssml\r\n\r\n'
        '$ssml',
      );

      final BytesBuilder audio = BytesBuilder(copy: false);
      final Completer<void> finished = Completer<void>();

      late final StreamSubscription<dynamic> subscription;
      subscription = socket.listen(
        (dynamic data) {
          if (data is String) {
            if (data.contains('Path:turn.end') && !finished.isCompleted) {
              finished.complete();
            }
            return;
          }
          if (data is List<int>) {
            final Uint8List bytes = data is Uint8List
                ? data
                : Uint8List.fromList(data);
            if (bytes.length < 2) return;
            final int headerLength = (bytes[0] << 8) | bytes[1];
            final int audioStart = 2 + headerLength;
            if (audioStart > bytes.length) return;
            final String header = utf8.decode(
              bytes.sublist(2, audioStart),
              allowMalformed: true,
            );
            if (header.contains('Path:audio')) {
              audio.add(bytes.sublist(audioStart));
            }
          }
        },
        onError: (Object error, StackTrace stack) {
          if (!finished.isCompleted) finished.completeError(error);
        },
        onDone: () {
          if (!finished.isCompleted) finished.complete();
        },
        cancelOnError: false,
      );

      try {
        await finished.future.timeout(const Duration(seconds: 10));
      } finally {
        await subscription.cancel();
      }

      final List<int> bytes = audio.takeBytes();
      if (bytes.isEmpty) return null;
      await target.writeAsBytes(bytes, flush: true);
      return target;
    } catch (error) {
      debugPrint('Edge TTS failed: $error');
      return null;
    } finally {
      try {
        await socket?.close();
      } catch (_) {
        // ignore
      }
    }
  }

  /// 语音气泡与系统 TTS 兜底共用的本地缓存目录。
  Future<Directory> cacheDirectory() => _cacheDirectory();

  Future<Directory> _cacheDirectory() async {
    final Directory base = await getTemporaryDirectory();
    final Directory directory = Directory(p.join(base.path, _cacheFolder));
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    return directory;
  }

  /// 清理旧语音缓存。返回删除的文件数量。
  Future<int> clearCache({Duration maxAge = const Duration(days: 7)}) async {
    try {
      final Directory directory = await _cacheDirectory();
      final DateTime now = DateTime.now();
      int removed = 0;
      final List<File> remaining = <File>[];
      final List<FileSystemEntity> entries = await directory.list().toList();
      for (final FileSystemEntity item in entries) {
        if (item is! File) continue;
        final FileStat stat = await item.stat();
        if (now.difference(stat.modified) > maxAge) {
          await item.delete();
          removed++;
        } else {
          remaining.add(item);
        }
      }
      // 即使都在 7 天内，也限制最多保留 120 个音频文件。
      if (remaining.length > 120) {
        remaining.sort((File a, File b) {
          try {
            return a.lastModifiedSync().compareTo(b.lastModifiedSync());
          } catch (_) {
            return 0;
          }
        });
        for (final File file in remaining.take(remaining.length - 120)) {
          try {
            await file.delete();
            removed++;
          } catch (_) {
            // ignore
          }
        }
      }
      return removed;
    } catch (error) {
      debugPrint('Edge TTS cache cleanup failed: $error');
      return 0;
    }
  }

  String _normalizeText(String input) {
    String text = input
        .replaceAll(RegExp(r'```[\s\S]*?```'), '')
        .replaceAll(RegExp(r'https?://\S+'), '')
        .replaceAll(RegExp(r'[*_#>`~]'), '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    final List<int> runes = text.runes.toList();
    if (runes.length > 1200) {
      text = String.fromCharCodes(runes.take(1200));
    }
    return text;
  }

  String _cacheKey(String text, String voice, double rate, double pitch) {
    final String raw = '$text|$voice|${rate.toStringAsFixed(2)}|'
        '${pitch.toStringAsFixed(1)}';
    return sha256.convert(utf8.encode(raw)).toString().substring(0, 28);
  }

  String _secMsGec() {
    const int windowsEpochSeconds = 11644473600;
    final int unixSeconds = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    final int ticks = (unixSeconds + windowsEpochSeconds) * 10000000;
    final int rounded = (ticks ~/ 3000000000) * 3000000000;
    return sha256
        .convert(utf8.encode('$rounded$_trustedToken'))
        .toString()
        .toUpperCase();
  }

  String _hexId(int bytes) {
    final Random random = Random.secure();
    final StringBuffer buffer = StringBuffer();
    for (int i = 0; i < bytes; i++) {
      buffer.write(random.nextInt(256).toRadixString(16).padLeft(2, '0'));
    }
    return buffer.toString();
  }

  String _signedPercent(double rate) {
    final int percent = ((rate - 1.0) * 100).round();
    return '${percent >= 0 ? '+' : ''}$percent%';
  }

  String _signedHz(double pitch) {
    final int hz = pitch.round();
    return '${hz >= 0 ? '+' : ''}${hz}Hz';
  }

  String _escapeXml(String value) => value
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&apos;');
}

class EdgeTtsVoice {
  const EdgeTtsVoice(this.id, this.name, this.description);

  final String id;
  final String name;
  final String description;

  static EdgeTtsVoice? byId(String id) {
    for (final EdgeTtsVoice voice in FreeEdgeTtsService.voices) {
      if (voice.id == id) return voice;
    }
    return null;
  }
}
