import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';

class TtsService extends ChangeNotifier {
  final FlutterTts _tts = FlutterTts();

  bool _initialized = false;
  bool _disposed = false;
  String? _speakingId;
  String? _lastError;

  bool get initialized => _initialized;
  bool get isSpeaking => _speakingId != null;
  String? get speakingId => _speakingId;
  String? get lastError => _lastError;

  Future<void> initialize() async {
    if (_initialized) return;
    try {
      await _tts.awaitSpeakCompletion(false);
      await _tts.setLanguage('zh-CN');
      await _tts.setSpeechRate(0.46);
      await _tts.setPitch(1.02);
      await _tts.setVolume(1.0);

      _tts.setStartHandler(() {
        if (_disposed) return;
        notifyListeners();
      });
      _tts.setCompletionHandler(() {
        if (_disposed) return;
        _speakingId = null;
        notifyListeners();
      });
      _tts.setCancelHandler(() {
        if (_disposed) return;
        _speakingId = null;
        notifyListeners();
      });
      _tts.setErrorHandler((dynamic message) {
        if (_disposed) return;
        _lastError = '语音暂时无法播放：$message';
        _speakingId = null;
        notifyListeners();
      });
      _initialized = true;
      _lastError = null;
    } catch (error) {
      debugPrint('TTS initialize failed: $error');
      _lastError = '当前设备没有可用的中文语音引擎';
      _initialized = false;
    }
    if (!_disposed) notifyListeners();
  }

  Future<bool> speak(String messageId, String text) async {
    final String clean = _cleanForSpeech(text);
    if (clean.isEmpty) return false;
    if (!_initialized) {
      await initialize();
    }
    if (!_initialized) return false;

    try {
      await _tts.stop();
      _speakingId = messageId;
      _lastError = null;
      if (!_disposed) notifyListeners();
      await _tts.speak(clean);
      return true;
    } catch (error) {
      debugPrint('TTS speak failed: $error');
      _speakingId = null;
      _lastError = '语音播放失败，请检查系统语音引擎';
      if (!_disposed) notifyListeners();
      return false;
    }
  }

  Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {
      // ignore
    }
    _speakingId = null;
    if (!_disposed) notifyListeners();
  }

  String _cleanForSpeech(String input) {
    String text = input
        .replaceAll(RegExp(r'```[\s\S]*?```'), '')
        .replaceAll(RegExp(r'https?://\S+'), '')
        .replaceAll(RegExp(r'[*_#>`~]'), '')
        .replaceAll(RegExp(r'\n+'), '，')
        .trim();
    text = text.replaceAll(
      RegExp(
        r'[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]',
        unicode: true,
      ),
      '',
    );
    final List<int> runes = text.runes.toList();
    if (runes.length > 700) {
      return String.fromCharCodes(runes.take(700));
    }
    return text;
  }

  @override
  void dispose() {
    _disposed = true;
    try {
      _tts.stop();
    } catch (_) {
      // ignore
    }
    super.dispose();
  }
}
