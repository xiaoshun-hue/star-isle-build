import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:path/path.dart' as p;

import 'free_edge_tts_service.dart';

class TtsService extends ChangeNotifier {
  TtsService() {
    _audioChannel.setMethodCallHandler(_handleAudioCall);
  }

  final FlutterTts _tts = FlutterTts();
  static const MethodChannel _audioChannel = MethodChannel(
    'com.starisle.companion/audio',
  );

  bool _initialized = false;
  bool _disposed = false;
  String? _speakingId;
  String? _lastError;
  String _engine = 'system';
  String _edgeVoice = 'zh-CN-XiaoxiaoNeural';
  double _edgeRate = 1.0;
  double _edgePitch = 0.0;

  bool get initialized => _initialized;
  bool get isSpeaking => _speakingId != null;
  String? get speakingId => _speakingId;
  String? get lastError => _lastError;
  String get engine => _engine;

  void configure({
    required String engine,
    required String edgeVoice,
    required double edgeRate,
    required double edgePitch,
  }) {
    _engine = engine == 'edge' ? 'edge' : 'system';
    if (FreeEdgeTtsService.voices.any((EdgeTtsVoice v) => v.id == edgeVoice)) {
      _edgeVoice = edgeVoice;
    }
    _edgeRate = edgeRate.clamp(0.7, 1.3).toDouble();
    _edgePitch = edgePitch.clamp(-12.0, 12.0).toDouble();
  }

  Future<void> initialize() async {
    if (_initialized) return;
    try {
      await _tts.awaitSpeakCompletion(false);
      await _tts.setLanguage('zh-CN');
      await _tts.setSpeechRate(0.46);
      await _tts.setPitch(1.02);
      await _tts.setVolume(1.0);

      _tts.setStartHandler(() {
        if (_disposed) return;
        notifyListeners();
      });
      _tts.setCompletionHandler(() {
        if (_disposed) return;
        _speakingId = null;
        notifyListeners();
      });
      _tts.setCancelHandler(() {
        if (_disposed) return;
        _speakingId = null;
        notifyListeners();
      });
      _tts.setErrorHandler((dynamic message) {
        if (_disposed) return;
        _lastError = '语音暂时无法播放：$message';
        _speakingId = null;
        notifyListeners();
      });
      _initialized = true;
      _lastError = null;
    } catch (error) {
      debugPrint('TTS initialize failed: $error');
      _lastError = '当前设备没有可用的中文语音引擎';
      _initialized = false;
    }
    if (!_disposed) notifyListeners();
  }

  Future<bool> speak(String messageId, String text) async {
    final String clean = _cleanForSpeech(text);
    if (clean.isEmpty) return false;
    if (!_initialized) {
      await initialize();
    }

    if (_engine == 'edge') {
      final File? audio = await FreeEdgeTtsService.instance.synthesize(
        text: clean,
        voice: _edgeVoice,
        rate: _edgeRate,
        pitch: _edgePitch,
      );
      if (audio != null) {
        final bool played = await playFile(
          messageId,
          audio.path,
          fallbackText: clean,
        );
        if (played) return true;
      }
      // Edge 接口失效、无网络或解码失败时自动降级系统朗读。
    }
    return _speakSystem(messageId, clean);
  }

  Future<bool> playFile(
    String messageId,
    String path, {
    String? fallbackText,
  }) async {
    if (path.trim().isEmpty || !File(path).existsSync()) {
      if (fallbackText != null && fallbackText.trim().isNotEmpty) {
        if (!_initialized) await initialize();
        return _speakSystem(messageId, _cleanForSpeech(fallbackText));
      }
      return false;
    }
    try {
      await _tts.stop();
      await _audioChannel.invokeMethod<void>('stop');
      final bool started =
          await _audioChannel.invokeMethod<bool>('playFile', <String, Object>{
            'path': path,
          }) ??
          false;
      if (started) {
        _speakingId = messageId;
        _lastError = null;
        if (!_disposed) notifyListeners();
        return true;
      }
    } catch (error) {
      debugPrint('cached voice playback failed: $error');
    }
    if (fallbackText != null && fallbackText.trim().isNotEmpty) {
      if (!_initialized) await initialize();
      return _speakSystem(messageId, _cleanForSpeech(fallbackText));
    }
    _speakingId = null;
    _lastError = '语音播放失败';
    if (!_disposed) notifyListeners();
    return false;
  }

  Future<bool> _speakSystem(String messageId, String text) async {
    if (!_initialized) {
      await initialize();
    }
    if (!_initialized) return false;
    try {
      await _audioChannel.invokeMethod<void>('stop');
      await _tts.stop();
      _speakingId = messageId;
      _lastError = null;
      if (!_disposed) notifyListeners();
      await _tts.speak(text);
      return true;
    } catch (error) {
      debugPrint('TTS speak failed: $error');
      _speakingId = null;
      _lastError = '语音播放失败，请检查系统语音引擎';
      if (!_disposed) notifyListeners();
      return false;
    }
  }

  Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {
      // ignore
    }
    try {
      await _audioChannel.invokeMethod<void>('stop');
    } catch (_) {
      // ignore
    }
    _speakingId = null;
    if (!_disposed) notifyListeners();
  }

  Future<dynamic> _handleAudioCall(MethodCall call) async {
    if (_disposed) return;
    if (call.method == 'onAudioComplete') {
      _speakingId = null;
      notifyListeners();
    } else if (call.method == 'onAudioError') {
      _speakingId = null;
      _lastError = '语音播放失败';
      notifyListeners();
    }
    return null;
  }

  /// 用系统离线 TTS 合成一个本地音频文件，供 Edge 失败时的语音气泡兜底。
  Future<File?> synthesizeSystemFile(String text) async {
    final String clean = _cleanForSpeech(text);
    if (clean.isEmpty) return null;
    try {
      final Directory directory =
          await FreeEdgeTtsService.instance.cacheDirectory();
      final File target = File(
        p.join(
          directory.path,
          'sys_${DateTime.now().microsecondsSinceEpoch}.wav',
        ),
      );
      final bool ok = await _audioChannel.invokeMethod<bool>(
            'synthesizeToFile',
            <String, Object>{'text': clean, 'path': target.path},
          ) ??
          false;
      if (ok && await target.exists() && await target.length() > 0) {
        return target;
      }
    } catch (error) {
      debugPrint('system TTS file synthesis failed: $error');
    }
    return null;
  }

  String _cleanForSpeech(String input) {
    String text = input
        .replaceAll(RegExp(r'```[\s\S]*?```'), '')
        .replaceAll(RegExp(r'https?://\S+'), '')
        .replaceAll(RegExp(r'[*_#>`~]'), '')
        .replaceAll(RegExp(r'\n+'), '，')
        .trim();
    text = text.replaceAll(
      RegExp(
        r'[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]',
        unicode: true,
      ),
      '',
    );
    final List<int> runes = text.runes.toList();
    if (runes.length > 700) {
      return String.fromCharCodes(runes.take(700));
    }
    return text;
  }

  @override
  void dispose() {
    _disposed = true;
    try {
      _tts.stop();
    } catch (_) {
      // ignore
    }
    try {
      _audioChannel.invokeMethod<void>('stop');
    } catch (_) {
      // ignore
    }
    super.dispose();
  }
}
