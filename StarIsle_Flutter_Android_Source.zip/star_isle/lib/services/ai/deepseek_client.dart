import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import 'ai_types.dart';

class DeepSeekConfig {
  const DeepSeekConfig({
    required this.apiKey,
    required this.baseUrl,
    required this.model,
  });

  final String apiKey;
  final String baseUrl;
  final String model;
}

class DeepSeekClient {
  const DeepSeekClient();

  Future<String> complete({
    required DeepSeekConfig config,
    required List<Map<String, String>> messages,
    double temperature = 1.05,
    int maxTokens = 700,
  }) async {
    final String key = config.apiKey.trim();
    if (key.isEmpty) {
      throw AiException('还没有填写 DeepSeek API Key');
    }
    final Uri endpoint = _endpoint(config.baseUrl);
    final Map<String, Object?> payload = <String, Object?>{
      'model': config.model.trim().isEmpty
          ? 'deepseek-chat'
          : config.model.trim(),
      'messages': messages,
      'temperature': temperature,
      'max_tokens': maxTokens,
      'stream': false,
    };

    final http.Client client = http.Client();
    http.Response response;
    try {
      response = await client
          .post(
            endpoint,
            headers: <String, String>{
              'Content-Type': 'application/json; charset=utf-8',
              'Accept': 'application/json',
              'Authorization': 'Bearer $key',
              'User-Agent': 'StarIsle/1.0 (Flutter Android)',
            },
            body: jsonEncode(payload),
          )
          .timeout(const Duration(seconds: 45));
    } on TimeoutException {
      throw AiException('网络超时了，DeepSeek 没有及时回应');
    } on SocketException {
      throw AiException('网络似乎断开了，请检查手机网络');
    } on HandshakeException {
      throw AiException('无法建立安全连接，请检查网络或代理');
    } on http.ClientException catch (error) {
      throw AiException('网络请求失败：${error.message}');
    } catch (error) {
      throw AiException('网络请求失败：$error');
    } finally {
      client.close();
    }

    final String body = utf8.decode(response.bodyBytes, allowMalformed: true);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final String detail = _errorDetail(body);
      final String message = switch (response.statusCode) {
        401 => 'API Key 无效或已过期',
        402 => 'DeepSeek 账户余额不足',
        403 => '当前 API Key 没有访问权限',
        404 => '接口地址不存在，请检查 Base URL',
        429 => '请求太频繁，稍后再试',
        >= 500 => 'DeepSeek 服务暂时不可用',
        _ => '请求失败（${response.statusCode}）',
      };
      throw AiException(detail.isEmpty ? message : '$message · $detail');
    }

    try {
      final Object? decoded = jsonDecode(body);
      if (decoded is! Map) throw const FormatException('bad response');
      final Object? choices = decoded['choices'];
      if (choices is! List || choices.isEmpty) {
        throw const FormatException('no choices');
      }
      final Object? first = choices.first;
      if (first is! Map) throw const FormatException('bad choice');
      final Object? message = first['message'];
      if (message is! Map) throw const FormatException('bad message');
      final Object? content = message['content'];
      if (content is! String || content.trim().isEmpty) {
        throw const FormatException('empty content');
      }
      return content.trim();
    } catch (_) {
      throw AiException('DeepSeek 返回了无法识别的内容');
    }
  }

  Future<String> testConnection(DeepSeekConfig config) async {
    final String answer = await complete(
      config: config,
      messages: const <Map<String, String>>[
        <String, String>{'role': 'user', 'content': '这是连接测试。请只回复四个字：连接成功。'},
      ],
      temperature: 0.1,
      maxTokens: 16,
    );
    return answer.replaceAll(RegExp(r'\s+'), '').contains('连接成功')
        ? '连接成功'
        : '服务已响应：${answer.length > 28 ? '${answer.substring(0, 28)}…' : answer}';
  }

  Uri _endpoint(String baseUrl) {
    String base = baseUrl.trim();
    if (base.isEmpty) base = 'https://api.deepseek.com';
    if (!base.startsWith('http://') && !base.startsWith('https://')) {
      base = 'https://$base';
    }
    base = base.replaceFirst(RegExp(r'/+$'), '');
    final String endpoint = base.endsWith('/chat/completions')
        ? base
        : '$base/chat/completions';
    final Uri? uri = Uri.tryParse(endpoint);
    if (uri == null || !uri.hasScheme || uri.host.isEmpty) {
      throw AiException('Base URL 格式不正确');
    }
    if (uri.scheme != 'https' && uri.scheme != 'http') {
      throw AiException('Base URL 必须使用 http 或 https');
    }
    return uri;
  }

  String _errorDetail(String body) {
    try {
      final Object? decoded = jsonDecode(body);
      if (decoded is Map) {
        final Object? error = decoded['error'];
        if (error is Map && error['message'] is String) {
          final String msg = error['message'] as String;
          return msg.length > 90 ? '${msg.substring(0, 90)}…' : msg;
        }
        if (decoded['message'] is String) {
          final String msg = decoded['message'] as String;
          return msg.length > 90 ? '${msg.substring(0, 90)}…' : msg;
        }
      }
    } catch (_) {
      // ignore
    }
    return '';
  }
}
