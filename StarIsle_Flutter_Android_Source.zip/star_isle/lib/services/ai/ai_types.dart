import '../../data/models/chat_message.dart';
import '../../data/models/companion_profile.dart';
import '../../data/models/memory_entry.dart';

enum AiSource { online, offline }

class ChatAiContext {
  const ChatAiContext({
    required this.userMessage,
    required this.profile,
    required this.userName,
    required this.recentMessages,
    required this.memories,
    this.imageAttached = false,
  });

  final String userMessage;
  final CompanionProfile profile;
  final String userName;
  final List<ChatMessage> recentMessages;
  final List<MemoryEntry> memories;
  final bool imageAttached;
}

class ProfileSuggestion {
  const ProfileSuggestion({this.nickname, this.signature});

  final String? nickname;
  final String? signature;

  bool get isEmpty =>
      (nickname == null || nickname!.trim().isEmpty) &&
      (signature == null || signature!.trim().isEmpty);
}

class AnniversarySuggestion {
  const AnniversarySuggestion({
    required this.title,
    required this.date,
    this.note = '',
    this.repeatYearly = true,
  });

  final String title;
  final DateTime date;
  final String note;
  final bool repeatYearly;
}

class ProfileEvolution {
  const ProfileEvolution({
    required this.avatarSeed,
    required this.signature,
    required this.mood,
    this.nickname,
  });

  final int avatarSeed;
  final String signature;
  final String mood;
  final String? nickname;

  bool get nicknameChanged => nickname != null && nickname!.trim().isNotEmpty;
}

class AiTurnResult {
  const AiTurnResult({
    required this.bubbles,
    required this.mood,
    required this.source,
    this.affectionDelta = 1,
    this.memory,
    this.memoryCategory = 'memory',
    this.memoryImportance = 1,
    this.profile,
    this.anniversary,
    this.sendArt = false,
    this.fallbackNotice,
  });

  final List<String> bubbles;
  final String mood;
  final int affectionDelta;
  final String? memory;
  final String memoryCategory;
  final int memoryImportance;
  final ProfileSuggestion? profile;
  final AnniversarySuggestion? anniversary;
  final bool sendArt;
  final AiSource source;
  final String? fallbackNotice;

  String get combinedText => bubbles.join('\n');

  AiTurnResult copyWith({
    List<String>? bubbles,
    String? mood,
    int? affectionDelta,
    String? memory,
    String? memoryCategory,
    int? memoryImportance,
    ProfileSuggestion? profile,
    AnniversarySuggestion? anniversary,
    bool? sendArt,
    AiSource? source,
    String? fallbackNotice,
  }) {
    return AiTurnResult(
      bubbles: bubbles ?? this.bubbles,
      mood: mood ?? this.mood,
      source: source ?? this.source,
      affectionDelta: affectionDelta ?? this.affectionDelta,
      memory: memory ?? this.memory,
      memoryCategory: memoryCategory ?? this.memoryCategory,
      memoryImportance: memoryImportance ?? this.memoryImportance,
      profile: profile ?? this.profile,
      anniversary: anniversary ?? this.anniversary,
      sendArt: sendArt ?? this.sendArt,
      fallbackNotice: fallbackNotice ?? this.fallbackNotice,
    );
  }
}

class MomentDraft {
  const MomentDraft({
    required this.text,
    required this.mood,
    required this.palette,
    required this.source,
  });

  final String text;
  final String mood;
  final int palette;
  final AiSource source;
}

class AiException implements Exception {
  AiException(this.message);

  final String message;

  @override
  String toString() => message;
}
