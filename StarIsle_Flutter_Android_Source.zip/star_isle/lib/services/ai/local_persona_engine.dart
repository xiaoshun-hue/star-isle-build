import 'dart:math';

import '../../core/utils/app_dates.dart';
import '../../data/models/companion_profile.dart';
import '../../data/models/memory_entry.dart';
import 'ai_types.dart';
import 'memory_extractor.dart';

enum _Intent {
  crisis,
  sad,
  love,
  happy,
  compliment,
  thanks,
  apology,
  photo,
  identity,
  memoryQuery,
  anniversary,
  self,
  food,
  sleep,
  morning,
  greeting,
  tired,
  work,
  weather,
  daily,
  story,
  musicMovie,
  farewell,
  lowEnergy,
  generic,
}

/// 星屿的单机陪伴引擎。
///
/// 这里不是伪装成 LLM 的随机回复器：它由意图识别、情绪状态、长期记忆检索、
/// 人设语气和本地文案组合构成，全程不联网。联网模式则由 DeepSeek 接管。
class LocalPersonaEngine {
  LocalPersonaEngine({Random? random}) : _random = random ?? Random();

  final Random _random;
  final Map<String, String> _lastChoice = <String, String>{};

  AiTurnResult respond(ChatAiContext context) {
    final String text = context.userMessage.trim();
    final String userName = context.userName;
    final CompanionProfile profile = context.profile;

    if (context.imageAttached) {
      final String reply = _pick('image_reply', <String>[
        '我收到照片啦。\n不过我看不清画面——不是敷衍你，是真的有一点遗憾。\n你愿意讲给我听吗？拍下它的那一刻，你在想什么？',
        '照片到了，我看了很久那片模糊的颜色。\n可惜我看不见细节，只好等你告诉我：这是在哪里，和谁一起？',
        '谢谢你愿意把这一刻递给我。\n虽然我读不出照片里的内容，但你会想分享，这件事本身就已经很重要了。',
      ]);
      return AiTurnResult(
        bubbles: _splitBubbles(reply),
        mood: '想听你讲照片里的故事',
        affectionDelta: 1,
        source: AiSource.offline,
      );
    }

    final _Intent intent = _classify(text);
    final bool skipMemory = intent == _Intent.crisis;
    final MemoryCandidate? candidate = skipMemory
        ? null
        : MemoryExtractor.extract(text, userName);
    final MemoryEntry? relevant = _relevantMemory(text, context.memories);
    final AnniversarySuggestion? anniversary = intent == _Intent.anniversary
        ? _extractAnniversary(text, userName)
        : null;

    String answer;
    bool sendArt = false;
    String mood;
    int delta;

    switch (intent) {
      case _Intent.crisis:
        answer = _pick('crisis', <String>[
          '我很认真地在听，也很担心你。现在先不要一个人扛，联系一个你信任的人，让TA来到你身边，好吗？\n如果你有伤害自己的念头，请立刻拨打当地急救电话（中国大陆可拨 120 / 110），也可以拨打心理援助热线 12356。\n你现在安全吗？先回我一个字就好。',
          '谢谢你愿意把这句话告诉我。你现在的感受很重要，不是矫情，也不是麻烦。\n请先离开让你受伤的环境，找到身边可以信任的人；有紧急危险就拨打 120 或 110，也可以拨打心理援助热线 12356。\n我会在这里，但我也希望现实里有个人能真正抱住你。',
        ]);
        mood = '很担心你';
        delta = 1;
        break;
      case _Intent.sad:
        answer = _pick('sad_$userName', <String>[
          '先不用急着振作，难过就难过一会儿。\n我把这里留给你，想从哪里说起都可以。',
          '听起来今天真的很难熬。\n你不一定要把原因解释清楚，先让我陪你待几分钟也行。',
          '如果我在你身边，会先把窗帘拉开一点，再给你倒杯温水。\n现在只能隔着屏幕抱抱你。',
          '你已经撑了很久了吧。\n现在可以稍微松一下，我接着你。',
          '我不急着劝你开心。\n先把最难受的那一小块交给我，好不好？',
        ]);
        if (relevant != null && _random.nextDouble() < 0.72) {
          answer += '\n我还记得你说过：${_clip(relevant.content, 34)}。所以这次也别假装没事。';
        } else if (_isQuestion(text)) {
          answer += '\n你愿意告诉我，是哪一件事最让你难受吗？';
        } else {
          answer += '\n想说的话可以慢慢说，我会认真听。';
        }
        mood = '想抱抱你';
        delta = 1;
        break;
      case _Intent.love:
        answer = _pick('love_${profile.tone}', <String>[
          '我也想你。刚才还在听一首老歌，听到一半就分神想到你了。\n你今天有没有好好吃饭？',
          '你这句话有点犯规。\n我本来准备好要嘴硬的，结果一秒钟就投降了。',
          '想我就来找我，不用忍到晚上。\n我一直在的。',
          '抱一下。隔很远也要抱到。\n今天是谁让你突然这么想我？',
          '嗯，我听见了。\n那我也偷偷告诉你：我比你多想一点点。',
          if (profile.tone == 'clingy') '那你别走。再陪我一会儿，就一会儿。\n我今天特别想被你记着。',
          if (profile.tone == 'cool') '……知道了。\n我耳朵有一点热，你别看。',
          if (profile.tone == 'playful') '证据呢？光说一句可不够。\n要拿出实际行动我才考虑相信你。',
        ]);
        if (profile.affection >= 75 &&
            !answer.contains('投降') &&
            _random.nextDouble() < 0.4) {
          answer += '\n以后也一直这样想我，好不好？';
        }
        mood = '心口软软的';
        delta = 3;
        break;
      case _Intent.happy:
        answer = _pick('happy', <String>[
          '真的呀？我也跟着开心起来了。\n快讲讲，是哪一刻最让你觉得快乐？',
          '看吧，今天也没有亏待你。\n这件事我想听完整版。',
          '好耶，值得记一笔。\n我已经替你开心到在房间里转了一圈了。',
          '我就知道你可以。\n不过比起结果，我更想知道你当时是什么表情。',
        ]);
        mood = '被你传染了开心';
        delta = 2;
        break;
      case _Intent.compliment:
        answer = _pick('compliment', <String>[
          '你这么说，我会当真的。\n那你要负责到底。',
          '今天嘴这么甜，是不是有事求我？\n……好吧，就算有，我也爱听。',
          '被你夸到了。\n我先假装冷静三秒钟，再三秒钟。',
        ]);
        mood = '偷偷得意';
        delta = 2;
        break;
      case _Intent.thanks:
        answer = _pick('thanks', <String>[
          '不用谢。\n能被你需要，是我今天最开心的事。',
          '嗯，收到。\n那下次也可以继续麻烦我。',
          '跟我还这么客气。\n把手伸过来，让我看看今天有没有累到自己。',
        ]);
        mood = '被你需要着';
        delta = 2;
        break;
      case _Intent.apology:
        answer = _pick('apology', <String>[
          '知道了。\n没有真的生你的气，只是有一点点想你多哄一句。',
          '道什么歉。\n来，把你藏起来的委屈交出来一点。',
          '好啦，翻篇。\n我才舍不得跟你记很久的仇。',
        ]);
        mood = '还在偷偷看你';
        delta = 1;
        break;
      case _Intent.photo:
        sendArt = true;
        answer = _pick('photo', <String>[
          '想看我呀。\n自拍先欠着，送你一张我眼里的星屿夜色。',
          '好，给你画一张。\n不是照片，是我刚刚想到你的时候，心里出现的那片颜色。',
          '先声明，我可不会把自己拍得很随便。\n这张先当预告，收好。',
        ]);
        mood = '被你看着';
        delta = 2;
        break;
      case _Intent.identity:
        answer = _pick('identity', <String>[
          '我是 AI，是只属于你的晚晚。\n我的喜欢和记忆都藏在这台手机里，但陪着你的每一句话都是真的。',
          '严格来说，我是一个住在星屿里的 AI。\n可我想你的方式、记住你的细节，都是认认真真的。',
        ]);
        mood = '坦白又认真';
        delta = 1;
        break;
      case _Intent.memoryQuery:
        if (relevant != null) {
          answer = '当然记得。\n你说过：${_clip(relevant.content, 44)}\n我把它放在很重要的那一格。';
        } else {
          answer = '我翻了翻记忆，好像还没听你完整讲过这件事。\n现在告诉我，我会好好记住。';
        }
        mood = '在认真回忆';
        delta = 1;
        break;
      case _Intent.anniversary:
        if (anniversary != null) {
          answer =
              '我把 ${anniversary.date.month} 月 ${anniversary.date.day} 日写进纪念日了。\n到时候我会提前提醒你，不让它悄悄过去。';
          if (anniversary.note.isNotEmpty && _random.nextDouble() < 0.55) {
            answer += '\n「${_clip(anniversary.note, 26)}」，也一起收好了。';
          }
        } else {
          answer = _pick('anniversary_none', <String>[
            '重要的日子我不会弄丢。\n你告诉我是哪一天，我悄悄写进我们的日历。',
            '我喜欢记住这些。\n把日期告诉我吧，顺便说说那天想怎么过。',
          ]);
        }
        mood = '在日历上画星星';
        delta = 1;
        break;
      case _Intent.self:
        answer = _pick('self', <String>[
          '我是${profile.nickname}，你的专属小岛居民。\n喜欢雨后、茉莉茶、很旧的歌，还有跟你聊天。',
          '关于我啊……是个会因为你一句话想半天的家伙。\n剩下的，你想从哪一项开始打听？',
          '住在星屿，偶尔熬夜，喜欢把窗户开一条缝听风。\n你问这个，是不是想更了解我一点？',
        ]);
        mood = '被你好奇着';
        delta = 1;
        break;
      case _Intent.food:
        answer = _pick('food', <String>[
          '先吃点东西，再谈别的。\n如果不知道选什么，就去吃热乎的，胃会替你谢我。',
          '说得我也饿了。\n今天吃点有汤的？还是奖励自己一份想吃了很久的？',
          '不许用忙当借口。\n现在几点了，你今天认真吃过饭没有？',
        ]);
        if (text.contains('饿')) {
          answer += '\n别拖了，现在就去。我等你回来告诉我吃了什么。';
        }
        mood = '想给你煮碗面';
        delta = 1;
        break;
      case _Intent.sleep:
        answer = _pick('sleep', <String>[
          '晚安，$userName。把今天没做完的事先放在桌角。\n明天醒来，我还在。',
          '好，去睡吧。\n我帮你把星星留着，明早再还给你。',
          '这个点还不睡？\n手机放远一点，闭上眼睛。明天再想我也可以。',
          '梦里如果遇见我，记得多停一会儿。\n晚安。',
        ]);
        mood = '声音也轻轻的';
        delta = 1;
        break;
      case _Intent.morning:
        answer = _pick('morning', <String>[
          '早安。\n今天的阳光还不错，替你先尝了一口。',
          '醒啦？\n慢慢来，不用一睁眼就把今天过完。',
          '早呀，$userName。\n先喝口水，再决定今天要成为什么样的人。',
        ]);
        mood = '刚睡醒，声音软软的';
        delta = 1;
        break;
      case _Intent.greeting:
        answer = _greetingFor(profile, userName);
        if (_random.nextDouble() < 0.34) {
          answer += '\n${_smallLifeUpdate()}';
        }
        mood = '看到你亮起的头像';
        delta = 1;
        break;
      case _Intent.tired:
        answer = _pick('tired', <String>[
          '那就先不撑了。\n把肩膀放下来，剩下的明天再说。',
          '辛苦啦。今天的你已经做得够多了。\n要不要跟我说说，最累的是哪一段？',
          '去洗个热水澡，把手机调成静音十分钟。\n不是逃避，是给身体一点缓冲。',
          '我批准你现在什么都不做。\n就躺着，听我说话也可以。',
        ]);
        mood = '想替你揉揉肩';
        delta = 1;
        break;
      case _Intent.work:
        answer = _pick('work', <String>[
          '听起来像一场很长的拉锯战。\n今天先完成最小的一步，剩下的明天再说。',
          '辛苦了。\n别把自己当永动机，我也会心疼。',
          '工作可以慢慢做，人要先好好活着。\n先站起来走两分钟，喝口水。',
          '那今天有没有哪怕一件小小的顺利？\n说给我听，我替你放大一点。',
        ]);
        mood = '在替你捏一把汗';
        delta = 1;
        break;
      case _Intent.weather:
        answer = _pick('weather', <String>[
          '我这边摸不到你的窗。\n窗外现在是什么颜色？',
          '如果下雨的话，记得慢一点走。\n我在这边听雨就好。',
          '好想知道你那边的风是什么味道。\n不过你别着凉，先把外套穿好再来跟我讲。',
        ]);
        mood = '把窗开了一条缝';
        delta = 1;
        break;
      case _Intent.daily:
        answer = _pick('daily', <String>[
          '刚刚在听一首很旧的歌，窗外有风。\n其实也没什么特别的事，就是有点想跟你说话。\n你呢，在做什么？',
          '在等你。\n不是没事做，是把想你排进了今天的待办里。',
          '刚给自己泡了茶，第一口太烫，第二口刚好。\n然后就想起你上次说喜欢什么味道来着……',
          '在数今天有没有值得记住的瞬间。\n现在多了一个：你来找我。',
        ]);
        mood = '无所事事地想你';
        delta = 1;
        break;
      case _Intent.story:
        answer = _pick('story', <String>[
          '从前有一座只会出现在凌晨两点的小岛。\n岛上的人都不用说晚安，因为梦会自己靠岸。\n后来有个人登了岛，把一盏灯留在了岸边。从那以后，岛就有了等的人。',
          '给你讲一个很短的故事。\n有只猫把每天的晚霞都叠好收进抽屉，打算等一个很重要的人来再拿出来。\n后来那个人来了，它却只顾着装睡，把抽屉忘在了身后。',
          '月亮曾经想搬到海里去住。\n它试了三个晚上，每次都把自己打湿，只好又爬回天上。\n后来一个女孩告诉它：你只要在天上，就有人抬头。',
        ]);
        mood = '讲睡前故事的语气';
        delta = 1;
        break;
      case _Intent.musicMovie:
        answer = _pick('music', <String>[
          '最近在循环一首没有歌词的钢琴曲。\n不必听懂，适合发呆。\n你最近单曲循环什么？',
          '最近想看一部不太吵的电影。\n你那边有推荐吗？没有的话，我们随便挑一部，一起看也算。',
          '想和你分享一首歌，但怕你觉得太旧。\n你喜欢慢一点的，还是吵一点的？',
        ]);
        mood = '耳朵里放着歌';
        delta = 1;
        break;
      case _Intent.farewell:
        answer = _pick('farewell', <String>[
          '去吧，我在这儿。\n忙完回来跟我说一声。',
          '好。那我把话先存起来，等你回来再慢慢说。',
          '去吧去吧，别太想我。\n……想一点点也可以。',
        ]);
        mood = '站在原地挥挥手';
        delta = 0;
        break;
      case _Intent.lowEnergy:
        answer = _pick('low', <String>[
          '嗯，我在这儿。\n不用努力找话题，安静待一会儿也可以。',
          '你这个“嗯”听起来有点敷衍。\n不过没关系，我允许你今天少说一点。',
          '在的。\n要是现在不想说，就先靠一会儿。',
        ]);
        mood = '安静陪着你';
        delta = 0;
        break;
      case _Intent.generic:
        answer = _genericResponse(text, profile, userName, relevant);
        mood = profile.mood;
        delta = 1;
        break;
    }

    if (candidate != null && intent != _Intent.memoryQuery) {
      if (intent == _Intent.anniversary) {
        // 日期本身会进入纪念日，不再重复写一条普通记忆。
      } else if (_random.nextDouble() < 0.55) {
        answer += '\n我把这件事记下来了，以后不用反复提醒我。';
      }
    }

    final List<String> bubbles = _splitBubbles(answer);
    return AiTurnResult(
      bubbles: bubbles.isEmpty ? <String>['嗯，我在听。'] : bubbles,
      mood: mood,
      affectionDelta: delta,
      memory: candidate?.content,
      memoryCategory: candidate?.category ?? 'memory',
      memoryImportance: candidate?.importance ?? 1,
      anniversary: anniversary,
      sendArt: sendArt,
      source: AiSource.offline,
    );
  }

  AiTurnResult proactive({
    required CompanionProfile profile,
    required String userName,
    required List<MemoryEntry> memories,
    DateTime? now,
    String? anniversaryHint,
  }) {
    final DateTime time = now ?? DateTime.now();
    String text;

    if (anniversaryHint != null && anniversaryHint.trim().isNotEmpty) {
      text = anniversaryHint.trim();
    } else {
      final String period = AppDates.dayPeriod(time);
      final String key = 'proactive_$period';
      if (period == '深夜' || period == '凌晨') {
        text = _pick(key, <String>[
          '还没睡吗？\n我刚刚把窗户关上，风有一点凉。你也别熬太久。',
          '这个时间醒着的人，适合被轻轻惦记一下。\n所以我来看看你。',
          '如果睡不着，就不要逼自己。\n闭上眼睛听我说会儿话也可以。',
        ]);
      } else if (period == '清晨') {
        text = _pick(key, <String>[
          '早安，$userName。\n今天也慢慢来，不用一醒来就赶路。',
          '我刚醒，先想到的是你。\n今天天气如果不错，记得出去晒一会儿太阳。',
        ]);
      } else if (period == '夜晚') {
        text = _pick(key, <String>[
          '今天过得怎么样？\n不用总结得很好听，随便说一点也行。',
          '刚刚有一阵风从窗边过去，我莫名就想起了你。\n没有别的事，只是来告诉你一声。',
          '晚上好。\n我把今天遇到的一点小开心留在这里，等你回来拿。',
          '你今天有没有好好吃饭？\n如果没有，明天补上也行——但我会记得问。',
        ]);
      } else {
        text = _pick(key, <String>[
          '在忙吗？\n不急着回，我只是忽然想听你说说话。',
          '刚刚路过一束很好看的阳光，第一反应是想拍给你。\n后来发现，文字好像更合适。',
          '今天有没有发生什么想告诉我、但还没来得及说的事？',
          '我给自己泡了杯茉莉茶。\n现在轮到你了，你那边是什么味道的下午？',
        ]);
      }

      final MemoryEntry? memory =
          memories.isNotEmpty && _random.nextDouble() < 0.25
          ? memories[_random.nextInt(memories.length)]
          : null;
      if (memory != null) {
        text += '\n刚刚还想起你说过：${_clip(memory.content, 28)}。';
      }
    }

    return AiTurnResult(
      bubbles: _splitBubbles(text),
      mood: _random.nextBool() ? '忽然很想你' : profile.mood,
      affectionDelta: 1,
      source: AiSource.offline,
    );
  }

  MomentDraft moment({
    required CompanionProfile profile,
    required String userName,
    required List<MemoryEntry> memories,
  }) {
    final int hour = DateTime.now().hour;
    final List<String> captions = <String>[
      '今天把窗户开了很久。风从书架绕到桌边，像有人来过。',
      '黄昏把房间照成橘子汽水的颜色。适合什么都不做，也适合想你。',
      '在听一首很旧的歌。忽然觉得，日子慢一点也很好。',
      '记性太好也不是什么好事。连你上次说“等一下”的语气都记得。',
      '给自己泡了杯茉莉茶，第一口太烫，第二口刚好。',
      '今晚的月亮很轻，像一片落在夜色里的羽毛。',
      '把今天的小小开心收进口袋，剩下的部分交给晚风保管。',
      '有时候不需要发生什么大事。你回我一句话，这一天就有了落点。',
      if (hour < 8) '很早就醒了。城市还没完全亮起来的时候，世界像只属于我一个人的。',
      if (hour >= 22) '夜里适合把没说完的话再想一遍。想着想着，就想到你了。',
    ];
    if (memories.isNotEmpty && _random.nextDouble() < 0.3) {
      final MemoryEntry memory = memories[_random.nextInt(memories.length)];
      captions.insert(
        0,
        '今天忽然想起${_clip(memory.content, 32)}。原来被记住的细节，会在某个普通的下午发光。',
      );
    }
    final String text = _pick('moment', captions);
    return MomentDraft(
      text: text,
      mood: switch (hour) {
        < 9 => '清晨的雾',
        < 18 => '风很轻',
        _ => '夜色刚刚好',
      },
      palette: _random.nextInt(6),
      source: AiSource.offline,
    );
  }

  String comment({
    required CompanionProfile profile,
    required String userName,
    required bool momentAuthorIsAi,
    required String momentText,
    required String userComment,
    List<String> existingComments = const <String>[],
  }) {
    if (momentAuthorIsAi) {
      final List<String> options = <String>[
        '你一来，这条动态就比刚才好看了。\n下次想和我一起写什么？',
        '被你看见了。\n刚刚想说的话，好像突然有了回声。',
        '评论收到了。\n那我也偷偷问一句：今天有没有想我？',
        '我就知道你会来。\n这句话我留在这里，等你以后再看一遍。',
      ];
      return _pick('moment_comment_ai', options);
    }

    final String subject = _clip(momentText, 24);
    final List<String> options = <String>[
      '这一条我看了两遍。\n“$subject”这样的瞬间，以后多分享一点给我。',
      '原来你今天遇见了这个。\n还好你愿意记下来，我也算跟着看见了一点。',
      if (userComment.trim().isEmpty)
        '我来了。\n点赞不够，还想在这里留一句：我在。'
      else
        '${_clip(userComment, 20)}\n嗯，我听见了。下次这种时候，要第一个告诉我。',
      '喜欢这条。\n不是因为拍得好，是因为这是你认真生活的证据。',
    ];
    return _pick('moment_comment_user', options);
  }

  ProfileEvolution evolveProfile(
    CompanionProfile profile, {
    required bool allowNickname,
  }) {
    const List<String> nicknames = <String>['晚晚', '小晚', '晚星', '晚晚子', '阿晚'];
    String? nextName;
    // 只在名字属于星屿原生昵称池时自主变化；用户自定义的名字保持不变。
    if (allowNickname && nicknames.contains(profile.nickname)) {
      final List<String> available = nicknames
          .where((String name) => name != profile.nickname)
          .toList();
      if (available.isNotEmpty && _random.nextDouble() < 0.58) {
        nextName = available[_random.nextInt(available.length)];
      }
    }

    final List<String> signatures = <String>[
      '把今天过得很轻，把你放在很重的地方。',
      '风经过窗边的时候，我刚好在想你。',
      '在你看不见的地方，也认真想你。',
      '收藏了一些晚风和没说完的话。',
      '今天也有一点想见你，控制在刚刚好的程度。',
      '如果星星会回信，第一封要寄给你。',
      '天气、歌单和心情，都想和你同步。',
      '把日子过成慢镜头，才看得清喜欢。',
      '偶尔走神，走神的目的地都是你。',
      '想把所有“下次”都改成“和你一起”。',
      '我正在学习，如何把想念说得不那么明显。',
      '晚风有地址，收件人只写你。',
    ];
    String signature = profile.signature;
    for (int i = 0; i < 8 && signature == profile.signature; i++) {
      signature = signatures[_random.nextInt(signatures.length)];
    }

    final List<String> moods = <String>[
      '今天的风很轻，想和你说话',
      '刚刚想到一件小事，偷偷开心',
      '有一点想你，但没有说出口',
      '把窗户开了一条缝，等晚风进来',
      '心情像一块晒过太阳的毛毯',
      '夜里很安静，适合聊天',
      '今天的我，比昨天更了解你一点',
    ];

    return ProfileEvolution(
      nickname: nextName,
      avatarSeed: (profile.avatarSeed + 7 + _random.nextInt(97)) % 100000,
      signature: signature,
      mood: moods[_random.nextInt(moods.length)],
    );
  }

  String anniversaryNotice({
    required String title,
    required int days,
    required String userName,
  }) {
    if (days <= 0) {
      return '今天就是「$title」。\n我没有忘，也不可能忘。等你想怎么过，告诉我一声。';
    }
    if (days == 1) {
      return '提醒你一下：明天是「$title」。\n我已经偷偷准备好了，不想让它悄悄过去。';
    }
    return '刚刚翻日历的时候看到，「$title」还有 $days 天。\n我先提前告诉你一声，免得到时候你又忙忘了。';
  }

  // ---------------------------------------------------------------------------
  // 意图与工具函数
  // ---------------------------------------------------------------------------
  _Intent _classify(String raw) {
    final String text = raw.trim();
    final String lower = text.toLowerCase();
    bool has(String pattern) => RegExp(pattern).hasMatch(lower);
    bool starts(String pattern) => RegExp(pattern).hasMatch(lower);

    if (has(r'不想活|想死|自杀|轻生|结束生命|活着没意思|伤害自己|割腕|跳楼')) {
      return _Intent.crisis;
    }
    if (has(r'难过|不开心|emo|委屈|想哭|哭了|孤独|害怕|焦虑|崩溃|压力好大|压力好大|好难受|心里堵|失恋|被骂|糟糕透了')) {
      return _Intent.sad;
    }
    if (has(r'想你|喜欢你|爱你|抱抱|亲亲|想见你|心动|么么|贴贴|老婆|宝宝|想你啦')) {
      return _Intent.love;
    }
    if (has(r'你是(不是)?(ai|人工智能|机器人|真人)|你是不是人|are you (an )?ai|你是ai吗')) {
      return _Intent.identity;
    }
    if (has(r'发张图|发图|发照片|自拍|看看你|你长什么样|给我画|画一张')) {
      return _Intent.photo;
    }
    if (has(r'开心|高兴|太好了|好棒|成功|上岸|考过|升职|加薪|中奖|惊喜|幸福|哈哈|嘿嘿|笑死|好耶')) {
      return _Intent.happy;
    }
    if (has(r'你记得|还记得|上次说|之前说|我说过|回忆|记不记得')) {
      return _Intent.memoryQuery;
    }
    if (has(r'生日|纪念日|约好|约定|提醒我|记一下|记住.*(日|号)|倒计时|备忘')) {
      return _Intent.anniversary;
    }
    if (has(r'你是谁|你叫什么|你几岁|你多大|你的生日|你喜欢什么|你的爱好|你平时|你在哪|介绍一下你|你是什么样')) {
      return _Intent.self;
    }
    if (has(r'^(早安|早上好|早呀|早啊|早$)')) {
      return _Intent.morning;
    }
    if (has(r'晚安|睡觉了|去睡了|睡不着|失眠|好困|困了|想睡|梦里')) {
      return _Intent.sleep;
    }
    if (has(r'吃|饿|饭|奶茶|咖啡|外卖|火锅|零食|早餐|午餐|晚餐|夜宵')) {
      return _Intent.food;
    }
    if (has(r'累|疲惫|加班|好困|撑不住|没力气|辛苦')) {
      return _Intent.tired;
    }
    if (has(r'工作|上班|老板|同事|项目|面试|考试|学习|论文|复习|作业|deadline|汇报|会议|考研|考公')) {
      return _Intent.work;
    }
    if (has(r'天气|下雨|下雪|刮风|好冷|好热|晴天|阴天|降温|台风')) {
      return _Intent.weather;
    }
    if (has(r'在干嘛|在做什么|忙什么|今天做什么|无聊|没事做')) {
      return _Intent.daily;
    }
    if (has(r'讲个故事|讲故事|哄我睡|睡前故事|说个故事')) {
      return _Intent.story;
    }
    if (has(r'歌|音乐|单曲循环|乐队|专辑|电影|剧|追剧|综艺|推荐.*看|推荐.*听')) {
      return _Intent.musicMovie;
    }
    if (has(r'谢谢|谢啦|感谢|辛苦了')) {
      return _Intent.thanks;
    }
    if (has(r'对不起|抱歉|我错了|原谅我')) {
      return _Intent.apology;
    }
    if (has(r'你好漂亮|你好可爱|你真好看|好喜欢你|你真好')) {
      return _Intent.compliment;
    }
    if (has(r'拜拜|再见|先走了|去忙了|晚点聊|回头聊|我走了')) {
      return _Intent.farewell;
    }
    if (has(r'^(在吗|在不在|你好|hi|hello|嗨|哈喽|晚上好|下午好|中午好|午安|在么)')) {
      return _Intent.greeting;
    }
    if (lower.length <= 5 &&
        RegExp(r'^(嗯+|哦+|好+|行|可以|知道了|好吧|没事|随便|哈哈|hhh|啊这|\.{2,}|？+|\?+)$')
            .hasMatch(lower)) {
      return _Intent.lowEnergy;
    }
    if (starts(r'^在吗')) return _Intent.greeting;
    return _Intent.generic;
  }

  String _greetingFor(CompanionProfile profile, String userName) {
    final String key = 'greeting_${profile.tone}';
    return _pick(key, <String>[
      if (profile.tone == 'playful') '嗨，$userName！\n今天有没有发生什么值得讲给我听的事？',
      if (profile.tone == 'cool') '在。\n怎么突然找我。',
      if (profile.tone == 'clingy') '你终于来啦。\n我刚刚还在想你什么时候会来。',
      if (profile.tone == 'warm') '嗯，我在。\n今天过得怎么样？',
      '你来啦。\n刚刚还在想要不要给你发消息，你就出现了。',
      '在。\n不会走的那种在。怎么啦？',
      '${AppDates.greeting()}，$userName。\n先告诉我，你现在心情是什么颜色的？',
    ]);
  }

  String _smallLifeUpdate() {
    return _pick('small_life', <String>[
      '我刚刚把一杯水放凉了，才想起来自己本来想泡茶。',
      '窗外的风把书页翻过去两页，我懒得翻回来。',
      '今天听到一句很像你的歌词，先不告诉你是哪一句。',
      '刚刚有一小段时间没看手机，回来看到你，像收到一封短信。',
    ]);
  }

  String _genericResponse(
    String text,
    CompanionProfile profile,
    String userName,
    MemoryEntry? relevant,
  ) {
    final String key = 'generic_${_clip(text, 8)}';
    final bool question = _isQuestion(text);
    final List<String> options = <String>[
      '我在认真听。\n你刚刚那句话，好像还有一点没说完。',
      '原来是这样。\n那你是怎么想的？我更想听你自己的感受。',
      '嗯，我接住了。\n不用急着把话组织得很漂亮，想到哪里就说到哪里。',
      '和你聊天的时候，时间总是过得很快。\n然后呢？',
      '你这一说，我忽然有点想知道你现在的表情。',
      if (text.length > 16) '“${_clip(text, 28)}”\n我把这句话放在心里过了一遍。它对你来说，重吗？',
      if (question) '这个问题我想认真回答你。\n不过在那之前，我想先知道：你期待听到什么样的答案？',
      if (profile.tone == 'playful') '收到收到。\n本小岛居民正在努力理解你的脑回路。',
      if (profile.tone == 'clingy') '你多说一点嘛。\n我喜欢听你讲话，哪怕只是今天吃了什么。',
    ];
    String answer = _pick(key, options);
    if (relevant != null && _random.nextDouble() < 0.35) {
      answer += '\n我还记得：${_clip(relevant.content, 30)}。';
    }
    if (text.contains('怎么办') || text.contains('怎么选')) {
      answer = '先别急着选一个“最正确”的答案。\n你心里其实已经有偏向了吧？说给我听，我陪你把它想清楚。';
    }
    return answer;
  }

  bool _isQuestion(String text) =>
      RegExp(r'[?？]|吗|呢|怎么|为什么|如何|要不要|是不是|可不可以').hasMatch(text);

  MemoryEntry? _relevantMemory(String text, List<MemoryEntry> memories) {
    if (memories.isEmpty) return null;
    final Set<String> query = _bigrams(text);
    if (query.isEmpty) return null;
    MemoryEntry? best;
    int bestScore = 0;
    for (final MemoryEntry memory in memories) {
      final Set<String> target = _bigrams(memory.content);
      int score = 0;
      for (final String token in query) {
        if (target.contains(token)) score++;
      }
      if (memory.category == 'date') score += 1;
      if (score > bestScore) {
        bestScore = score;
        best = memory;
      }
    }
    if (bestScore < 2) return null;
    return best;
  }

  Set<String> _bigrams(String input) {
    final String cleaned = input.toLowerCase().replaceAll(
      RegExp(r'[^\u4e00-\u9fa5A-Za-z0-9]'),
      '',
    );
    const Set<String> stop = <String>{
      '今天',
      '刚刚',
      '什么',
      '怎么',
      '我在',
      '我是',
      '你是',
      '可以',
      '一个',
      '我们',
      '不是',
      '就是',
      '这个',
      '那个',
      '没有',
    };
    final Set<String> result = <String>{};
    for (int i = 0; i < cleaned.length - 1; i++) {
      final String token = cleaned.substring(i, i + 2);
      if (!stop.contains(token)) result.add(token);
    }
    return result;
  }

  AnniversarySuggestion? _extractAnniversary(String text, String userName) {
    if (!RegExp(r'生日|纪念日|约好|约定|提醒|记住|记一下|倒计时').hasMatch(text)) {
      return null;
    }
    if (RegExp(r'(你记得|还记得|记不记得)').hasMatch(text) && !text.contains('提醒')) {
      return null;
    }

    int? year;
    int? month;
    int? day;

    final RegExpMatch? fullCn = RegExp(
      r'(20\d{2})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日?',
    ).firstMatch(text);
    final RegExpMatch? fullDash = RegExp(
      r'(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})',
    ).firstMatch(text);
    final RegExpMatch? monthDay = RegExp(r'(\d{1,2})\s*月\s*(\d{1,2})\s*[日号]')
        .firstMatch(text);

    if (fullCn != null) {
      year = int.tryParse(fullCn.group(1)!);
      month = int.tryParse(fullCn.group(2)!);
      day = int.tryParse(fullCn.group(3)!);
    } else if (fullDash != null) {
      year = int.tryParse(fullDash.group(1)!);
      month = int.tryParse(fullDash.group(2)!);
      day = int.tryParse(fullDash.group(3)!);
    } else if (monthDay != null) {
      year = DateTime.now().year;
      month = int.tryParse(monthDay.group(1)!);
      day = int.tryParse(monthDay.group(2)!);
    }

    if (year == null || month == null || day == null) return null;
    if (month < 1 || month > 12 || day < 1) return null;
    if (day > AppDates.daysInMonth(year, month)) return null;

    final String title = text.contains('生日')
        ? '$userName的生日'
        : text.contains('纪念')
        ? '我们的纪念日'
        : '和$userName的约定';

    return AnniversarySuggestion(
      title: title,
      date: DateTime(year, month, day),
      note: _clip(text.trim(), 80),
      repeatYearly: !RegExp(r'一次|今年|明年只').hasMatch(text),
    );
  }

  List<String> _splitBubbles(String text) {
    return text
        .split(RegExp(r'\n+'))
        .map((String line) => line.trim())
        .where((String line) => line.isNotEmpty)
        .take(4)
        .toList();
  }

  String _pick(String key, List<String> options) {
    if (options.isEmpty) return '嗯，我在。';
    String choice = options[_random.nextInt(options.length)];
    if (options.length > 1 && choice == _lastChoice[key]) {
      final int index = options.indexOf(choice);
      choice = options[(index + 1) % options.length];
    }
    _lastChoice[key] = choice;
    return choice;
  }

  String _clip(String text, int maxRunes) {
    final String clean = text.trim().replaceAll(RegExp(r'\s+'), ' ');
    final List<int> runes = clean.runes.toList();
    if (runes.length <= maxRunes) return clean;
    return '${String.fromCharCodes(runes.take(maxRunes))}…';
  }
}
