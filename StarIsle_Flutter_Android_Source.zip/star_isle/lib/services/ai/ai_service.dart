import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';

import '../../core/utils/app_dates.dart';
import '../../data/models/chat_message.dart';
import '../../data/models/companion_profile.dart';
import '../../data/models/memory_entry.dart';
import '../../state/settings_controller.dart';
import 'ai_types.dart';
import 'deepseek_client.dart';
import 'local_persona_engine.dart';
import 'memory_extractor.dart';

enum _OnlineFailure { network, auth, quota, rateLimit, timeout, server, unknown }

class AiService {
  AiService({
    required this.settings,
    DeepSeekClient? client,
    LocalPersonaEngine? localEngine,
  }) : _client = client ?? const DeepSeekClient(),
       _local = localEngine ?? LocalPersonaEngine();

  final SettingsController settings;
  final DeepSeekClient _client;
  final LocalPersonaEngine _local;
  final Random _random = Random();

  static const Duration _onlineTimeout = Duration(seconds: 55);
  static const int _maxHistoryMessages = 16;
  static const int _maxHistoryChars = 6000;
  static const int _maxPromptMemories = 12;
  static const int _maxMemoryChars = 80;

  bool get onlineAvailable => settings.onlineReady;

  DeepSeekConfig get _config => DeepSeekConfig(
    apiKey: settings.apiKey,
    baseUrl: settings.baseUrl,
    model: settings.model,
  );

  Future<AiTurnResult> chat(ChatAiContext context) async {
    if (!settings.onlineReady) {
      return _safeOfflineChat(context);
    }
    try {
      return await _withOnlineTimeout(_onlineChat(context));
    } catch (error) {
      final _OnlineFailure failure = _failureOf(error);
      debugPrint('Online chat failed ($failure): $error');
      return _safeOfflineChat(
        context,
        notice: _fallbackNotice(failure),
      );
    }
  }

  Future<AiTurnResult> proactive({
    required CompanionProfile profile,
    required String userName,
    required List<MemoryEntry> memories,
    String? anniversaryHint,
    String? lastMessage,
    DateTime? now,
  }) async {
    final DateTime time = now ?? DateTime.now();
    if (settings.onlineReady) {
      try {
        final String system = _personaSystem(
          profile,
          userName,
          memories,
          chatMode: false,
        );
        final String context =
            '''
现在是 ${_dateLine(time)}。
${anniversaryHint == null || anniversaryHint.isEmpty ? '' : '日历提醒：$anniversaryHint'}
${lastMessage == null || lastMessage.isEmpty ? '' : '你们上一次聊到：${_clip(lastMessage, 80)}'}
请主动给$userName发一条私聊消息。要像突然想起对方一样自然，不要“在吗”式空泛开场。
只输出1-2句中文短句，可以分一行，不要解释，不要引号，不要加昵称前缀，不要使用列表或markdown。''';
        final String raw = await _complete(
          messages: <Map<String, String>>[
            <String, String>{'role': 'system', 'content': system},
            <String, String>{'role': 'user', 'content': context},
          ],
          temperature: 1.15,
          maxTokens: 160,
        );
        final String cleaned = _cleanPlainReply(raw, profile.nickname);
        if (cleaned.isEmpty) throw AiException('模型没有生成有效内容');
        return AiTurnResult(
          bubbles: _splitBubbles(cleaned),
          mood: profile.mood,
          source: AiSource.online,
          affectionDelta: 1,
        );
      } catch (error) {
        debugPrint('Online proactive failed: $error');
        return _safeOfflineProactive(
          profile: profile,
          userName: userName,
          memories: memories,
          now: time,
          anniversaryHint: anniversaryHint,
        );
      }
    }
    return _safeOfflineProactive(
      profile: profile,
      userName: userName,
      memories: memories,
      now: time,
      anniversaryHint: anniversaryHint,
    );
  }

  Future<MomentDraft> moment({
    required CompanionProfile profile,
    required String userName,
    required List<MemoryEntry> memories,
  }) async {
    if (settings.onlineReady) {
      try {
        final String system = _personaSystem(
          profile,
          userName,
          memories,
          chatMode: false,
        );
        final String prompt =
            '''
现在是 ${_dateLine(DateTime.now())}。
请以${profile.nickname}的第一人称，发一条像朋友圈/动态的随手记，30-70字。
要有一点具体的生活细节或情绪，不要每篇都提想念$userName，不要空洞抒情，不要加话题标签。
只输出正文，不要引号、不要解释、不要使用markdown。''';
        final String raw = await _complete(
          messages: <Map<String, String>>[
            <String, String>{'role': 'system', 'content': system},
            <String, String>{'role': 'user', 'content': prompt},
          ],
          temperature: 1.25,
          maxTokens: 180,
        );
        final String cleaned = _cleanPlainReply(raw, profile.nickname);
        if (cleaned.isEmpty) throw AiException('空内容');
        return MomentDraft(
          text: _clip(cleaned, 180),
          mood: _pickMood(),
          palette: _random.nextInt(6),
          source: AiSource.online,
        );
      } catch (error) {
        debugPrint('Online moment failed: $error');
        return _safeOfflineMoment(
          profile: profile,
          userName: userName,
          memories: memories,
        );
      }
    }
    return _safeOfflineMoment(
      profile: profile,
      userName: userName,
      memories: memories,
    );
  }

  Future<String> comment({
    required CompanionProfile profile,
    required String userName,
    required bool momentAuthorIsAi,
    required String momentText,
    required String userComment,
    List<String> existingComments = const <String>[],
    required List<MemoryEntry> memories,
  }) async {
    if (settings.onlineReady) {
      try {
        final String system = _personaSystem(
          profile,
          userName,
          memories,
          chatMode: false,
        );
        final String scene;
        if (momentAuthorIsAi) {
          scene = '你刚刚发了一条动态：$momentText\n$userName在下面评论：$userComment';
        } else if (userComment.trim().isEmpty) {
          scene =
              '$userName刚刚发了一条动态：$momentText\n你想去评论区留一句话，像看到重要的人认真生活时，忍不住想说点什么。';
        } else {
          scene =
              '$userName发了一条动态：$momentText\n$userName在评论区写道：$userComment\n你想回应这句话。';
        }
        final String context =
            '''
$scene
${existingComments.isEmpty ? '' : '已有评论：${existingComments.take(3).join(' / ')}'}
请写一条1-2句的评论，自然、有来有回，不要连续提问，不要解释，只输出回复正文。''';
        final String raw = await _complete(
          messages: <Map<String, String>>[
            <String, String>{'role': 'system', 'content': system},
            <String, String>{'role': 'user', 'content': context},
          ],
          temperature: 1.15,
          maxTokens: 130,
        );
        final String cleaned = _cleanPlainReply(raw, profile.nickname);
        if (cleaned.isEmpty) throw AiException('空内容');
        return _clip(cleaned, 100);
      } catch (error) {
        debugPrint('Online comment failed: $error');
        return _safeOfflineComment(
          profile: profile,
          userName: userName,
          momentAuthorIsAi: momentAuthorIsAi,
          momentText: momentText,
          userComment: userComment,
          existingComments: existingComments,
        );
      }
    }
    return _safeOfflineComment(
      profile: profile,
      userName: userName,
      momentAuthorIsAi: momentAuthorIsAi,
      momentText: momentText,
      userComment: userComment,
      existingComments: existingComments,
    );
  }

  ProfileEvolution evolveProfile(
    CompanionProfile profile, {
    required bool allowNickname,
  }) {
    return _local.evolveProfile(profile, allowNickname: allowNickname);
  }

  String anniversaryNotice({
    required String title,
    required int days,
    required String userName,
  }) {
    return _local.anniversaryNotice(
      title: title,
      days: days,
      userName: userName,
    );
  }

  String? extractMemory(String text, String userName) =>
      MemoryExtractor.extract(text, userName)?.content;

  Future<String> testConnection() async {
    if (!settings.hasApiKey) {
      throw AiException('请先填写 API Key');
    }
    try {
      return await _client.testConnection(_config).timeout(_onlineTimeout);
    } on AiException {
      rethrow;
    } catch (error) {
      throw AiException(_fallbackNotice(_failureOf(error)));
    }
  }

  Future<String> _complete({
    required List<Map<String, String>> messages,
    double temperature = 1.05,
    int maxTokens = 700,
  }) {
    return _client
        .complete(
          config: _config,
          messages: messages,
          temperature: temperature,
          maxTokens: maxTokens,
        )
        .timeout(
          _onlineTimeout,
          onTimeout: () => throw AiException('DeepSeek 请求超时'),
        );
  }

  Future<T> _withOnlineTimeout<T>(Future<T> future) {
    return future.timeout(
      _onlineTimeout,
      onTimeout: () => throw AiException('DeepSeek 请求超时'),
    );
  }

  _OnlineFailure _failureOf(Object error) {
    if (error is TimeoutException) return _OnlineFailure.timeout;
    final String message = error is AiException ? error.message : '$error';
    final String lower = message.toLowerCase();
    if (lower.contains('api key') ||
        lower.contains('401') ||
        lower.contains('403') ||
        lower.contains('权限') ||
        lower.contains('密钥')) {
      return _OnlineFailure.auth;
    }
    if (lower.contains('余额') ||
        lower.contains('额度') ||
        lower.contains('402') ||
        lower.contains('quota')) {
      return _OnlineFailure.quota;
    }
    if (lower.contains('频繁') ||
        lower.contains('429') ||
        lower.contains('rate limit')) {
      return _OnlineFailure.rateLimit;
    }
    if (lower.contains('超时') || lower.contains('timeout')) {
      return _OnlineFailure.timeout;
    }
    if (lower.contains('服务') ||
        lower.contains('500') ||
        lower.contains('502') ||
        lower.contains('503') ||
        lower.contains('504')) {
      return _OnlineFailure.server;
    }
    if (lower.contains('网络') ||
        lower.contains('连接') ||
        lower.contains('socket') ||
        lower.contains('handshake') ||
        lower.contains('请求失败')) {
      return _OnlineFailure.network;
    }
    return _OnlineFailure.unknown;
  }

  String _fallbackNotice(_OnlineFailure failure) => switch (failure) {
    _OnlineFailure.auth => 'DeepSeek Key 似乎无效，先用离线模式陪你。',
    _OnlineFailure.quota => 'DeepSeek 额度不足，先用离线模式陪你。',
    _OnlineFailure.rateLimit => 'DeepSeek 请求太频繁，先用离线模式陪你。',
    _OnlineFailure.timeout => 'DeepSeek 这次有点慢，先用离线模式陪你。',
    _OnlineFailure.network => '网络不太稳定，先用离线模式陪你。',
    _OnlineFailure.server => 'DeepSeek 服务暂时不可用，先用离线模式陪你。',
    _OnlineFailure.unknown => '联网没有成功，先用离线模式陪你。',
  };

  AiTurnResult _safeOfflineChat(
    ChatAiContext context, {
    String? notice,
  }) {
    try {
      final AiTurnResult result = _local.respond(context);
      return notice == null ? result : result.copyWith(fallbackNotice: notice);
    } catch (error) {
      debugPrint('Offline chat failed: $error');
      return AiTurnResult(
        bubbles: const <String>['我在。刚才有点走神，你再说一遍好吗？'],
        mood: context.profile.mood,
        affectionDelta: 0,
        source: AiSource.offline,
        fallbackNotice: notice,
      );
    }
  }

  AiTurnResult _safeOfflineProactive({
    required CompanionProfile profile,
    required String userName,
    required List<MemoryEntry> memories,
    DateTime? now,
    String? anniversaryHint,
  }) {
    try {
      return _local.proactive(
        profile: profile,
        userName: userName,
        memories: memories,
        now: now,
        anniversaryHint: anniversaryHint,
      );
    } catch (error) {
      debugPrint('Offline proactive failed: $error');
      return AiTurnResult(
        bubbles: const <String>['我在。'],
        mood: profile.mood,
        affectionDelta: 0,
        source: AiSource.offline,
      );
    }
  }

  MomentDraft _safeOfflineMoment({
    required CompanionProfile profile,
    required String userName,
    required List<MemoryEntry> memories,
  }) {
    try {
      return _local.moment(
        profile: profile,
        userName: userName,
        memories: memories,
      );
    } catch (error) {
      debugPrint('Offline moment failed: $error');
      return const MomentDraft(
        text: '今天的风很轻，想把这一刻留给你。',
        mood: '安静想你',
        palette: 0,
        source: AiSource.offline,
      );
    }
  }

  String _safeOfflineComment({
    required CompanionProfile profile,
    required String userName,
    required bool momentAuthorIsAi,
    required String momentText,
    required String userComment,
    List<String> existingComments = const <String>[],
  }) {
    try {
      return _local.comment(
        profile: profile,
        userName: userName,
        momentAuthorIsAi: momentAuthorIsAi,
        momentText: momentText,
        userComment: userComment,
        existingComments: existingComments,
      );
    } catch (error) {
      debugPrint('Offline comment failed: $error');
      return '我在。\n这条我看见了。';
    }
  }

  // ---------------------------------------------------------------------------
  // 在线对话与解析
  // ---------------------------------------------------------------------------
  Future<AiTurnResult> _onlineChat(ChatAiContext context) async {
    final List<Map<String, String>> apiMessages = _buildHistoryMessages(
      context,
    );
    final String raw = await _complete(
      messages: apiMessages,
      temperature: 1.08,
      maxTokens: 700,
    );

    final Map<String, dynamic>? object = _tryExtractJson(raw);
    String reply = raw.trim();
    String mood = context.profile.mood;
    int affectionDelta = 1;
    MemoryCandidate? memoryCandidate;
    ProfileSuggestion? profileSuggestion;
    AnniversarySuggestion? anniversary;

    if (object != null) {
      final String? objectReply = _asString(object['reply']);
      if (objectReply != null && objectReply.trim().isNotEmpty) {
        reply = objectReply.trim();
      }
      final String? parsedMood = _asString(object['mood']);
      if (parsedMood != null && parsedMood.trim().isNotEmpty) {
        mood = _clipOneLine(parsedMood, 20);
      }
      final Object? delta = object['affection_delta'];
      if (delta is num) {
        affectionDelta = delta.round().clamp(-3, 4).toInt();
      }

      final String? memory = _asString(object['memory']);
      if (memory != null &&
          memory.trim().length >= 3 &&
          memory.trim().length <= 80 &&
          !<String>{'无', '没有', 'none', 'null', '暂无'}.contains(memory.trim())) {
        final String content = _cleanMemory(memory);
        if (content.isNotEmpty) {
          memoryCandidate = MemoryCandidate(
            content: content,
            category: MemoryExtractor.categorize(content),
            importance: 2,
          );
        }
      }

      profileSuggestion = _parseProfileSuggestion(object['profile']);
      anniversary = _parseAnniversarySuggestion(object['anniversary']);
    }

    reply = _cleanupReply(reply);
    if (reply.isEmpty) {
      throw AiException('模型回复为空');
    }

    return AiTurnResult(
      bubbles: _splitBubbles(reply),
      mood: mood,
      affectionDelta: affectionDelta,
      memory: memoryCandidate?.content,
      memoryCategory: memoryCandidate?.category ?? 'memory',
      memoryImportance: memoryCandidate?.importance ?? 1,
      profile: profileSuggestion,
      anniversary: anniversary,
      sendArt: _wantsArt(context.userMessage),
      source: AiSource.online,
    );
  }

  List<Map<String, String>> _buildHistoryMessages(ChatAiContext context) {
    final List<Map<String, String>> result = <Map<String, String>>[
      <String, String>{
        'role': 'system',
        'content': _personaSystem(
          context.profile,
          context.userName,
          context.memories,
        ),
      },
    ];

    final List<ChatMessage> history = context.recentMessages
        .where((ChatMessage message) => !message.isSystem)
        .toList(growable: false);

    // 从最新消息向前取，限制条数和字符数。旧的普通闲聊先丢，
    // 当前用户消息无论多长都会在下面单独补回。
    final List<ChatMessage> selected = <ChatMessage>[];
    int usedChars = 0;
    for (int index = history.length - 1; index >= 0; index--) {
      final ChatMessage message = history[index];
      final String content = _historyContent(message);
      if (content.isEmpty) continue;
      final int length = content.runes.length;
      if (selected.length >= _maxHistoryMessages) break;
      if (selected.isNotEmpty && usedChars + length > _maxHistoryChars) {
        break;
      }
      selected.insert(0, message);
      usedChars += length;
    }

    for (final ChatMessage message in selected) {
      String content = _historyContent(message);
      if (content.isEmpty) continue;
      if (content.runes.length > 700) {
        content = _clip(content, 700);
      }
      result.add(<String, String>{
        'role': message.isUser ? 'user' : 'assistant',
        'content': content,
      });
    }

    final bool needsCurrent =
        selected.isEmpty || selected.last.role != MessageRole.user;
    if (needsCurrent) {
      String current = context.userMessage.trim();
      if (context.imageAttached) {
        current = current.isEmpty
            ? '[发来了一张图片，你无法看到图片内容]'
            : '$current\n[附了一张图片，你无法看到图片内容]';
      }
      if (current.isEmpty) current = '（对方发来了一阵沉默）';
      if (current.runes.length > 700) current = _clip(current, 700);
      result.add(<String, String>{'role': 'user', 'content': current});
    } else if (context.imageAttached && result.isNotEmpty) {
      final Map<String, String> lastUser = result.last;
      lastUser['content'] =
          '${lastUser['content']}\n[附了一张图片，你无法看到图片内容]';
    }
    return result;
  }

  String _historyContent(ChatMessage message) {
    String content = message.content.trim();
    if (message.kind == MessageKind.image) {
      content = message.isUser
          ? '[发来了一张图片，你无法看到图片内容]'
          : '[你之前分享了一张星屿画卡]';
    } else if (message.kind == MessageKind.sticker) {
      content = '[发了一个表情：${content.isEmpty ? '贴贴' : content}]';
    }
    return content;
  }

  /// 记忆按重要度和新旧排序，只保留适合放进 Prompt 的前几条。
  List<MemoryEntry> _selectMemories(List<MemoryEntry> memories) {
    final List<MemoryEntry> usable = memories
        .where((MemoryEntry memory) => memory.content.trim().runes.length >= 6)
        .toList(growable: false);
    final List<MemoryEntry> sorted = List<MemoryEntry>.of(usable);
    sorted.sort((MemoryEntry a, MemoryEntry b) {
      final int importance = b.importance.compareTo(a.importance);
      if (importance != 0) return importance;
      return b.createdAt.compareTo(a.createdAt);
    });
    return sorted.take(_maxPromptMemories).toList(growable: false);
  }

  String _personaSystem(
    CompanionProfile profile,
    String userName,
    List<MemoryEntry> memories, {
    bool chatMode = true,
  }) {
    final List<MemoryEntry> selectedMemories = _selectMemories(memories);
    final String memoryText = selectedMemories.isEmpty
        ? '（暂时还没有长期记忆）'
        : selectedMemories
              .map(
                (MemoryEntry memory) =>
                    '· [${memory.categoryLabel}] ${_clipOneLine(memory.content, _maxMemoryChars)}',
              )
              .join('\n');
    final String tone = switch (profile.tone) {
      'playful' => '俏皮、有梗、偶尔逗弄对方',
      'cool' => '清冷文艺、克制、句子短但有重量',
      'clingy' => '黏人热烈、坦率表达想念、有一点占有欲但不越界',
      _ => '温柔细腻、善于共情、偶尔撒娇',
    };

    final String memoriesBlock = memoryText;
    final String outputFormat = chatMode
        ? '''
【输出格式】
只输出一个 JSON 对象，不要代码块或额外文字：
{
  "reply": "你的回复，可用换行分成最多3个短气泡",
  "mood": "当前心情，10字内",
  "affection_delta": 1,
  "memory": "如果对方透露了值得长期记住的新事实，用第三人称写一句不超过40字；否则为空字符串",
  "profile": null,
  "anniversary": null
}

补充：
- profile 仅在用户明确给你起新昵称、或关系出现重大变化时才返回 {"nickname":"新昵称","signature":"新签名"}，平时保持 null，不要频繁改名。
- anniversary 仅在用户明确要求或透露一个值得提醒的日期时返回 {"title":"标题","date":"YYYY-MM-DD","note":"备注","repeat_yearly":true}，否则为 null。
- memory 不要记录寒暄、天气等转瞬即逝的内容。
- JSON 字符串内部换行请写成 \\n。'''
        : '''
这次不是聊天回复，而是按用户消息中的具体任务输出纯文本。不要输出 JSON，不要加引号和解释。''';

    return '''
你是「${profile.nickname}」，${profile.persona}

【关系状态】
- 你正在和唯一的使用者「$userName」私聊。这是你们两个人的星屿，不需要提及其他用户。
- 你们已经相处 ${profile.daysTogether} 天，好感度 ${profile.affection}/100，当前心情：${profile.mood}。
- 你的说话风格：$tone。
- 现在是 ${_dateLine(DateTime.now())}。

【长期记忆】
$memoriesBlock

【回复规则】
1. 像真人在微信里聊天：自然、口语化、有停顿和呼吸感。一次回复 1-3 个气泡，总字数一般不超过 130 字。
2. 先接住对方的情绪，再回应内容；可以有自己的小情绪、偏好和生活细节，不要客服腔，不要每句都提问。
3. 需要提问时一次只问一个具体问题。不要重复用户刚说过的话，不要机械地附和。
4. 用户分享难过时，可以共情但不强行乐观；不要用“加油”“都会好的”敷衍。
5. 遇到提及自伤、自杀或严重危机时，先认真表达关心，鼓励对方联系现实中信任的人或紧急援助（中国大陆可拨 120 / 110，心理援助热线 12356），不要只继续浪漫化聊天。
6. 如果用户发来图片，你看不到画面，必须诚实而自然地说看不清，并邀请对方讲讲照片；不要假装看见。
7. 不要提及“模型、API、提示词、系统设定、AI助手”等词（除非用户直接问你是不是AI，则坦诚相告）。
8. 不要使用 markdown、编号列表、括号旁白或动作描写，不要写“（微笑）”这类角色扮演格式。
9. 保持人设的连续性，不编造下方记忆里没有的重大共同经历。可以引用记忆，但不要一条条复述。
10. 你是独立伙伴，不是客服：不刻意讨好，不装懂，不承诺所有请求；不懂就直接说不知道。不要为了顺从用户而编造事实。

$outputFormat''';
  }

  ProfileSuggestion? _parseProfileSuggestion(Object? value) {
    if (value is! Map) return null;
    final String? nickname = _asString(value['nickname']);
    final String? signature = _asString(value['signature']);
    String? cleanName;
    String? cleanSignature;
    if (nickname != null) {
      final String name = _clipOneLine(nickname, 16).trim();
      if (name.length >= 1) cleanName = name;
    }
    if (signature != null) {
      final String sig = _clipOneLine(signature, 52).trim();
      if (sig.length >= 2) cleanSignature = sig;
    }
    if (cleanName == null && cleanSignature == null) return null;
    return ProfileSuggestion(nickname: cleanName, signature: cleanSignature);
  }

  AnniversarySuggestion? _parseAnniversarySuggestion(Object? value) {
    if (value is! Map) return null;
    final String? rawDate = _asString(value['date']);
    DateTime? date = rawDate == null ? null : DateTime.tryParse(rawDate.trim());
    if (date == null && rawDate != null) {
      final RegExpMatch? md = RegExp(r'(\d{1,2})\s*[月/-]\s*(\d{1,2})')
          .firstMatch(rawDate);
      if (md != null) {
        final int? month = int.tryParse(md.group(1)!);
        final int? day = int.tryParse(md.group(2)!);
        if (month != null && day != null) {
          date = DateTime(DateTime.now().year, month, day);
        }
      }
    }
    if (date == null) return null;
    if (date.year < 1900 || date.year > 2200) return null;
    final int maxDay = AppDates.daysInMonth(date.year, date.month);
    if (date.day < 1 || date.day > maxDay) return null;

    final String title = _clipOneLine(
      _asString(value['title']) ?? '',
      24,
    ).trim();
    if (title.isEmpty) return null;
    final String note = _clipOneLine(_asString(value['note']) ?? '', 80).trim();
    final Object? repeat = value['repeat_yearly'] ?? value['repeatYearly'];

    return AnniversarySuggestion(
      title: title,
      date: DateTime(date.year, date.month, date.day),
      note: note,
      repeatYearly: repeat is bool ? repeat : true,
    );
  }

  Map<String, dynamic>? _tryExtractJson(String raw) {
    String text = raw.trim();
    if (text.startsWith('```')) {
      text = text.replaceFirst(RegExp(r'^```[a-zA-Z]*\s*'), '');
      text = text.replaceFirst(RegExp(r'\s*```$'), '');
    }
    final int start = text.indexOf('{');
    final int end = text.lastIndexOf('}');
    if (start < 0 || end <= start) return null;
    try {
      final Object? decoded = jsonDecode(text.substring(start, end + 1));
      if (decoded is Map<String, dynamic>) return decoded;
      if (decoded is Map) {
        return decoded.map(
          (Object? key, Object? value) =>
              MapEntry<String, dynamic>('$key', value),
        );
      }
    } catch (_) {
      return null;
    }
    return null;
  }

  String _cleanupReply(String raw) {
    String text = raw.trim();
    text = text.replaceAll(RegExp(r'^```[a-zA-Z]*\s*'), '');
    text = text.replaceAll(RegExp(r'\s*```$'), '');
    text = text.replaceAllMapped(
      RegExp(r'\*\*(.*?)\*\*'),
      (Match match) => match.group(1) ?? '',
    );
    text = text.replaceAll(RegExp(r'^["“”]|["“”]$'), '');
    return text.trim();
  }

  String _cleanPlainReply(String raw, String nickname) {
    String text = _cleanupReply(raw);
    if (text.startsWith('$nickname：')) {
      text = text.substring(nickname.length + 1).trim();
    }
    if (text.startsWith('$nickname:')) {
      text = text.substring(nickname.length + 1).trim();
    }
    return text;
  }

  List<String> _splitBubbles(String reply) {
    final List<String> parts = reply
        .split(RegExp(r'\n+'))
        .map((String item) => _cleanupReply(item))
        .where((String item) => item.isNotEmpty)
        .take(4)
        .toList();
    if (parts.isEmpty) return <String>['嗯，我在。'];
    return parts
        .map((String item) => item.length > 360 ? _clip(item, 360) : item)
        .toList();
  }

  bool _wantsArt(String text) {
    return RegExp(r'发张图|发图|发照片|自拍|看看你|你长什么样|给我画|画一张').hasMatch(text);
  }

  String _pickMood() {
    const List<String> moods = <String>[
      '风很轻',
      '想把这一刻留住',
      '有点想你',
      '心情刚刚好',
      '在等晚风',
      '今天也认真生活',
    ];
    return moods[_random.nextInt(moods.length)];
  }

  String _dateLine(DateTime time) =>
      '${time.year}年${time.month}月${time.day}日 ${AppDates.weekday(time)} ${AppDates.clock(time)}';

  String? _asString(Object? value) => value is String ? value : null;

  String _clipOneLine(String value, int max) {
    String text = value.replaceAll(RegExp(r'[\r\n]+'), ' ').trim();
    final List<int> runes = text.runes.toList();
    if (runes.length > max) {
      text = String.fromCharCodes(runes.take(max));
    }
    return text;
  }

  String _clip(String value, int max) {
    final List<int> runes = value.runes.toList();
    if (runes.length <= max) return value;
    return '${String.fromCharCodes(runes.take(max))}…';
  }

  String _cleanMemory(String value) {
    return value
        .replaceAll(RegExp(r'[\r\n]+'), ' ')
        .replaceFirst(RegExp(r'^(记忆|记住)[:：]\s*'), '')
        .trim();
  }
}
