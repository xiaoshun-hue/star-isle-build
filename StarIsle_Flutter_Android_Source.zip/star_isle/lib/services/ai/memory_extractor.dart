class MemoryCandidate {
  const MemoryCandidate({
    required this.content,
    required this.category,
    required this.importance,
  });

  final String content;
  final String category;
  final int importance;
}

class MemoryExtractor {
  MemoryExtractor._();

  static const List<_MemoryRule> _rules = [
    _MemoryRule(
      pattern: r'我叫([\u4e00-\u9fa5A-Za-z0-9·]{1,12})',
      category: 'life',
      importance: 3,
    ),
    _MemoryRule(
      pattern: r'(我的)?生日(是|在)?([0-9]{1,2}月[0-9]{1,2}日|[0-9]{1,4}[年./-][0-9]{1,2}[月./-][0-9]{1,2}日?)',
      category: 'date',
      importance: 3,
    ),
    _MemoryRule(
      pattern: r'我(最|很|超|特别)?(喜欢|爱|偏爱|中意)([^。！？!?，,\n]{1,42})',
      category: 'preference',
      importance: 2,
    ),
    _MemoryRule(
      pattern: r'我(最|很|超|特别)?(讨厌|不喜欢|受不了|害怕|怕)([^。！？!?，,\n]{1,42})',
      category: 'preference',
      importance: 2,
    ),
    _MemoryRule(
      pattern: r'我(住在|搬到了|来自)([^。！？!?，,\n]{1,30})',
      category: 'life',
      importance: 2,
    ),
    _MemoryRule(
      pattern: r'我(养了|在养)([^。！？!?，,\n]{1,30})',
      category: 'life',
      importance: 2,
    ),
    _MemoryRule(
      pattern: r'我(最近|现在|正在)([^。！？!?，,\n]{2,45})',
      category: 'life',
      importance: 1,
    ),
    _MemoryRule(
      pattern: r'我(希望|想要|想去|打算|决定)([^。！？!?，,\n]{1,42})',
      category: 'preference',
      importance: 1,
    ),
    _MemoryRule(
      pattern: r'(记住|别忘了)([^。！？!?，,\n]{2,58})',
      category: 'promise',
      importance: 2,
    ),
    _MemoryRule(
      pattern: r'我们(约好|说好|约定)([^。！？!?，,\n]{2,45})',
      category: 'promise',
      importance: 2,
    ),
  ];

  static MemoryCandidate? extract(String text, String userName) {
    final String trimmed = text.trim();
    if (trimmed.length < 4 || trimmed.length > 180) return null;
    if (RegExp(r'[?？]$').hasMatch(trimmed)) return null;
    if (RegExp(r'(你记得|你知道|你还记得|猜猜)').hasMatch(trimmed)) return null;
    if (RegExp(r'^(你是|你叫什么|你多大)').hasMatch(trimmed)) return null;

    for (final _MemoryRule rule in _rules) {
      final RegExpMatch? match = RegExp(rule.pattern).firstMatch(trimmed);
      if (match == null) continue;

      String content = trimmed;
      if (rule.category == 'promise') {
        content = content
            .replaceFirst(RegExp(r'^(你)?(要|请)?(记住|别忘了)'), '')
            .replaceFirst(RegExp(r'^我们(约好|说好|约定)'), '约定')
            .trim();
      }
      content = content.replaceAll(RegExp(r'\s+'), ' ').trim();
      if (content.length < 3) continue;
      content = _clip(content, 72);
      return MemoryCandidate(
        content: content,
        category: rule.category,
        importance: rule.importance,
      );
    }
    return null;
  }

  static String categorize(String content) {
    if (RegExp(r'生日|纪念日|月.{1,3}日|约定').hasMatch(content)) return 'date';
    if (RegExp(r'喜欢|爱|讨厌|不喜欢|怕|想要').hasMatch(content)) {
      return 'preference';
    }
    if (RegExp(r'约好|说好|答应|保证').hasMatch(content)) return 'promise';
    if (RegExp(r'难过|焦虑|心事|委屈|孤单').hasMatch(content)) return 'emotion';
    return 'life';
  }

  static String normalize(String content) {
    return content.toLowerCase().replaceAll(
      RegExp(r'[\s，。！？、,.!?：:；;"“”‘’]'),
      '',
    );
  }

  static String _clip(String text, int maxRunes) {
    final List<int> runes = text.runes.toList();
    if (runes.length <= maxRunes) return text;
    return '${String.fromCharCodes(runes.take(maxRunes))}…';
  }
}

class _MemoryRule {
  const _MemoryRule({
    required this.pattern,
    required this.category,
    required this.importance,
  });

  final String pattern;
  final String category;
  final int importance;
}
