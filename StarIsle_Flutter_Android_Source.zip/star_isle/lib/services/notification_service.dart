import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

/// Android 本地通知桥接。
///
/// 这里不依赖第三方通知插件：原生端只负责系统通知、权限和点击回传，
/// 通知内容仍由本地 AI 消息生成，不经过服务器。
class NotificationService extends ChangeNotifier {
  NotificationService._() {
    _channel.setMethodCallHandler(_handleMethodCall);
  }

  static final NotificationService instance = NotificationService._();
  static const MethodChannel _channel = MethodChannel(
    'com.starisle.companion/notifications',
  );

  bool _initialized = false;
  int _tapSerial = 0;

  /// 每次用户点击通知都会自增，HomeShell 监听它切回聊天页。
  int get tapSerial => _tapSerial;

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;
    try {
      final bool openChat =
          await _channel.invokeMethod<bool>('initialize') ?? false;
      if (openChat) _emitTap();
    } on MissingPluginException {
      // 非 Android 或原生端未接好时不阻塞 App。
    } on PlatformException catch (error) {
      debugPrint('notification initialize failed: ${error.message}');
    } catch (error) {
      debugPrint('notification initialize failed: $error');
    }
  }

  Future<bool> requestPermission() async {
    try {
      return await _channel.invokeMethod<bool>('requestPermission') ?? false;
    } on MissingPluginException {
      return false;
    } on PlatformException catch (error) {
      debugPrint('notification permission failed: ${error.message}');
      return false;
    } catch (error) {
      debugPrint('notification permission failed: $error');
      return false;
    }
  }

  Future<bool> areNotificationsEnabled() async {
    try {
      return await _channel.invokeMethod<bool>('areEnabled') ?? false;
    } on MissingPluginException {
      return false;
    } on PlatformException catch (error) {
      debugPrint('notification state failed: ${error.message}');
      return false;
    } catch (error) {
      debugPrint('notification state failed: $error');
      return false;
    }
  }

  Future<bool> showMessage({
    required String title,
    required String body,
    int id = 4101,
  }) async {
    final String cleanBody = body.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (cleanBody.isEmpty) return false;
    try {
      final bool shown = await _channel.invokeMethod<bool>(
            'show',
            <String, Object>{
              'id': id,
              'title': title.trim().isEmpty ? '星屿' : title.trim(),
              'body': cleanBody,
            },
          ) ??
          false;
      return shown;
    } on MissingPluginException {
      return false;
    } on PlatformException catch (error) {
      debugPrint('show notification failed: ${error.message}');
      return false;
    } catch (error) {
      debugPrint('show notification failed: $error');
      return false;
    }
  }

  Future<void> cancelAll() async {
    try {
      await _channel.invokeMethod<void>('cancelAll');
    } on MissingPluginException {
      // 忽略。
    } on PlatformException catch (error) {
      debugPrint('cancel notification failed: ${error.message}');
    } catch (error) {
      debugPrint('cancel notification failed: $error');
    }
  }

  void _handleMethodCall(MethodCall call) {
    if (call.method == 'onNotificationTap') {
      _emitTap();
    }
  }

  void _emitTap() {
    _tapSerial++;
    notifyListeners();
  }
}
