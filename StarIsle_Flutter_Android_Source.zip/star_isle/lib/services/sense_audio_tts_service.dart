import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;

import 'free_edge_tts_service.dart';

class SenseAudioVoice {
  const SenseAudioVoice(this.id, this.name, this.description);

  final String id;
  final String name;
  final String description;

  static SenseAudioVoice? byId(String id) {
    for (final SenseAudioVoice voice in SenseAudioTtsService.voices) {
      if (voice.id == id) return voice;
    }
    return null;
  }
}

/// SenseAudio 云端 TTS。
///
/// 官方接口：POST https://api.senseaudio.cn/v1/t2a_v2
/// 非流式返回的音频是 hex 字符串。接口失败时调用方继续降级。
class SenseAudioTtsService {
  SenseAudioTtsService._();

  static final SenseAudioTtsService instance = SenseAudioTtsService._();

  static const String baseUrl = 'https://api.senseaudio.cn';
  static const String defaultModel = 'sensenova-tts-2.0';

  static const List<SenseAudioVoice> voices = <SenseAudioVoice>[
    SenseAudioVoice('female_0023_a', '羞涩甜妹', '情感陪伴，声音轻而好奇'),
    SenseAudioVoice('female_0038_a', '亲切女孩', '自然亲切，适合日常聊天'),
    SenseAudioVoice('female_0018_a', '森系少女', '害羞、开心两种情绪'),
    SenseAudioVoice('female_0037_a', '自然少女', '清晰、温柔、真实'),
    SenseAudioVoice('female_0036_a', '青春女声', '开朗活泼，适合日常'),
    SenseAudioVoice('male_0004_a', '儒雅道长', '温润叙事男声'),
    SenseAudioVoice('male_0018_a', '沙哑青年', '深情、略带沙哑'),
    SenseAudioVoice('child_0001_b', '可爱萌娃', '平稳、轻快的童声'),
  ];

  Future<File?> synthesize({
    required String apiKey,
    required String text,
    String voiceId = 'female_0023_a',
    double speed = 1.0,
    double pitch = 0.0,
  }) async {
    final String key = apiKey.trim();
    final String clean = text.trim();
    if (key.isEmpty || clean.isEmpty) return null;

    final double rate = speed.clamp(0.5, 2.0).toDouble();
    final double tone = pitch.clamp(-12.0, 12.0).toDouble();
    final String cacheKey = _cacheKey(clean, voiceId, rate, tone);
    try {
      final Directory directory =
          await FreeEdgeTtsService.instance.cacheDirectory();
      final File target = File(p.join(directory.path, 'sa_$cacheKey.mp3'));
      if (await target.exists() && await target.length() > 0) {
        return target;
      }

      final http.Response response = await http
          .post(
            Uri.parse('$baseUrl/v1/t2a_v2'),
            headers: <String, String>{
              'Authorization': 'Bearer $key',
              'Content-Type': 'application/json; charset=utf-8',
              'Accept': 'application/json',
            },
            body: jsonEncode(<String, Object>{
              'model': defaultModel,
              'text': clean,
              'stream': false,
              'voice_setting': <String, Object>{
                'voice_id': voiceId,
                'speed': rate,
                'vol': 1.0,
                'pitch': tone,
              },
              'audio_setting': <String, Object>{
                'format': 'mp3',
                'sample_rate': 32000,
                'bitrate': 128000,
                'channel': 1,
              },
            }),
          )
          .timeout(const Duration(seconds: 35));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        debugPrint(
          'SenseAudio TTS HTTP ${response.statusCode}: '
          '${_clip(response.body, 180)}',
        );
        return null;
      }

      final Object? decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (decoded is! Map<String, dynamic>) return null;
      final Object? data = decoded['data'];
      if (data is! Map) return null;
      final String? hex = data['audio'] as String?;
      if (hex == null || hex.trim().isEmpty) return null;
      final Uint8List bytes = _decodeAudio(hex);
      if (bytes.isEmpty) return null;
      await target.writeAsBytes(bytes, flush: true);
      return target;
    } catch (error) {
      debugPrint('SenseAudio TTS failed: $error');
      return null;
    }
  }

  Uint8List _decodeAudio(String raw) {
    final String clean = raw.replaceAll(RegExp(r'\s+'), '');
    if (clean.length.isEven &&
        RegExp(r'^[0-9a-fA-F]+$').hasMatch(clean)) {
      final Uint8List bytes = Uint8List(clean.length ~/ 2);
      for (int i = 0; i < bytes.length; i++) {
        bytes[i] = int.parse(clean.substring(i * 2, i * 2 + 2), radix: 16);
      }
      return bytes;
    }
    try {
      return base64Decode(clean);
    } catch (_) {
      return Uint8List(0);
    }
  }

  String _cacheKey(String text, String voice, double speed, double pitch) {
    final String raw = '$text|$voice|${speed.toStringAsFixed(2)}|'
        '${pitch.toStringAsFixed(1)}|$defaultModel';
    return sha256.convert(utf8.encode(raw)).toString().substring(0, 28);
  }

  String _clip(String value, int max) {
    final String clean = value.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (clean.runes.length <= max) return clean;
    return '${String.fromCharCodes(clean.runes.take(max))}…';
  }
}
