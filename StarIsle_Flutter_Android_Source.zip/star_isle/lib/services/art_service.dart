import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../core/theme/app_theme_spec.dart';
import '../core/utils/app_dates.dart';
import 'media_service.dart';

/// 星屿的本地配图引擎。
///
/// DeepSeek 文本模型本身不生成图片，因此动态/聊天的「AI 配图」由本地程序化
/// 插画引擎完成：根据文案、种子、色板生成一张可长期保存的原创氛围画卡。
class ArtService {
  ArtService._();

  static const double _width = 900;
  static const double _height = 1125;

  static Future<String?> generateCard({
    required String text,
    required int seed,
    required int paletteIndex,
    String aiName = '晚晚',
    String kicker = '此刻',
    DateTime? createdAt,
  }) async {
    ui.Image? image;
    try {
      final ui.PictureRecorder recorder = ui.PictureRecorder();
      final ui.Canvas canvas = ui.Canvas(recorder);
      final math.Random random = math.Random(seed);
      final List<Color> palette = AppThemeSpec
          .artPalettes[paletteIndex % AppThemeSpec.artPalettes.length];
      final String quote = _clip(text, 92);

      _paintBackground(canvas, palette, random);
      _paintComposition(canvas, palette, random, seed);
      _paintGrain(canvas, random);
      _paintVignette(canvas);
      _paintTypography(
        canvas,
        palette,
        quote,
        aiName,
        kicker,
        random,
        createdAt ?? DateTime.now(),
      );

      final ui.Picture picture = recorder.endRecording();
      image = await picture.toImage(_width.toInt(), _height.toInt());
      picture.dispose();
      final ByteData? data = await image.toByteData(
        format: ui.ImageByteFormat.png,
      );
      if (data == null) return null;
      final Uint8List bytes = data.buffer.asUint8List();
      final File file = await MediaService.saveBytes(
        bytes,
        folder: 'art',
        prefix: 'starry',
      );
      return file.path;
    } catch (error) {
      debugPrint('local art generation failed: $error');
      return null;
    } finally {
      image?.dispose();
    }
  }

  static void _paintBackground(
    ui.Canvas canvas,
    List<Color> palette,
    math.Random random,
  ) {
    final Rect rect = const Rect.fromLTWH(0, 0, _width, _height);
    final Paint bg = Paint()
      ..shader = ui.Gradient.linear(
        const Offset(0, 0),
        const Offset(_width, _height),
        <Color>[
          palette[0],
          Color.lerp(palette[0], palette[1], 0.55)!,
          Color.lerp(palette[2], Colors.black, 0.38)!,
        ],
        <double>[0.0, 0.52, 1.0],
      );
    canvas.drawRect(rect, bg);

    for (int i = 0; i < 4; i++) {
      final Offset center = Offset(
        random.nextDouble() * _width,
        140 + random.nextDouble() * 760,
      );
      final Color color = i.isEven ? palette[1] : palette[2];
      final double radius = 180 + random.nextDouble() * 310;
      final Paint glow = Paint()
        ..shader = ui.Gradient.radial(
          center,
          radius,
          <Color>[
            color.withOpacity(0.34),
            color.withOpacity(0.08),
            Colors.transparent,
          ],
          <double>[0.0, 0.58, 1.0],
        )
        ..maskFilter = const ui.MaskFilter.blur(ui.BlurStyle.normal, 35);
      canvas.drawCircle(center, radius, glow);
    }
  }

  static void _paintComposition(
    ui.Canvas canvas,
    List<Color> palette,
    math.Random random,
    int seed,
  ) {
    final int variant = seed.abs() % 4;
    final Offset focus = Offset(
      _width * (0.58 + random.nextDouble() * 0.18),
      _height * (0.26 + random.nextDouble() * 0.08),
    );

    if (variant == 0) {
      final Paint halo = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = Colors.white.withOpacity(0.22);
      canvas.drawCircle(focus, 126, halo);
      canvas.drawCircle(
        focus,
        176,
        halo..color = Colors.white.withOpacity(0.09),
      );
      final Paint moon = Paint()
        ..shader = ui.Gradient.radial(focus.translate(-20, -18), 120, <Color>[
          Colors.white.withOpacity(0.96),
          palette[2].withOpacity(0.7),
        ]);
      canvas.drawCircle(focus, 86, moon);
      final Paint orbit = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.8
        ..color = Colors.white.withOpacity(0.32);
      canvas.drawArc(
        Rect.fromCenter(center: focus, width: 520, height: 230),
        -0.32,
        4.5,
        false,
        orbit,
      );
    } else if (variant == 1) {
      for (int layer = 0; layer < 4; layer++) {
        final Path path = Path();
        final double baseY = _height * (0.47 + layer * 0.07);
        path.moveTo(-40, baseY);
        for (double x = -40; x <= _width + 40; x += 24) {
          final double y =
              baseY + math.sin((x / 112) + layer * 0.9) * (22 + layer * 7);
          path.lineTo(x, y);
        }
        final Paint line = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = layer == 0 ? 2.4 : 1.2
          ..color = Colors.white.withOpacity(0.26 - layer * 0.045);
        canvas.drawPath(path, line);
      }
      final Paint sun = Paint()
        ..shader = ui.Gradient.radial(focus, 105, <Color>[
          palette[2].withOpacity(0.95),
          palette[2].withOpacity(0.0),
        ]);
      canvas.drawCircle(focus, 105, sun);
    } else if (variant == 2) {
      final Offset stemBase = Offset(_width * 0.68, _height * 0.54);
      final Paint stemPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = Colors.white.withOpacity(0.32);
      for (int i = 0; i < 5; i++) {
        final Path stem = Path()
          ..moveTo(stemBase.dx, stemBase.dy)
          ..cubicTo(
            stemBase.dx - 44 + i * 22,
            stemBase.dy - 110,
            stemBase.dx + 32 - i * 14,
            stemBase.dy - 200,
            stemBase.dx - 70 + i * 38,
            stemBase.dy - 285 - i * 12,
          );
        canvas.drawPath(stem, stemPaint);
      }
      for (int i = 0; i < 8; i++) {
        final Offset dot = Offset(
          stemBase.dx - 90 + random.nextDouble() * 180,
          stemBase.dy - 60 - random.nextDouble() * 250,
        );
        canvas.drawCircle(
          dot,
          10 + random.nextDouble() * 22,
          Paint()
            ..color = (i.isEven ? palette[2] : Colors.white).withOpacity(
              0.26 + random.nextDouble() * 0.24,
            )
            ..maskFilter = const ui.MaskFilter.blur(ui.BlurStyle.normal, 4),
        );
      }
    } else {
      final Paint thin = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..color = Colors.white.withOpacity(0.2);
      for (int i = 0; i < 5; i++) {
        canvas.drawCircle(focus, 72.0 + i * 44, thin);
      }
      final ui.Path star = ui.Path();
      const int points = 8;
      for (int i = 0; i < points * 2; i++) {
        final double radius = i.isEven ? 190 : 60;
        final double angle = -math.pi / 2 + i * math.pi / points;
        final Offset p =
            focus + Offset(math.cos(angle) * radius, math.sin(angle) * radius);
        if (i == 0) {
          star.moveTo(p.dx, p.dy);
        } else {
          star.lineTo(p.dx, p.dy);
        }
      }
      star.close();
      canvas.drawPath(
        star,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.4
          ..color = Colors.white.withOpacity(0.24),
      );
    }

    for (int i = 0; i < 52; i++) {
      final Offset star = Offset(
        random.nextDouble() * _width,
        40 + random.nextDouble() * _height * 0.6,
      );
      final double size = random.nextDouble() * 2.4 + 0.7;
      canvas.drawCircle(
        star,
        size,
        Paint()
          ..color = Colors.white.withOpacity(0.2 + random.nextDouble() * 0.5),
      );
    }

    final Paint horizon = Paint()
      ..shader = ui.Gradient.linear(
        Offset(0, _height * 0.53),
        Offset(0, _height),
        <Color>[Colors.transparent, Colors.black.withOpacity(0.32)],
      );
    canvas.drawRect(
      Rect.fromLTWH(0, _height * 0.48, _width, _height * 0.52),
      horizon,
    );
  }

  static void _paintGrain(ui.Canvas canvas, math.Random random) {
    for (int i = 0; i < 460; i++) {
      final Offset point = Offset(
        random.nextDouble() * _width,
        random.nextDouble() * _height,
      );
      canvas.drawCircle(
        point,
        random.nextDouble() * 1.15 + 0.2,
        Paint()..color = Colors.white.withOpacity(random.nextDouble() * 0.08),
      );
    }
  }

  static void _paintTypography(
    ui.Canvas canvas,
    List<Color> palette,
    String quote,
    String aiName,
    String kicker,
    math.Random random,
    DateTime createdAt,
  ) {
    final String date =
        '${AppDates.two(createdAt.month)} / ${AppDates.two(createdAt.day)}';

    TextPainter label = TextPainter(
      text: TextSpan(
        text: 'S T A R   I S L E',
        style: TextStyle(
          color: Colors.white.withOpacity(0.72),
          fontSize: 20,
          fontWeight: FontWeight.w600,
          letterSpacing: 2.2,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: 600);
    label.paint(canvas, const Offset(70, 68));

    TextPainter dateText = TextPainter(
      text: TextSpan(
        text: date,
        style: TextStyle(
          color: Colors.white.withOpacity(0.7),
          fontSize: 22,
          letterSpacing: 2,
          fontWeight: FontWeight.w400,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: 200);
    dateText.paint(canvas, Offset(_width - dateText.width - 70, 68));

    final Paint line = Paint()
      ..color = Colors.white.withOpacity(0.17)
      ..strokeWidth = 1;
    canvas.drawLine(const Offset(70, 116), Offset(_width - 70, 116), line);

    TextPainter quoteMark = TextPainter(
      text: TextSpan(
        text: '“',
        style: TextStyle(
          color: palette[2].withOpacity(0.6),
          fontSize: 164,
          fontFamilyFallback: const <String>['serif'],
          fontWeight: FontWeight.w200,
          height: 1,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    quoteMark.paint(canvas, const Offset(58, 500));

    TextPainter kickerText = TextPainter(
      text: TextSpan(
        text: '${aiName.toUpperCase()} · $kicker',
        style: TextStyle(
          color: palette[2].withOpacity(0.9),
          fontSize: 20,
          fontWeight: FontWeight.w600,
          letterSpacing: 1.2,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: _width - 140);
    kickerText.paint(canvas, const Offset(70, 640));

    final ui.Path gradientPath = ui.Path()
      ..addRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(_width - 258, 596, 188, 132),
          const Radius.circular(26),
        ),
      );
    canvas.drawPath(
      gradientPath,
      Paint()
        ..shader = ui.Gradient.linear(
          Offset(_width - 258, 596),
          Offset(_width - 70, 728),
          <Color>[Colors.white.withOpacity(0.16), palette[2].withOpacity(0.20)],
        ),
    );

    TextPainter mainText = TextPainter(
      text: TextSpan(
        text: quote,
        style: TextStyle(
          color: Colors.white.withOpacity(0.96),
          fontSize: 42,
          height: 1.55,
          fontWeight: FontWeight.w600,
          fontFamilyFallback: const <String>['Noto Sans SC', 'sans-serif'],
        ),
      ),
      maxLines: 4,
      ellipsis: '…',
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: _width - 140);
    mainText.paint(canvas, const Offset(70, 690));

    final double footerY = 984 + random.nextDouble() * 18;
    TextPainter footer = TextPainter(
      text: TextSpan(
        children: <InlineSpan>[
          TextSpan(
            text: '星屿',
            style: TextStyle(
              color: Colors.white.withOpacity(0.88),
              fontSize: 20,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.4,
            ),
          ),
          TextSpan(
            text: '   只对你可见',
            style: TextStyle(
              color: Colors.white.withOpacity(0.44),
              fontSize: 17,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: _width - 140);
    footer.paint(canvas, Offset(70, footerY));

    canvas.drawCircle(
      Offset(_width - 82, footerY + 10),
      30,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withOpacity(0.22),
    );
    canvas.drawCircle(
      Offset(_width - 82, footerY + 10),
      3.2,
      Paint()..color = palette[2].withOpacity(0.8),
    );
  }

  static void _paintVignette(ui.Canvas canvas) {
    final Rect rect = const Rect.fromLTWH(0, 0, _width, _height);
    final Paint vignette = Paint()
      ..shader = ui.Gradient.radial(
        const Offset(_width / 2, _height / 2),
        _height * 0.72,
        <Color>[
          Colors.transparent,
          Colors.black.withOpacity(0.13),
          Colors.black.withOpacity(0.45),
        ],
        <double>[0.0, 0.62, 1.0],
      );
    canvas.drawRect(rect, vignette);

    final Paint bottom = Paint()
      ..shader = ui.Gradient.linear(
        const Offset(0, _height - 350),
        const Offset(0, _height),
        <Color>[Colors.transparent, Colors.black.withOpacity(0.35)],
      );
    canvas.drawRect(Rect.fromLTWH(0, _height - 350, _width, 350), bottom);
  }

  static String _clip(String text, int maxRunes) {
    final String clean = text.trim().replaceAll(RegExp(r'\s+'), ' ');
    final List<int> runes = clean.runes.toList();
    if (runes.length <= maxRunes) return clean;
    return '${String.fromCharCodes(runes.take(maxRunes))}…';
  }
}
