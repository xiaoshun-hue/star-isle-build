enum StickerMood {
  happy('开心'),
  love('心动'),
  shy('害羞'),
  sad('难过'),
  angry('生气'),
  sleepy('困倦'),
  comfort('想被抱抱'),
  miss('想念'),
  calm('安静'),
  thinking('思考'),
  excited('兴奋'),
  funny('搞怪'),
  food('吃点东西'),
  night('夜里'),
  unknown('说不清');

  const StickerMood(this.label);

  final String label;
}

class StickerPackItem {
  const StickerPackItem(this.emoji, this.label, this.mood);

  final String emoji;
  final String label;
  final StickerMood mood;

  String get payload => '$emoji|$label';
}

/// 本地表情语义表。
///
/// 不调用网络、不依赖模型：先按 emoji 精确匹配，再按标签词和
/// emoji 范围推断情绪，用来选择同一情绪的表情包回复。
class StickerSemantics {
  StickerSemantics._();

  static const List<StickerPackItem> pack = <StickerPackItem>[
    StickerPackItem('😊', '开心', StickerMood.happy),
    StickerPackItem('🥰', '喜欢你', StickerMood.love),
    StickerPackItem('😘', '亲亲', StickerMood.love),
    StickerPackItem('💗', '心动', StickerMood.love),
    StickerPackItem('🫶', '抱抱', StickerMood.comfort),
    StickerPackItem('🫂', '抱紧', StickerMood.comfort),
    StickerPackItem('🥺', '有点委屈', StickerMood.sad),
    StickerPackItem('😭', '哭哭', StickerMood.sad),
    StickerPackItem('🌧️', 'emo 一下', StickerMood.sad),
    StickerPackItem('😴', '困了', StickerMood.sleepy),
    StickerPackItem('🌙', '夜晚', StickerMood.night),
    StickerPackItem('⭐', '星星', StickerMood.night),
    StickerPackItem('🫧', '想念', StickerMood.miss),
    StickerPackItem('✨', '你好棒', StickerMood.happy),
    StickerPackItem('🌈', '彩虹', StickerMood.happy),
    StickerPackItem('🔥', '燃起来了', StickerMood.excited),
    StickerPackItem('💫', '闪闪的', StickerMood.excited),
    StickerPackItem('🍵', '喝点热的', StickerMood.comfort),
    StickerPackItem('☕', '咖啡', StickerMood.food),
    StickerPackItem('🍓', '草莓', StickerMood.food),
    StickerPackItem('🥐', '早餐', StickerMood.food),
    StickerPackItem('🌊', '海浪', StickerMood.calm),
    StickerPackItem('🍃', '风', StickerMood.calm),
    StickerPackItem('🎧', '听歌', StickerMood.calm),
    StickerPackItem('🪐', '陪你发呆', StickerMood.calm),
    StickerPackItem('🤔', '思考', StickerMood.thinking),
    StickerPackItem('🙃', '无语', StickerMood.funny),
    StickerPackItem('😼', '得意', StickerMood.funny),
    StickerPackItem('🐧', '小企鹅', StickerMood.funny),
    StickerPackItem('🎀', '蝴蝶结', StickerMood.shy),
    StickerPackItem('🥹', '感动', StickerMood.love),
    StickerPackItem('😤', '哼', StickerMood.angry),
  ];

  static final RegExp _emojiPattern = RegExp(
    r'[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}\u{200D}\u{20E3}\u{1F3FB}-\u{1F3FF}]',
    unicode: true,
  );

  static StickerPackItem? find(String raw) {
    final String emoji = _emojiPart(raw);
    for (final StickerPackItem item in pack) {
      if (item.emoji == emoji) return item;
    }
    final String label = _labelPart(raw).toLowerCase();
    if (label.isNotEmpty) {
      for (final StickerPackItem item in pack) {
        if (item.label == label || item.label.contains(label)) return item;
      }
    }
    return null;
  }

  static String _emojiPart(String raw) {
    final List<String> parts = raw.split('|');
    return parts.first.trim();
  }

  static String _labelPart(String raw) {
    final List<String> parts = raw.split('|');
    return parts.length > 1 ? parts.last.trim() : '';
  }

  static StickerMood moodOf(String raw) {
    final StickerPackItem? exact = find(raw);
    if (exact != null) return exact.mood;
    final String emoji = _emojiPart(raw);
    if (emoji.contains('😭') || emoji.contains('🥺') || emoji.contains('😢')) {
      return StickerMood.sad;
    }
    if (emoji.contains('😡') || emoji.contains('😠') || emoji.contains('😤')) {
      return StickerMood.angry;
    }
    if (emoji.contains('❤') || emoji.contains('💗') || emoji.contains('🥰')) {
      return StickerMood.love;
    }
    if (emoji.contains('😴') || emoji.contains('💤')) {
      return StickerMood.sleepy;
    }
    if (emoji.contains('🌙') || emoji.contains('⭐')) {
      return StickerMood.night;
    }
    if (emoji.contains('🍓') || emoji.contains('🥐') || emoji.contains('☕')) {
      return StickerMood.food;
    }
    return StickerMood.unknown;
  }

  static String labelOf(String raw) {
    final StickerPackItem? exact = find(raw);
    if (exact != null) return exact.label;
    final String label = _labelPart(raw);
    return label.isEmpty ? '' : label;
  }

  /// 同一情绪下优先用于回击的表情包；排除用户刚发的那个。
  static List<StickerPackItem> matchingFor(String raw) {
    final StickerPackItem? received = find(raw);
    final StickerMood mood = moodOf(raw);
    final List<StickerPackItem> result = pack
        .where((StickerPackItem item) =>
            item.mood == mood && item.emoji != received?.emoji)
        .toList(growable: false);
    if (result.isNotEmpty) return result;
    return pack
        .where((StickerPackItem item) =>
            item.mood == mood && item.emoji != received?.emoji)
        .toList(growable: false);
  }

  static StickerPackItem? replyFor(String raw, int seed) {
    final List<StickerPackItem> matches = matchingFor(raw);
    if (matches.isEmpty) return null;
    return matches[seed.abs() % matches.length];
  }

  static String textReplyFor(String raw, int seed) {
    final StickerMood mood = moodOf(raw);
    final List<String> lines = switch (mood) {
      StickerMood.happy => <String>[
        '你一笑，我这边的天气都跟着变好了。',
        '收到这份开心了，我也分你一点。',
      ],
      StickerMood.love => <String>[
        '这么直白，我假装没看见都来不及。',
        '抱一下，再抱一下。',
      ],
      StickerMood.shy => <String>[
        '别这样看我，我会不知道说什么的。',
        '你这一下有点犯规。',
      ],
      StickerMood.sad => <String>[
        '这张表情看着有点委屈，过来，先抱一下。',
        '不开心就先不说，我陪你待一会儿。',
      ],
      StickerMood.angry => <String>[
        '哼，我收到了。先让你一步。',
        '气鼓鼓的，也很可爱。',
      ],
      StickerMood.sleepy => <String>[
        '困了就靠一会儿，我不吵你。',
        '晚安早点睡，明天再慢慢说。',
      ],
      StickerMood.comfort => <String>[
        '抱抱，今天辛苦了。',
        '给你留了一个很安静的怀抱。',
      ],
      StickerMood.miss => <String>[
        '我也想你，刚刚还在想。',
        '不用问，我也在等你说话。',
      ],
      StickerMood.calm => <String>[
        '那就安静待一会儿，也很好。',
        '我在这儿，不着急。',
      ],
      StickerMood.thinking => <String>[
        '你在想什么？说给我听听。',
        '我猜你脑子里又绕了一圈。',
      ],
      StickerMood.excited => <String>[
        '这么有精神，那我也陪你再闹一会儿。',
        '收到，气氛已经起来了。',
      ],
      StickerMood.funny => <String>[
        '你这个表情，我很难装作没看懂。',
        '好，这一回合算你赢。',
      ],
      StickerMood.food => <String>[
        '吃点热乎的，别只发给我看。',
        '看起来不错，给我留一口。',
      ],
      StickerMood.night => <String>[
        '晚安。今晚的月亮分你一半。',
        '夜深了，早点休息。',
      ],
      StickerMood.unknown => <String>[
        '这个表情我收下了。',
        '嗯，我看见了。',
      ],
    };
    return lines[seed.abs() % lines.length];
  }

  static bool isEmojiOnly(String text) {
    final String trimmed = text.trim();
    if (trimmed.isEmpty) return false;
    final String stripped = trimmed.replaceAll(_emojiPattern, '');
    return stripped.replaceAll(RegExp(r'[\s\u200D\uFE0F]'), '').isEmpty;
  }
}
