import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/theme/app_theme_spec.dart';
import '../services/free_edge_tts_service.dart';
import '../services/sense_audio_tts_service.dart';

class SettingsController extends ChangeNotifier {
  SettingsController._(this._prefs);

  final SharedPreferences _prefs;
  static const String _prefix = 'star_isle.';

  static Future<SettingsController> load() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return SettingsController._(prefs);
  }

  // ---------------------------------------------------------------------------
  // 基础资料
  // ---------------------------------------------------------------------------
  String get userName => _prefs.getString('${_prefix}user_name') ?? '阿屿';
  String get themeId =>
      _prefs.getString('${_prefix}theme_id') ?? AppThemeSpec.dusk.id;
  AppThemeSpec get themeSpec => AppThemeSpec.byId(themeId);

  ThemeMode get themeMode {
    final String raw = _prefs.getString('${_prefix}theme_mode') ?? 'dark';
    return switch (raw) {
      'light' => ThemeMode.light,
      'system' => ThemeMode.system,
      _ => ThemeMode.dark,
    };
  }

  bool get onboardingDone =>
      _prefs.getBool('${_prefix}onboarding_done') ?? false;

  // ---------------------------------------------------------------------------
  // 连接与模型
  // ---------------------------------------------------------------------------
  bool get isOnlineMode => _prefs.getBool('${_prefix}online_mode') ?? false;
  String get apiKey => _prefs.getString('${_prefix}api_key') ?? '';
  String get baseUrl =>
      _prefs.getString('${_prefix}base_url') ?? 'https://api.deepseek.com';
  String get model => _prefs.getString('${_prefix}model') ?? 'deepseek-chat';
  bool get hasApiKey => apiKey.trim().isNotEmpty;
  bool get onlineReady => isOnlineMode && hasApiKey;

  // ---------------------------------------------------------------------------
  // 陪伴偏好
  // ---------------------------------------------------------------------------
  bool get proactiveEnabled => _prefs.getBool('${_prefix}proactive') ?? true;
  /// 默认关闭，保持老用户原版行为；在设置中手动开启后才申请权限。
  bool get notificationsEnabled =>
      _prefs.getBool('${_prefix}notifications') ?? false;
  bool get autoMoments => _prefs.getBool('${_prefix}auto_moments') ?? true;
  bool get autoProfile => _prefs.getBool('${_prefix}auto_profile') ?? true;
  bool get autoSpeak => _prefs.getBool('${_prefix}auto_speak') ?? false;
  bool get haptics => _prefs.getBool('${_prefix}haptics') ?? true;

  /// 朗读引擎：system（默认）、edge（免费音色）或 sense（SenseAudio）。
  String get ttsEngine => _prefs.getString('${_prefix}tts_engine') ?? 'system';
  String get ttsEngineLabel => switch (ttsEngine) {
    'edge' => '免费 AI 音色',
    'sense' => 'SenseAudio 云端',
    _ => '系统本地朗读',
  };

  String get edgeVoice =>
      _prefs.getString('${_prefix}edge_voice') ?? 'zh-CN-XiaoxiaoNeural';
  String get edgeVoiceLabel =>
      EdgeTtsVoice.byId(edgeVoice)?.name ?? '晓晓';
  double get edgeRate => _prefs.getDouble('${_prefix}edge_rate') ?? 1.0;
  double get edgePitch => _prefs.getDouble('${_prefix}edge_pitch') ?? 0.0;

  /// 主动消息形式：text（默认）/ voice / random。
  String get proactiveMessageMode =>
      _prefs.getString('${_prefix}proactive_message_mode') ?? 'text';
  String get proactiveMessageModeLabel => switch (proactiveMessageMode) {
    'voice' => '语音气泡',
    'random' => '随机文字/语音',
    _ => '文字消息',
  };

  /// 普通聊天回复也用语音条。默认关闭，保持原版文字行为。
  bool get replyVoiceEnabled =>
      _prefs.getBool('${_prefix}reply_voice') ?? false;

  int get proactiveIntervalMinutes =>
      _prefs.getInt('${_prefix}proactive_interval') ?? 180;

  Duration get proactiveInterval => Duration(minutes: proactiveIntervalMinutes);

  DateTime? get nextProactiveAt {
    final String? raw = _prefs.getString('${_prefix}next_proactive_at');
    if (raw == null) return null;
    return DateTime.tryParse(raw);
  }

  // ---------------------------------------------------------------------------
  // 写入
  // ---------------------------------------------------------------------------
  Future<void> setUserName(String value) async {
    final String clean = value.trim();
    if (clean.isEmpty) return;
    await _prefs.setString('${_prefix}user_name', clean);
    notifyListeners();
  }

  Future<void> setThemeId(String value) async {
    if (!AppThemeSpec.all.any((AppThemeSpec item) => item.id == value)) return;
    await _prefs.setString('${_prefix}theme_id', value);
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    final String raw = switch (mode) {
      ThemeMode.light => 'light',
      ThemeMode.system => 'system',
      ThemeMode.dark => 'dark',
    };
    await _prefs.setString('${_prefix}theme_mode', raw);
    notifyListeners();
  }

  Future<void> completeOnboarding() async {
    await _prefs.setBool('${_prefix}onboarding_done', true);
    notifyListeners();
  }

  Future<void> saveApiConfig({
    required bool online,
    required String apiKey,
    required String baseUrl,
    required String model,
  }) async {
    await _prefs.setBool('${_prefix}online_mode', online);
    await _prefs.setString('${_prefix}api_key', apiKey.trim());
    await _prefs.setString(
      '${_prefix}base_url',
      baseUrl.trim().isEmpty ? 'https://api.deepseek.com' : baseUrl.trim(),
    );
    await _prefs.setString(
      '${_prefix}model',
      model.trim().isEmpty ? 'deepseek-chat' : model.trim(),
    );
    notifyListeners();
  }

  String get voiceApiKey =>
      _prefs.getString('${_prefix}voice_api_key') ?? '';
  bool get hasVoiceApiKey => voiceApiKey.trim().isNotEmpty;

  Future<void> saveVoiceApiKey(String value) async {
    await _prefs.setString('${_prefix}voice_api_key', value.trim());
    notifyListeners();
  }

  Future<void> setOnlineMode(bool value) async {
    await _prefs.setBool('${_prefix}online_mode', value);
    notifyListeners();
  }

  Future<void> setProactiveEnabled(bool value) async {
    await _prefs.setBool('${_prefix}proactive', value);
    notifyListeners();
  }

  Future<void> setNotificationsEnabled(bool value) async {
    await _prefs.setBool('${_prefix}notifications', value);
    notifyListeners();
  }

  Future<void> setAutoMoments(bool value) async {
    await _prefs.setBool('${_prefix}auto_moments', value);
    notifyListeners();
  }

  Future<void> setAutoProfile(bool value) async {
    await _prefs.setBool('${_prefix}auto_profile', value);
    notifyListeners();
  }

  Future<void> setAutoSpeak(bool value) async {
    await _prefs.setBool('${_prefix}auto_speak', value);
    notifyListeners();
  }

  Future<void> setHaptics(bool value) async {
    await _prefs.setBool('${_prefix}haptics', value);
    notifyListeners();
  }

  Future<void> setTtsEngine(String value) async {
    final String engine = switch (value) {
      'sense' => 'sense',
      'edge' => 'edge',
      _ => 'system',
    };
    await _prefs.setString('${_prefix}tts_engine', engine);
    notifyListeners();
  }

  Future<void> saveSenseAudioApiKey(String value) async {
    await _prefs.setString('${_prefix}sense_audio_key', value.trim());
    notifyListeners();
  }

  Future<void> setSenseVoice(String value) async {
    if (SenseAudioVoice.byId(value) == null) return;
    await _prefs.setString('${_prefix}sense_voice', value);
    notifyListeners();
  }

  Future<void> setSenseRate(double value) async {
    await _prefs.setDouble(
      '${_prefix}sense_rate',
      value.clamp(0.5, 2.0).toDouble(),
    );
    notifyListeners();
  }

  Future<void> setSensePitch(double value) async {
    await _prefs.setDouble(
      '${_prefix}sense_pitch',
      value.clamp(-12.0, 12.0).toDouble(),
    );
    notifyListeners();
  }

  Future<void> setEdgeVoice(String value) async {
    if (EdgeTtsVoice.byId(value) == null) return;
    await _prefs.setString('${_prefix}edge_voice', value);
    notifyListeners();
  }

  Future<void> setEdgeRate(double value) async {
    await _prefs.setDouble(
      '${_prefix}edge_rate',
      value.clamp(0.7, 1.3).toDouble(),
    );
    notifyListeners();
  }

  Future<void> setEdgePitch(double value) async {
    await _prefs.setDouble(
      '${_prefix}edge_pitch',
      value.clamp(-12.0, 12.0).toDouble(),
    );
    notifyListeners();
  }

  Future<void> setReplyVoiceEnabled(bool value) async {
    await _prefs.setBool('${_prefix}reply_voice', value);
    notifyListeners();
  }

  Future<void> setProactiveMessageMode(String value) async {
    final String mode = switch (value) {
      'voice' => 'voice',
      'random' => 'random',
      _ => 'text',
    };
    await _prefs.setString('${_prefix}proactive_message_mode', mode);
    notifyListeners();
  }

  Future<void> setProactiveInterval(int minutes) async {
    await _prefs.setInt('${_prefix}proactive_interval', minutes);
    notifyListeners();
  }

  Future<void> setNextProactiveAt(DateTime? value) async {
    if (value == null) {
      await _prefs.remove('${_prefix}next_proactive_at');
    } else {
      await _prefs.setString(
        '${_prefix}next_proactive_at',
        value.toIso8601String(),
      );
    }
    // 不需要触发重建；这只是调度信息。
  }

  String get connectionLabel {
    if (!isOnlineMode) return '单机模式';
    if (!hasApiKey) return '联网模式 · 待配置';
    return 'DeepSeek 在线';
  }

  String get proactiveIntervalLabel => switch (proactiveIntervalMinutes) {
    30 => '30 分钟',
    60 => '1 小时',
    120 => '2 小时',
    180 => '3 小时',
    360 => '6 小时',
    720 => '12 小时',
    _ => '$proactiveIntervalMinutes 分钟',
  };
}
