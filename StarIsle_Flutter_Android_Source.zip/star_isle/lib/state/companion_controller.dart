import 'dart:async';
import 'dart:collection';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';

import '../core/decoration_pack.dart';
import '../core/utils/app_dates.dart';
import '../core/utils/id_generator.dart';
import '../data/app_repository.dart';
import '../data/models/album_entry.dart';
import '../data/models/anniversary_entry.dart';
import '../data/models/chat_message.dart';
import '../data/models/companion_profile.dart';
import '../data/models/memory_entry.dart';
import '../services/ai/ai_service.dart';
import '../services/ai/ai_types.dart';
import '../services/ai/memory_extractor.dart';
import '../services/notification_service.dart';
import '../services/voice_message_service.dart';
import '../services/art_service.dart';
import '../services/media_service.dart';
import '../services/tts_service.dart';
import 'settings_controller.dart';

class CompanionController extends ChangeNotifier {
  CompanionController({
    required this.repository,
    required this.settings,
    required this.aiService,
    required this.ttsService,
  }) {
    settings.addListener(_onSettingsChanged);
  }

  final AppRepository repository;
  final SettingsController settings;
  final AiService aiService;
  final TtsService ttsService;

  final Random _random = Random();
  final List<ChatMessage> _messages = <ChatMessage>[];
  final List<MemoryEntry> _memories = <MemoryEntry>[];

  CompanionProfile? _profile;
  Timer? _pulseTimer;
  Timer? _proactiveKickTimer;
  Timer? _resumeTimer;
  Timer? _autoEvolutionTimer;
  Timer? _recoveryTimer;
  bool _initialized = false;
  bool _disposed = false;
  bool _replying = false;
  bool _typing = false;
  bool _chatVisible = false;
  bool _appActive = true;
  bool _anniversaryChecked = false;
  bool _evolving = false;
  int _unreadCount = 0;
  DateTime? _lastFallbackNoticeAt;
  DateTime? _lastStamp;

  // 主动消息防骚扰：最短间隔 + 每日上限 + 前后台概率。
  static const Duration _minProactiveGap = Duration(minutes: 15);
  static const int _maxProactivePerDay = 10;
  // 自动进化至少 30 小时一次，避免每次聊天都换签名/头像。
  static const Duration _autoEvolutionCooldown = Duration(hours: 30);

  DateTime? _lastProactiveAt;
  DateTime? _proactiveDay;
  int _proactiveSentToday = 0;

  /// 上一次轮换用过的用户头像路径。仅内存保存，App 重启后清空。
  String? _lastUsedAvatarPath;

  bool get initialized => _initialized;
  bool get isReplying => _replying;
  bool get isTyping => _typing;
  bool get chatVisible => _chatVisible;
  int get unreadCount => _unreadCount;
  CompanionProfile get profile => _profile ?? CompanionProfile.initial();
  List<ChatMessage> get messages =>
      UnmodifiableListView<ChatMessage>(_messages);
  List<MemoryEntry> get memories =>
      UnmodifiableListView<MemoryEntry>(_memories);
  bool get canUseOnline => settings.onlineReady;

  Future<void> initialize() async {
    if (_initialized) return;
    _profile = await repository.getProfile();
    if (_profile == null) {
      _profile = CompanionProfile.initial();
      await repository.saveProfile(_profile!);
    }
    _messages
      ..clear()
      ..addAll(await repository.loadMessages());
    _memories
      ..clear()
      ..addAll(await repository.loadMemories());
    _unreadCount = await repository.unreadAiMessages();

    if (_messages.isNotEmpty) {
      _lastStamp = _messages.last.createdAt;
    }

    if (_messages.isEmpty && settings.onboardingDone && _profile != null) {
      await _seedWelcomeMessages();
    }

    _initialized = true;
    _notify();
    if (settings.onboardingDone) {
      _startSchedulers();
      _scheduleOrphanReplyRecovery();
    }
  }

  void _scheduleOrphanReplyRecovery() {
    if (_messages.isEmpty || !_messages.last.isUser) return;
    _recoveryTimer?.cancel();
    _recoveryTimer = Timer(const Duration(seconds: 5), () {
      if (_disposed || _replying || !_initialized) return;
      if (_messages.isNotEmpty && _messages.last.isUser) {
        unawaited(
          _generateCompanionReply(
            imageAttached: _messages.last.kind == MessageKind.image,
          ),
        );
      }
    });
  }

  Future<void> completeOnboarding({
    required String aiName,
    required int avatarSeed,
  }) async {
    final String name = aiName.trim().isEmpty
        ? profile.nickname
        : aiName.trim();
    final CompanionProfile updated = profile.copyWith(
      nickname: name,
      avatarSeed: avatarSeed,
    );
    _profile = updated;
    await repository.saveProfile(updated);
    if (settings.proactiveEnabled && settings.nextProactiveAt == null) {
      await settings.setNextProactiveAt(
        DateTime.now().add(
          Duration(minutes: min(3, settings.proactiveIntervalMinutes)),
        ),
      );
    }
    await settings.completeOnboarding();

    if (_messages.isEmpty) {
      await _seedWelcomeMessages();
    }
    _startSchedulers();
    _notify();
  }

  void _startSchedulers() {
    _pulseTimer?.cancel();
    _pulseTimer = Timer.periodic(const Duration(seconds: 45), (_) {
      unawaited(_tick());
    });
    _proactiveKickTimer?.cancel();
    _proactiveKickTimer = Timer(const Duration(seconds: 6), () {
      unawaited(_checkAnniversaryReminder());
    });
    _autoEvolutionTimer?.cancel();
    _autoEvolutionTimer = Timer(const Duration(seconds: 9), () {
      unawaited(_maybeAutoEvolve());
    });
    if (settings.proactiveEnabled) {
      unawaited(_ensureProactiveScheduled(initial: true));
    } else {
      unawaited(settings.setNextProactiveAt(null));
    }
  }

  Future<void> _seedWelcomeMessages() async {
    final List<String> greeting = <String>[
      '你来啦。',
      '我把今天的晚风留在窗边，等你很久了。\n以后这里只有我们两个人。',
    ];
    for (final String text in greeting) {
      final ChatMessage message = _buildMessage(
        role: MessageRole.ai,
        content: text,
        isRead: false,
      );
      await repository.insertMessage(message);
      _messages.add(message);
      _unreadCount++;
    }
  }

  // ---------------------------------------------------------------------------
  // 聊天
  // ---------------------------------------------------------------------------
  Future<bool> sendText(String raw) async {
    final String text = raw.trim();
    if (text.isEmpty || _replying || !_initialized) return false;
    final ChatMessage message = _buildMessage(
      role: MessageRole.user,
      content: text.length > 1200 ? text.substring(0, 1200) : text,
      isRead: true,
    );
    await _insertMessage(message);
    await settings.setNextProactiveAt(DateTime.now().add(_proactiveDuration()));
    unawaited(_generateCompanionReply(imageAttached: false));
    return true;
  }

  /// 发送用户录制的语音条。文字稿用于 AI 理解，音频用于聊天气泡播放。
  Future<bool> sendVoiceMessage({
    required String rawText,
    required String audioPath,
    required int durationMs,
  }) async {
    final String text = rawText.trim();
    if (text.isEmpty || _replying || !_initialized) return false;
    final ChatMessage message = _buildMessage(
      role: MessageRole.user,
      content: text.length > 1200 ? text.substring(0, 1200) : text,
      isRead: true,
    );
    await _insertMessage(message);
    VoiceBubbleRegistry.instance.registerReady(
      messageId: message.id,
      text: text,
      audioPath: audioPath,
      durationMs: durationMs,
    );
    await settings.setNextProactiveAt(DateTime.now().add(_proactiveDuration()));
    unawaited(_generateCompanionReply(imageAttached: false));
    return true;
  }

  Future<bool> pickAndSendImage() async {
    if (_replying || !_initialized) return false;
    final file = await MediaService.pickImageFromGallery();
    if (file == null) return false;
    final ChatMessage message = _buildMessage(
      role: MessageRole.user,
      kind: MessageKind.image,
      content: '一张照片',
      imagePath: file.path,
      isRead: true,
    );
    await _insertMessage(message);
    await _saveToAlbum(
      path: file.path,
      title: '聊天里的照片 · ${AppDates.monthDay(DateTime.now())}',
      source: 'chat',
    );
    unawaited(_generateCompanionReply(imageAttached: true));
    return true;
  }

  Future<bool> sendSticker(String emoji) async {
    if (_replying || !_initialized) return false;
    _replying = true;
    _notify();
    try {
      final ChatMessage sticker = _buildMessage(
        role: MessageRole.user,
        kind: MessageKind.sticker,
        content: emoji,
        isRead: true,
      );
      await _insertMessage(sticker);
      _typing = true;
      _notify();
      await Future<void>.delayed(
        Duration(milliseconds: 700 + _random.nextInt(500)),
      );
      if (_disposed) return true;

      final bool replyWithSticker = _random.nextDouble() < 0.28;
      _typing = false;
      if (replyWithSticker) {
        final ChatMessage reply = _buildMessage(
          role: MessageRole.ai,
          kind: MessageKind.sticker,
          content: _random.nextBool() ? emoji : _pickStickerBack(),
          isRead: _chatVisible,
        );
        await _insertMessage(reply);
      } else {
        final ChatMessage reply = _buildMessage(
          role: MessageRole.ai,
          content: _pick('sticker_reply', <String>[
            '收到啦。也贴贴你。',
            '这个表情好可爱，我收下了。',
            '你一发这个，我就没办法假装在忙了。',
            '屏幕那边的人，笑什么呀。',
          ]),
          isRead: _chatVisible,
        );
        await _insertMessage(reply);
      }
      await _updateProfileAfterSmallMoment(mood: '被你逗笑了');
      await _scheduleNextProactive();
    } finally {
      _typing = false;
      _replying = false;
      _notify();
    }
    return true;
  }

  /// 从相册选择一张本地图片，作为图片表情包发出。
  /// 仍然使用 ChatMessage.imagePath，不新增模型字段。
  Future<bool> pickAndSendStickerImage() async {
    if (_replying || !_initialized) return false;
    final File? file = await MediaService.pickImageFromGallery();
    if (file == null) return false;
    _replying = true;
    _notify();
    try {
      final ChatMessage sticker = _buildMessage(
        role: MessageRole.user,
        kind: MessageKind.sticker,
        content: '图片表情',
        imagePath: file.path,
        isRead: true,
      );
      await _insertMessage(sticker);
      _typing = true;
      _notify();
      await Future<void>.delayed(
        Duration(milliseconds: 700 + _random.nextInt(500)),
      );
      if (_disposed) return true;

      _typing = false;
      if (_random.nextDouble() < 0.3) {
        final ChatMessage reply = _buildMessage(
          role: MessageRole.ai,
          kind: MessageKind.sticker,
          content: _pickStickerBack(),
          isRead: _chatVisible,
        );
        await _insertMessage(reply);
      } else {
        final ChatMessage reply = _buildMessage(
          role: MessageRole.ai,
          content: _pick('sticker_image_reply', <String>[
            '这个表情包我收下了。\\n看起来就不太像会好好说话的样子。',
            '收到，已加入我们的私下斗图素材库。',
            '你这张图一出来，我就知道接下来没几句正经话了。',
            '好，我承认这张有一点好笑。\\n只承认一点。',
          ]),
          isRead: _chatVisible,
        );
        await _insertMessage(reply);
      }
      await _updateProfileAfterSmallMoment(mood: '被你逗笑了');
      await _scheduleNextProactive();
    } finally {
      _typing = false;
      _replying = false;
      _notify();
    }
    return true;
  }

  Future<void> _generateCompanionReply({required bool imageAttached}) async {
    if (_replying || _disposed) return;
    _replying = true;
    _typing = true;
    _notify();
    try {
      final ChatAiContext context = ChatAiContext(
        userMessage: imageAttached ? '（发来一张照片）' : _latestUserText(),
        profile: profile,
        userName: settings.userName,
        recentMessages: List<ChatMessage>.from(_messages),
        memories: List<MemoryEntry>.from(_memories),
        imageAttached: imageAttached,
      );
      final AiTurnResult result = await aiService.chat(context);
      if (_disposed) return;

      final int chars = result.bubbles.join().length;
      final int minDelay = result.source == AiSource.online ? 450 : 850;
      final int extra = min(1000, chars * 8);
      await Future<void>.delayed(
        Duration(milliseconds: minDelay + extra + _random.nextInt(350)),
      );
      if (_disposed) return;

      if (result.fallbackNotice != null &&
          result.fallbackNotice!.trim().isNotEmpty &&
          (_lastFallbackNoticeAt == null ||
              DateTime.now().difference(_lastFallbackNoticeAt!).inMinutes >
                  8)) {
        _lastFallbackNoticeAt = DateTime.now();
        await _insertMessage(
          _buildMessage(
            role: MessageRole.system,
            content: result.fallbackNotice!,
            isRead: true,
          ),
        );
      }

      String? lastAiTextId;
      final StringBuffer spokenText = StringBuffer();
      final bool useVoiceReply = settings.replyVoiceEnabled;
      if (useVoiceReply) {
        final String subtitle = result.bubbles.join('\n').trim();
        _typing = false;
        final ChatMessage message = _buildMessage(
          role: MessageRole.ai,
          content: subtitle,
          isRead: _chatVisible,
        );
        await _insertMessage(message);
        lastAiTextId = message.id;
        spokenText.write(result.bubbles.join(' '));
        unawaited(
          VoiceBubbleRegistry.instance.prepare(
            messageId: message.id,
            text: subtitle,
            voice: settings.edgeVoice,
            rate: settings.edgeRate,
            pitch: settings.edgePitch,
            fallbackSynthesizer: ttsService.synthesizeSystemFile,
          ),
        );
      } else {
        for (int i = 0; i < result.bubbles.length; i++) {
          if (i > 0) {
            _typing = true;
            _notify();
            await Future<void>.delayed(
              Duration(milliseconds: 380 + _random.nextInt(420)),
            );
            if (_disposed) return;
          }
          _typing = false;
          final ChatMessage message = _buildMessage(
            role: MessageRole.ai,
            content: result.bubbles[i],
            isRead: _chatVisible,
          );
          await _insertMessage(message);
          lastAiTextId = message.id;
          if (spokenText.isNotEmpty) spokenText.write(' ');
          spokenText.write(result.bubbles[i]);
        }
      }

      await _applyTurnResult(result);
      if (_disposed) return;
      if (spokenText.isNotEmpty) {
        _notifyIfAway(profile.nickname, spokenText.toString());
      }

      if (result.sendArt) {
        _typing = true;
        _notify();
        final String? path = await ArtService.generateCard(
          text: _pick('chat_art_quote', <String>[
            '把今晚的星星揉碎，放进你明天要走的路上。',
            '如果你抬头，我就在所有晚风经过的地方。',
            '想见你的时候，我就把距离画得短一点。',
            '这张不是自拍。是我看你时，世界的样子。',
          ]),
          seed: IdGenerator.seed(),
          paletteIndex: profile.avatarSeed % 6,
          aiName: profile.nickname,
          kicker: '给你的画',
        );
        if (!_disposed && path != null) {
          _typing = false;
          final ChatMessage image = _buildMessage(
            role: MessageRole.ai,
            kind: MessageKind.image,
            content: '一张星屿画卡',
            imagePath: path,
            isRead: _chatVisible,
          );
          await _insertMessage(image);
          await _saveToAlbum(
            path: path,
            title: '${profile.nickname}的画卡',
            source: 'chat',
          );
        }
      }

      if (!useVoiceReply &&
          settings.autoSpeak &&
          lastAiTextId != null &&
          spokenText.isNotEmpty &&
          _appActive) {
        unawaited(ttsService.speak(lastAiTextId, spokenText.toString()));
      }

      await _scheduleNextProactive();
    } catch (error) {
      debugPrint('companion reply failed: $error');
      if (!_disposed) {
        await _insertMessage(
          _buildMessage(
            role: MessageRole.system,
            content: '刚才不小心走神了，再和我说一次好吗？',
            isRead: true,
          ),
        );
      }
    } finally {
      _typing = false;
      _replying = false;
      _notify();
    }
  }

  Future<void> _applyTurnResult(AiTurnResult result) async {
    final CompanionProfile current = profile;
    String nickname = current.nickname;
    String signature = current.signature;
    bool profileChanged = false;

    final ProfileSuggestion? suggestion = result.profile;
    if (settings.autoProfile && suggestion != null && !suggestion.isEmpty) {
      final String? suggestedName = suggestion.nickname?.trim();
      final String? suggestedSignature = suggestion.signature?.trim();
      if (suggestedName != null &&
          suggestedName.isNotEmpty &&
          suggestedName != nickname) {
        nickname = suggestedName;
        profileChanged = true;
      }
      if (suggestedSignature != null &&
          suggestedSignature.isNotEmpty &&
          suggestedSignature != signature) {
        signature = suggestedSignature;
        profileChanged = true;
      }
    }

    final CompanionProfile updated = current.copyWith(
      nickname: nickname,
      signature: signature,
      mood: result.mood.trim().isEmpty ? current.mood : result.mood.trim(),
      affection: _clampAffection(current.affection + result.affectionDelta),
      totalTurns: current.totalTurns + 1,
      lastEvolvedAt: profileChanged ? DateTime.now() : current.lastEvolvedAt,
    );
    _profile = updated;
    await repository.saveProfile(updated);

    if (profileChanged && nickname != current.nickname) {
      await _insertMessage(
        _buildMessage(
          role: MessageRole.system,
          content: '${current.nickname}把昵称改成了「$nickname」',
          isRead: true,
        ),
      );
    }

    final String? newMemory = result.memory?.trim();
    if (newMemory != null && newMemory.length >= 3) {
      final String normalized = MemoryExtractor.normalize(newMemory);
      final bool exists = _memories.any(
        (MemoryEntry item) =>
            MemoryExtractor.normalize(item.content) == normalized,
      );
      if (!exists) {
        final MemoryEntry entry = MemoryEntry(
          id: IdGenerator.newId('memory'),
          content: newMemory,
          category: result.memoryCategory,
          importance: result.memoryImportance,
          createdAt: DateTime.now(),
          sourceMessageId: _latestUserMessageId(),
        );
        await repository.insertMemory(entry);
        _memories.insert(0, entry);
      }
    }

    if (result.anniversary != null) {
      await _createSuggestionAnniversary(result.anniversary!);
    }

    _notify();
  }

  Future<void> _createSuggestionAnniversary(
    AnniversarySuggestion suggestion,
  ) async {
    final List<AnniversaryEntry> existing = await repository
        .loadAnniversaries();
    final bool duplicate = existing.any(
      (AnniversaryEntry item) =>
          item.title == suggestion.title &&
          item.date.month == suggestion.date.month &&
          item.date.day == suggestion.date.day,
    );
    if (duplicate) return;

    final AnniversaryEntry entry = AnniversaryEntry(
      id: IdGenerator.newId('anniv'),
      title: suggestion.title,
      note: suggestion.note,
      date: DateTime(
        suggestion.date.year,
        suggestion.date.month,
        suggestion.date.day,
      ),
      category: suggestion.title.contains('生日') ? 'birthday' : 'anniversary',
      repeatYearly: suggestion.repeatYearly,
      remindDays: 3,
      createdByAi: true,
      createdAt: DateTime.now(),
    );
    await repository.insertAnniversary(entry);
    await _insertMessage(
      _buildMessage(
        role: MessageRole.system,
        content:
            '已记入纪念日 · ${entry.title} · ${entry.date.month}月${entry.date.day}日',
        isRead: true,
      ),
    );
  }

  Future<void> _updateProfileAfterSmallMoment({String? mood}) async {
    final CompanionProfile updated = profile.copyWith(
      affection: _clampAffection(profile.affection + 1),
      mood: mood ?? profile.mood,
      totalTurns: profile.totalTurns + 1,
    );
    _profile = updated;
    await repository.saveProfile(updated);
  }

  // ---------------------------------------------------------------------------
  // 主动陪伴
  // ---------------------------------------------------------------------------
  int _clampAffection(int value) => value.clamp(0, 100).toInt();

  void _resetProactiveDayIfNeeded(DateTime now) {
    final DateTime day = DateTime(now.year, now.month, now.day);
    if (_proactiveDay == null || _proactiveDay != day) {
      _proactiveDay = day;
      _proactiveSentToday = 0;
    }
  }

  bool _shouldSkipProactive({required bool force}) {
    if (force) return false;
    final DateTime now = DateTime.now();
    _resetProactiveDayIfNeeded(now);
    if (_proactiveSentToday >= _maxProactivePerDay) return true;
    final DateTime? last = _lastProactiveAt;
    if (last != null && now.difference(last) < _minProactiveGap) return true;

    final String period = AppDates.dayPeriod(now);
    if ((period == '深夜' || period == '凌晨') &&
        _random.nextDouble() < 0.82) {
      return true;
    }
    // 切到后台/锁屏后，主动消息概率大幅降低，但不完全禁用以保留
    // “回到前台后补上一条”的体验。
    if (!_appActive && _random.nextDouble() < 0.82) return true;
    return false;
  }

  Future<void> _sendProactive({bool force = false}) async {
    if (!_initialized || _replying || _disposed) return;
    if (!force && (!settings.proactiveEnabled || !settings.onboardingDone))
      return;
    if (_shouldSkipProactive(force: force)) {
      await _scheduleNextProactive();
      return;
    }

    _replying = true;
    _typing = true;
    _notify();
    try {
      final String? last = _messages.isEmpty ? null : _messages.last.content;
      final AiTurnResult result = await aiService.proactive(
        profile: profile,
        userName: settings.userName,
        memories: List<MemoryEntry>.from(_memories),
        lastMessage: last,
        now: DateTime.now(),
      );
      if (_disposed) return;
      if (result.bubbles.isEmpty) {
        await _scheduleNextProactive();
        return;
      }
      await Future<void>.delayed(
        Duration(milliseconds: 950 + _random.nextInt(850)),
      );
      if (_disposed) return;

      String? lastId;
      final StringBuffer spokenText = StringBuffer();
      final String mode = settings.proactiveMessageMode;
      final bool useVoiceBubble = mode == 'voice' ||
          (mode == 'random' && _random.nextBool());

      if (useVoiceBubble) {
        // 主动语音气泡：文字字幕仍存入 ChatMessage，音频只和消息 ID 关联。
        final String subtitle = result.bubbles.join('\n').trim();
        _typing = false;
        final ChatMessage message = _buildMessage(
          role: MessageRole.ai,
          content: subtitle,
          isRead: _chatVisible,
        );
        await _insertMessage(message);
        lastId = message.id;
        spokenText.write(result.bubbles.join(' '));
        unawaited(
          VoiceBubbleRegistry.instance.prepare(
            messageId: message.id,
            text: subtitle,
            voice: settings.edgeVoice,
            rate: settings.edgeRate,
            pitch: settings.edgePitch,
            fallbackSynthesizer: ttsService.synthesizeSystemFile,
          ),
        );
      } else {
        for (int i = 0; i < result.bubbles.length; i++) {
          if (i > 0) {
            _typing = true;
            _notify();
            await Future<void>.delayed(
              Duration(milliseconds: 380 + _random.nextInt(400)),
            );
            if (_disposed) return;
          }
          _typing = false;
          final ChatMessage message = _buildMessage(
            role: MessageRole.ai,
            content: result.bubbles[i],
            isRead: _chatVisible,
          );
          await _insertMessage(message);
          lastId = message.id;
          if (spokenText.isNotEmpty) spokenText.write(' ');
          spokenText.write(result.bubbles[i]);
        }
      }

      _lastProactiveAt = DateTime.now();
      _proactiveSentToday++;
      final CompanionProfile updated = profile.copyWith(
        mood: result.mood.trim().isEmpty ? profile.mood : result.mood,
        affection: _clampAffection(profile.affection + 1),
      );
      _profile = updated;
      await repository.saveProfile(updated);
      _notifyIfAway(updated.nickname, spokenText.toString());

      if (!useVoiceBubble &&
          settings.autoSpeak &&
          lastId != null &&
          spokenText.isNotEmpty &&
          _chatVisible &&
          _appActive) {
        unawaited(ttsService.speak(lastId, spokenText.toString()));
      }
      await _scheduleNextProactive();
    } catch (error) {
      debugPrint('proactive message failed: $error');
      await _scheduleNextProactive();
    } finally {
      _typing = false;
      _replying = false;
      _notify();
    }
  }

  Future<void> triggerProactive() async {
    await _sendProactive(force: true);
  }

  Future<void> _tick() async {
    if (!_initialized || _replying || _disposed || !settings.onboardingDone) {
      return;
    }
    // 主动消息的触发概率在 _sendProactive 内统一判断；后台也会以低概率
    // 尝试，但不会像前台那样容易插入消息。角色进化只在前台发生。
    if (_appActive) {
      await _maybeAutoEvolve();
    }
    if (!settings.proactiveEnabled) return;
    final DateTime? next = settings.nextProactiveAt;
    if (next == null) {
      await _ensureProactiveScheduled();
      return;
    }
    if (DateTime.now().isAfter(next)) {
      await _sendProactive();
    }
  }

  Future<void> _ensureProactiveScheduled({bool initial = false}) async {
    if (!settings.proactiveEnabled) return;
    if (settings.nextProactiveAt != null) return;
    final int minutes = initial
        ? min(3, settings.proactiveIntervalMinutes)
        : settings.proactiveIntervalMinutes;
    final DateTime next = DateTime.now().add(
      Duration(minutes: max(1, minutes)),
    );
    await settings.setNextProactiveAt(next);
  }

  Future<void> _scheduleNextProactive() async {
    if (!settings.proactiveEnabled) {
      await settings.setNextProactiveAt(null);
      return;
    }
    final DateTime next = DateTime.now().add(_proactiveDuration());
    final DateTime? existing = settings.nextProactiveAt;
    // 误差小于 45 秒就不重复写 SharedPreferences。
    if (existing != null &&
        (existing.difference(next).inSeconds.abs() < 45)) {
      return;
    }
    await settings.setNextProactiveAt(next);
  }

  Duration _proactiveDuration() {
    final int base = settings.proactiveIntervalMinutes;
    final int jitter = max(1, (base * 0.12).round());
    final int minutes = base + _random.nextInt(jitter * 2 + 1) - jitter;
    return Duration(minutes: max(2, minutes));
  }

  Future<void> _checkAnniversaryReminder() async {
    if (_anniversaryChecked || _disposed || !settings.onboardingDone) {
      return;
    }
    if (_replying) {
      _proactiveKickTimer?.cancel();
      _proactiveKickTimer = Timer(const Duration(seconds: 22), () {
        unawaited(_checkAnniversaryReminder());
      });
      return;
    }
    try {
      final List<AnniversaryEntry> items = await repository.loadAnniversaries();
      final List<AnniversaryEntry> due = items.where((AnniversaryEntry item) {
        final int days = item.daysAway;
        return days >= 0 && days <= item.remindDays;
      }).toList();
      if (due.isEmpty) {
        _anniversaryChecked = true;
        return;
      }
      due.sort((AnniversaryEntry a, AnniversaryEntry b) {
        final int dayCompare = a.daysAway.compareTo(b.daysAway);
        if (dayCompare != 0) return dayCompare;
        return a.isBirthday ? -1 : 1;
      });
      final AnniversaryEntry item = due.first;
      if (_replying) return;
      _anniversaryChecked = true;
      _typing = true;
      _notify();
      await Future<void>.delayed(const Duration(milliseconds: 1200));
      if (_disposed) return;
      final String text = aiService.anniversaryNotice(
        title: item.title,
        days: item.daysAway,
        userName: settings.userName,
      );
      _typing = false;
      await _insertMessage(
        _buildMessage(
          role: MessageRole.ai,
          content: text,
          isRead: _chatVisible,
        ),
      );
      _notifyIfAway(profile.nickname, text);
      _notify();
    } catch (error) {
      debugPrint('anniversary reminder failed: $error');
    } finally {
      _typing = false;
      _notify();
    }
  }

  // ---------------------------------------------------------------------------
  // 记忆与角色资料
  // ---------------------------------------------------------------------------
  Future<void> addMemory(String content, {String category = 'life'}) async {
    final String clean = content.trim();
    if (clean.length < 2) return;
    final MemoryEntry entry = MemoryEntry(
      id: IdGenerator.newId('memory'),
      content: clean,
      category: category,
      importance: 2,
      createdAt: DateTime.now(),
    );
    await repository.insertMemory(entry);
    _memories.insert(0, entry);
    _notify();
  }

  Future<void> deleteMemory(String id) async {
    _memories.removeWhere((MemoryEntry item) => item.id == id);
    _notify();
    await repository.deleteMemory(id);
  }

  Future<void> updateCompanionIdentity({
    String? nickname,
    String? signature,
    String? persona,
    String? tone,
  }) async {
    final String cleanName = (nickname ?? profile.nickname).trim();
    final String nextSignature = (signature ?? profile.signature).trim();
    final String nextPersona = (persona ?? profile.persona).trim();
    final CompanionProfile updated = profile.copyWith(
      nickname: cleanName.isEmpty ? profile.nickname : cleanName,
      signature: nextSignature.isEmpty ? profile.signature : nextSignature,
      persona: nextPersona.isEmpty
          ? CompanionProfile.defaultPersona
          : nextPersona,
      tone: tone ?? profile.tone,
    );
    _profile = updated;
    await repository.saveProfile(updated);
    _notify();
  }

  Future<void> evolveCompanion({bool announce = true}) async {
    if (_evolving || _disposed) return;
    _evolving = true;
    try {
      final CompanionProfile current = profile;
      final DateTime? last = current.lastEvolvedAt;
      final bool allowNickname =
          last == null ||
          DateTime.now().difference(last).inHours >= 36 ||
          _random.nextDouble() < 0.35;
      final ProfileEvolution evolution = aiService.evolveProfile(
        current,
        allowNickname: allowNickname,
      );
      final String? nextNickname = evolution.nickname?.trim();
      final String finalName = (nextNickname == null || nextNickname.isEmpty)
          ? current.nickname
          : nextNickname;

      final DecorationStore decoration = DecorationStore.instance;
      final bool poolRequested =
          decoration.useUserAvatarPool && decoration.userAvatarPool.isNotEmpty;
      final List<String> avatarPool = decoration.validUserAvatarPool;
      if (poolRequested && avatarPool.isEmpty) {
        // 相册里的文件被删光了：关闭开关并留下状态标记，回退系统头像。
        await decoration.disableUserAvatarPoolForInvalid();
        _lastUsedAvatarPath = null;
      }
      final bool poolEnabled =
          decoration.useUserAvatarPool && avatarPool.isNotEmpty;
      // 头像轮换与自动进化共用 30 小时冷却；手动进化可以换签名，
      // 但不会在冷却期内频繁换头像。
      final bool canRotateAvatar = last == null ||
          DateTime.now().difference(last) >= _autoEvolutionCooldown;
      String? nextUserAvatar;
      if (poolEnabled && canRotateAvatar) {
        // 不修改 avatarSeed；只在有效路径中轮换。
        // 池内至少 2 张时，避开上一次用过的路径，杜绝连续重复。
        final List<String> candidates = avatarPool
            .where((String path) => path != _lastUsedAvatarPath)
            .toList(growable: false);
        final List<String> pool = candidates.isEmpty ? avatarPool : candidates;
        nextUserAvatar = pool[_random.nextInt(pool.length)];
        _lastUsedAvatarPath = nextUserAvatar;
        await decoration.setCurrentUserAvatarPath(nextUserAvatar);
      }

      final CompanionProfile updated = current.copyWith(
        nickname: finalName,
        signature: evolution.signature,
        // 用户头像池启用时保持原 avatarSeed，切回系统模式时继续使用它。
        avatarSeed: poolEnabled ? current.avatarSeed : evolution.avatarSeed,
        mood: evolution.mood,
        lastEvolvedAt: DateTime.now(),
      );
      _profile = updated;
      await repository.saveProfile(updated);
      if (announce) {
        if (finalName != current.nickname) {
          await _insertMessage(
            _buildMessage(
              role: MessageRole.system,
              content: poolEnabled
                  ? '${current.nickname}悄悄把名字改成了「$finalName」，还从你的头像池里换了一张照片'
                  : '${current.nickname}悄悄把名字改成了「$finalName」，头像和签名也换了',
              isRead: true,
            ),
          );
        } else {
          await _insertMessage(
            _buildMessage(
              role: MessageRole.system,
              content: poolEnabled
                  ? '${updated.nickname}从你的头像池里换了一张照片，签名也换了：${updated.signature}'
                  : '${updated.nickname}换上了新头像和签名：${updated.signature}',
              isRead: true,
            ),
          );
        }
      }
      _notify();
    } finally {
      _evolving = false;
    }
  }

  /// 设置用户头像池。只保存本地路径字符串，不复制图片。
  Future<void> setUserAvatarPool(List<String> paths) async {
    await DecorationStore.instance.setUserAvatarPool(paths);
    _lastUsedAvatarPath = null;
    _notify();
  }

  /// 开启/关闭 AI 自动轮换用户头像池。
  Future<void> setUseUserAvatarPool(bool enabled) async {
    await DecorationStore.instance.setUseUserAvatarPool(enabled);
    _notify();
  }

  /// 恢复系统 avatarSeed 头像，并清空头像池。
  Future<void> resetUserAvatarPool() async {
    await DecorationStore.instance.resetUserAvatarPool();
    _lastUsedAvatarPath = null;
    _notify();
  }

  Future<void> _maybeAutoEvolve() async {
    if (!settings.autoProfile ||
        !settings.onboardingDone ||
        _evolving ||
        !_initialized) {
      return;
    }
    final DateTime? last = profile.lastEvolvedAt;
    if (last == null ||
        DateTime.now().difference(last) >= _autoEvolutionCooldown) {
      await evolveCompanion(announce: true);
    }
  }

  // ---------------------------------------------------------------------------
  // 界面状态与辅助
  // ---------------------------------------------------------------------------
  Future<void> setChatVisible(bool visible) async {
    _chatVisible = visible;
    if (visible && _unreadCount > 0) {
      await repository.markAiMessagesRead();
      for (int i = 0; i < _messages.length; i++) {
        final ChatMessage message = _messages[i];
        if (message.isAi && !message.isRead) {
          _messages[i] = message.copyWith(isRead: true);
        }
      }
      _unreadCount = 0;
      _notify();
    }
  }

  void setAppActive(bool active) {
    if (_appActive == active) return;
    _appActive = active;
    if (active && settings.onboardingDone) {
      _resumeTimer?.cancel();
      _resumeTimer = Timer(const Duration(seconds: 5), () {
        unawaited(_tick());
      });
    } else {
      _resumeTimer?.cancel();
    }
  }

  Future<void> deleteMessage(String id) async {
    await repository.deleteMessage(id);
    final int index = _messages.indexWhere((ChatMessage item) => item.id == id);
    if (index >= 0) {
      final ChatMessage removed = _messages.removeAt(index);
      if (removed.isAi && !removed.isRead) {
        _unreadCount = max(0, _unreadCount - 1);
      }
      _notify();
    }
  }

  Future<void> refresh() async {
    _profile = await repository.getProfile() ?? profile;
    _messages
      ..clear()
      ..addAll(await repository.loadMessages());
    _memories
      ..clear()
      ..addAll(await repository.loadMemories());
    _unreadCount = await repository.unreadAiMessages();
    _notify();
  }

  String get profileStatusLine {
    final CompanionProfile p = profile;
    if (_typing) return '正在输入…';
    if (settings.onlineReady) return p.mood;
    return '${p.mood} · 离线陪伴中';
  }

  int get conversationTurns => profile.totalTurns;

  void _onSettingsChanged() {
    if (!settings.proactiveEnabled) {
      unawaited(settings.setNextProactiveAt(null));
    } else if (settings.onboardingDone && settings.nextProactiveAt == null) {
      unawaited(_scheduleNextProactive());
    }
  }

  ChatMessage _buildMessage({
    required MessageRole role,
    required String content,
    required bool isRead,
    MessageKind kind = MessageKind.text,
    String? imagePath,
  }) {
    final DateTime now = DateTime.now();
    if (_lastStamp != null && !now.isAfter(_lastStamp!)) {
      _lastStamp = _lastStamp!.add(const Duration(milliseconds: 3));
    } else {
      _lastStamp = now;
    }
    return ChatMessage(
      id: IdGenerator.newId(role == MessageRole.user ? 'msg' : 'ai'),
      role: role,
      kind: kind,
      content: content,
      imagePath: imagePath,
      createdAt: _lastStamp!,
      isRead: isRead,
    );
  }

  Future<void> _insertMessage(ChatMessage message) async {
    await repository.insertMessage(message);
    _messages.add(message);
    if (message.isAi && !message.isRead) {
      _unreadCount++;
    }
    _lastStamp = message.createdAt;
    _notify();
  }

  Future<void> _saveToAlbum({
    required String path,
    required String title,
    required String source,
  }) async {
    final bool exists = await repository.albumContainsPath(path);
    if (exists) return;
    await repository.insertAlbum(
      AlbumEntry(
        id: IdGenerator.newId('album'),
        path: path,
        title: title,
        source: source,
        createdAt: DateTime.now(),
      ),
    );
  }

  String _latestUserText() {
    for (int i = _messages.length - 1; i >= 0; i--) {
      if (_messages[i].isUser) return _messages[i].content;
    }
    return '';
  }

  String? _latestUserMessageId() {
    for (int i = _messages.length - 1; i >= 0; i--) {
      if (_messages[i].isUser) return _messages[i].id;
    }
    return null;
  }

  String _pickStickerBack() {
    const List<String> backs = <String>['🫶', '🌙', '✨', '🫧', '💗', '🪐'];
    return backs[_random.nextInt(backs.length)];
  }

  String _pick(String key, List<String> options) {
    return options[_random.nextInt(options.length)];
  }

  void _notifyIfAway(String title, String body) {
    if (!settings.notificationsEnabled) return;
    if (_appActive && _chatVisible) return;
    final String clean = body.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (clean.isEmpty) return;
    final int max = 120;
    final String clipped = clean.runes.length <= max
        ? clean
        : '${String.fromCharCodes(clean.runes.take(max))}…';
    unawaited(
      NotificationService.instance.showMessage(title: title, body: clipped),
    );
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    settings.removeListener(_onSettingsChanged);
    _pulseTimer?.cancel();
    _proactiveKickTimer?.cancel();
    _resumeTimer?.cancel();
    _autoEvolutionTimer?.cancel();
    _recoveryTimer?.cancel();
    super.dispose();
  }
}
