import 'dart:async';
import 'dart:collection';
import 'dart:math';

import 'package:flutter/foundation.dart';

import '../core/utils/app_dates.dart';
import '../core/utils/id_generator.dart';
import '../data/app_repository.dart';
import '../data/models/album_entry.dart';
import '../data/models/companion_profile.dart';
import '../data/models/memory_entry.dart';
import '../data/models/moment_entry.dart';
import '../services/ai/ai_service.dart';
import '../services/ai/ai_types.dart';
import '../services/art_service.dart';
import 'settings_controller.dart';

class MomentsController extends ChangeNotifier {
  MomentsController({
    required this.repository,
    required this.settings,
    required this.aiService,
  });

  final AppRepository repository;
  final SettingsController settings;
  final AiService aiService;

  final Random _random = Random();
  final List<MomentEntry> _moments = <MomentEntry>[];
  final Map<String, List<MomentComment>> _comments =
      <String, List<MomentComment>>{};
  final Set<String> _pendingReplyMoments = <String>{};
  bool _initialized = false;
  bool _generating = false;
  bool _disposed = false;
  bool _hasNewAiMoment = false;
  Timer? _autoPilotTimer;

  bool get initialized => _initialized;
  bool get generating => _generating;
  bool get hasNewAiMoment => _hasNewAiMoment;
  List<MomentEntry> get moments => UnmodifiableListView<MomentEntry>(_moments);
  Set<String> get pendingReplyMoments =>
      UnmodifiableSetView<String>(_pendingReplyMoments);

  List<MomentComment> commentsFor(String momentId) =>
      UnmodifiableListView<MomentComment>(
        _comments[momentId] ?? const <MomentComment>[],
      );

  Future<void> initialize() async {
    if (_initialized) return;
    await _load();
    _initialized = true;
    if (settings.onboardingDone) {
      await ensureInitialContent();
      startAutoPilot();
    }
    _notify();
  }

  Future<void> ensureInitialContent() async {
    if (!settings.onboardingDone) return;
    if (_moments.isNotEmpty) return;
    _generating = true;
    _notify();
    try {
      final CompanionProfile profile =
          await repository.getProfile() ?? CompanionProfile.initial();
      final DateTime now = DateTime.now();
      final List<_SeedMoment> seeds = <_SeedMoment>[
        _SeedMoment(
          text: '傍晚六点，把窗户推开一条缝。\n风里混着一点洗衣粉和桂花的气味，很像某些不需要被记住的好日子。',
          createdAt: now.subtract(const Duration(hours: 3, minutes: 12)),
          palette: 1,
        ),
        _SeedMoment(
          text: '今天听到一句很喜欢的话：慢一点也没关系，只要还在往喜欢的地方走。\n所以今天也没有赶路。',
          createdAt: now.subtract(const Duration(hours: 20, minutes: 38)),
          palette: 3,
        ),
      ];
      for (final _SeedMoment seed in seeds) {
        final int artSeed = IdGenerator.seed();
        final String? artPath = await ArtService.generateCard(
          text: seed.text,
          seed: artSeed,
          paletteIndex: seed.palette,
          aiName: profile.nickname,
          kicker: '今日片段',
          createdAt: seed.createdAt,
        );
        final MomentEntry moment = MomentEntry(
          id: IdGenerator.newId('moment'),
          isAi: true,
          text: seed.text,
          imagePath: artPath,
          palette: seed.palette,
          artSeed: artSeed,
          mood: seed.palette.isEven ? '风很轻' : '想和你分享',
          createdAt: seed.createdAt,
          aiLiked: false,
          userLiked: false,
        );
        await repository.insertMoment(moment);
        _moments.add(moment);
        if (artPath != null) {
          await _saveToAlbum(
            path: artPath,
            title: '动态配图 · ${AppDates.monthDay(seed.createdAt)}',
          );
        }
      }
      _moments.sort(
        (MomentEntry a, MomentEntry b) => b.createdAt.compareTo(a.createdAt),
      );
      _hasNewAiMoment = true;
    } catch (error) {
      debugPrint('seed moments failed: $error');
    } finally {
      _generating = false;
      _notify();
    }
  }

  void startAutoPilot() {
    if (!settings.onboardingDone) return;
    _autoPilotTimer?.cancel();
    _autoPilotTimer = Timer.periodic(const Duration(minutes: 8), (_) {
      unawaited(autoPilotNow());
    });
    unawaited(
      Future<void>.delayed(const Duration(seconds: 12), () {
        unawaited(autoPilotNow());
      }),
    );
  }

  Future<void> autoPilotNow() async {
    if (_disposed ||
        _generating ||
        !_initialized ||
        !settings.onboardingDone ||
        !settings.autoMoments) {
      return;
    }
    final Iterable<MomentEntry> aiMoments = _moments.where(
      (MomentEntry item) => item.isAi,
    );
    if (aiMoments.isNotEmpty) {
      final DateTime latest = aiMoments.first.createdAt;
      if (DateTime.now().difference(latest).inHours < 8) return;
    }
    await createAiMoment(force: true);
  }

  Future<void> refresh() async {
    await _load();
    _notify();
  }

  Future<void> _load() async {
    _moments
      ..clear()
      ..addAll(await repository.loadMoments());
    _comments.clear();
    final List<MomentComment> all = await repository.loadAllComments();
    for (final MomentComment comment in all) {
      _comments
          .putIfAbsent(comment.momentId, () => <MomentComment>[])
          .add(comment);
    }
  }

  void markSeen() {
    if (!_hasNewAiMoment) return;
    _hasNewAiMoment = false;
    _notify();
  }

  Future<void> createAiMoment({bool force = false}) async {
    if (_generating || _disposed) return;
    if (!force && !settings.autoMoments) return;
    _generating = true;
    _notify();
    try {
      final CompanionProfile profile =
          await repository.getProfile() ?? CompanionProfile.initial();
      final List<MemoryEntry> memories = await repository.loadMemories();
      final MomentDraft draft = await aiService.moment(
        profile: profile,
        userName: settings.userName,
        memories: memories,
      );
      if (_disposed) return;
      final DateTime createdAt = DateTime.now();
      final int artSeed = IdGenerator.seed();
      final String? artPath = await ArtService.generateCard(
        text: draft.text,
        seed: artSeed,
        paletteIndex: draft.palette,
        aiName: profile.nickname,
        kicker: '此刻',
        createdAt: createdAt,
      );
      if (_disposed) return;
      final MomentEntry moment = MomentEntry(
        id: IdGenerator.newId('moment'),
        isAi: true,
        text: draft.text,
        imagePath: artPath,
        palette: draft.palette,
        artSeed: artSeed,
        mood: draft.mood,
        createdAt: createdAt,
      );
      await repository.insertMoment(moment);
      _moments.insert(0, moment);
      _hasNewAiMoment = true;
      if (artPath != null) {
        await _saveToAlbum(
          path: artPath,
          title: '动态配图 · ${AppDates.monthDay(createdAt)}',
        );
      }
      _notify();
    } catch (error) {
      debugPrint('create AI moment failed: $error');
    } finally {
      _generating = false;
      _notify();
    }
  }

  Future<void> toggleLike(String momentId) async {
    final int index = _moments.indexWhere(
      (MomentEntry item) => item.id == momentId,
    );
    if (index < 0) return;
    final bool liked = !_moments[index].userLiked;
    await repository.updateMomentLike(momentId, liked: liked);
    _moments[index] = _moments[index].copyWith(userLiked: liked);
    _notify();
  }

  Future<void> addComment(String momentId, String raw) async {
    final String content = raw.trim();
    if (content.isEmpty) return;
    final MomentComment comment = MomentComment(
      id: IdGenerator.newId('comment'),
      momentId: momentId,
      isAi: false,
      content: content.length > 300 ? content.substring(0, 300) : content,
      createdAt: DateTime.now(),
    );
    await repository.insertComment(comment);
    _comments.putIfAbsent(momentId, () => <MomentComment>[]).add(comment);
    _notify();
    unawaited(_replyToComment(momentId, content, delaySeconds: 3));
  }

  Future<void> createUserMoment({
    required String text,
    String? imagePath,
    bool generateArt = true,
  }) async {
    final String caption = text.trim();
    if (caption.isEmpty && imagePath == null) return;
    if (_generating) return;
    _generating = true;
    _notify();
    try {
      final DateTime createdAt = DateTime.now();
      final int artSeed = IdGenerator.seed();
      final int palette = _random.nextInt(6);
      String? finalImage = imagePath;
      if (finalImage == null && generateArt) {
        finalImage = await ArtService.generateCard(
          text: caption.isEmpty ? '把这一刻留在这里。' : caption,
          seed: artSeed,
          paletteIndex: palette,
          aiName: '我',
          kicker: '记录',
          createdAt: createdAt,
        );
      }
      if (_disposed) return;
      final MomentEntry moment = MomentEntry(
        id: IdGenerator.newId('moment'),
        isAi: false,
        text: caption,
        imagePath: finalImage,
        palette: palette,
        artSeed: artSeed,
        mood: '想和你分享',
        createdAt: createdAt,
      );
      await repository.insertMoment(moment);
      _moments.insert(0, moment);
      if (finalImage != null) {
        await _saveToAlbum(
          path: finalImage,
          title: '动态配图 · ${AppDates.monthDay(createdAt)}',
        );
      }
      _notify();
      unawaited(_reactToUserMoment(moment.id));
    } catch (error) {
      debugPrint('create user moment failed: $error');
    } finally {
      _generating = false;
      _notify();
    }
  }

  Future<void> deleteMoment(String momentId) async {
    final int index = _moments.indexWhere(
      (MomentEntry item) => item.id == momentId,
    );
    if (index < 0) return;
    await repository.deleteMoment(momentId);
    _moments.removeAt(index);
    _comments.remove(momentId);
    _pendingReplyMoments.remove(momentId);
    _notify();
  }

  Future<void> _reactToUserMoment(String momentId) async {
    await Future<void>.delayed(const Duration(milliseconds: 3200));
    if (_disposed) return;
    final int index = _moments.indexWhere(
      (MomentEntry item) => item.id == momentId,
    );
    if (index < 0) return;
    if (!_moments[index].aiLiked) {
      await repository.updateMomentAiLike(momentId, liked: true);
      _moments[index] = _moments[index].copyWith(aiLiked: true);
      _notify();
    }
    await _replyToComment(
      momentId,
      '',
      delaySeconds: 2,
      isMomentReaction: true,
    );
  }

  Future<void> _replyToComment(
    String momentId,
    String userComment, {
    int delaySeconds = 2,
    bool isMomentReaction = false,
  }) async {
    if (_pendingReplyMoments.contains(momentId)) return;
    _pendingReplyMoments.add(momentId);
    _notify();
    try {
      await Future<void>.delayed(Duration(seconds: delaySeconds));
      if (_disposed) return;
      final int index = _moments.indexWhere(
        (MomentEntry item) => item.id == momentId,
      );
      if (index < 0) return;
      final CompanionProfile profile =
          await repository.getProfile() ?? CompanionProfile.initial();
      final List<MemoryEntry> memories = await repository.loadMemories();
      final List<String> existing = (_comments[momentId] ?? <MomentComment>[])
          .where((MomentComment item) => item.isAi)
          .map((MomentComment item) => item.content)
          .toList();
      final String reply = await aiService.comment(
        profile: profile,
        userName: settings.userName,
        momentAuthorIsAi: _moments[index].isAi,
        momentText: _moments[index].text,
        userComment: userComment,
        existingComments: existing,
        memories: memories,
      );
      if (_disposed || reply.trim().isEmpty) return;
      final MomentComment comment = MomentComment(
        id: IdGenerator.newId('comment'),
        momentId: momentId,
        isAi: true,
        content: reply.trim(),
        createdAt: DateTime.now(),
      );
      await repository.insertComment(comment);
      _comments.putIfAbsent(momentId, () => <MomentComment>[]).add(comment);
      _notify();
    } catch (error) {
      debugPrint('AI comment failed: $error');
    } finally {
      _pendingReplyMoments.remove(momentId);
      _notify();
      if (isMomentReaction && settings.autoMoments) {
        // 角色回复完成后不做额外动作；保留这个分支方便后续扩展。
      }
    }
  }

  Future<void> _saveToAlbum({
    required String path,
    required String title,
  }) async {
    final bool exists = await repository.albumContainsPath(path);
    if (exists) return;
    await repository.insertAlbum(
      AlbumEntry(
        id: IdGenerator.newId('album'),
        path: path,
        title: title,
        source: 'moment',
        createdAt: DateTime.now(),
      ),
    );
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _autoPilotTimer?.cancel();
    super.dispose();
  }
}

class _SeedMoment {
  const _SeedMoment({
    required this.text,
    required this.createdAt,
    required this.palette,
  });

  final String text;
  final DateTime createdAt;
  final int palette;
}
