import 'dart:collection';

import 'package:flutter/foundation.dart';

import '../core/utils/id_generator.dart';
import '../data/app_repository.dart';
import '../data/models/album_entry.dart';
import '../services/media_service.dart';

class AlbumController extends ChangeNotifier {
  AlbumController({required this.repository});

  final AppRepository repository;
  final List<AlbumEntry> _items = <AlbumEntry>[];
  bool _initialized = false;
  bool _importing = false;

  bool get initialized => _initialized;
  bool get importing => _importing;
  bool get isEmpty => _items.isEmpty;
  List<AlbumEntry> get items => UnmodifiableListView<AlbumEntry>(_items);

  Future<void> initialize() async {
    if (_initialized) return;
    await refresh();
    _initialized = true;
  }

  Future<void> refresh() async {
    _items
      ..clear()
      ..addAll(await repository.loadAlbum());
    notifyListeners();
  }

  Future<bool> importFromGallery() async {
    if (_importing) return false;
    _importing = true;
    notifyListeners();
    try {
      final file = await MediaService.pickImageFromGallery();
      if (file == null) return false;
      final AlbumEntry entry = AlbumEntry(
        id: IdGenerator.newId('album'),
        path: file.path,
        title: '珍藏的照片',
        source: 'manual',
        createdAt: DateTime.now(),
      );
      await repository.insertAlbum(entry);
      _items.insert(0, entry);
      notifyListeners();
      return true;
    } finally {
      _importing = false;
      notifyListeners();
    }
  }

  Future<void> delete(String id) async {
    await repository.deleteAlbumEntry(id);
    _items.removeWhere((AlbumEntry entry) => entry.id == id);
    notifyListeners();
  }
}
