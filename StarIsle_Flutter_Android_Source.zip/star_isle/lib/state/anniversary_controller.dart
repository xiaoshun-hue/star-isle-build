import 'dart:collection';

import 'package:flutter/foundation.dart';

import '../core/utils/app_dates.dart';
import '../core/utils/id_generator.dart';
import '../data/app_repository.dart';
import '../data/models/anniversary_entry.dart';

class AnniversaryController extends ChangeNotifier {
  AnniversaryController({required this.repository});

  final AppRepository repository;
  final List<AnniversaryEntry> _items = <AnniversaryEntry>[];
  bool _initialized = false;

  bool get initialized => _initialized;
  bool get isEmpty => _items.isEmpty;
  List<AnniversaryEntry> get items =>
      UnmodifiableListView<AnniversaryEntry>(_items);

  List<AnniversaryEntry> get sorted {
    final List<AnniversaryEntry> copy = List<AnniversaryEntry>.from(_items);
    copy.sort((AnniversaryEntry a, AnniversaryEntry b) {
      final int dayCompare = a.daysAway.compareTo(b.daysAway);
      if (dayCompare != 0) return dayCompare;
      return a.title.compareTo(b.title);
    });
    return copy;
  }

  AnniversaryEntry? get nextUpcoming {
    final List<AnniversaryEntry> upcoming =
        _items.where((AnniversaryEntry item) => item.daysAway >= 0).toList()
          ..sort((AnniversaryEntry a, AnniversaryEntry b) {
            final int compare = a.daysAway.compareTo(b.daysAway);
            if (compare != 0) return compare;
            return a.isBirthday ? -1 : 1;
          });
    return upcoming.isEmpty ? null : upcoming.first;
  }

  int get todayCount =>
      _items.where((AnniversaryEntry item) => item.daysAway == 0).length;

  Future<void> initialize() async {
    if (_initialized) return;
    await refresh();
    _initialized = true;
  }

  Future<void> refresh() async {
    _items
      ..clear()
      ..addAll(await repository.loadAnniversaries());
    _items.sort(
      (AnniversaryEntry a, AnniversaryEntry b) =>
          a.daysAway.compareTo(b.daysAway),
    );
    notifyListeners();
  }

  Future<AnniversaryEntry> add({
    required String title,
    required DateTime date,
    String note = '',
    String category = 'anniversary',
    bool repeatYearly = true,
    int remindDays = 3,
  }) async {
    final AnniversaryEntry entry = AnniversaryEntry(
      id: IdGenerator.newId('anniv'),
      title: title.trim(),
      note: note.trim(),
      date: AppDates.dateOnly(date),
      category: category,
      repeatYearly: repeatYearly,
      remindDays: remindDays,
      createdByAi: false,
      createdAt: DateTime.now(),
    );
    await repository.insertAnniversary(entry);
    _items.add(entry);
    await refresh();
    return entry;
  }

  Future<void> update(AnniversaryEntry entry) async {
    await repository.updateAnniversary(entry);
    await refresh();
  }

  Future<void> delete(String id) async {
    await repository.deleteAnniversary(id);
    _items.removeWhere((AnniversaryEntry item) => item.id == id);
    notifyListeners();
  }

  AnniversaryEntry? findById(String id) {
    for (final AnniversaryEntry item in _items) {
      if (item.id == id) return item;
    }
    return null;
  }
}
