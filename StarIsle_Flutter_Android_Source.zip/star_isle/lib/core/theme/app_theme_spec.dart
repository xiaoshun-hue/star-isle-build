import 'package:flutter/material.dart';

/// 五套完整的视觉皮肤。每套同时具备深色/浅色背景与气泡色彩。
@immutable
class AppThemeSpec {
  const AppThemeSpec({
    required this.id,
    required this.name,
    required this.description,
    required this.seed,
    required this.accent,
    required this.darkColors,
    required this.lightColors,
    required this.darkAurora,
    required this.lightAurora,
    required this.userBubble,
  });

  final String id;
  final String name;
  final String description;
  final Color seed;
  final Color accent;
  final List<Color> darkColors;
  final List<Color> lightColors;
  final List<Color> darkAurora;
  final List<Color> lightAurora;
  final List<Color> userBubble;

  Color get primary => seed;

  static const AppThemeSpec dusk = AppThemeSpec(
    id: 'dusk',
    name: '暮光海',
    description: '海雾、蓝调时刻与晚霞',
    seed: Color(0xFF6F8CFF),
    accent: Color(0xFFFF8FA3),
    darkColors: [Color(0xFF060A18), Color(0xFF0B1230), Color(0xFF171229)],
    lightColors: [Color(0xFFF3F6FF), Color(0xFFEEF2FF), Color(0xFFFBF2F6)],
    darkAurora: [Color(0xFF4B6CFF), Color(0xFFFF7F9D)],
    lightAurora: [Color(0xFF9CB2FF), Color(0xFFFFBDCB)],
    userBubble: [Color(0xFFFF8FA3), Color(0xFF9C7BFF)],
  );

  static const AppThemeSpec rose = AppThemeSpec(
    id: 'rose',
    name: '雾玫瑰',
    description: '被月光揉软的玫瑰色',
    seed: Color(0xFFC9778D),
    accent: Color(0xFFFFAFC0),
    darkColors: [Color(0xFF140B12), Color(0xFF20111D), Color(0xFF2A1422)],
    lightColors: [Color(0xFFFFF5F7), Color(0xFFFCEAF0), Color(0xFFF7EDF3)],
    darkAurora: [Color(0xFFD27397), Color(0xFFF5B37F)],
    lightAurora: [Color(0xFFF2A5B9), Color(0xFFFFD1BC)],
    userBubble: [Color(0xFFF297AE), Color(0xFFC87BFF)],
  );

  static const AppThemeSpec mint = AppThemeSpec(
    id: 'mint',
    name: '薄荷岛',
    description: '潮汐、青柠与温柔的风',
    seed: Color(0xFF3FAE98),
    accent: Color(0xFF7BE0C4),
    darkColors: [Color(0xFF041310), Color(0xFF0A211D), Color(0xFF102B26)],
    lightColors: [Color(0xFFF0FBF7), Color(0xFFE7F8F1), Color(0xFFF6FBF7)],
    darkAurora: [Color(0xFF1FA78F), Color(0xFFA6E8A1)],
    lightAurora: [Color(0xFF81D9C3), Color(0xFFD1F0A5)],
    userBubble: [Color(0xFF4CC7A9), Color(0xFF4E9FC9)],
  );

  static const AppThemeSpec amber = AppThemeSpec(
    id: 'amber',
    name: '琥珀黄昏',
    description: '黄昏落进一杯气泡水',
    seed: Color(0xFFC98743),
    accent: Color(0xFFF5C26B),
    darkColors: [Color(0xFF160F08), Color(0xFF21150B), Color(0xFF2C1B10)],
    lightColors: [Color(0xFFFFF9F0), Color(0xFFFDF0DE), Color(0xFFFAF4EA)],
    darkAurora: [Color(0xFFDD9444), Color(0xFFF17B6C)],
    lightAurora: [Color(0xFFF0B363), Color(0xFFFFD9A4)],
    userBubble: [Color(0xFFF1AE5A), Color(0xFFE67C70)],
  );

  static const AppThemeSpec lilac = AppThemeSpec(
    id: 'lilac',
    name: '夜樱紫',
    description: '霓虹、花火与凌晨两点',
    seed: Color(0xFF9B7BFF),
    accent: Color(0xFFF19CE6),
    darkColors: [Color(0xFF0E0819), Color(0xFF180F2A), Color(0xFF231236)],
    lightColors: [Color(0xFFF9F4FF), Color(0xFFF1E8FF), Color(0xFFFFF5FC)],
    darkAurora: [Color(0xFF8D6BFF), Color(0xFFF292DD)],
    lightAurora: [Color(0xFFBFA6FF), Color(0xFFFFC0E7)],
    userBubble: [Color(0xFFC08CFF), Color(0xFFF08BC7)],
  );

  static const List<AppThemeSpec> all = [dusk, rose, mint, amber, lilac];

  static AppThemeSpec byId(String? id) {
    return all.firstWhere(
      (AppThemeSpec item) => item.id == id,
      orElse: () => dusk,
    );
  }

  /// 头像和配图共用的氛围色。
  static const List<List<Color>> artPalettes = [
    [Color(0xFF243B80), Color(0xFF7C9DFF), Color(0xFFFFB3C1)],
    [Color(0xFF632E44), Color(0xFFE68AA5), Color(0xFFFFD1B8)],
    [Color(0xFF0D3D36), Color(0xFF57C8AF), Color(0xFFD4EC9B)],
    [Color(0xFF4A2A12), Color(0xFFE39A4C), Color(0xFFFFD88F)],
    [Color(0xFF2D1A4D), Color(0xFFA27CFF), Color(0xFFFFB7E8)],
    [Color(0xFF0D2B43), Color(0xFF5BA4C9), Color(0xFFCCE8F5)],
  ];
}
