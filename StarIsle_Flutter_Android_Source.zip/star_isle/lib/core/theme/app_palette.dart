import 'package:flutter/material.dart';

/// 每套皮肤在运行时的色彩语义。
/// 所有页面都从这里取渐变、玻璃卡片、气泡颜色，切换皮肤时无需改页面代码。
@immutable
class AppPalette extends ThemeExtension<AppPalette> {
  const AppPalette({
    required this.backgroundTop,
    required this.backgroundMid,
    required this.backgroundBottom,
    required this.auroraA,
    required this.auroraB,
    required this.glass,
    required this.glassStrong,
    required this.border,
    required this.bubbleAi,
    required this.bubbleUserStart,
    required this.bubbleUserEnd,
    required this.muted,
    required this.navBar,
    required this.shadow,
    required this.isDark,
  });

  final Color backgroundTop;
  final Color backgroundMid;
  final Color backgroundBottom;
  final Color auroraA;
  final Color auroraB;
  final Color glass;
  final Color glassStrong;
  final Color border;
  final Color bubbleAi;
  final Color bubbleUserStart;
  final Color bubbleUserEnd;
  final Color muted;
  final Color navBar;
  final Color shadow;
  final bool isDark;

  LinearGradient get backgroundGradient => LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [backgroundTop, backgroundMid, backgroundBottom],
    stops: const [0.0, 0.52, 1.0],
  );

  LinearGradient get userBubbleGradient => LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [bubbleUserStart, bubbleUserEnd],
  );

  LinearGradient get accentGradient => LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [auroraA, auroraB],
  );

  @override
  AppPalette copyWith({
    Color? backgroundTop,
    Color? backgroundMid,
    Color? backgroundBottom,
    Color? auroraA,
    Color? auroraB,
    Color? glass,
    Color? glassStrong,
    Color? border,
    Color? bubbleAi,
    Color? bubbleUserStart,
    Color? bubbleUserEnd,
    Color? muted,
    Color? navBar,
    Color? shadow,
    bool? isDark,
  }) {
    return AppPalette(
      backgroundTop: backgroundTop ?? this.backgroundTop,
      backgroundMid: backgroundMid ?? this.backgroundMid,
      backgroundBottom: backgroundBottom ?? this.backgroundBottom,
      auroraA: auroraA ?? this.auroraA,
      auroraB: auroraB ?? this.auroraB,
      glass: glass ?? this.glass,
      glassStrong: glassStrong ?? this.glassStrong,
      border: border ?? this.border,
      bubbleAi: bubbleAi ?? this.bubbleAi,
      bubbleUserStart: bubbleUserStart ?? this.bubbleUserStart,
      bubbleUserEnd: bubbleUserEnd ?? this.bubbleUserEnd,
      muted: muted ?? this.muted,
      navBar: navBar ?? this.navBar,
      shadow: shadow ?? this.shadow,
      isDark: isDark ?? this.isDark,
    );
  }

  @override
  AppPalette lerp(covariant AppPalette? other, double t) {
    if (other == null) return this;
    return AppPalette(
      backgroundTop: Color.lerp(backgroundTop, other.backgroundTop, t)!,
      backgroundMid: Color.lerp(backgroundMid, other.backgroundMid, t)!,
      backgroundBottom: Color.lerp(
        backgroundBottom,
        other.backgroundBottom,
        t,
      )!,
      auroraA: Color.lerp(auroraA, other.auroraA, t)!,
      auroraB: Color.lerp(auroraB, other.auroraB, t)!,
      glass: Color.lerp(glass, other.glass, t)!,
      glassStrong: Color.lerp(glassStrong, other.glassStrong, t)!,
      border: Color.lerp(border, other.border, t)!,
      bubbleAi: Color.lerp(bubbleAi, other.bubbleAi, t)!,
      bubbleUserStart: Color.lerp(bubbleUserStart, other.bubbleUserStart, t)!,
      bubbleUserEnd: Color.lerp(bubbleUserEnd, other.bubbleUserEnd, t)!,
      muted: Color.lerp(muted, other.muted, t)!,
      navBar: Color.lerp(navBar, other.navBar, t)!,
      shadow: Color.lerp(shadow, other.shadow, t)!,
      isDark: t < 0.5 ? isDark : other.isDark,
    );
  }
}

extension AppPaletteContext on BuildContext {
  AppPalette get palette {
    final ThemeData theme = Theme.of(this);
    return theme.extension<AppPalette>() ??
        AppPalette(
          backgroundTop: theme.colorScheme.surface,
          backgroundMid: theme.colorScheme.surface,
          backgroundBottom: theme.colorScheme.surface,
          auroraA: theme.colorScheme.primary,
          auroraB: theme.colorScheme.secondary,
          glass: theme.colorScheme.surface.withOpacity(0.65),
          glassStrong: theme.colorScheme.surface,
          border: theme.colorScheme.outline.withOpacity(0.2),
          bubbleAi: theme.colorScheme.surfaceContainerHighest,
          bubbleUserStart: theme.colorScheme.primary,
          bubbleUserEnd: theme.colorScheme.secondary,
          muted: theme.colorScheme.onSurface.withOpacity(0.55),
          navBar: theme.colorScheme.surface.withOpacity(0.88),
          shadow: Colors.black,
          isDark: theme.brightness == Brightness.dark,
        );
  }
}
