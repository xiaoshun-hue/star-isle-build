import 'package:flutter/cupertino.dart' show CupertinoPageTransitionsBuilder;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app_palette.dart';
import 'app_theme_spec.dart';

class AppTheme {
  AppTheme._();

  static ThemeData build(AppThemeSpec spec, Brightness brightness) {
    final bool isDark = brightness == Brightness.dark;
    final List<Color> bg = isDark ? spec.darkColors : spec.lightColors;
    final List<Color> aurora = isDark ? spec.darkAurora : spec.lightAurora;

    ColorScheme scheme = ColorScheme.fromSeed(
      seedColor: spec.seed,
      brightness: brightness,
    );
    scheme = scheme.copyWith(
      primary: isDark ? spec.accent : spec.seed,
      secondary: isDark ? spec.seed : spec.accent,
      surface: bg[1],
      onSurface: isDark ? const Color(0xFFF7F3FF) : const Color(0xFF231C2C),
      error: const Color(0xFFFF6B81),
    );

    final AppPalette palette = AppPalette(
      backgroundTop: bg[0],
      backgroundMid: bg[1],
      backgroundBottom: bg[2],
      auroraA: aurora[0],
      auroraB: aurora[1],
      glass: isDark
          ? Colors.white.withOpacity(0.055)
          : Colors.white.withOpacity(0.64),
      glassStrong: isDark
          ? const Color(0xFF1A1C2A).withOpacity(0.90)
          : Colors.white.withOpacity(0.93),
      border: isDark
          ? Colors.white.withOpacity(0.10)
          : Colors.black.withOpacity(0.06),
      bubbleAi: isDark
          ? Colors.white.withOpacity(0.065)
          : Colors.white.withOpacity(0.76),
      bubbleUserStart: spec.userBubble[0],
      bubbleUserEnd: spec.userBubble[1],
      muted: isDark ? const Color(0xFF9C9AB0) : const Color(0xFF7A7284),
      navBar: isDark
          ? const Color(0xFF10111E).withOpacity(0.86)
          : Colors.white.withOpacity(0.88),
      shadow: isDark ? Colors.black : const Color(0xFF755E85),
      isDark: isDark,
    );

    final ThemeData base = ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: bg[0],
      canvasColor: bg[0],
    );

    final TextTheme textTheme = base.textTheme
        .apply(
          bodyColor: scheme.onSurface,
          displayColor: scheme.onSurface,
          fontFamilyFallback: const ['Noto Sans SC', 'sans-serif'],
        )
        .copyWith(
          displayLarge: base.textTheme.displayLarge?.copyWith(
            fontWeight: FontWeight.w800,
            letterSpacing: -1.8,
            height: 1.08,
          ),
          displayMedium: base.textTheme.displayMedium?.copyWith(
            fontWeight: FontWeight.w800,
            letterSpacing: -1.2,
            height: 1.1,
          ),
          headlineLarge: base.textTheme.headlineLarge?.copyWith(
            fontWeight: FontWeight.w800,
            letterSpacing: -0.9,
            height: 1.18,
          ),
          headlineMedium: base.textTheme.headlineMedium?.copyWith(
            fontWeight: FontWeight.w700,
            letterSpacing: -0.5,
          ),
          titleLarge: base.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w700,
            letterSpacing: -0.2,
          ),
          titleMedium: base.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
          bodyLarge: base.textTheme.bodyLarge?.copyWith(height: 1.55),
          bodyMedium: base.textTheme.bodyMedium?.copyWith(height: 1.55),
          labelLarge: base.textTheme.labelLarge?.copyWith(
            fontWeight: FontWeight.w600,
            letterSpacing: 0.1,
          ),
        );

    final OutlineInputBorder normalBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(20),
      borderSide: BorderSide(color: palette.border),
    );
    final OutlineInputBorder focusedBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(20),
      borderSide: BorderSide(
        color: scheme.primary.withOpacity(0.75),
        width: 1.2,
      ),
    );

    return base.copyWith(
      textTheme: textTheme,
      extensions: <ThemeExtension<dynamic>>[palette],
      splashFactory: InkRipple.splashFactory,
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: textTheme.titleLarge,
        iconTheme: IconThemeData(color: scheme.onSurface),
        systemOverlayStyle: isDark
            ? SystemUiOverlayStyle.light
            : SystemUiOverlayStyle.dark,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: isDark
            ? Colors.white.withOpacity(0.05)
            : Colors.white.withOpacity(0.62),
        hintStyle: textTheme.bodyMedium?.copyWith(color: palette.muted),
        labelStyle: textTheme.bodyMedium?.copyWith(color: palette.muted),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 16,
        ),
        border: normalBorder,
        enabledBorder: normalBorder,
        focusedBorder: focusedBorder,
        errorBorder: normalBorder.copyWith(
          borderSide: const BorderSide(color: Color(0xFFFF6B81)),
        ),
        focusedErrorBorder: focusedBorder.copyWith(
          borderSide: const BorderSide(color: Color(0xFFFF6B81)),
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: isDark
            ? const Color(0xFF24243A)
            : const Color(0xFF2C2433),
        contentTextStyle: textTheme.bodyMedium?.copyWith(color: Colors.white),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        insetPadding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: Colors.transparent,
        modalBackgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        modalBarrierColor: Colors.black54,
      ),
      dividerTheme: DividerThemeData(
        color: palette.border,
        thickness: 0.7,
        space: 0.7,
      ),
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: <TargetPlatform, PageTransitionsBuilder>{
          TargetPlatform.android: CupertinoPageTransitionsBuilder(),
          TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
        },
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: scheme.primary,
          foregroundColor: isDark ? const Color(0xFF171221) : Colors.white,
          minimumSize: const Size(56, 52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          textStyle: textTheme.labelLarge,
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: scheme.primary,
          textStyle: textTheme.labelLarge,
        ),
      ),
      iconTheme: IconThemeData(color: scheme.onSurface.withOpacity(0.82)),
      datePickerTheme: DatePickerThemeData(
        backgroundColor: palette.glassStrong,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      ),
      timePickerTheme: TimePickerThemeData(
        backgroundColor: palette.glassStrong,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      ),
    );
  }
}
