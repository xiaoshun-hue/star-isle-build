import 'dart:math' as math;

class AppDates {
  AppDates._();

  static const List<String> _weekdays = [
    '星期一',
    '星期二',
    '星期三',
    '星期四',
    '星期五',
    '星期六',
    '星期日',
  ];

  static const List<String> _shortWeekdays = [
    '周一',
    '周二',
    '周三',
    '周四',
    '周五',
    '周六',
    '周日',
  ];

  static String two(int value) => value.toString().padLeft(2, '0');

  static DateTime dateOnly(DateTime date) =>
      DateTime(date.year, date.month, date.day);

  static DateTime today() => dateOnly(DateTime.now());

  static bool isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  static bool isYesterday(DateTime value, {DateTime? now}) {
    final DateTime n = now ?? DateTime.now();
    return isSameDay(value, n.subtract(const Duration(days: 1)));
  }

  static String weekday(DateTime date) => _weekdays[date.weekday - 1];

  static String shortWeekday(DateTime date) => _shortWeekdays[date.weekday - 1];

  static String monthDay(DateTime date) => '${date.month}月${date.day}日';

  static String fullDate(DateTime date) =>
      '${date.year}年${date.month}月${date.day}日';

  static String fullDateWithWeek(DateTime date) =>
      '${date.year}年${date.month}月${date.day}日 ${weekday(date)}';

  static String clock(DateTime date) => '${two(date.hour)}:${two(date.minute)}';

  static String greeting([DateTime? now]) {
    final int hour = (now ?? DateTime.now()).hour;
    if (hour < 5) return '夜深了';
    if (hour < 9) return '早上好';
    if (hour < 12) return '上午好';
    if (hour < 14) return '中午好';
    if (hour < 18) return '下午好';
    if (hour < 23) return '晚上好';
    return '夜深了';
  }

  static String dayPeriod([DateTime? now]) {
    final int hour = (now ?? DateTime.now()).hour;
    if (hour < 5) return '凌晨';
    if (hour < 9) return '清晨';
    if (hour < 12) return '上午';
    if (hour < 14) return '午后';
    if (hour < 18) return '下午';
    if (hour < 23) return '夜晚';
    return '深夜';
  }

  static String daySeparator(DateTime value, {DateTime? now}) {
    final DateTime n = now ?? DateTime.now();
    if (isSameDay(value, n)) return '今天';
    if (isYesterday(value, now: n)) return '昨天';
    if (value.year == n.year) {
      return '${value.month}月${value.day}日 ${shortWeekday(value)}';
    }
    return '${value.year}年${value.month}月${value.day}日';
  }

  static String relative(DateTime value, {DateTime? now}) {
    final DateTime n = now ?? DateTime.now();
    final Duration diff = n.difference(value);
    if (diff.isNegative) return clock(value);
    if (diff.inMinutes < 1) return '刚刚';
    if (diff.inMinutes < 60) return '${diff.inMinutes} 分钟前';
    if (isSameDay(value, n)) return '今天 ${clock(value)}';
    if (isYesterday(value, now: n)) return '昨天 ${clock(value)}';
    if (diff.inDays < 7) return '${shortWeekday(value)} ${clock(value)}';
    if (value.year == n.year) return '${monthDay(value)} ${clock(value)}';
    return '${value.year}/${two(value.month)}/${two(value.day)}';
  }

  static String messageTime(DateTime value, {DateTime? now}) {
    final DateTime n = now ?? DateTime.now();
    if (isSameDay(value, n)) return clock(value);
    if (isYesterday(value, now: n)) return '昨天 ${clock(value)}';
    if (value.year == n.year) return '${monthDay(value)} ${clock(value)}';
    return '${value.year}/${value.month}/${value.day} ${clock(value)}';
  }

  static int daysInMonth(int year, int month) =>
      DateTime(year, month + 1, 0).day;

  /// 计算下一次周年日。传入的 month/day 表示每年重复的日期。
  static DateTime nextYearlyOccurrence({
    required int month,
    required int day,
    DateTime? from,
  }) {
    final DateTime base = today();
    final DateTime anchor = from == null ? base : dateOnly(from);

    DateTime candidateFor(int year) {
      final int safeDay = math.min(day, daysInMonth(year, month));
      return DateTime(year, month, safeDay);
    }

    DateTime candidate = candidateFor(anchor.year);
    if (candidate.isBefore(anchor)) {
      candidate = candidateFor(anchor.year + 1);
    }
    return candidate;
  }

  /// 非重复事件的下一次发生日：如果已经过去，返回原始日期。
  static DateTime nextOccurrenceFor({
    required DateTime date,
    required bool repeatYearly,
    DateTime? from,
  }) {
    if (!repeatYearly) return dateOnly(date);
    return nextYearlyOccurrence(month: date.month, day: date.day, from: from);
  }

  static int daysUntil(DateTime target, {DateTime? from}) {
    final DateTime anchor = from == null ? today() : dateOnly(from);
    return dateOnly(target).difference(anchor).inDays;
  }

  static String countdownText(DateTime target, {DateTime? from}) {
    final int days = daysUntil(target, from: from);
    if (days == 0) return '就是今天';
    if (days == 1) return '明天';
    if (days > 1) return '还有 $days 天';
    if (days == -1) return '昨天';
    return '已经 ${days.abs()} 天';
  }

  static String statDuration(int days) {
    if (days <= 0) return '今天';
    if (days < 30) return '$days 天';
    final int months = days ~/ 30;
    final int rest = days % 30;
    if (months < 12) {
      return rest == 0 ? '$months 个月' : '$months 个月 $rest 天';
    }
    final int years = days ~/ 365;
    final int remainDays = days % 365;
    return remainDays == 0 ? '$years 年' : '$years 年 $remainDays 天';
  }

  static String seedDate(DateTime date) {
    final DateTime now = DateTime.now();
    if (date.year == now.year) {
      return '${two(date.month)}/${two(date.day)}';
    }
    return '${date.year}.${two(date.month)}.${two(date.day)}';
  }
}
