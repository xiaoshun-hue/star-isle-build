import 'package:flutter/services.dart';

class AppFeedback {
  AppFeedback._();

  static void tap(bool enabled) {
    if (!enabled) return;
    HapticFeedback.selectionClick();
  }

  static void impact(bool enabled) {
    if (!enabled) return;
    HapticFeedback.lightImpact();
  }

  static void soft(bool enabled) {
    if (!enabled) return;
    HapticFeedback.mediumImpact();
  }
}
