import 'dart:math';

class IdGenerator {
  IdGenerator._();

  static final Random _random = Random.secure();

  static String newId([String prefix = '']) {
    final int micros = DateTime.now().microsecondsSinceEpoch;
    final String suffix = List<String>.generate(
      4,
      (_) => _random.nextInt(256).toRadixString(16).padLeft(2, '0'),
    ).join();
    final String base = '${micros.toRadixString(36)}$suffix';
    return prefix.isEmpty ? base : '${prefix}_$base';
  }

  static int seed() =>
      DateTime.now().microsecondsSinceEpoch ^ _random.nextInt(1 << 32);
}
