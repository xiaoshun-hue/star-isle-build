import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// 头像框装扮。
@immutable
class AvatarFrameDecoration {
  const AvatarFrameDecoration({
    required this.id,
    required this.name,
    required this.description,
    required this.primary,
    required this.secondary,
    required this.glow,
    this.padding = 2.2,
    this.borderWidth = 1.2,
  });

  final String id;
  final String name;
  final String description;
  final Color primary;
  final Color secondary;
  final Color glow;
  final double padding;
  final double borderWidth;
}

/// 聊天气泡装扮。颜色均由本地数据提供，不加载网络资源。
@immutable
class ChatBubbleDecoration {
  const ChatBubbleDecoration({
    required this.id,
    required this.name,
    required this.description,
    required this.userStart,
    required this.userEnd,
    required this.aiColor,
    required this.aiBorder,
    this.radius = 22,
  });

  final String id;
  final String name;
  final String description;
  final Color userStart;
  final Color userEnd;
  final Color aiColor;
  final Color aiBorder;
  final double radius;
}

/// 主题配色套装。可单独使用，也可与头像框/气泡叠加。
@immutable
class ThemeColorDecoration {
  const ThemeColorDecoration({
    required this.id,
    required this.name,
    required this.description,
    required this.userStart,
    required this.userEnd,
    required this.aiColor,
    required this.aiBorder,
    required this.accent,
  });

  final String id;
  final String name;
  final String description;
  final Color userStart;
  final Color userEnd;
  final Color aiColor;
  final Color aiBorder;
  final Color accent;
}

/// 用户当前选中的装扮 ID。null 表示原生外观。
@immutable
class DecorationSelection {
  const DecorationSelection({
    this.avatarFrameId,
    this.bubbleStyleId,
    this.colorThemeId,
  });

  static const DecorationSelection native = DecorationSelection();

  final String? avatarFrameId;
  final String? bubbleStyleId;
  final String? colorThemeId;

  bool get isNative =>
      avatarFrameId == null && bubbleStyleId == null && colorThemeId == null;

  Map<String, Object?> toJson() => <String, Object?>{
    'avatarFrameId': avatarFrameId,
    'bubbleStyleId': bubbleStyleId,
    'colorThemeId': colorThemeId,
  };

  factory DecorationSelection.fromJson(Map<String, dynamic> json) {
    String? read(String key) {
      final Object? value = json[key];
      return value is String && value.isNotEmpty ? value : null;
    }

    return DecorationSelection(
      avatarFrameId: read('avatarFrameId'),
      bubbleStyleId: read('bubbleStyleId'),
      colorThemeId: read('colorThemeId'),
    );
  }

  DecorationSelection copyWith({
    String? avatarFrameId,
    bool clearAvatarFrame = false,
    String? bubbleStyleId,
    bool clearBubbleStyle = false,
    String? colorThemeId,
    bool clearColorTheme = false,
  }) {
    return DecorationSelection(
      avatarFrameId: clearAvatarFrame
          ? null
          : (avatarFrameId ?? this.avatarFrameId),
      bubbleStyleId: clearBubbleStyle
          ? null
          : (bubbleStyleId ?? this.bubbleStyleId),
      colorThemeId: clearColorTheme
          ? null
          : (colorThemeId ?? this.colorThemeId),
    );
  }
}

/// 内置装扮目录。所有资源都是本地颜色数据，不依赖网络。
class DecorationCatalog {
  DecorationCatalog._();

  static const List<AvatarFrameDecoration> avatarFrames =
      <AvatarFrameDecoration>[
        AvatarFrameDecoration(
          id: 'moon_ring',
          name: '月晕',
          description: '一圈很轻的月色，适合安静的夜晚。',
          primary: Color(0xFFFFB4C1),
          secondary: Color(0xFF7E9BFF),
          glow: Color(0xFFFF8FA3),
        ),
        AvatarFrameDecoration(
          id: 'star_dust',
          name: '星屑',
          description: '细碎的金色光点，像她抬眼时落下的星。',
          primary: Color(0xFFFFD9A0),
          secondary: Color(0xFF9C7BFF),
          glow: Color(0xFFFFC46B),
          padding: 2.6,
          borderWidth: 1.4,
        ),
        AvatarFrameDecoration(
          id: 'tide',
          name: '潮汐',
          description: '蓝绿色的潮声，把头像围成一座小岛。',
          primary: Color(0xFF8DE8E1),
          secondary: Color(0xFF6F9CFF),
          glow: Color(0xFF5ED8CF),
        ),
        AvatarFrameDecoration(
          id: 'ember',
          name: '余烬',
          description: '暖橘与深红，是冬夜里没有说出口的想念。',
          primary: Color(0xFFFFB07A),
          secondary: Color(0xFFE86D9A),
          glow: Color(0xFFFF8C62),
          padding: 2.8,
        ),
      ];

  static const List<ChatBubbleDecoration> bubbleStyles =
      <ChatBubbleDecoration>[
        ChatBubbleDecoration(
          id: 'dawn_mist',
          name: '晨雾',
          description: '粉紫渐层，像天刚亮时还没有散尽的雾。',
          userStart: Color(0xFFF08FB4),
          userEnd: Color(0xFF8F9BFF),
          aiColor: Color(0xFF1A2035),
          aiBorder: Color(0x335F6F9F),
          radius: 22,
        ),
        ChatBubbleDecoration(
          id: 'jade_wind',
          name: '青岚',
          description: '青绿与雾蓝，适合慢慢说话。',
          userStart: Color(0xFF6ED6C8),
          userEnd: Color(0xFF7198E8),
          aiColor: Color(0xFF14252A),
          aiBorder: Color(0x335A8F92),
          radius: 20,
        ),
        ChatBubbleDecoration(
          id: 'peach_soda',
          name: '蜜桃汽水',
          description: '明亮但不刺眼，像她偶尔露出的那一点俏皮。',
          userStart: Color(0xFFFFB39B),
          userEnd: Color(0xFFE98CA6),
          aiColor: Color(0xFF2A1B22),
          aiBorder: Color(0x336E4A58),
          radius: 24,
        ),
        ChatBubbleDecoration(
          id: 'paper_white',
          name: '素笺',
          description: '低饱和的纸色，克制、安静，适合深夜。',
          userStart: Color(0xFFB8B4C8),
          userEnd: Color(0xFF8C96A8),
          aiColor: Color(0xFF20242D),
          aiBorder: Color(0x335A6070),
          radius: 18,
        ),
      ];

  static const List<ThemeColorDecoration> colorThemes =
      <ThemeColorDecoration>[
        ThemeColorDecoration(
          id: 'dusk_rose',
          name: '暮玫瑰',
          description: '暮色、玫瑰和一层薄薄的蓝。',
          userStart: Color(0xFFE98DAF),
          userEnd: Color(0xFF7D8FEA),
          aiColor: Color(0xFF1A2035),
          aiBorder: Color(0x335F6F9F),
          accent: Color(0xFFFFB4C1),
        ),
        ThemeColorDecoration(
          id: 'mint_night',
          name: '薄荷夜',
          description: '清透的薄荷色，落在深蓝的夜里。',
          userStart: Color(0xFF6CCCC0),
          userEnd: Color(0xFF587FC5),
          aiColor: Color(0xFF132126),
          aiBorder: Color(0x335C8E8B),
          accent: Color(0xFF9AE4D8),
        ),
        ThemeColorDecoration(
          id: 'amber_moon',
          name: '琥珀月',
          description: '暖金色的月光，不刺眼，也不会冷。',
          userStart: Color(0xFFE7B46D),
          userEnd: Color(0xFFCB7D75),
          aiColor: Color(0xFF2A211A),
          aiBorder: Color(0x336E5A42),
          accent: Color(0xFFFFD9A0),
        ),
        ThemeColorDecoration(
          id: 'violet_hush',
          name: '紫罗兰静默',
          description: '安静的紫，适合把想说的话放慢一点。',
          userStart: Color(0xFFA88BE8),
          userEnd: Color(0xFF6F7FD8),
          aiColor: Color(0xFF211B33),
          aiBorder: Color(0x335F568F),
          accent: Color(0xFFC5B4FF),
        ),
      ];

  static AvatarFrameDecoration? avatarFrameById(String? id) {
    if (id == null) return null;
    for (final AvatarFrameDecoration item in avatarFrames) {
      if (item.id == id) return item;
    }
    return null;
  }

  static ChatBubbleDecoration? bubbleStyleById(String? id) {
    if (id == null) return null;
    for (final ChatBubbleDecoration item in bubbleStyles) {
      if (item.id == id) return item;
    }
    return null;
  }

  static ThemeColorDecoration? colorThemeById(String? id) {
    if (id == null) return null;
    for (final ThemeColorDecoration item in colorThemes) {
      if (item.id == id) return item;
    }
    return null;
  }
}

/// 全局装扮状态。默认全部为 null，即保持原版星屿外观。
///
/// 使用单例而不是新增 Provider，避免改动现有 App 的依赖注入结构；
/// 页面和聊天气泡只需要监听 [DecorationStore.instance]。
class DecorationStore extends ChangeNotifier {
  DecorationStore._() {
    unawaited(load());
  }

  static final DecorationStore instance = DecorationStore._();
  static const String _prefsKey = 'star_isle_decoration_v1';

  DecorationSelection _selection = DecorationSelection.native;
  bool _loaded = false;
  Future<void>? _loading;

  DecorationSelection get selection => _selection;
  bool get isLoaded => _loaded;

  AvatarFrameDecoration? get avatarFrame =>
      DecorationCatalog.avatarFrameById(_selection.avatarFrameId);
  ChatBubbleDecoration? get bubbleStyle =>
      DecorationCatalog.bubbleStyleById(_selection.bubbleStyleId);
  ThemeColorDecoration? get colorTheme =>
      DecorationCatalog.colorThemeById(_selection.colorThemeId);
  bool get isCustomized => !_selection.isNative;

  Future<void> load() {
    if (_loaded) return Future<void>.value();
    return _loading ??= _loadInternal();
  }

  Future<void> _loadInternal() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final String? raw = prefs.getString(_prefsKey);
      if (raw != null && raw.trim().isNotEmpty) {
        final Object? decoded = jsonDecode(raw);
        if (decoded is Map<String, dynamic>) {
          final DecorationSelection parsed = DecorationSelection.fromJson(
            decoded,
          );
          _selection = DecorationSelection(
            avatarFrameId: DecorationCatalog.avatarFrameById(
              parsed.avatarFrameId,
            )?.id,
            bubbleStyleId: DecorationCatalog.bubbleStyleById(
              parsed.bubbleStyleId,
            )?.id,
            colorThemeId: DecorationCatalog.colorThemeById(
              parsed.colorThemeId,
            )?.id,
          );
        }
      }
    } catch (error) {
      debugPrint('Decoration load failed: $error');
      _selection = DecorationSelection.native;
    } finally {
      _loaded = true;
      _loading = null;
      notifyListeners();
    }
  }

  Future<void> selectAvatarFrame(String? id) async {
    await load();
    final String? valid = DecorationCatalog.avatarFrameById(id)?.id;
    _selection = _selection.copyWith(
      avatarFrameId: valid,
      clearAvatarFrame: valid == null,
    );
    await _persist();
    notifyListeners();
  }

  Future<void> selectBubbleStyle(String? id) async {
    await load();
    final String? valid = DecorationCatalog.bubbleStyleById(id)?.id;
    _selection = _selection.copyWith(
      bubbleStyleId: valid,
      clearBubbleStyle: valid == null,
    );
    await _persist();
    notifyListeners();
  }

  Future<void> selectColorTheme(String? id) async {
    await load();
    final String? valid = DecorationCatalog.colorThemeById(id)?.id;
    _selection = _selection.copyWith(
      colorThemeId: valid,
      clearColorTheme: valid == null,
    );
    await _persist();
    notifyListeners();
  }

  Future<void> resetAll() async {
    await load();
    _selection = DecorationSelection.native;
    await _persist();
    notifyListeners();
  }

  Future<void> _persist() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefsKey, jsonEncode(_selection.toJson()));
    } catch (error) {
      debugPrint('Decoration save failed: $error');
    }
  }
}
