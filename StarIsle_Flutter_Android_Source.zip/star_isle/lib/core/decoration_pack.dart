import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// 头像框装扮。
@immutable
class AvatarFrameDecoration {
  const AvatarFrameDecoration({
    required this.id,
    required this.name,
    required this.description,
    required this.primary,
    required this.secondary,
    required this.glow,
    this.padding = 2.2,
    this.borderWidth = 1.2,
  });

  final String id;
  final String name;
  final String description;
  final Color primary;
  final Color secondary;
  final Color glow;
  final double padding;
  final double borderWidth;
}

/// 聊天气泡装扮。颜色均由本地数据提供，不加载网络资源。
@immutable
class ChatBubbleDecoration {
  const ChatBubbleDecoration({
    required this.id,
    required this.name,
    required this.description,
    required this.userStart,
    required this.userEnd,
    required this.aiColor,
    required this.aiBorder,
    this.radius = 22,
  });

  final String id;
  final String name;
  final String description;
  final Color userStart;
  final Color userEnd;
  final Color aiColor;
  final Color aiBorder;
  final double radius;
}

/// 主题配色套装。可单独使用，也可与头像框/气泡叠加。
@immutable
class ThemeColorDecoration {
  const ThemeColorDecoration({
    required this.id,
    required this.name,
    required this.description,
    required this.userStart,
    required this.userEnd,
    required this.aiColor,
    required this.aiBorder,
    required this.accent,
  });

  final String id;
  final String name;
  final String description;
  final Color userStart;
  final Color userEnd;
  final Color aiColor;
  final Color aiBorder;
  final Color accent;
}

/// 用户当前选中的装扮 ID 与头像池配置。
///
/// [userAvatarPool] 只保存本地文件路径字符串，不读取、不复制图片；
/// [useUserAvatarPool] 默认 false，保持原版 avatarSeed 头像。
@immutable
class DecorationSelection {
  const DecorationSelection({
    this.avatarFrameId,
    this.bubbleStyleId,
    this.colorThemeId,
    this.userAvatarPool = const <String>[],
    this.useUserAvatarPool = false,
  });

  static const DecorationSelection native = DecorationSelection();

  final String? avatarFrameId;
  final String? bubbleStyleId;
  final String? colorThemeId;
  final List<String> userAvatarPool;
  final bool useUserAvatarPool;

  bool get isNative =>
      avatarFrameId == null &&
      bubbleStyleId == null &&
      colorThemeId == null &&
      userAvatarPool.isEmpty &&
      !useUserAvatarPool;

  Map<String, Object?> toJson() => <String, Object?>{
    'avatarFrameId': avatarFrameId,
    'bubbleStyleId': bubbleStyleId,
    'colorThemeId': colorThemeId,
    'userAvatarPool': userAvatarPool,
    'useUserAvatarPool': useUserAvatarPool,
  };

  factory DecorationSelection.fromJson(Map<String, dynamic> json) {
    String? read(String key) {
      final Object? value = json[key];
      return value is String && value.trim().isNotEmpty ? value.trim() : null;
    }

    final Object? rawPool = json['userAvatarPool'];
    final List<String> pool = rawPool is List
        ? rawPool
              .whereType<String>()
              .map((String path) => path.trim())
              .where((String path) => path.isNotEmpty)
              .toList(growable: false)
        : const <String>[];

    return DecorationSelection(
      avatarFrameId: read('avatarFrameId'),
      bubbleStyleId: read('bubbleStyleId'),
      colorThemeId: read('colorThemeId'),
      userAvatarPool: pool,
      // 旧配置没有该字段，或字段类型异常时一律关闭。
      useUserAvatarPool: json['useUserAvatarPool'] == true,
    );
  }

  DecorationSelection copyWith({
    String? avatarFrameId,
    bool clearAvatarFrame = false,
    String? bubbleStyleId,
    bool clearBubbleStyle = false,
    String? colorThemeId,
    bool clearColorTheme = false,
    List<String>? userAvatarPool,
    bool? useUserAvatarPool,
  }) {
    return DecorationSelection(
      avatarFrameId: clearAvatarFrame
          ? null
          : (avatarFrameId ?? this.avatarFrameId),
      bubbleStyleId: clearBubbleStyle
          ? null
          : (bubbleStyleId ?? this.bubbleStyleId),
      colorThemeId: clearColorTheme
          ? null
          : (colorThemeId ?? this.colorThemeId),
      userAvatarPool: userAvatarPool ?? this.userAvatarPool,
      useUserAvatarPool: useUserAvatarPool ?? this.useUserAvatarPool,
    );
  }
}

/// 内置装扮目录。所有资源都是本地颜色数据，不依赖网络。
class DecorationCatalog {
  DecorationCatalog._();

  static const List<AvatarFrameDecoration> avatarFrames =
      <AvatarFrameDecoration>[
        AvatarFrameDecoration(
          id: 'moon_ring',
          name: '月晕',
          description: '一圈很轻的月色，适合安静的夜晚。',
          primary: Color(0xFFFFB4C1),
          secondary: Color(0xFF7E9BFF),
          glow: Color(0xFFFF8FA3),
        ),
        AvatarFrameDecoration(
          id: 'star_dust',
          name: '星屑',
          description: '细碎的金色光点，像她抬眼时落下的星。',
          primary: Color(0xFFFFD9A0),
          secondary: Color(0xFF9C7BFF),
          glow: Color(0xFFFFC46B),
          padding: 2.6,
          borderWidth: 1.4,
        ),
        AvatarFrameDecoration(
          id: 'tide',
          name: '潮汐',
          description: '蓝绿色的潮声，把头像围成一座小岛。',
          primary: Color(0xFF8DE8E1),
          secondary: Color(0xFF6F9CFF),
          glow: Color(0xFF5ED8CF),
        ),
        AvatarFrameDecoration(
          id: 'ember',
          name: '余烬',
          description: '暖橘与深红，是冬夜里没有说出口的想念。',
          primary: Color(0xFFFFB07A),
          secondary: Color(0xFFE86D9A),
          glow: Color(0xFFFF8C62),
          padding: 2.8,
        ),
      ];

  static const List<ChatBubbleDecoration> bubbleStyles =
      <ChatBubbleDecoration>[
        ChatBubbleDecoration(
          id: 'dawn_mist',
          name: '晨雾',
          description: '粉紫渐层，像天刚亮时还没有散尽的雾。',
          userStart: Color(0xFFF08FB4),
          userEnd: Color(0xFF8F9BFF),
          aiColor: Color(0xFF1A2035),
          aiBorder: Color(0x335F6F9F),
          radius: 22,
        ),
        ChatBubbleDecoration(
          id: 'jade_wind',
          name: '青岚',
          description: '青绿与雾蓝，适合慢慢说话。',
          userStart: Color(0xFF6ED6C8),
          userEnd: Color(0xFF7198E8),
          aiColor: Color(0xFF14252A),
          aiBorder: Color(0x335A8F92),
          radius: 20,
        ),
        ChatBubbleDecoration(
          id: 'peach_soda',
          name: '蜜桃汽水',
          description: '明亮但不刺眼，像她偶尔露出的那一点俏皮。',
          userStart: Color(0xFFFFB39B),
          userEnd: Color(0xFFE98CA6),
          aiColor: Color(0xFF2A1B22),
          aiBorder: Color(0x336E4A58),
          radius: 24,
        ),
        ChatBubbleDecoration(
          id: 'paper_white',
          name: '素笺',
          description: '低饱和的纸色，克制、安静，适合深夜。',
          userStart: Color(0xFFB8B4C8),
          userEnd: Color(0xFF8C96A8),
          aiColor: Color(0xFF20242D),
          aiBorder: Color(0x335A6070),
          radius: 18,
        ),
      ];

  static const List<ThemeColorDecoration> colorThemes =
      <ThemeColorDecoration>[
        ThemeColorDecoration(
          id: 'dusk_rose',
          name: '暮玫瑰',
          description: '暮色、玫瑰和一层薄薄的蓝。',
          userStart: Color(0xFFE98DAF),
          userEnd: Color(0xFF7D8FEA),
          aiColor: Color(0xFF1A2035),
          aiBorder: Color(0x335F6F9F),
          accent: Color(0xFFFFB4C1),
        ),
        ThemeColorDecoration(
          id: 'mint_night',
          name: '薄荷夜',
          description: '清透的薄荷色，落在深蓝的夜里。',
          userStart: Color(0xFF6CCCC0),
          userEnd: Color(0xFF587FC5),
          aiColor: Color(0xFF132126),
          aiBorder: Color(0x335C8E8B),
          accent: Color(0xFF9AE4D8),
        ),
        ThemeColorDecoration(
          id: 'amber_moon',
          name: '琥珀月',
          description: '暖金色的月光，不刺眼，也不会冷。',
          userStart: Color(0xFFE7B46D),
          userEnd: Color(0xFFCB7D75),
          aiColor: Color(0xFF2A211A),
          aiBorder: Color(0x336E5A42),
          accent: Color(0xFFFFD9A0),
        ),
        ThemeColorDecoration(
          id: 'violet_hush',
          name: '紫罗兰静默',
          description: '安静的紫，适合把想说的话放慢一点。',
          userStart: Color(0xFFA88BE8),
          userEnd: Color(0xFF6F7FD8),
          aiColor: Color(0xFF211B33),
          aiBorder: Color(0x335F568F),
          accent: Color(0xFFC5B4FF),
        ),
      ];

  static AvatarFrameDecoration? avatarFrameById(String? id) {
    if (id == null) return null;
    for (final AvatarFrameDecoration item in avatarFrames) {
      if (item.id == id) return item;
    }
    return null;
  }

  static ChatBubbleDecoration? bubbleStyleById(String? id) {
    if (id == null) return null;
    for (final ChatBubbleDecoration item in bubbleStyles) {
      if (item.id == id) return item;
    }
    return null;
  }

  static ThemeColorDecoration? colorThemeById(String? id) {
    if (id == null) return null;
    for (final ThemeColorDecoration item in colorThemes) {
      if (item.id == id) return item;
    }
    return null;
  }
}

/// 全局装扮状态。默认全部为 null，即保持原版星屿外观。
///
/// 使用单例而不是新增 Provider，避免改动现有 App 的依赖注入结构；
/// 页面和聊天气泡只需要监听 [DecorationStore.instance]。
class DecorationStore extends ChangeNotifier {
  DecorationStore._() {
    unawaited(load());
  }

  static final DecorationStore instance = DecorationStore._();
  static const String _prefsKey = 'star_isle_decoration_v1';
  static const String _activeAvatarKey = 'star_isle_active_user_avatar_v1';
  static const int maxUserAvatarPool = 20;

  DecorationSelection _selection = DecorationSelection.native;
  String? _activeUserAvatarPath;
  bool _loaded = false;
  bool _avatarPoolAutoDisabled = false;
  String? _avatarPoolNotice;
  Future<void>? _loading;

  DecorationSelection get selection => _selection;
  bool get isLoaded => _loaded;

  AvatarFrameDecoration? get avatarFrame =>
      DecorationCatalog.avatarFrameById(_selection.avatarFrameId);
  ChatBubbleDecoration? get bubbleStyle =>
      DecorationCatalog.bubbleStyleById(_selection.bubbleStyleId);
  ThemeColorDecoration? get colorTheme =>
      DecorationCatalog.colorThemeById(_selection.colorThemeId);

  /// 头像池只读快照。修改必须走 [setUserAvatarPool]。
  List<String> get userAvatarPool =>
      List<String>.unmodifiable(_selection.userAvatarPool);
  bool get useUserAvatarPool => _selection.useUserAvatarPool;

  /// 进化时随机选中的路径；关闭开关后仍保留，便于再次开启。
  String? get currentUserAvatarPath => _activeUserAvatarPath;

  /// 只包含文件确实存在的头像路径，供渲染和进化挑选。
  List<String> get validUserAvatarPool => List<String>.unmodifiable(
    _selection.userAvatarPool.where(_isUsableAvatarFile),
  );

  bool get avatarPoolAutoDisabled => _avatarPoolAutoDisabled;
  String? get avatarPoolNotice => _avatarPoolNotice;

  /// 当前真正应该渲染的用户头像路径。
  ///
  /// 只有开关开启、池非空且路径仍在池内时才生效；否则返回 null，
  /// 调用方继续使用 avatarSeed 系统头像。
  String? get effectiveUserAvatarPath {
    if (!_selection.useUserAvatarPool) return null;
    final List<String> pool = validUserAvatarPool;
    if (pool.isEmpty) return null;
    final String? current = _activeUserAvatarPath;
    if (current != null && pool.contains(current)) return current;
    return pool.first;
  }

  bool _isUsableAvatarFile(String path) {
    try {
      final File file = File(path);
      return file.existsSync() && file.lengthSync() > 0;
    } catch (_) {
      return false;
    }
  }

  bool get isCustomized => !_selection.isNative;

  Future<void> load() {
    if (_loaded) return Future<void>.value();
    return _loading ??= _loadInternal();
  }

  Future<void> _loadInternal() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final String? raw = prefs.getString(_prefsKey);
      if (raw != null && raw.trim().isNotEmpty) {
        final Object? decoded = jsonDecode(raw);
        if (decoded is Map<String, dynamic>) {
          final DecorationSelection parsed = DecorationSelection.fromJson(
            decoded,
          );
          final List<String> pool = _cleanAvatarPool(parsed.userAvatarPool);
          String? active = prefs.getString(_activeAvatarKey);
          if (active != null) active = active.trim();
          if (active == null || active.isEmpty || !pool.contains(active)) {
            active = pool.isEmpty ? null : pool.first;
          }
          _selection = DecorationSelection(
            avatarFrameId: DecorationCatalog.avatarFrameById(
              parsed.avatarFrameId,
            )?.id,
            bubbleStyleId: DecorationCatalog.bubbleStyleById(
              parsed.bubbleStyleId,
            )?.id,
            colorThemeId: DecorationCatalog.colorThemeById(
              parsed.colorThemeId,
            )?.id,
            userAvatarPool: pool,
            useUserAvatarPool: parsed.useUserAvatarPool,
          );
          _activeUserAvatarPath = active;
        }
      }
    } catch (error) {
      debugPrint('Decoration load failed: $error');
      _selection = DecorationSelection.native;
      _activeUserAvatarPath = null;
    } finally {
      _loaded = true;
      _loading = null;
      notifyListeners();
      if (_selection.userAvatarPool.isNotEmpty) {
        unawaited(pruneInvalidUserAvatars());
      }
    }
  }

  List<String> _cleanAvatarPool(Iterable<String> paths) {
    final Set<String> seen = <String>{};
    final List<String> result = <String>[];
    for (final String raw in paths) {
      final String path = raw.trim();
      if (path.isEmpty || !seen.add(path)) continue;
      result.add(path);
      if (result.length >= maxUserAvatarPool) break;
    }
    return result;
  }

  Future<void> selectAvatarFrame(String? id) async {
    await load();
    final String? valid = DecorationCatalog.avatarFrameById(id)?.id;
    _selection = _selection.copyWith(
      avatarFrameId: valid,
      clearAvatarFrame: valid == null,
    );
    await _persist();
    notifyListeners();
  }

  Future<void> selectBubbleStyle(String? id) async {
    await load();
    final String? valid = DecorationCatalog.bubbleStyleById(id)?.id;
    _selection = _selection.copyWith(
      bubbleStyleId: valid,
      clearBubbleStyle: valid == null,
    );
    await _persist();
    notifyListeners();
  }

  Future<void> selectColorTheme(String? id) async {
    await load();
    final String? valid = DecorationCatalog.colorThemeById(id)?.id;
    _selection = _selection.copyWith(
      colorThemeId: valid,
      clearColorTheme: valid == null,
    );
    await _persist();
    notifyListeners();
  }

  /// 设置/替换头像池。路径按输入顺序去重，只存储字符串。
  Future<void> setUserAvatarPool(List<String> paths) async {
    await load();
    final List<String> pool = _cleanAvatarPool(paths);
    String? active = _activeUserAvatarPath;
    if (pool.isEmpty) {
      active = null;
    } else if (active == null || !pool.contains(active)) {
      active = pool.first;
    }
    _selection = _selection.copyWith(userAvatarPool: pool);
    _activeUserAvatarPath = active;
    if (pool.isNotEmpty) {
      _avatarPoolAutoDisabled = false;
      _avatarPoolNotice = null;
      // 外部直接传入了全部失效的路径时，同样自动回退。
      if (_selection.useUserAvatarPool && validUserAvatarPool.isEmpty) {
        _selection = _selection.copyWith(useUserAvatarPool: false);
        _activeUserAvatarPath = null;
        _avatarPoolAutoDisabled = true;
        _avatarPoolNotice = '头像池图片已全部失效，已自动切回系统头像。';
      }
    }
    await _persist();
    notifyListeners();
  }

  Future<void> addUserAvatarPath(String path) async {
    final String clean = path.trim();
    if (clean.isEmpty) return;
    await load();
    if (_selection.userAvatarPool.contains(clean)) return;
    if (_selection.userAvatarPool.length >= maxUserAvatarPool) return;
    await setUserAvatarPool(<String>[
      ..._selection.userAvatarPool,
      clean,
    ]);
  }

  Future<void> removeUserAvatarPath(String path) async {
    await load();
    final List<String> next = _selection.userAvatarPool
        .where((String item) => item != path)
        .toList(growable: false);
    await setUserAvatarPool(next);
  }

  /// 切换“AI 自动轮换用户头像池”。池为空时不报错，渲染层自动回退系统头像。
  Future<void> setUseUserAvatarPool(bool enabled) async {
    await load();
    bool nextEnabled = enabled;
    if (enabled && _selection.userAvatarPool.isNotEmpty) {
      final List<String> valid = validUserAvatarPool;
      if (valid.isEmpty) {
        nextEnabled = false;
        _avatarPoolAutoDisabled = true;
        _avatarPoolNotice = '头像池图片已全部失效，已自动切回系统头像。';
      } else {
        final String? active = _activeUserAvatarPath;
        if (active == null || !valid.contains(active)) {
          _activeUserAvatarPath = valid.first;
        }
        _avatarPoolAutoDisabled = false;
        _avatarPoolNotice = null;
      }
    }
    _selection = _selection.copyWith(useUserAvatarPool: nextEnabled);
    await _persist();
    notifyListeners();
  }

  /// 角色进化时由控制器调用，保存本次随机选中的路径。
  Future<void> setCurrentUserAvatarPath(String? path) async {
    await load();
    final String? clean = path?.trim();
    if (clean == null || clean.isEmpty) {
      _activeUserAvatarPath = null;
    } else {
      if (!_selection.userAvatarPool.contains(clean)) return;
      if (!_isUsableAvatarFile(clean)) return;
      _activeUserAvatarPath = clean;
    }
    await _persist();
    notifyListeners();
  }

  /// 启动/进入装扮页时调用：移除不存在或空文件的路径。
  /// 如果全部失效，自动关闭开关并记录提示。
  Future<void> pruneInvalidUserAvatars() async {
    await load();
    final List<String> invalid = _selection.userAvatarPool
        .where((String path) => !_isUsableAvatarFile(path))
        .toList(growable: false);
    if (invalid.isEmpty) return;
    final List<String> valid = _selection.userAvatarPool
        .where(_isUsableAvatarFile)
        .toList(growable: false);
    _selection = _selection.copyWith(userAvatarPool: valid);
    if (valid.isEmpty) {
      _activeUserAvatarPath = null;
      if (_selection.useUserAvatarPool) {
        _selection = _selection.copyWith(useUserAvatarPool: false);
        _avatarPoolAutoDisabled = true;
        _avatarPoolNotice = '头像池图片已全部失效，已自动切回系统头像。';
      }
    } else {
      final String? active = _activeUserAvatarPath;
      if (active == null || !valid.contains(active)) {
        _activeUserAvatarPath = valid.first;
      }
    }
    await _persist();
    notifyListeners();
  }

  /// 缩略图加载失败时调用。最后一帧失效时关闭开关。
  Future<void> markUserAvatarUnavailable(String path) async {
    await load();
    if (!_selection.userAvatarPool.contains(path)) return;
    final List<String> remaining = _selection.userAvatarPool
        .where((String item) => item != path)
        .toList(growable: false);
    _selection = _selection.copyWith(userAvatarPool: remaining);
    if (remaining.isEmpty) {
      _activeUserAvatarPath = null;
      if (_selection.useUserAvatarPool) {
        _selection = _selection.copyWith(useUserAvatarPool: false);
        _avatarPoolAutoDisabled = true;
        _avatarPoolNotice = '头像池图片已全部失效，已自动切回系统头像。';
      }
    } else {
      final List<String> valid = validUserAvatarPool;
      if (valid.isEmpty) {
        _activeUserAvatarPath = null;
        if (_selection.useUserAvatarPool) {
          _selection = _selection.copyWith(useUserAvatarPool: false);
          _avatarPoolAutoDisabled = true;
          _avatarPoolNotice = '头像池图片已全部失效，已自动切回系统头像。';
        }
      } else if (_activeUserAvatarPath == null ||
          !valid.contains(_activeUserAvatarPath)) {
        _activeUserAvatarPath = valid.first;
      }
    }
    await _persist();
    notifyListeners();
  }

  /// 控制器发现池内全部失效时调用，保留路径供用户检查，但关闭开关。
  Future<void> disableUserAvatarPoolForInvalid() async {
    await load();
    _selection = _selection.copyWith(useUserAvatarPool: false);
    _activeUserAvatarPath = null;
    _avatarPoolAutoDisabled = true;
    _avatarPoolNotice = '头像池图片已全部失效，已自动切回系统头像。';
    await _persist();
    notifyListeners();
  }

  /// 清空池但保留开关状态；渲染层会立刻回退系统头像。
  Future<void> clearUserAvatarPool() async {
    await load();
    _selection = _selection.copyWith(
      userAvatarPool: const <String>[],
    );
    _activeUserAvatarPath = null;
    _avatarPoolAutoDisabled = false;
    _avatarPoolNotice = null;
    await _persist();
    notifyListeners();
  }

  /// 恢复系统头像模式：关闭开关并清空池。
  Future<void> resetUserAvatarPool() async {
    await load();
    _selection = _selection.copyWith(
      userAvatarPool: const <String>[],
      useUserAvatarPool: false,
    );
    _activeUserAvatarPath = null;
    _avatarPoolAutoDisabled = false;
    _avatarPoolNotice = null;
    await _persist();
    notifyListeners();
  }

  Future<void> resetAll() async {
    await load();
    _selection = DecorationSelection.native;
    _activeUserAvatarPath = null;
    _avatarPoolAutoDisabled = false;
    _avatarPoolNotice = null;
    await _persist();
    notifyListeners();
  }

  Future<void> _persist() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefsKey, jsonEncode(_selection.toJson()));
      final String? active = _activeUserAvatarPath;
      if (active == null || active.trim().isEmpty) {
        await prefs.remove(_activeAvatarKey);
      } else {
        await prefs.setString(_activeAvatarKey, active);
      }
    } catch (error) {
      debugPrint('Decoration save failed: $error');
    }
  }
}
