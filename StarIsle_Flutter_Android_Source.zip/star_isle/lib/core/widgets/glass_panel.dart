import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../theme/app_palette.dart';

class GlassPanel extends StatelessWidget {
  const GlassPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.margin,
    this.borderRadius = 24,
    this.blur = 18,
    this.color,
    this.gradient,
    this.border,
    this.onTap,
    this.shadow = false,
    this.clipBehavior = Clip.antiAlias,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final double borderRadius;
  final double blur;
  final Color? color;
  final Gradient? gradient;
  final Border? border;
  final VoidCallback? onTap;
  final bool shadow;
  final Clip clipBehavior;

  @override
  Widget build(BuildContext context) {
    final palette = context.palette;
    final Radius radius = Radius.circular(borderRadius);
    final BorderRadius borderRadiusAll = BorderRadius.all(radius);

    final Widget surface = Container(
      decoration: BoxDecoration(
        color: gradient == null ? (color ?? palette.glass) : null,
        gradient: gradient,
        borderRadius: borderRadiusAll,
        border: border ?? Border.all(color: palette.border, width: 0.8),
      ),
      child: onTap == null
          ? Padding(padding: padding, child: child)
          : Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: borderRadiusAll,
                onTap: onTap,
                splashColor: Theme.of(context).colorScheme.primary
                    .withOpacity(0.08),
                highlightColor: Colors.transparent,
                child: Padding(padding: padding, child: child),
              ),
            ),
    );

    Widget panel = ClipRRect(
      borderRadius: borderRadiusAll,
      clipBehavior: clipBehavior,
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: surface,
      ),
    );

    if (shadow) {
      panel = DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: borderRadiusAll,
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: palette.shadow.withOpacity(palette.isDark ? 0.26 : 0.10),
              blurRadius: 30,
              offset: const Offset(0, 14),
            ),
          ],
        ),
        child: panel,
      );
    }

    if (margin != null) {
      panel = Padding(padding: margin!, child: panel);
    }
    return panel;
  }
}
