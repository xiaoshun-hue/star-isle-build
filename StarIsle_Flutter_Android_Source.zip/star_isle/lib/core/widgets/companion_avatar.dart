import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../theme/app_theme_spec.dart';

class CompanionAvatar extends StatelessWidget {
  const CompanionAvatar({
    super.key,
    required this.seed,
    required this.size,
    this.nickname = '晚晚',
    this.showOnline = false,
    this.ring = true,
  });

  final int seed;
  final double size;
  final String nickname;
  final bool showOnline;
  final bool ring;

  static const List<String> _symbols = <String>[
    '🌙',
    '✦',
    '🪐',
    '🌊',
    '🫧',
    '🌷',
    '🍃',
    '⭐',
  ];

  @override
  Widget build(BuildContext context) {
    final List<Color> colors =
        AppThemeSpec.artPalettes[seed.abs() % AppThemeSpec.artPalettes.length];
    final String symbol = _symbols[(seed.abs() ~/ 3) % _symbols.length];
    final double ringPadding = ring ? math.max(3.0, size * 0.034) : 0;

    return Semantics(
      label: nickname,
      image: true,
      child: SizedBox(
        width: size,
        height: size,
        child: Stack(
          clipBehavior: Clip.none,
          children: <Widget>[
            Container(
              width: size,
              height: size,
              padding: EdgeInsets.all(ringPadding),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[
                    Colors.white.withOpacity(0.82),
                    colors[2],
                    colors[1],
                  ],
                  stops: const <double>[0.0, 0.52, 1.0],
                ),
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: colors[1].withOpacity(0.25),
                    blurRadius: size * 0.22,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: ClipOval(
                child: CustomPaint(
                  painter: _CompanionAvatarPainter(
                    seed: seed,
                    colors: colors,
                    isDark: Theme.of(context).brightness == Brightness.dark,
                  ),
                  child: Center(
                    child: ExcludeSemantics(
                      child: Text(
                        symbol,
                        style: TextStyle(
                          fontSize: size * 0.34,
                          height: 1,
                          shadows: <Shadow>[
                            Shadow(
                              color: Colors.black.withOpacity(0.22),
                              blurRadius: size * 0.08,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            if (showOnline)
              Positioned(
                right: ringPadding * 0.4,
                bottom: ringPadding * 0.4,
                child: Container(
                  width: math.max(11.0, size * 0.19),
                  height: math.max(11.0, size * 0.19),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF66E6B0),
                    border: Border.all(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? const Color(0xFF141521)
                          : Colors.white,
                      width: math.max(1.5, size * 0.027),
                    ),
                    boxShadow: <BoxShadow>[
                      BoxShadow(
                        color: const Color(0xFF66E6B0).withOpacity(0.6),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _CompanionAvatarPainter extends CustomPainter {
  _CompanionAvatarPainter({
    required this.seed,
    required this.colors,
    required this.isDark,
  });

  final int seed;
  final List<Color> colors;
  final bool isDark;

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Paint bg = Paint()
      ..shader = ui.Gradient.linear(
        rect.topLeft,
        rect.bottomRight,
        <Color>[
          Color.lerp(colors[0], Colors.black, isDark ? 0.06 : 0.0)!,
          colors[1],
          colors[2],
        ],
        const <double>[0.0, 0.55, 1.0],
      );
    canvas.drawRect(rect, bg);

    final math.Random random = math.Random(seed + 11);
    for (int i = 0; i < 4; i++) {
      final Offset center = Offset(
        random.nextDouble() * size.width,
        random.nextDouble() * size.height,
      );
      final Paint glow = Paint()
        ..shader = ui.Gradient.radial(
          center,
          size.width * (0.18 + random.nextDouble() * 0.28),
          <Color>[
            Colors.white.withOpacity(0.22),
            Colors.white.withOpacity(0.0),
          ],
        );
      canvas.drawCircle(center, size.width * 0.46, glow);
    }

    final Paint arc = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1
      ..color = Colors.white.withOpacity(0.34);
    canvas.drawArc(
      Rect.fromCenter(
        center: Offset(size.width * 0.55, size.height * 0.49),
        width: size.width * 0.9,
        height: size.height * 0.56,
      ),
      -0.5,
      3.9,
      false,
      arc,
    );

    final Paint dot = Paint();
    for (int i = 0; i < 15; i++) {
      final Offset p = Offset(
        random.nextDouble() * size.width,
        random.nextDouble() * size.height,
      );
      dot.color = Colors.white.withOpacity(0.18 + random.nextDouble() * 0.48);
      canvas.drawCircle(p, 0.6 + random.nextDouble() * 1.2, dot);
    }

    final Paint shade = Paint()
      ..shader = ui.Gradient.linear(
        Offset(0, size.height * 0.5),
        Offset(0, size.height),
        <Color>[Colors.transparent, Colors.black.withOpacity(0.16)],
      );
    canvas.drawRect(rect, shade);
  }

  @override
  bool shouldRepaint(covariant _CompanionAvatarPainter oldDelegate) {
    return oldDelegate.seed != seed ||
        oldDelegate.isDark != isDark ||
        oldDelegate.colors != colors;
  }
}

class UserAvatar extends StatelessWidget {
  const UserAvatar({
    super.key,
    required this.name,
    required this.size,
    this.online = false,
  });

  final String name;
  final double size;
  final bool online;

  @override
  Widget build(BuildContext context) {
    final String trimmed = name.trim();
    final String initial = trimmed.isEmpty
        ? '我'
        : String.fromCharCode(trimmed.runes.first);
    final int seed = trimmed.isEmpty
        ? 7
        : trimmed.runes.fold<int>(7, (int a, int b) => a + b);
    final List<Color> colors =
        AppThemeSpec.artPalettes[seed % AppThemeSpec.artPalettes.length];
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        children: <Widget>[
          Container(
            width: size,
            height: size,
            padding: EdgeInsets.all(math.max(2.0, size * 0.03)),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[colors[2], colors[1]],
              ),
            ),
            child: Container(
              decoration: BoxDecoration(
                color: Color.lerp(colors[0], Colors.black, 0.18),
                shape: BoxShape.circle,
              ),
              alignment: Alignment.center,
              child: Text(
                initial,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.95),
                  fontSize: size * 0.38,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
          if (online)
            Positioned(
              right: 1,
              bottom: 1,
              child: Container(
                width: math.max(10.0, size * 0.2),
                height: math.max(10.0, size * 0.2),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF66E6B0),
                  border: Border.all(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? const Color(0xFF141521)
                        : Colors.white,
                    width: 2,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
