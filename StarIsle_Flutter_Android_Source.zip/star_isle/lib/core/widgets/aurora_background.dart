import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../theme/app_palette.dart';

class AuroraBackground extends StatefulWidget {
  const AuroraBackground({
    super.key,
    required this.child,
    this.showStars = true,
    this.animate = true,
  });

  final Widget child;
  final bool showStars;
  final bool animate;

  @override
  State<AuroraBackground> createState() => _AuroraBackgroundState();
}

class _AuroraBackgroundState extends State<AuroraBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 32),
    );
    if (widget.animate) _controller.repeat();
  }

  @override
  void didUpdateWidget(covariant AuroraBackground oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.animate && !_controller.isAnimating) {
      _controller.repeat();
    } else if (!widget.animate && _controller.isAnimating) {
      _controller.stop();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _controller,
        child: widget.child,
        builder: (BuildContext context, Widget? child) {
          return CustomPaint(
            painter: _AuroraPainter(
              progress: widget.animate ? _controller.value : 0.35,
              palette: palette,
              showStars: widget.showStars,
            ),
            child: child,
          );
        },
      ),
    );
  }
}

class _AuroraPainter extends CustomPainter {
  _AuroraPainter({
    required this.progress,
    required this.palette,
    required this.showStars,
  });

  final double progress;
  final AppPalette palette;
  final bool showStars;

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Paint background = Paint()
      ..shader = uiGradientLinear(
        rect.topLeft,
        rect.bottomRight,
        palette.backgroundGradient.colors,
        palette.backgroundGradient.stops,
      );
    canvas.drawRect(rect, background);

    final double t = progress * math.pi * 2;
    _blob(
      canvas,
      Offset(
        size.width * (0.18 + math.sin(t * 0.7) * 0.11),
        size.height * (0.16 + math.cos(t * 0.52) * 0.08),
      ),
      size.width * 0.75,
      palette.auroraA.withOpacity(palette.isDark ? 0.22 : 0.30),
    );
    _blob(
      canvas,
      Offset(
        size.width * (0.86 + math.cos(t * 0.55) * 0.10),
        size.height * (0.30 + math.sin(t * 0.63) * 0.09),
      ),
      size.width * 0.66,
      palette.auroraB.withOpacity(palette.isDark ? 0.17 : 0.22),
    );
    _blob(
      canvas,
      Offset(
        size.width * (0.54 + math.sin(t * 0.42) * 0.14),
        size.height * (0.78 + math.cos(t * 0.36) * 0.07),
      ),
      size.width * 0.72,
      Color.lerp(
        palette.auroraA,
        palette.auroraB,
        0.55,
      )!.withOpacity(palette.isDark ? 0.12 : 0.16),
    );

    if (showStars) {
      final Paint starPaint = Paint();
      for (int i = 0; i < 72; i++) {
        final double x = (math.sin(i * 37.17) * 0.5 + 0.5) * size.width;
        final double y = (math.cos(i * 59.31) * 0.5 + 0.5) * size.height * 0.8;
        final double alpha =
            (0.10 + 0.22 * (math.sin(t * 0.8 + i) * 0.5 + 0.5));
        starPaint.color = (palette.isDark ? Colors.white : palette.auroraA)
            .withOpacity(alpha * 0.45);
        canvas.drawCircle(Offset(x, y), i % 9 == 0 ? 1.5 : 0.8, starPaint);
      }
    }

    final Paint haze = Paint()
      ..shader = uiGradientLinear(
        Offset(0, size.height * 0.45),
        Offset(0, size.height),
        <Color>[
          Colors.transparent,
          palette.backgroundBottom.withOpacity(palette.isDark ? 0.20 : 0.12),
        ],
      );
    canvas.drawRect(rect, haze);
  }

  void _blob(Canvas canvas, Offset center, double radius, Color color) {
    final Paint paint = Paint()
      ..shader = uiGradientRadial(
        center,
        radius,
        <Color>[
          color,
          color.withOpacity(color.opacity * 0.33),
          Colors.transparent,
        ],
        <double>[0.0, 0.55, 1.0],
      );
    canvas.drawCircle(center, radius, paint);
  }

  @override
  bool shouldRepaint(covariant _AuroraPainter oldDelegate) {
    return oldDelegate.progress != progress ||
        oldDelegate.palette != palette ||
        oldDelegate.showStars != showStars;
  }
}

// Small indirection keeps the painter readable and avoids name clashes.
ui.Shader uiGradientLinear(
  Offset from,
  Offset to,
  List<Color> colors, [
  List<double>? stops,
]) {
  return ui.Gradient.linear(from, to, colors, stops);
}

ui.Shader uiGradientRadial(
  Offset center,
  double radius,
  List<Color> colors,
  List<double> stops,
) {
  return ui.Gradient.radial(center, radius, colors, stops);
}
