import 'dart:math' as math;

import 'package:flutter/material.dart';

class TypingDots extends StatefulWidget {
  const TypingDots({super.key, this.color, this.size = 6, this.spacing = 4});

  final Color? color;
  final double size;
  final double spacing;

  @override
  State<TypingDots> createState() => _TypingDotsState();
}

class _TypingDotsState extends State<TypingDots>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Color color =
        widget.color ??
        Theme.of(context).colorScheme.onSurface.withOpacity(0.62);
    return AnimatedBuilder(
      animation: _controller,
      builder: (BuildContext context, _) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List<Widget>.generate(3, (int index) {
            final double wave = math.sin(
              (_controller.value * math.pi * 2) - index * 0.9,
            );
            final double offset = wave.clamp(-1.0, 1.0).toDouble() * 2.5;
            final double opacity =
                0.38 + (wave.clamp(-1.0, 1.0).toDouble() + 1) * 0.24;
            return Padding(
              padding: EdgeInsets.only(right: index == 2 ? 0 : widget.spacing),
              child: Transform.translate(
                offset: Offset(0, -offset),
                child: Opacity(
                  opacity: opacity.clamp(0.3, 0.95).toDouble(),
                  child: Container(
                    width: widget.size,
                    height: widget.size,
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }
}
