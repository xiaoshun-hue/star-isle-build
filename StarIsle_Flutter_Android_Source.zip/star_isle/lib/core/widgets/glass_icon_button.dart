import 'package:flutter/material.dart';

import '../theme/app_palette.dart';
import 'pressable_scale.dart';

class GlassIconButton extends StatelessWidget {
  const GlassIconButton({
    super.key,
    required this.icon,
    required this.onTap,
    this.size = 44,
    this.iconSize = 20,
    this.tooltip,
    this.active = false,
    this.color,
  });

  final IconData icon;
  final VoidCallback? onTap;
  final double size;
  final double iconSize;
  final String? tooltip;
  final bool active;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final Color iconColor =
        color ??
        (active
            ? Theme.of(context).colorScheme.primary
            : Theme.of(context).colorScheme.onSurface.withOpacity(0.76));

    Widget button = PressableScale(
      onTap: onTap,
      enabled: onTap != null,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: active
              ? Theme.of(context).colorScheme.primary.withOpacity(0.14)
              : palette.glass,
          border: Border.all(
            color: active
                ? Theme.of(context).colorScheme.primary.withOpacity(0.28)
                : palette.border,
            width: 0.8,
          ),
        ),
        child: Icon(icon, size: iconSize, color: iconColor),
      ),
    );

    if (tooltip != null && tooltip!.isNotEmpty) {
      button = Tooltip(message: tooltip!, child: button);
    }
    return button;
  }
}
