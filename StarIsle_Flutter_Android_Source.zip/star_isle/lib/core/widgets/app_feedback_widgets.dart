import 'package:flutter/material.dart';

import '../theme/app_palette.dart';

void showAppToast(
  BuildContext context,
  String message, {
  IconData icon = Icons.auto_awesome_rounded,
  SnackBarAction? action,
}) {
  final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
  messenger
    ..hideCurrentSnackBar()
    ..showSnackBar(
      SnackBar(
        duration: const Duration(milliseconds: 2400),
        action: action,
        content: Row(
          children: <Widget>[
            Icon(icon, size: 18, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                  height: 1.4,
                ),
              ),
            ),
          ],
        ),
      ),
    );
}

Future<bool> showAppConfirm(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = '确认',
  String cancelLabel = '再想想',
  bool destructive = false,
}) async {
  final AppPalette palette = context.palette;
  final Color danger = const Color(0xFFFF707F);
  final bool? result = await showDialog<bool>(
    context: context,
    barrierColor: Colors.black.withOpacity(0.55),
    builder: (BuildContext dialogContext) {
      return AlertDialog(
        backgroundColor: palette.glassStrong,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
        title: Text(
          title,
          style: Theme.of(dialogContext).textTheme.titleLarge
              ?.copyWith(fontWeight: FontWeight.w700),
        ),
        content: Text(
          message,
          style: Theme.of(dialogContext).textTheme.bodyMedium
              ?.copyWith(color: palette.muted, height: 1.6),
        ),
        actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            style: TextButton.styleFrom(
              foregroundColor: palette.muted,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            ),
            child: Text(cancelLabel),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            style: FilledButton.styleFrom(
              backgroundColor: destructive
                  ? danger
                  : Theme.of(dialogContext).colorScheme.primary,
              foregroundColor: destructive ? Colors.white : null,
              minimumSize: const Size(72, 42),
              padding: const EdgeInsets.symmetric(horizontal: 20),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            child: Text(confirmLabel),
          ),
        ],
      );
    },
  );
  return result ?? false;
}
