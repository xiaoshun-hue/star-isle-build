import 'package:flutter/material.dart';

import '../theme/app_palette.dart';

Future<T?> showGlassSheet<T>(
  BuildContext context, {
  required Widget child,
  String? title,
  bool isDismissible = true,
  bool enableDrag = true,
  double maxHeightFactor = 0.90,
}) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    enableDrag: enableDrag,
    isDismissible: isDismissible,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black.withOpacity(0.56),
    builder: (BuildContext sheetContext) {
      final AppPalette palette = sheetContext.palette;
      final double keyboard = MediaQuery.viewInsetsOf(sheetContext).bottom;
      final double maxHeight =
          MediaQuery.sizeOf(sheetContext).height * maxHeightFactor - keyboard;
      return Padding(
        padding: EdgeInsets.only(bottom: keyboard),
        child: Align(
          alignment: Alignment.bottomCenter,
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: maxHeight.clamp(240.0, 900.0).toDouble(),
            ),
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: palette.glassStrong,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(30),
                ),
                border: Border(
                  top: BorderSide(color: palette.border, width: 0.8),
                  left: BorderSide(color: palette.border, width: 0.4),
                  right: BorderSide(color: palette.border, width: 0.4),
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const SizedBox(height: 10),
                  Container(
                    width: 38,
                    height: 4,
                    decoration: BoxDecoration(
                      color: palette.muted.withOpacity(0.28),
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                  if (title != null)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(22, 16, 12, 2),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              title,
                              style: Theme.of(sheetContext).textTheme.titleLarge
                                  ?.copyWith(fontWeight: FontWeight.w700),
                            ),
                          ),
                          IconButton(
                            onPressed: () => Navigator.of(sheetContext).pop(),
                            icon: const Icon(Icons.close_rounded, size: 21),
                            style: IconButton.styleFrom(
                              backgroundColor: palette.glass,
                              minimumSize: const Size(38, 38),
                              maximumSize: const Size(38, 38),
                            ),
                          ),
                        ],
                      ),
                    ),
                  Flexible(child: SafeArea(top: false, child: child)),
                ],
              ),
            ),
          ),
        ),
      );
    },
  );
}

class SheetBody extends StatelessWidget {
  const SheetBody({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.fromLTRB(22, 14, 22, 24),
    this.scroll = true,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final bool scroll;

  @override
  Widget build(BuildContext context) {
    if (!scroll) return Padding(padding: padding, child: child);
    return SingleChildScrollView(
      padding: padding,
      physics: const BouncingScrollPhysics(),
      child: child,
    );
  }
}
