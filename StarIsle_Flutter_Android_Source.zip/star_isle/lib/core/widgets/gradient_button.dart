import 'package:flutter/material.dart';

import '../theme/app_palette.dart';
import 'pressable_scale.dart';

class GradientButton extends StatelessWidget {
  const GradientButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.busy = false,
    this.expand = true,
    this.height = 56,
    this.gradient,
    this.foregroundColor,
    this.borderRadius = 20,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool busy;
  final bool expand;
  final double height;
  final Gradient? gradient;
  final Color? foregroundColor;
  final double borderRadius;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    final bool enabled = onPressed != null && !busy;
    final Color fg =
        foregroundColor ??
        (palette.isDark ? const Color(0xFF171321) : Colors.white);
    final Gradient fill =
        gradient ??
        LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Theme.of(context).colorScheme.primary,
            Theme.of(context).colorScheme.secondary,
          ],
        );

    final Widget content = AnimatedOpacity(
      opacity: enabled ? 1 : 0.55,
      duration: const Duration(milliseconds: 200),
      child: Container(
        height: height,
        width: expand ? double.infinity : null,
        padding: EdgeInsets.symmetric(horizontal: expand ? 20 : 26),
        decoration: BoxDecoration(
          gradient: fill,
          borderRadius: BorderRadius.circular(borderRadius),
          boxShadow: enabled
              ? <BoxShadow>[
                  BoxShadow(
                    color: Theme.of(context).colorScheme.primary
                        .withOpacity(palette.isDark ? 0.28 : 0.22),
                    blurRadius: 24,
                    offset: const Offset(0, 10),
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            if (busy)
              SizedBox(
                width: 19,
                height: 19,
                child: CircularProgressIndicator(
                  strokeWidth: 2.2,
                  valueColor: AlwaysStoppedAnimation<Color>(fg),
                ),
              )
            else if (icon != null)
              Icon(icon, color: fg, size: 20),
            if (icon != null || busy) const SizedBox(width: 9),
            Text(
              label,
              style: Theme.of(context).textTheme.labelLarge?.copyWith(
                color: fg,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.3,
              ),
            ),
          ],
        ),
      ),
    );

    final Widget button = PressableScale(
      onTap: enabled ? onPressed : null,
      enabled: enabled,
      scale: 0.98,
      child: content,
    );

    return expand ? SizedBox(width: double.infinity, child: button) : button;
  }
}
