import 'package:flutter/material.dart';

import '../theme/app_palette.dart';
import 'gradient_button.dart';

class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
    this.actionLabel,
    this.onAction,
    this.compact = false,
  });

  final IconData icon;
  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final AppPalette palette = context.palette;
    return Center(
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: 34,
          vertical: compact ? 24 : 44,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            SizedBox(
              width: compact ? 78 : 108,
              height: compact ? 78 : 108,
              child: Stack(
                alignment: Alignment.center,
                children: <Widget>[
                  Container(
                    width: compact ? 62 : 84,
                    height: compact ? 62 : 84,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: <Color>[
                          palette.auroraA.withOpacity(0.28),
                          palette.auroraB.withOpacity(0.22),
                        ],
                      ),
                      border: Border.all(color: palette.border),
                    ),
                    child: Icon(
                      icon,
                      size: compact ? 27 : 34,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                  Positioned(
                    top: compact ? 5 : 8,
                    right: compact ? 4 : 8,
                    child: Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: palette.auroraB.withOpacity(0.8),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: compact ? 2 : 7,
                    left: compact ? 8 : 12,
                    child: Icon(
                      Icons.auto_awesome_rounded,
                      size: compact ? 13 : 17,
                      color: palette.auroraA.withOpacity(0.8),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            Text(
              title,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleMedium
                  ?.copyWith(fontWeight: FontWeight.w700, letterSpacing: -0.2),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium
                  ?.copyWith(color: palette.muted, height: 1.65),
            ),
            if (actionLabel != null && onAction != null) ...<Widget>[
              const SizedBox(height: 22),
              SizedBox(
                width: 180,
                child: GradientButton(
                  label: actionLabel!,
                  onPressed: onAction,
                  height: 48,
                  borderRadius: 16,
                  icon: Icons.add_rounded,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
