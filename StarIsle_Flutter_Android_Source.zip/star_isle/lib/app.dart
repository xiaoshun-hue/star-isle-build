import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'core/theme/app_theme.dart';
import 'core/theme/app_theme_spec.dart';
import 'state/settings_controller.dart';
import 'ui/screens/splash/splash_screen.dart';

class StarIsleApp extends StatelessWidget {
  const StarIsleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsController>(
      builder: (BuildContext context, SettingsController settings, _) {
        final AppThemeSpec spec = settings.themeSpec;
        final ThemeData lightTheme = AppTheme.build(spec, Brightness.light);
        final ThemeData darkTheme = AppTheme.build(spec, Brightness.dark);
        return MaterialApp(
          title: '星屿',
          debugShowCheckedModeBanner: false,
          locale: const Locale('zh', 'CN'),
          supportedLocales: const <Locale>[
            Locale('zh', 'CN'),
            Locale('en', 'US'),
          ],
          localizationsDelegates: const <LocalizationsDelegate<dynamic>>[
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          theme: lightTheme,
          darkTheme: darkTheme,
          themeMode: settings.themeMode,
          themeAnimationDuration: const Duration(milliseconds: 520),
          themeAnimationCurve: Curves.easeOutCubic,
          scrollBehavior: const _StarIsleScrollBehavior(),
          builder: (BuildContext context, Widget? child) {
            final bool isDark = Theme.of(context).brightness == Brightness.dark;
            final SystemUiOverlayStyle overlay =
                (isDark
                        ? SystemUiOverlayStyle.light
                        : SystemUiOverlayStyle.dark)
                    .copyWith(
                      statusBarColor: Colors.transparent,
                      systemNavigationBarColor: Colors.transparent,
                      systemNavigationBarDividerColor: Colors.transparent,
                      systemNavigationBarContrastEnforced: false,
                    );
            return AnnotatedRegion<SystemUiOverlayStyle>(
              value: overlay,
              child: child ?? const SizedBox.shrink(),
            );
          },
          home: const SplashScreen(),
        );
      },
    );
  }
}

class _StarIsleScrollBehavior extends MaterialScrollBehavior {
  const _StarIsleScrollBehavior();

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) {
    return const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics());
  }

  @override
  Widget buildOverscrollIndicator(
    BuildContext context,
    Widget child,
    ScrollableDetails details,
  ) {
    return child;
  }
}
