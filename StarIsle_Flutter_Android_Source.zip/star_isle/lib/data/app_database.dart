import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();

  static const int schemaVersion = 1;
  static const String databaseName = 'star_isle.db';

  static Future<Database> open() async {
    final String databasesPath = await getDatabasesPath();
    final String path = p.join(databasesPath, databaseName);
    return openDatabase(
      path,
      version: schemaVersion,
      onConfigure: (Database db) async {
        await db.rawQuery('PRAGMA journal_mode = WAL');
      },
      onCreate: (Database db, int version) async {
        final Batch batch = db.batch();
        batch.execute('''
          CREATE TABLE profile (
            id INTEGER PRIMARY KEY,
            nickname TEXT NOT NULL,
            signature TEXT NOT NULL,
            avatar_seed INTEGER NOT NULL,
            mood TEXT NOT NULL,
            affection INTEGER NOT NULL,
            total_turns INTEGER NOT NULL,
            persona TEXT NOT NULL,
            tone TEXT NOT NULL,
            created_at TEXT NOT NULL,
            last_evolved_at TEXT
          )
        ''');

        batch.execute('''
          CREATE TABLE messages (
            id TEXT PRIMARY KEY,
            role TEXT NOT NULL,
            kind TEXT NOT NULL,
            content TEXT NOT NULL DEFAULT '',
            image_path TEXT,
            created_at TEXT NOT NULL,
            is_read INTEGER NOT NULL DEFAULT 0
          )
        ''');
        batch.execute(
          'CREATE INDEX idx_messages_created_at ON messages(created_at)',
        );

        batch.execute('''
          CREATE TABLE memories (
            id TEXT PRIMARY KEY,
            content TEXT NOT NULL,
            category TEXT NOT NULL,
            importance INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL,
            source_message_id TEXT
          )
        ''');
        batch.execute(
          'CREATE INDEX idx_memories_important ON memories(importance, created_at)',
        );

        batch.execute('''
          CREATE TABLE moments (
            id TEXT PRIMARY KEY,
            is_ai INTEGER NOT NULL DEFAULT 1,
            text TEXT NOT NULL,
            image_path TEXT,
            palette INTEGER NOT NULL DEFAULT 0,
            art_seed INTEGER NOT NULL DEFAULT 0,
            mood TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            user_liked INTEGER NOT NULL DEFAULT 0,
            ai_liked INTEGER NOT NULL DEFAULT 0
          )
        ''');
        batch.execute(
          'CREATE INDEX idx_moments_created_at ON moments(created_at)',
        );

        batch.execute('''
          CREATE TABLE comments (
            id TEXT PRIMARY KEY,
            moment_id TEXT NOT NULL,
            is_ai INTEGER NOT NULL DEFAULT 0,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
        batch.execute(
          'CREATE INDEX idx_comments_moment ON comments(moment_id, created_at)',
        );

        batch.execute('''
          CREATE TABLE albums (
            id TEXT PRIMARY KEY,
            path TEXT,
            title TEXT NOT NULL,
            source TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
        batch.execute(
          'CREATE INDEX idx_albums_created_at ON albums(created_at)',
        );

        batch.execute('''
          CREATE TABLE anniversaries (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            note TEXT NOT NULL DEFAULT '',
            date TEXT NOT NULL,
            category TEXT NOT NULL,
            repeat_yearly INTEGER NOT NULL DEFAULT 1,
            remind_days INTEGER NOT NULL DEFAULT 1,
            created_by_ai INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
          )
        ''');
        batch.execute(
          'CREATE INDEX idx_anniversaries_date ON anniversaries(date)',
        );

        await batch.commit(noResult: true);
      },
    );
  }
}
