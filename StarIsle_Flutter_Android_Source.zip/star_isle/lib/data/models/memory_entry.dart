class MemoryEntry {
  const MemoryEntry({
    required this.id,
    required this.content,
    required this.category,
    required this.importance,
    required this.createdAt,
    this.sourceMessageId,
  });

  final String id;
  final String content;
  final String category;
  final int importance;
  final DateTime createdAt;
  final String? sourceMessageId;

  String get categoryLabel => switch (category) {
    'preference' => '喜欢',
    'life' => '生活',
    'promise' => '约定',
    'date' => '日期',
    'emotion' => '心事',
    _ => '记忆',
  };

  Map<String, Object?> toMap() {
    return <String, Object?>{
      'id': id,
      'content': content,
      'category': category,
      'importance': importance,
      'created_at': createdAt.toIso8601String(),
      'source_message_id': sourceMessageId,
    };
  }

  factory MemoryEntry.fromMap(Map<String, Object?> map) {
    return MemoryEntry(
      id: map['id'] as String,
      content: (map['content'] as String?) ?? '',
      category: (map['category'] as String?) ?? 'memory',
      importance: (map['importance'] as int?) ?? 1,
      createdAt:
          DateTime.tryParse((map['created_at'] as String?) ?? '') ??
          DateTime.now(),
      sourceMessageId: map['source_message_id'] as String?,
    );
  }
}
