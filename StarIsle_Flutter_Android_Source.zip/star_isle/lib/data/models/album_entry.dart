class AlbumEntry {
  const AlbumEntry({
    required this.id,
    required this.path,
    required this.title,
    required this.source,
    required this.createdAt,
  });

  final String id;
  final String? path;
  final String title;
  final String source;
  final DateTime createdAt;

  String get sourceLabel => switch (source) {
    'chat' => '聊天',
    'moment' => '动态',
    _ => '珍藏',
  };

  Map<String, Object?> toMap() {
    return <String, Object?>{
      'id': id,
      'path': path,
      'title': title,
      'source': source,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory AlbumEntry.fromMap(Map<String, Object?> map) {
    return AlbumEntry(
      id: map['id'] as String,
      path: map['path'] as String?,
      title: (map['title'] as String?) ?? '星屿收藏',
      source: (map['source'] as String?) ?? 'manual',
      createdAt:
          DateTime.tryParse((map['created_at'] as String?) ?? '') ??
          DateTime.now(),
    );
  }
}
