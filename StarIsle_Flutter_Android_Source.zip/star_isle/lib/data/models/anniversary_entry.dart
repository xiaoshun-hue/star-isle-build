import '../../core/utils/app_dates.dart';

class AnniversaryEntry {
  const AnniversaryEntry({
    required this.id,
    required this.title,
    required this.date,
    required this.category,
    required this.createdAt,
    this.note = '',
    this.repeatYearly = true,
    this.remindDays = 1,
    this.createdByAi = false,
  });

  final String id;
  final String title;
  final String note;
  final DateTime date;
  final String category;
  final bool repeatYearly;
  final int remindDays;
  final bool createdByAi;
  final DateTime createdAt;

  bool get isBirthday => category == 'birthday';
  bool get isMemo => category == 'memo';

  String get categoryLabel => switch (category) {
    'birthday' => '生日',
    'memo' => '备忘',
    _ => '纪念日',
  };

  DateTime get nextDate =>
      AppDates.nextOccurrenceFor(date: date, repeatYearly: repeatYearly);

  int get daysAway => AppDates.daysUntil(nextDate);

  String get countdown => AppDates.countdownText(nextDate);

  String get dateLabel => repeatYearly
      ? '每年 ${date.month} 月 ${date.day} 日'
      : AppDates.fullDate(date);

  AnniversaryEntry copyWith({
    String? title,
    String? note,
    DateTime? date,
    String? category,
    bool? repeatYearly,
    int? remindDays,
    bool? createdByAi,
  }) {
    return AnniversaryEntry(
      id: id,
      title: title ?? this.title,
      note: note ?? this.note,
      date: date ?? this.date,
      category: category ?? this.category,
      repeatYearly: repeatYearly ?? this.repeatYearly,
      remindDays: remindDays ?? this.remindDays,
      createdByAi: createdByAi ?? this.createdByAi,
      createdAt: createdAt,
    );
  }

  Map<String, Object?> toMap() {
    return <String, Object?>{
      'id': id,
      'title': title,
      'note': note,
      'date':
          AppDates.two(date.year) +
          '-' +
          AppDates.two(date.month) +
          '-' +
          AppDates.two(date.day),
      'category': category,
      'repeat_yearly': repeatYearly ? 1 : 0,
      'remind_days': remindDays,
      'created_by_ai': createdByAi ? 1 : 0,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory AnniversaryEntry.fromMap(Map<String, Object?> map) {
    return AnniversaryEntry(
      id: map['id'] as String,
      title: (map['title'] as String?) ?? '重要的日子',
      note: (map['note'] as String?) ?? '',
      date: DateTime.tryParse((map['date'] as String?) ?? '') ?? DateTime.now(),
      category: (map['category'] as String?) ?? 'anniversary',
      repeatYearly: ((map['repeat_yearly'] as int?) ?? 1) == 1,
      remindDays: (map['remind_days'] as int?) ?? 1,
      createdByAi: ((map['created_by_ai'] as int?) ?? 0) == 1,
      createdAt:
          DateTime.tryParse((map['created_at'] as String?) ?? '') ??
          DateTime.now(),
    );
  }
}
