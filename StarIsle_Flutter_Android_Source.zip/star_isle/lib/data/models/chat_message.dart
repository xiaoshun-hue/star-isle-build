enum MessageRole { user, ai, system }

enum MessageKind { text, image, sticker }

class ChatMessage {
  const ChatMessage({
    required this.id,
    required this.role,
    required this.kind,
    required this.content,
    required this.createdAt,
    this.imagePath,
    this.isRead = false,
  });

  final String id;
  final MessageRole role;
  final MessageKind kind;
  final String content;
  final DateTime createdAt;
  final String? imagePath;
  final bool isRead;

  bool get isUser => role == MessageRole.user;
  bool get isAi => role == MessageRole.ai;
  bool get isSystem => role == MessageRole.system;

  ChatMessage copyWith({
    String? id,
    MessageRole? role,
    MessageKind? kind,
    String? content,
    DateTime? createdAt,
    String? imagePath,
    bool? isRead,
  }) {
    return ChatMessage(
      id: id ?? this.id,
      role: role ?? this.role,
      kind: kind ?? this.kind,
      content: content ?? this.content,
      createdAt: createdAt ?? this.createdAt,
      imagePath: imagePath ?? this.imagePath,
      isRead: isRead ?? this.isRead,
    );
  }

  Map<String, Object?> toMap() {
    return <String, Object?>{
      'id': id,
      'role': role.name,
      'kind': kind.name,
      'content': content,
      'image_path': imagePath,
      'created_at': createdAt.toIso8601String(),
      'is_read': isRead ? 1 : 0,
    };
  }

  factory ChatMessage.fromMap(Map<String, Object?> map) {
    return ChatMessage(
      id: map['id'] as String,
      role: switch (map['role']) {
        'user' => MessageRole.user,
        'system' => MessageRole.system,
        _ => MessageRole.ai,
      },
      kind: switch (map['kind']) {
        'image' => MessageKind.image,
        'sticker' => MessageKind.sticker,
        _ => MessageKind.text,
      },
      content: (map['content'] as String?) ?? '',
      imagePath: map['image_path'] as String?,
      createdAt:
          DateTime.tryParse((map['created_at'] as String?) ?? '') ??
          DateTime.now(),
      isRead: ((map['is_read'] as int?) ?? 0) == 1,
    );
  }
}
