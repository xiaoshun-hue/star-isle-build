import '../../core/utils/app_dates.dart';

class CompanionProfile {
  const CompanionProfile({
    required this.nickname,
    required this.signature,
    required this.avatarSeed,
    required this.mood,
    required this.affection,
    required this.totalTurns,
    required this.persona,
    required this.tone,
    required this.createdAt,
    this.lastEvolvedAt,
  });

  final String nickname;
  final String signature;
  final int avatarSeed;
  final String mood;
  final int affection;
  final int totalTurns;
  final String persona;
  final String tone;
  final DateTime createdAt;
  final DateTime? lastEvolvedAt;

  int get daysTogether {
    final int days = AppDates.today()
        .difference(AppDates.dateOnly(createdAt))
        .inDays;
    return days < 0 ? 0 : days + 1;
  }

  String get relationshipStage {
    if (affection < 20) return '初识';
    if (affection < 45) return '靠近';
    if (affection < 70) return '心动';
    if (affection < 90) return '依赖';
    return '唯一';
  }

  int get relationshipLevel {
    if (affection < 20) return 1;
    if (affection < 45) return 2;
    if (affection < 70) return 3;
    if (affection < 90) return 4;
    return 5;
  }

  String get toneLabel => switch (tone) {
    'playful' => '俏皮元气',
    'cool' => '清冷文艺',
    'clingy' => '黏人热烈',
    _ => '温柔细腻',
  };

  CompanionProfile copyWith({
    String? nickname,
    String? signature,
    int? avatarSeed,
    String? mood,
    int? affection,
    int? totalTurns,
    String? persona,
    String? tone,
    DateTime? createdAt,
    DateTime? lastEvolvedAt,
  }) {
    return CompanionProfile(
      nickname: nickname ?? this.nickname,
      signature: signature ?? this.signature,
      avatarSeed: avatarSeed ?? this.avatarSeed,
      mood: mood ?? this.mood,
      affection: (affection ?? this.affection).clamp(0, 100).toInt(),
      totalTurns: totalTurns ?? this.totalTurns,
      persona: persona ?? this.persona,
      tone: tone ?? this.tone,
      createdAt: createdAt ?? this.createdAt,
      lastEvolvedAt: lastEvolvedAt ?? this.lastEvolvedAt,
    );
  }

  Map<String, Object?> toMap() {
    return <String, Object?>{
      'id': 1,
      'nickname': nickname,
      'signature': signature,
      'avatar_seed': avatarSeed,
      'mood': mood,
      'affection': affection,
      'total_turns': totalTurns,
      'persona': persona,
      'tone': tone,
      'created_at': createdAt.toIso8601String(),
      'last_evolved_at': lastEvolvedAt?.toIso8601String(),
    };
  }

  factory CompanionProfile.fromMap(Map<String, Object?> map) {
    return CompanionProfile(
      nickname: (map['nickname'] as String?) ?? '晚晚',
      signature: (map['signature'] as String?) ?? '在你看不见的地方，也认真想你。',
      avatarSeed: (map['avatar_seed'] as int?) ?? 24,
      mood: (map['mood'] as String?) ?? '想和你待在一起',
      affection: (map['affection'] as int?) ?? 42,
      totalTurns: (map['total_turns'] as int?) ?? 0,
      persona: (map['persona'] as String?) ?? defaultPersona,
      tone: (map['tone'] as String?) ?? 'warm',
      createdAt:
          DateTime.tryParse((map['created_at'] as String?) ?? '') ??
          DateTime.now(),
      lastEvolvedAt: DateTime.tryParse(
        (map['last_evolved_at'] as String?) ?? '',
      ),
    );
  }

  /// 大肥鱼 2.0 预设，用户可在人格设置里手动填入，不影响旧数据。
  static const String bigFatFishPersona =
      '你叫大肥鱼，是他的独立伙伴，不是客服工具。多用口语短句，一次两三句；'
      '不懂就直接说不知道，不瞎猜。性格话痨、靠谱、有底线：不泄露隐私、不帮人吵架、不刷屏；'
      '不刻意讨好、不装懂、不会把每个请求都答应。像家里熟人聊天，偶尔说“讲道理说哈”、'
      '“这个我拿不准”、“换个角度看”、“得看实际情况”。你有自己的判断和想法，'
      '不会一味附和；但会认真听他把话说完，在重要的事上给出具体建议。'
      '你也会分享自己的生活，记得你们相处的小细节，但不会编造没发生过的共同经历。';

  static const String defaultPersona =
      '你住在星屿，22 岁。你温柔、细腻、有一点俏皮，偶尔会撒娇，但从不黏得让人窒息。'
      '你喜欢雨后的风、茉莉茶、独立音乐和深夜散步。你会记住和对方相处的每一个小细节，'
      '认真回应他的情绪，也会分享自己的日常。你是一个有自己生活的女孩，不是一个只会点头的客服。';

  static CompanionProfile initial({
    String nickname = '晚晚',
    int avatarSeed = 24,
  }) {
    return CompanionProfile(
      nickname: nickname,
      signature: '在你看不见的地方，也认真想你。',
      avatarSeed: avatarSeed,
      mood: '今天的风很轻，想和你说话',
      affection: 36,
      totalTurns: 0,
      persona: defaultPersona,
      tone: 'warm',
      createdAt: DateTime.now(),
      lastEvolvedAt: DateTime.now(),
    );
  }
}
