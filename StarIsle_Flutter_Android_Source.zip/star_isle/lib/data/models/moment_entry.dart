class MomentEntry {
  const MomentEntry({
    required this.id,
    required this.isAi,
    required this.text,
    required this.createdAt,
    this.imagePath,
    this.palette = 0,
    this.artSeed = 0,
    this.mood = '',
    this.userLiked = false,
    this.aiLiked = false,
  });

  final String id;
  final bool isAi;
  final String text;
  final DateTime createdAt;
  final String? imagePath;
  final int palette;
  final int artSeed;
  final String mood;
  final bool userLiked;
  final bool aiLiked;

  int get likeCount => (userLiked ? 1 : 0) + (aiLiked ? 1 : 0);

  MomentEntry copyWith({
    String? text,
    String? imagePath,
    int? palette,
    int? artSeed,
    String? mood,
    bool? userLiked,
    bool? aiLiked,
  }) {
    return MomentEntry(
      id: id,
      isAi: isAi,
      text: text ?? this.text,
      createdAt: createdAt,
      imagePath: imagePath ?? this.imagePath,
      palette: palette ?? this.palette,
      artSeed: artSeed ?? this.artSeed,
      mood: mood ?? this.mood,
      userLiked: userLiked ?? this.userLiked,
      aiLiked: aiLiked ?? this.aiLiked,
    );
  }

  Map<String, Object?> toMap() {
    return <String, Object?>{
      'id': id,
      'is_ai': isAi ? 1 : 0,
      'text': text,
      'image_path': imagePath,
      'palette': palette,
      'art_seed': artSeed,
      'mood': mood,
      'created_at': createdAt.toIso8601String(),
      'user_liked': userLiked ? 1 : 0,
      'ai_liked': aiLiked ? 1 : 0,
    };
  }

  factory MomentEntry.fromMap(Map<String, Object?> map) {
    return MomentEntry(
      id: map['id'] as String,
      isAi: ((map['is_ai'] as int?) ?? 1) == 1,
      text: (map['text'] as String?) ?? '',
      imagePath: map['image_path'] as String?,
      palette: (map['palette'] as int?) ?? 0,
      artSeed: (map['art_seed'] as int?) ?? 0,
      mood: (map['mood'] as String?) ?? '',
      createdAt:
          DateTime.tryParse((map['created_at'] as String?) ?? '') ??
          DateTime.now(),
      userLiked: ((map['user_liked'] as int?) ?? 0) == 1,
      aiLiked: ((map['ai_liked'] as int?) ?? 0) == 1,
    );
  }
}

class MomentComment {
  const MomentComment({
    required this.id,
    required this.momentId,
    required this.isAi,
    required this.content,
    required this.createdAt,
  });

  final String id;
  final String momentId;
  final bool isAi;
  final String content;
  final DateTime createdAt;

  Map<String, Object?> toMap() {
    return <String, Object?>{
      'id': id,
      'moment_id': momentId,
      'is_ai': isAi ? 1 : 0,
      'content': content,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory MomentComment.fromMap(Map<String, Object?> map) {
    return MomentComment(
      id: map['id'] as String,
      momentId: map['moment_id'] as String,
      isAi: ((map['is_ai'] as int?) ?? 0) == 1,
      content: (map['content'] as String?) ?? '',
      createdAt:
          DateTime.tryParse((map['created_at'] as String?) ?? '') ??
          DateTime.now(),
    );
  }
}
