import 'package:sqflite/sqflite.dart';

import '../data/app_database.dart';
import 'models/album_entry.dart';
import 'models/anniversary_entry.dart';
import 'models/chat_message.dart';
import 'models/companion_profile.dart';
import 'models/memory_entry.dart';
import 'models/moment_entry.dart';

class AppRepository {
  AppRepository._(this._db);

  final Database _db;

  static Future<AppRepository> create() async {
    final Database db = await AppDatabase.open();
    return AppRepository._(db);
  }

  // ---------------------------------------------------------------------------
  // 角色资料
  // ---------------------------------------------------------------------------
  Future<CompanionProfile?> getProfile() async {
    final List<Map<String, Object?>> rows = await _db.query(
      'profile',
      where: 'id = ?',
      whereArgs: <Object?>[1],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return CompanionProfile.fromMap(rows.first);
  }

  Future<void> saveProfile(CompanionProfile profile) async {
    await _db.insert(
      'profile',
      profile.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // ---------------------------------------------------------------------------
  // 私聊消息
  // ---------------------------------------------------------------------------
  Future<List<ChatMessage>> loadMessages({int limit = 400}) async {
    final List<Map<String, Object?>> rows = await _db.rawQuery(
      '''
      SELECT * FROM (
        SELECT * FROM messages
        ORDER BY created_at DESC
        LIMIT ?
      ) ORDER BY created_at ASC
      ''',
      <Object?>[limit],
    );
    return rows.map(ChatMessage.fromMap).toList();
  }

  Future<void> insertMessage(ChatMessage message) async {
    await _db.insert(
      'messages',
      message.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> deleteMessage(String id) async {
    await _db.delete('messages', where: 'id = ?', whereArgs: <Object?>[id]);
  }

  Future<void> markAiMessagesRead() async {
    await _db.update('messages', <String, Object?>{
      'is_read': 1,
    }, where: "role = 'ai' AND is_read = 0");
  }

  Future<int> unreadAiMessages() async {
    final List<Map<String, Object?>> result = await _db.rawQuery(
      "SELECT COUNT(*) AS count FROM messages WHERE role = 'ai' AND is_read = 0",
    );
    return (result.first['count'] as int?) ?? 0;
  }

  Future<int> userMessageCount() async {
    final List<Map<String, Object?>> result = await _db.rawQuery(
      "SELECT COUNT(*) AS count FROM messages WHERE role = 'user'",
    );
    return (result.first['count'] as int?) ?? 0;
  }

  Future<ChatMessage?> latestMessage() async {
    final List<Map<String, Object?>> rows = await _db.query(
      'messages',
      orderBy: 'created_at DESC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return ChatMessage.fromMap(rows.first);
  }

  // ---------------------------------------------------------------------------
  // 长期记忆
  // ---------------------------------------------------------------------------
  Future<List<MemoryEntry>> loadMemories({int limit = 120}) async {
    final List<Map<String, Object?>> rows = await _db.query(
      'memories',
      orderBy: 'importance DESC, created_at DESC',
      limit: limit,
    );
    return rows.map(MemoryEntry.fromMap).toList();
  }

  Future<void> insertMemory(MemoryEntry memory) async {
    await _db.insert(
      'memories',
      memory.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> deleteMemory(String id) async {
    await _db.delete('memories', where: 'id = ?', whereArgs: <Object?>[id]);
  }

  // ---------------------------------------------------------------------------
  // 动态与评论
  // ---------------------------------------------------------------------------
  Future<List<MomentEntry>> loadMoments({int limit = 80}) async {
    final List<Map<String, Object?>> rows = await _db.query(
      'moments',
      orderBy: 'created_at DESC',
      limit: limit,
    );
    return rows.map(MomentEntry.fromMap).toList();
  }

  Future<void> insertMoment(MomentEntry moment) async {
    await _db.insert(
      'moments',
      moment.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateMomentLike(String id, {required bool liked}) async {
    await _db.update(
      'moments',
      <String, Object?>{'user_liked': liked ? 1 : 0},
      where: 'id = ?',
      whereArgs: <Object?>[id],
    );
  }

  Future<void> updateMomentAiLike(String id, {required bool liked}) async {
    await _db.update(
      'moments',
      <String, Object?>{'ai_liked': liked ? 1 : 0},
      where: 'id = ?',
      whereArgs: <Object?>[id],
    );
  }

  Future<void> deleteMoment(String id) async {
    await _db.delete(
      'comments',
      where: 'moment_id = ?',
      whereArgs: <Object?>[id],
    );
    await _db.delete('moments', where: 'id = ?', whereArgs: <Object?>[id]);
  }

  Future<List<MomentComment>> loadAllComments() async {
    final List<Map<String, Object?>> rows = await _db.query(
      'comments',
      orderBy: 'created_at ASC',
    );
    return rows.map(MomentComment.fromMap).toList();
  }

  Future<List<MomentComment>> loadComments(String momentId) async {
    final List<Map<String, Object?>> rows = await _db.query(
      'comments',
      where: 'moment_id = ?',
      whereArgs: <Object?>[momentId],
      orderBy: 'created_at ASC',
    );
    return rows.map(MomentComment.fromMap).toList();
  }

  Future<void> insertComment(MomentComment comment) async {
    await _db.insert(
      'comments',
      comment.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<int> momentCount() async {
    final List<Map<String, Object?>> result = await _db.rawQuery(
      'SELECT COUNT(*) AS count FROM moments',
    );
    return (result.first['count'] as int?) ?? 0;
  }

  // ---------------------------------------------------------------------------
  // 相册
  // ---------------------------------------------------------------------------
  Future<List<AlbumEntry>> loadAlbum({int limit = 200}) async {
    final List<Map<String, Object?>> rows = await _db.query(
      'albums',
      orderBy: 'created_at DESC',
      limit: limit,
    );
    return rows.map(AlbumEntry.fromMap).toList();
  }

  Future<void> insertAlbum(AlbumEntry entry) async {
    await _db.insert(
      'albums',
      entry.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<bool> albumContainsPath(String path) async {
    final List<Map<String, Object?>> rows = await _db.query(
      'albums',
      columns: <String>['id'],
      where: 'path = ?',
      whereArgs: <Object?>[path],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  Future<void> deleteAlbumEntry(String id) async {
    await _db.delete('albums', where: 'id = ?', whereArgs: <Object?>[id]);
  }

  // ---------------------------------------------------------------------------
  // 纪念日与备忘
  // ---------------------------------------------------------------------------
  Future<List<AnniversaryEntry>> loadAnniversaries() async {
    final List<Map<String, Object?>> rows = await _db.query(
      'anniversaries',
      orderBy: 'date ASC',
    );
    return rows.map(AnniversaryEntry.fromMap).toList();
  }

  Future<void> insertAnniversary(AnniversaryEntry entry) async {
    await _db.insert(
      'anniversaries',
      entry.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateAnniversary(AnniversaryEntry entry) async {
    await _db.update(
      'anniversaries',
      entry.toMap(),
      where: 'id = ?',
      whereArgs: <Object?>[entry.id],
    );
  }

  Future<void> deleteAnniversary(String id) async {
    await _db.delete(
      'anniversaries',
      where: 'id = ?',
      whereArgs: <Object?>[id],
    );
  }

  Future<void> close() => _db.close();
}
