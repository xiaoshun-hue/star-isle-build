# 星屿 · 用户头像池（相册选图版）

## 数据模型

`lib/core/decoration_pack.dart` 的 `DecorationSelection` 新增：

```dart
final List<String> userAvatarPool;   // 本地图片路径，默认 const []
final bool useUserAvatarPool;        // 默认 false，保持 avatarSeed 系统头像
```

- 已经不存在单一 `userAvatarPath` 字段。
- `toJson()` 完整输出两个字段。
- `fromJson()` 对旧配置兼容：缺字段时 `userAvatarPool = []`、`useUserAvatarPool = false`。
- 旧配置里如果残留 `userAvatarPath`，会被忽略，不会自动开启。
- 最多 20 张；加载/设置时自动去重、去空白、截断到 20。
- 当前生效的池内路径单独保存在本机：
  `star_isle_active_user_avatar_v1`
  仅用于跨重启显示上次选中的那张，不写进会话数据库。

## 相册选图

复用项目现有的 `image_picker`，没有新增依赖：

```dart
MediaService.pickImagePathsFromGallery(limit: 20)
```

- 内部调用 `ImagePicker.pickMultiImage`。
- **不调用** `persistXFile`，不复制、不迁移图片文件。
- 只返回相册返回的本地路径字符串。
- 用户取消或选择失败时返回空列表，页面直接 return，不弹错误框。
- 页面会根据剩余名额限制数量，最多 20 张。

## 头像池预览

`lib/ui/pages/decoration_page.dart` 的「AVATAR · 用户头像池」区域：

- 横向滚动缩略图
- 每张缩略图右上角单张删除
- 头像池为空时隐藏缩略图，保留“已开启，但池为空，自动回退系统头像”
- 「添加头像」直接从相册多选
- 「清空」清空整个池
- 「恢复系统头像」关闭开关并清空池
- 显示 `0/20` 数量
- 显示自动回退提示

## 失效图片处理

### 路径不存在

- `DecorationStore` 用 `File(path).existsSync()` 和 `lengthSync() > 0` 校验。
- 启动时/进入装扮页时调用 `pruneInvalidUserAvatars()`。
- 移除失效路径，保留有效路径。
- 全部失效且开关开启时：
  - 自动关闭 `useUserAvatarPool`
  - 写入内存状态标记 `avatarPoolAutoDisabled`
  - 页面显示“头像池图片已全部失效，已自动切回系统头像”

### 缩略图解码失败

- `Image.file` 的 `errorBuilder` 显示破损占位图。
- 同时通过 `markUserAvatarUnavailable(path)` 运行时移除这条路径。
- 最后一张也失效时自动关闭开关。

### 头像组件

- `CompanionAvatar` 读取 `effectiveUserAvatarPath`。
- 路径有效：`Image.file`
- 路径为空/文件失效/解码失败：原 `avatarSeed` 绘制
- 头像外圈、在线状态点保留
- 聊天界面的头像框仍可叠加在用户图片外层

## 轮换策略

控制器内新增：

```dart
String? _lastUsedAvatarPath;
```

- **只存在内存**，App 重启后自动清空，不写 SharedPreferences。
- 只在角色进化时轮换。
- 头像池有效图片 >= 2 张时，排除 `_lastUsedAvatarPath` 后再随机。
- 只有 1 张时不做排除，直接使用。
- 选中后更新 `_lastUsedAvatarPath`。
- 全部失效时调用 `disableUserAvatarPoolForInvalid()`，回退系统头像。
- 头像轮换沿用 30 小时角色进化冷却。

## 控制器

实际入口是 `evolveCompanion()`（项目中没有 `CompanionController.evolveProfile`）。

新增 set 方法：

```dart
Future<void> setUserAvatarPool(List<String> paths);
Future<void> setUseUserAvatarPool(bool enabled);
Future<void> resetUserAvatarPool();
```

逻辑：

```dart
final bool poolRequested =
    decoration.useUserAvatarPool && decoration.userAvatarPool.isNotEmpty;
final List<String> avatarPool = decoration.validUserAvatarPool;

if (poolRequested && avatarPool.isEmpty) {
  await decoration.disableUserAvatarPoolForInvalid();
  _lastUsedAvatarPath = null;
}

if (poolEnabled && canRotateAvatar) {
  final List<String> candidates = avatarPool
      .where((path) => path != _lastUsedAvatarPath)
      .toList(growable: false);
  final List<String> pool = candidates.isEmpty ? avatarPool : candidates;
  final String next = pool[_random.nextInt(pool.length)];
  _lastUsedAvatarPath = next;
  await decoration.setCurrentUserAvatarPath(next);
}
```

## 默认与兼容

- 出厂：`userAvatarPool = []`，`useUserAvatarPool = false`
- 旧配置缺字段自动回落，不破坏原有装扮
- 关闭开关：立刻使用 `avatarSeed` 生成头像
- 头像池为空：自动使用 `avatarSeed`，不报错
- 进化冷却：自动进化 30 小时；头像轮换同一冷却
- 不改 `CompanionProfile`、`ChatMessage`、`AiTurnResult` 结构

## 校验清单

- [x] 装扮页存在头像池缩略图列表，支持单张删除
- [x] 添加头像调用现有相册多选工具
- [x] 只保存本地路径，不复制、不上传
- [x] 自动去重，最多 20 张
- [x] 取消/失败不报错
- [x] 失效路径自动清理，破损缩略图有占位
- [x] 全部失效自动关闭开关并回退系统头像
- [x] `_lastUsedAvatarPath` 为私有内存变量，不持久化
- [x] 池 >=2 张时避开上一张
- [x] 池 =1 张时正常使用
- [x] 头像轮换受 30 小时进化冷却控制
- [x] 头像框可叠加
- [x] 默认关闭，旧用户不受影响
