# 星屿 · 聊天交互层完成说明

本轮已把四项交互正式接入 `chat_screen.dart`，不再只是片段。

## 1. 长按菜单：复制 / 引用回复

- 新增 `ChatMessage? _quotedMessage`
- 长按文字或表情消息，菜单新增「引用回复」
- 输入框上方显示引用条，可关闭
- 发送时自动拼成：

```text
（引用回复她：今天有点累）
那我陪你坐一会儿。
```

引用内容会作为普通用户消息进入上下文，DeepSeek 和离线引擎都能看到。
不修改 `CompanionController.sendText` 签名，不新增消息字段。

## 2. 输入框草稿缓存

- SharedPreferences key：`star_isle_chat_draft_v1`
- 进入聊天页自动恢复
- 输入后 450ms 防抖保存
- 发送成功清空
- 退出/销毁页面再保存一次
- 杀进程重进也能恢复

## 3. 消息列表分页

- 默认只渲染最近 **80 条**
- 滑到顶部附近自动再加载 60 条
- 加载时保持当前阅读位置，不会跳回底部
- 原始 `ListView.builder` 不变，仍按需构建
- 消息少于 80 条时行为与之前完全一致

## 4. 多图选择框架

已实现：

- `MediaService.pickImagesFromGallery({limit: 9})`
- 长按聊天输入框左侧图片按钮，进入多图选择
- 输入框上方显示待发送缩略图
- 支持逐张删除、清空
- 单图点按发送的原有行为不变

**发送端尚未接入**：`ChatMessage` 仍是单图字段，所以当前多图只保留在待发送预览里，不会伪造数据结构。等后续在控制器增加批量发送接口后，可直接把 `_pendingImages` 接过去。

## 改动文件

- `lib/ui/screens/chat/chat_screen.dart`
  - 引用条、引用菜单、草稿读写、分页、多图预览
- `lib/ui/screens/chat/widgets/chat_composer.dart`
  - 可选 `onPickImages`，图片按钮支持长按
- `lib/services/media_service.dart`
  - 新增多图选择方法
- `lib/ui/screens/chat/widgets/chat_bubble.dart`
  - 已支持装扮渲染（上一轮）
- `lib/ui/screens/profile/profile_screen.dart`
  - 已增加「装扮与气泡」入口（上一轮）

## 默认行为

- 不选择装扮：原版气泡、头像、颜色
- 不引用：输入框没有引用条
- 消息少于 80 条：分页逻辑不生效
- 不常按图片按钮：单图发送逻辑不变

## 校验

- 69 个 Dart 文件语法检查：0 错误
- 项目合并静态分析：0 error / 0 warning
- 未修改公开模型、枚举、`AiTurnResult`、`ChatMessage` 结构
